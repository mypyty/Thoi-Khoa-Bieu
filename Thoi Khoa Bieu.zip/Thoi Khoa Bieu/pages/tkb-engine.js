/* ==============================
   TKB ENGINE – XẾP THEO TIẾT CHUẨN
   - sotiet: số tiết/tuần
   - gioihan: giới hạn số tiết/1 buổi (nếu =2 thì có thể xếp đôi hoặc xếp lẻ)
   Hỗ trợ:
   - OFF
   - {mon, fixed:true} cho tiết cố định
============================== */

function taoTKBTrong(){
  let tkb = {};
  DAYS.forEach(d=>{
    tkb[d] = { sang: Array(SANG).fill(""), chieu: Array(CHIEU).fill("") };
  });
  return tkb;
}

function _cellMon(v){
  if(v === "OFF" || v === "" || v == null) return "";
  if(typeof v === "string") return v;
  if(typeof v === "object" && v.mon) return v.mon;
  return "";
}
function _isFixed(v){ return (v && typeof v === "object" && v.fixed); }
function _isEmpty(v){ return v === ""; }

// ===== (PATCH) Randomization helpers to diversify auto-schedule results =====
function _shuffle(arr){
  const a = Array.isArray(arr) ? arr.slice() : [];
  for(let i=a.length-1;i>0;i--){
    const j = Math.floor(Math.random()*(i+1));
    const t = a[i]; a[i]=a[j]; a[j]=t;
  }
  return a;
}
function _pickOrderDays(){ return _shuffle((typeof DAYS!=='undefined' && Array.isArray(DAYS)) ? DAYS : []); }
function _pickOrderSessions(){ return _shuffle(["sang","chieu"]); }
function _pickOrderIdx(n){
  const a = [];
  for(let i=0;i<n;i++) a.push(i);
  return _shuffle(a);
}

function _countMonBuoi(tkb, thu, buoi, mon){
  let c=0;
  tkb[thu][buoi].forEach(x=>{
    if(_cellMon(x) === mon) c++;
  });
  return c;
}

function _canPlaceBlock(tkb, thu, buoi, i, mon, len, gioihan){
  const arr = tkb[thu][buoi];

  // đủ chỗ
  if(i + len > arr.length) return false;

  // các ô phải rỗng
  for(let k=0;k<len;k++){
    if(!_isEmpty(arr[i+k])) return false;
  }

  // giới hạn theo buổi (nếu không có thì coi như 99)
  const lim = Number(gioihan || 99);
  const used = _countMonBuoi(tkb, thu, buoi, mon);
  if(used + len > lim) return false;

  return true;
}

function _placeBlock(tkb, mon, len, gioihan){
  const dayOrder = _pickOrderDays();
  const sessOrder = _pickOrderSessions();
  for(const buoi of sessOrder){
    for(const thu of dayOrder){
      const arr = tkb[thu][buoi];
      const idxOrder = _pickOrderIdx(arr.length - len + 1);
      for(const i of idxOrder){
        if(!_canPlaceBlock(tkb, thu, buoi, i, mon, len, gioihan)) continue;
        for(let k=0;k<len;k++) arr[i+k] = mon;
        return true;
      }
    }
  }
  return false;
}

/* ===== API DUY NHẤT UI ĐƯỢC GỌI ===== */
function taoTKBTheoConfig(mons, config){
  const tkb = taoTKBTrong();

  // 1) Tiết cố định
  (config.fixed || []).forEach(f=>{
    tkb[f.thu][f.buoi][f.tiet] = { mon: f.ten, fixed: true };
  });

  // 2) Tiết nghỉ
  (config.off || []).forEach(o=>{
    tkb[o.thu][o.buoi][o.tiet] = "OFF";
  });

  // 3) Tạo danh sách tiết đơn theo tiết chuẩn; môn giới hạn 2 vẫn có thể tự ghép đôi về sau.
  const blocks = [];
  (mons || []).forEach(m=>{
    const ten = (m.ten || "").toString().trim();
    if(!ten) return;
    let n = Number(m.sotiet || 0);
    if(!n || n < 0) n = 0;

    let lim = Number(m.gioihan || 1);
    if(!lim || lim < 1) lim = 1;

    while(n > 0){
      blocks.push({ten, len:1, lim, rand:Math.random()});
      n -= 1;
    }
  });

  // sort: ưu tiên môn còn nhiều tiết, nhưng vẫn đảo nhẹ để tránh dồn cứng.
  const freq = {};
  blocks.forEach(b=>{ freq[b.ten] = (freq[b.ten]||0) + b.len; });
  blocks.sort((a,b)=>{
    const fa = freq[a.ten]||0, fb = freq[b.ten]||0;
    if(fb !== fa) return fb - fa;
    if(b.len !== a.len) return b.len - a.len;
    if((a.rand || 0) !== (b.rand || 0)) return (a.rand || 0) - (b.rand || 0);
    return a.ten.localeCompare(b.ten,'vi');
  });

  // 4) Rải theo block
  blocks.forEach(b=>{
    _placeBlock(tkb, b.ten, b.len, b.lim);
  });

  return tkb;
}


/* ===== API: BỔ SUNG / GIỮ BẢN CŨ (KHÔNG XÓA HẾT) =====
   - Giữ nguyên các ô đã có (trừ khi bị OFF / cố định đè lên)
   - Chỉ rải phần tiết còn thiếu theo sotiet/tuần, tôn trọng gioihan/buổi
   - Rải nhanh các tiết còn thiếu, chỉ giữ giới hạn số tiết/1 buổi.
*/
// Bổ sung TKB theo Tiết chuẩn + ràng buộc (optional) ở cấp ô.
// extraCanPlaceCell(thu, buoi, tietIdx, mon) => true/false
// extraScoreBlock(tkb, thu, buoi, startIdx, mon, len) => number (điểm càng cao càng ưu tiên)
function taoTKBBoSungTheoConfig(existingTkb, mons, config, extraCanPlaceCell, extraScoreBlock){
  const tkb = existingTkb ? JSON.parse(JSON.stringify(existingTkb)) : taoTKBTrong();

  (config.fixed || []).forEach(f=>{
    tkb[f.thu][f.buoi][f.tiet] = { mon: f.ten, fixed: true };
  });

  (config.off || []).forEach(o=>{
    tkb[o.thu][o.buoi][o.tiet] = "OFF";
  });

  function countMonWeek(mon){
    let c=0;
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        tkb[thu][buoi].forEach(x=>{ if(_cellMon(x)===mon) c++; });
      }
    }
    return c;
  }

  function canPlaceBlockKeepOneCluster(thu, buoi, i, mon, len, gioihan){
    if(!_canPlaceBlock(tkb, thu, buoi, i, mon, len, gioihan)) return false;
    return true;
  }

  const blocks=[];
  (mons||[]).forEach(m=>{
    const ten=(m.ten||"").toString().trim();
    if(!ten) return;
    let total = Number(m.sotiet||0);
    if(!total || total<0) total=0;
    let lim = Number(m.gioihan||1); if(!lim||lim<1) lim=1;

    const used = countMonWeek(ten);
    let need = Math.max(0, total - used);

    while(need>0){
      blocks.push({ten,len:1,lim,rand:Math.random()});
      need-=1;
    }
  });

  const freq={};
  blocks.forEach(b=>{ freq[b.ten]=(freq[b.ten]||0)+b.len; });
  blocks.sort((a,b)=>{
    const fa=freq[a.ten]||0, fb=freq[b.ten]||0;
    if(fb!==fa) return fb-fa;
    if(b.len!==a.len) return b.len-a.len;
    if((a.rand || 0) !== (b.rand || 0)) return (a.rand || 0) - (b.rand || 0);
    return a.ten.localeCompare(b.ten,'vi');
  });

  for(const b of blocks){
    // Tìm vị trí tốt nhất (điểm cao nhất) thay vì đặt vào ô đầu tiên
    let best = null; // {thu,buoi,i,score}
    let bestScore = -Infinity;

    const buoiOrder = _pickOrderSessions();
    const thuOrder  = _pickOrderDays();
    for(const buoi of buoiOrder){
      for(const thu of thuOrder){
        const arr = tkb[thu][buoi];
        const idxOrder = _pickOrderIdx(arr.length - b.len + 1);
        for(const i of idxOrder){
          if(!canPlaceBlockKeepOneCluster(thu,buoi,i,b.ten,b.len,b.lim)) continue;

          // kiểm tra ràng buộc ngoài (GV/Phòng...) theo từng tiết trong block
          if(typeof extraCanPlaceCell === "function"){
            let ok = true;
            for(let k=0;k<b.len;k++){
              if(!extraCanPlaceCell(thu, buoi, i+k, b.ten)) { ok = false; break; }
            }
            if(!ok) continue;
          }

          let score = 0;
          if(typeof extraScoreBlock === "function"){
            try {
              score = Number(extraScoreBlock(tkb, thu, buoi, i, b.ten, b.len));
              if(!Number.isFinite(score)) score = 0;
            } catch(e){ score = 0; }
          }

          if(score > bestScore || (score === bestScore && Math.random() < 0.5)){
            bestScore = score;
            best = {thu, buoi, i, score};
          }
        }
      }
    }

    if(best){
      const arr = tkb[best.thu][best.buoi];
      for(let k=0;k<b.len;k++) arr[best.i+k] = b.ten;
    }
  }

  return tkb;
}
