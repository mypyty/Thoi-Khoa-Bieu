window.__PHANMON_VERSION = "updated-v6.1 (safe highlight, no crash)";
/* =======================
   PHÂN MÔN / SẮP XẾP TKB (DẠNG NGANG)
   - Lấy lớp theo KHỐI, và lấy TIẾT CHUẨN theo KHỐI từ DATA.mon (bắt buộc có khối + số tiết)
   - Drag & drop có kiểm tra "không trùng môn trong 1 buổi" (chỉ cho phép 1 cụm liên tiếp, tối đa = giới hạn/buổi)
   - Khi kéo: các ô cùng môn sẽ mờ (conflict) để cảnh báo
======================= */

/* ======================= LOAD DATA ======================= */
// Đồng bộ storage với trang chính (app.js):
// - Key chuẩn: TKB_STORE::<schoolId> (schoolId đã sanitize kiểu app.js)
// - Fallback: các key cũ
function sanitizeSchoolId(s){
  s = (s || "default").toString().trim();
  // cho phép chữ, số, gạch dưới, gạch ngang
  s = s.replace(/[^0-9a-zA-Z_\-]/g, "_");
  if(!s) s = "default";
  return s;
}

// (Legacy) phanmon.js bản cũ từng UPPERCASE nên dễ lệch key.
// Giữ lại để migrate dữ liệu nếu người dùng đã lưu theo key cũ.
function legacySanitizeSchoolId(s){
  return (s||"")
    .toString()
    .trim()
    .toUpperCase()
    .replace(/\s+/g,'_')
    .replace(/[^A-Z0-9_-]/g,'')
    .slice(0,40) || "";
}

const urlParams = new URLSearchParams(location.search);
// school: tên hiển thị (có thể có dấu) để URL dễ đọc
const rawSchoolParam = (urlParams.get("school") || "").toString().trim();
// sid: mã trường ổn định để đọc/ghi storage (ưu tiên dùng sid nếu có)
const rawSidParam = (urlParams.get("sid") || "").toString().trim();

const schoolParam = sanitizeSchoolId(rawSidParam || rawSchoolParam);
const schoolParamLegacy = legacySanitizeSchoolId(rawSidParam || rawSchoolParam || schoolParam);

const PRIMARY_STORE_KEY = schoolParam ? `TKB_STORE::${schoolParam}` : "TKB_STORE";
const LEGACY_SCHOOL_KEY = (schoolParamLegacy ? `TKB_STORE::${schoolParamLegacy}` : "");

const STORE_KEYS = [
  PRIMARY_STORE_KEY,
  ...(LEGACY_SCHOOL_KEY && LEGACY_SCHOOL_KEY !== PRIMARY_STORE_KEY ? [LEGACY_SCHOOL_KEY] : []),
  "TKB_STORE",
  "VietSchool_TKB_STORE",
  "VIETSCHOOL_STORE"
];

let STORE_KEY = PRIMARY_STORE_KEY;
let DATA = {};
for (const k of STORE_KEYS){
  try {
    const raw = localStorage.getItem(k);
    if (!raw) continue;
    const obj = JSON.parse(raw || "{}");
    if (obj && (Array.isArray(obj.lop) || Array.isArray(obj.mon) || obj.pccmMatrix || obj.tkb)) {
      STORE_KEY = k; DATA = obj; break;
    }
  } catch(e){}
}

// Nếu mở theo schoolParam mà key chuẩn chưa có dữ liệu, nhưng lại tìm thấy ở key khác
// => migrate về key chuẩn để đồng bộ với trang "Phân công"
try{
  if(schoolParam){
    const hasPrimary = !!localStorage.getItem(PRIMARY_STORE_KEY);
    if(!hasPrimary && STORE_KEY !== PRIMARY_STORE_KEY){
      localStorage.setItem(PRIMARY_STORE_KEY, JSON.stringify(DATA));
      STORE_KEY = PRIMARY_STORE_KEY;
    }
  }
}catch(e){}
if(!DATA || typeof DATA !== "object") DATA = {};
if(!DATA.tkb) DATA.tkb = {};
if(!DATA.lop) DATA.lop = [];
if(!DATA.mon) DATA.mon = [];
if(!DATA.monhoc) DATA.monhoc = [];
if(!DATA.pccmMatrix) DATA.pccmMatrix = {};
if(!DATA.pccmRoomMatrix) DATA.pccmRoomMatrix = {};
if(!DATA.pccmTietMatrix) DATA.pccmTietMatrix = {};
if(!DATA.pccmGioihanMatrix) DATA.pccmGioihanMatrix = {};
if(!DATA.tkbUserOff || typeof DATA.tkbUserOff !== "object") DATA.tkbUserOff = {};

// Many optimizer patches run in separate script blocks and access the store as
// window.DATA. A top-level `let DATA` is not automatically exposed on window, so
// keep both entry points bound to the same object to avoid saving a stale TKB
// after auto-sort/optimize and then seeing lessons reappear as unassigned on F5.
try{
  if(!Object.getOwnPropertyDescriptor(window, "DATA")?.get){
    Object.defineProperty(window, "DATA", {
      configurable: true,
      get(){ return DATA; },
      set(v){
        DATA = (v && typeof v === "object") ? v : {};
        if(!DATA.tkb) DATA.tkb = {};
        if(!DATA.lop) DATA.lop = [];
        if(!DATA.mon) DATA.mon = [];
        if(!DATA.monhoc) DATA.monhoc = [];
        if(!DATA.pccmMatrix) DATA.pccmMatrix = {};
        if(!DATA.pccmRoomMatrix) DATA.pccmRoomMatrix = {};
        if(!DATA.pccmTietMatrix) DATA.pccmTietMatrix = {};
        if(!DATA.pccmGioihanMatrix) DATA.pccmGioihanMatrix = {};
        if(!DATA.tkbUserOff || typeof DATA.tkbUserOff !== "object") DATA.tkbUserOff = {};
      }
    });
  }else{
    window.DATA = DATA;
  }
}catch(_){}


/* ===== CONFIG VIETSCHOOL (mặc định) ===== */
const SANG = 5;
const CHIEU = 5;

if(!DATA.tkbConfig){
  DATA.tkbConfig = {
    // Mặc định KHÔNG auto chèn "Chào cờ" / "SHL" nữa.
    // Người dùng có thể tự cố định bằng cách double-click vào tiết đã xếp.
    fixed: [],
    off: []
  };
}

const DAYS = ["thu2","thu3","thu4","thu5","thu6","thu7"];
const LABEL = { thu2:"Thứ 2", thu3:"Thứ 3", thu4:"Thứ 4", thu5:"Thứ 5", thu6:"Thứ 6", thu7:"Thứ 7" };

let currentLop = null;

// Chế độ xem: theo Lớp / Giáo viên / Phòng
let VIEW_MODE = "lop"; // "lop" | "gv" | "phong"
let currentGV = null;
let currentPhong = null;

let dragData = null;   // {type:"mon", mon} or {type:"cell", from, val}
let dragMon = "";      // tên môn đang kéo

// Cache tiết chuẩn theo lớp đang chọn
let CURRENT_MONS = [];         // [{ten,sotiet,gioihan}]
let CURRENT_MON_META = {};     // ten -> {sotiet, gioihan}

/* ======================= CHỌN Ô + COPY/PASTE (NGHỈ) ======================= */
let TKB_CELL_SELECTION = new Set(); // key: "thu|buoi|ti"
let TKB_CELL_ANCHOR = null;         // key
let TKB_CELL_ACTIVE = null;         // key
let TKB_DRAG_SELECTING = false;
let TKB_CLIPBOARD = { type: "", payload: null };

// Long-press menu
let __CELL_LONGPRESS_TIMER = null;
let __CELL_LONGPRESS_FIRED = false;
let __CELL_MENU = null;
let __CELL_MENU_KEY = null;

/* ======================= HELPERS ======================= */
function extractKhoiNumber(str){
  const m = (str||"").toString().match(/\d+/);
  return m ? m[0] : "";
}
function khoiKey(str){
  const n = extractKhoiNumber(str);
  return n ? ("Khối " + n) : (str||"").toString().trim();
}

function normalizeClassName(name){
  if(!name) return "";
  return name.toString().trim().toUpperCase()
      .replace(/\s+/g,'')
      .replace(/[^A-Z0-9]/g,'');
}

// Chuẩn hoá text để tránh trùng do khoảng trắng / unicode
function normText(s){
  return (s ?? "").toString().normalize('NFC').trim().replace(/\s+/g,' ');
}
function normKey(s){
  return normText(s).toLowerCase();
}

// Migration: bỏ mặc định "Chào cờ" / "SHL" (nếu dữ liệu cũ còn)
function migrateRemoveLegacyDefaultFixedEvents(){
  let changed = false;

  // 1) dọn trong config.fixed
  try{
    const cfg = DATA.tkbConfig;
    if(cfg && Array.isArray(cfg.fixed)){
      const before = cfg.fixed.length;
      cfg.fixed = cfg.fixed.filter(f=>{
        const ten = (f?.ten||"").toString().trim();
        const thu = (f?.thu||"").toString().trim();
        const buoi = (f?.buoi||"").toString().trim();
        const tiet = Number(f?.tiet);
        const isCC = (ten === "Chào cờ" && thu === "thu2" && buoi === "sang" && tiet === 0);
        const isSHL = (ten === "SHL" && thu === "thu6" && buoi === "chieu" && tiet === (CHIEU-1));
        return !(isCC || isSHL);
      });
      if(cfg.fixed.length !== before) changed = true;
    }
  }catch(_){ }

  // 2) dọn trong từng TKB lớp (nếu đã được chèn trước đây)
  try{
    const positions = [
      {thu:"thu2", buoi:"sang", ti:0, ten:"Chào cờ"},
      {thu:"thu6", buoi:"chieu", ti:(CHIEU-1), ten:"SHL"}
    ];
    for(const lopId of Object.keys(DATA.tkb||{})){
      const tkb = DATA.tkb?.[lopId];
      if(!tkb) continue;
      for(const p of positions){
        const cur = tkb?.[p.thu]?.[p.buoi]?.[p.ti];
        const mon = cellMon(cur);
        if(mon && mon.toString().trim() === p.ten){
          tkb[p.thu][p.buoi][p.ti] = "";
          changed = true;
        }
      }
    }
  }catch(_){ }

  if(changed){
    try{ saveStore(); }catch(_){ }
  }
}

function looksLikeCode(s){
  const str = (s||"").toString().trim();
  return str && str.length <= 10 && !/\s/.test(str) && /^[A-Za-z0-9_.-]+$/.test(str);
}

function resolveTeacherCode(input){
  const raw = (input||"").toString().trim();
  if(!raw) return "";
  const lower = raw.toLowerCase();

  const byCode = (DATA.giaovien||[]).find(g => (g.magv||"").toString().trim().toLowerCase() === lower);
  if(byCode && byCode.magv) return byCode.magv.toString().trim();

  const byName = (DATA.giaovien||[]).find(g=>{
    const full = `${(g.hodem||"").toString().trim()} ${(g.ten||"").toString().trim()}`.trim().toLowerCase();
    return full && full === lower;
  });
  if(byName && byName.magv) return byName.magv.toString().trim();

  return raw;
}

function findMonHoc(mon){
  const key = (mon||"").toString().trim().toLowerCase();
  if(!key) return null;
  return (DATA.monhoc||[]).find(m=>{
    const ten = (m.ten||"").toString().trim().toLowerCase();
    const ma = (m.ma||"").toString().trim().toLowerCase();
    const ma2 = (m.ma2||"").toString().trim().toLowerCase();
    const id = (m.id||"").toString().trim().toLowerCase();
    return (ten && ten===key) || (ma && ma===key) || (ma2 && ma2===key) || (id && id===key);
  }) || null;
}

function getMonShort(mon){
  const mh = findMonHoc(mon);
  if(!mh) return (mon||"").toString().trim();
  const ten = (mh.ten||"").toString().trim();
  const ma = (mh.ma||"").toString().trim();
  const ma2 = (mh.ma2||"").toString().trim();
  // ưu tiên code ngắn, fallback ten
  const candidates = [ma, ma2, ten].filter(Boolean).sort((a,b)=>a.length-b.length);
  // nếu code nhìn giống mã thì ưu tiên, còn lại dùng candidate ngắn nhất
  if(looksLikeCode(ma)) return ma;
  if(looksLikeCode(ma2)) return ma2;
  return candidates[0] || (mon||"").toString().trim();
}

function getTeacherForClassMon(lopCanon, mon){
  const cls = (lopCanon||"").toString().trim();
  const monRaw = (mon||"").toString().trim();
  if(!cls || !monRaw) return "";

  const mh = findMonHoc(monRaw);
  const tries = [];
  // dùng chính chuỗi môn hiện có
  tries.push(`${cls}|${monRaw}`);
  if(mh){
    if(mh.ma && mh.ma.toString().trim() !== monRaw) tries.push(`${cls}|${mh.ma.toString().trim()}`);
    if(mh.ten && mh.ten.toString().trim() !== monRaw) tries.push(`${cls}|${mh.ten.toString().trim()}`);
    if(mh.ma2) tries.push(`${cls}|${mh.ma2.toString().trim()}`);
    if(mh.id) tries.push(`${cls}|${mh.id.toString().trim()}`);
  }

  for(const k of tries){
    const v = DATA.pccmMatrix?.[k];
    if(v) return resolveTeacherCode(v);
  }
  return "";
}

function getRoomForClassMon(lopCanon, mon){
  const cls = (lopCanon||"").toString().trim();
  const monRaw = (mon||"").toString().trim();
  if(!cls || !monRaw) return "";

  const mh = findMonHoc(monRaw);
  const tries = [];
  tries.push(`${cls}|${monRaw}`);
  if(mh){
    if(mh.ma && mh.ma.toString().trim() !== monRaw) tries.push(`${cls}|${mh.ma.toString().trim()}`);
    if(mh.ten && mh.ten.toString().trim() !== monRaw) tries.push(`${cls}|${mh.ten.toString().trim()}`);
    if(mh.ma2) tries.push(`${cls}|${mh.ma2.toString().trim()}`);
    if(mh.id) tries.push(`${cls}|${mh.id.toString().trim()}`);
  }

  for(const k of tries){
    const v = DATA.pccmRoomMatrix?.[k];
    if(v && String(v).trim()) return String(v).trim();
  }
  return "";
}

// Lấy số tiết / giới hạn theo Lớp|Môn từ bảng phân công (ưu tiên)
function _getPccmNum(matrix, lopCanon, mon){
  const cls = (lopCanon||"").toString().trim();
  const monRaw = (mon||"").toString().trim();
  if(!cls || !monRaw) return 0;

  const mh = findMonHoc(monRaw);
  const tries = [];
  tries.push(`${cls}|${monRaw}`);
  if(mh){
    const ma = (mh.ma||"").toString().trim();
    const ten = (mh.ten||"").toString().trim();
    const ma2 = (mh.ma2||"").toString().trim();
    const id = (mh.id||"").toString().trim();
    if(ma && ma !== monRaw) tries.push(`${cls}|${ma}`);
    if(ten && ten !== monRaw) tries.push(`${cls}|${ten}`);
    if(ma2) tries.push(`${cls}|${ma2}`);
    if(id) tries.push(`${cls}|${id}`);
  }

  for(const k of tries){
    const v = matrix?.[k];
    const s = (v==null) ? "" : String(v).trim();
    if(!s) continue;
    const n = Number(s);
    if(Number.isFinite(n) && n > 0) return n;
  }
  return 0;
}

function getSoTietForClassMon(lopCanon, mon){
  return _getPccmNum(DATA.pccmTietMatrix, lopCanon, mon);
}
function getGioiHanForClassMon(lopCanon, mon){
  return _getPccmNum(DATA.pccmGioihanMatrix, lopCanon, mon);
}
function cellMon(v){
  if(v === "OFF" || v === "" || v == null) return "";
  if(typeof v === "string") return v;
  if(typeof v === "object" && v.mon) return v.mon;
  return "";
}
function isFixed(v){ return (v && typeof v === "object" && v.fixed); }

function getLopCanonById(lopId){
  const id = (lopId||"").toString();
  const lop = (DATA.lop||[]).find(l=>String(l.id) === id);
  if(!lop) return normalizeClassName(id) || id;
  return (lop.ten2 || normalizeClassName(lop.ten) || normalizeClassName(lop.id) || id).toString().trim();
}

function findTeacherConflictAtSlot(teacherCode, thu, buoi, ti, ignoreLopId){
  const gv = (teacherCode||"").toString().trim();
  if(!gv) return null;
  const tThu = String(thu||"");
  const tBuoi = String(buoi||"");
  const tTi = Number(ti);
  const tkbs = DATA.tkb || {};
  for(const lopId of Object.keys(tkbs)){
    if(ignoreLopId && String(lopId) === String(ignoreLopId)) continue;
    const tkb = tkbs[lopId];
    const cell = tkb?.[tThu]?.[tBuoi]?.[tTi];
    if(!cell || cell === "OFF" || isFixed(cell)) continue;
    const mon = cellMon(cell);
    if(!mon) continue;
    const canon = getLopCanonById(lopId);
    const gv2 = getTeacherForClassMon(canon, mon);
    if(gv2 && gv2 === gv) return { lopId, mon };
  }
  return null;
}

function findRoomConflictAtSlot(roomName, thu, buoi, ti, ignoreLopId){
  const room = (roomName||"").toString().trim();
  if(!room) return null;
  const tThu = String(thu||"");
  const tBuoi = String(buoi||"");
  const tTi = Number(ti);
  const tkbs = DATA.tkb || {};
  for(const lopId of Object.keys(tkbs)){
    if(ignoreLopId && String(lopId) === String(ignoreLopId)) continue;
    const tkb = tkbs[lopId];
    const cell = tkb?.[tThu]?.[tBuoi]?.[tTi];
    if(!cell || cell === "OFF" || isFixed(cell)) continue;
    const mon = cellMon(cell);
    if(!mon) continue;
    const canon = getLopCanonById(lopId);
    const r2 = getRoomForClassMon(canon, mon);
    if(r2 && String(r2).trim() === room) return { lopId, mon };
  }
  return null;
}

let __tkbStableSave = { payload: "", stats: null, at: 0, reason: "init" };

function __tkbSaveNum(v){
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}
function __tkbCurrentSaveStats(){
  try{
    if(typeof calcSchoolTKBStats === "function"){
      const s = calcSchoolTKBStats() || {};
      return {
        total: __tkbSaveNum(s.soTiet),
        assigned: __tkbSaveNum(s.daXepTiet),
        missing: __tkbSaveNum(s.chuaXepTiet)
      };
    }
  }catch(_){}
  return { total: 0, assigned: 0, missing: 0 };
}
function __tkbStatsWorse(a, b){
  if(!a || !b) return false;
  if(__tkbSaveNum(a.missing) > __tkbSaveNum(b.missing)) return true;
  if(__tkbSaveNum(a.assigned) < __tkbSaveNum(b.assigned)) return true;
  return false;
}
function __tkbAlgorithmRunning(){
  try{
    return !!(
      window.__TKB_AUTO_SORT_RUNNING_20260508 ||
      window.__TKB_SUPPRESS_UNSTABLE_SAVE_20260508 ||
      window.__AUTO_SORT_STOP_REQUESTED ||
      window.__OPT_PANEL_STATE?.running
    );
  }catch(_){
    return false;
  }
}
function __tkbRememberStablePayload(payload, stats, reason){
  if(!payload) return;
  __tkbStableSave = {
    payload,
    stats: stats || __tkbCurrentSaveStats(),
    at: Date.now(),
    reason: reason || "save"
  };
  try{
    window.__TKB_STABLE_SAVE_20260508 = {
      stats: __tkbStableSave.stats,
      at: __tkbStableSave.at,
      reason: __tkbStableSave.reason
    };
  }catch(_){}
}
function __tkbPayloadForSave(options){
  const opts = options || {};
  const payload = JSON.stringify(DATA);
  const currentStats = __tkbCurrentSaveStats();
  const stable = __tkbStableSave || {};
  const running = __tkbAlgorithmRunning();
  const worse = stable.payload && __tkbStatsWorse(currentStats, stable.stats);
  const guardWorse = !!(worse && (running || opts.beforeUnload || opts.guardUnstable));
  const partialRefresh = !!(opts.beforeUnload && running && __tkbSaveNum(currentStats.missing) > 0);

  if(!opts.force && stable.payload && (guardWorse || partialRefresh)){
    try{
      window.__TKB_LAST_BLOCKED_UNSTABLE_SAVE_20260508 = {
        reason: worse ? "worse-than-stable" : "partial-refresh",
        currentStats,
        stableStats: stable.stats,
        at: new Date().toISOString()
      };
    }catch(_){}
    return { payload: stable.payload, stats: stable.stats, usedStable: true };
  }

  __tkbRememberStablePayload(payload, currentStats, opts.beforeUnload ? "beforeunload-current" : "saveStore");
  return { payload, stats: currentStats, usedStable: false };
}
function saveStore(options){
  try{ if(typeof reapplyAllUserOffLocks === "function") reapplyAllUserOffLocks(); }catch(_){}
  const chosen = __tkbPayloadForSave(options);
  localStorage.setItem(STORE_KEY, chosen.payload);
  try{
    if(typeof PRIMARY_STORE_KEY !== "undefined" && PRIMARY_STORE_KEY && PRIMARY_STORE_KEY !== STORE_KEY){
      localStorage.setItem(PRIMARY_STORE_KEY, chosen.payload);
    }
  }catch(_){}
  return !chosen.usedStable;
}
try{
  __tkbRememberStablePayload(JSON.stringify(DATA), __tkbCurrentSaveStats(), "loaded");
  window.saveStore = saveStore;
  window.__tkbMarkStableSavePoint20260508 = function(reason){
    __tkbRememberStablePayload(JSON.stringify(DATA), __tkbCurrentSaveStats(), reason || "mark");
    return true;
  };
  if(!window.__TKB_SAVE_ON_RELOAD_20260508__){
    window.__TKB_SAVE_ON_RELOAD_20260508__ = true;
    window.addEventListener("beforeunload", function(){
      try{ saveStore({ beforeUnload: true }); }catch(_){}
    });
  }
}catch(_){}

function getMonMeta(mon){
  return CURRENT_MON_META[mon] || {sotiet: 0, gioihan: 1};
}



/* [MOVED -> phanmon-ops.js] Section: heuristic_optimize */

/* ======================= VIEW MODE (LỚP / GIÁO VIÊN) ======================= */
function updateViewButtonsActive(){
  const bL = document.getElementById("btnViewLop");
  const bG = document.getElementById("btnViewGV");
  const bP = document.getElementById("btnViewPhong");
  if(bL) bL.classList.toggle("primary", VIEW_MODE === "lop");
  if(bG) bG.classList.toggle("primary", VIEW_MODE === "gv");
  if(bP) bP.classList.toggle("primary", VIEW_MODE === "phong");

  const leftTitle = document.getElementById("leftTitle");
  if(leftTitle) leftTitle.innerText = (VIEW_MODE === "gv") ? "Giáo viên" : "Lớp";

  // cập nhật placeholder tiêu đề
  const t = document.getElementById("titleLop");
  if(t){
    if(VIEW_MODE === "gv" && !currentGV) t.innerText = "Chọn giáo viên để xem TKB";
    if(VIEW_MODE === "phong" && !currentLop) t.innerText = "Chọn lớp để xem TKB";
    if(VIEW_MODE === "lop" && !currentLop) t.innerText = "Chọn lớp để xem TKB";
  }
}

function getFilteredLops(){
  const khoiSel = document.getElementById("chonKhoi")?.value || "";
  const kFilter = extractKhoiNumber(khoiSel);
  return (DATA.lop||[]).filter(l=>{
    if(!kFilter) return true;
    const kNum = extractKhoiNumber(l?.khoi) || extractKhoiNumber(l?.ten2) || extractKhoiNumber(l?.ten);
    return String(kNum) === String(kFilter);
  });
}

function getTeacherNameByCode(code){
  const c = (code||"").toString().trim().toLowerCase();
  if(!c) return "";
  const g = (DATA.giaovien||[]).find(x => (x.magv||"").toString().trim().toLowerCase() === c);
  if(!g) return "";
  return `${(g.hodem||"").toString().trim()} ${(g.ten||"").toString().trim()}`.trim();
}

function getTeacherListForCurrentFilter(){
  const map = new Map(); // code -> {code,name}

  // 1) Lấy từ bảng giáo viên
  (DATA.giaovien||[]).forEach(g=>{
    const code = resolveTeacherCode(g?.magv);
    if(!code) return;
    map.set(code, {code, name: getTeacherNameByCode(code)});
  });

  // 2) Lấy thêm từ bảng phân công (lọc theo khối hiện tại)
  const lops = getFilteredLops();
  const classCanonSet = new Set(lops.map(l => getLopCanonById(l.id)));
  for(const [k,v] of Object.entries(DATA.pccmMatrix || {})){
    const cls = (k||"").split("|")[0] || "";
    if(!cls) continue;
    if(classCanonSet.size && !classCanonSet.has(cls)) continue;
    const code = resolveTeacherCode(v);
    if(!code) continue;
    if(!map.has(code)) map.set(code, {code, name: getTeacherNameByCode(code)});
  }

  // Nếu đang lọc theo khối và có dữ liệu phân công, ưu tiên chỉ hiện GV có phân công trong khối
  const khoiSel = document.getElementById("chonKhoi")?.value || "";
  const kFilter = extractKhoiNumber(khoiSel);
  let arr = Array.from(map.values()).filter(x=>x.code);
  if(kFilter){
    const has = new Set();
    for(const [k,v] of Object.entries(DATA.pccmMatrix || {})){
      const cls = (k||"").split("|")[0] || "";
      if(!cls) continue;
      if(!classCanonSet.has(cls)) continue;
      const code = resolveTeacherCode(v);
      if(code) has.add(code);
    }
    if(has.size) arr = arr.filter(t=>has.has(t.code));
  }

  arr.sort((a,b)=>a.code.localeCompare(b.code,'vi'));
  return arr;
}

function showAllGV(){
  const box = document.getElementById("listLop");
  if(!box) return;
  box.innerHTML = "";

  const teachers = getTeacherListForCurrentFilter();

  if(!teachers.length){
    currentGV = null;
    updateViewButtonsActive();

    const t = document.getElementById("titleLop");
    if(t) t.innerText = "Chưa có giáo viên (hoặc chưa phân công)";
    const tkbBox = document.getElementById("tkb");
    if(tkbBox) tkbBox.innerHTML = "";
    return;
  }

  teachers.forEach(ti=>{
    const d = document.createElement("div");
    d.className = "lop-item";
    d.dataset.id = ti.code;
    // Theo yêu cầu: danh sách giáo viên chỉ hiển thị MÃ GV
    d.innerText = ti.code;
    d.onclick = ()=>selectGV(ti.code);
    box.appendChild(d);
  });

  // tự mở GV đầu tiên
  if(!currentGV || !teachers.some(t=>t.code===currentGV)) currentGV = teachers[0].code;
  selectGV(currentGV);
}

function selectGV(code){
  clearDragVisual();
  dragData = null;
  dragMon = "";

  currentGV = (code||"").toString().trim();

  // active highlight ở danh sách
  document.querySelectorAll("#listLop .lop-item").forEach(el=>{
    el.classList.toggle("active", (el.dataset.id||"") == currentGV);
  });

  renderTKBTeacher(currentGV);
}

function renderCurrentView(){
  if(VIEW_MODE === "gv"){
    if(currentGV) renderTKBTeacher(currentGV);
    else {
      const t = document.getElementById("titleLop");
      if(t) t.innerText = "Chọn giáo viên để xem TKB";
      const tkbBox = document.getElementById("tkb");
      if(tkbBox) tkbBox.innerHTML = "";
    }
    return;
  }

  if(VIEW_MODE === "phong"){
    if(currentLop) renderTKBPhong(currentPhong || "");
    else {
      const t = document.getElementById("titleLop");
      if(t) t.innerText = "Chọn lớp để xem TKB";
      const tkbBox = document.getElementById("tkb");
      if(tkbBox) tkbBox.innerHTML = "";
    }
    return;
  }

  if(currentLop) renderTKB(currentLop);
  else {
    const t = document.getElementById("titleLop");
    if(t) t.innerText = "Chọn lớp để xem TKB";
    const tkbBox = document.getElementById("tkb");
    if(tkbBox) tkbBox.innerHTML = "";
  }
}

function setViewMode(mode){
  const m = (mode||"").toString();
  VIEW_MODE = (m === "gv") ? "gv" : (m === "phong" ? "phong" : "lop");

  // clear kéo thả khi đổi mode
  clearDragVisual();
  dragData = null;
  dragMon = "";

  // clear chọn ô / menu khi đổi mode
  try{ clearCellSelection(); }catch(_){ }
  try{ hideCellMenu(); }catch(_){ }
  try{ _cancelCellLongPress(); }catch(_){ }

  // ẩn menu xóa nếu đang mở
  if(typeof cancelDeleteMenu === "function") cancelDeleteMenu(true);

  updateViewButtonsActive();

  if(VIEW_MODE === "gv"){
    // Tắt trạng thái lớp để danh sách tiết chưa phân không còn draggable
    currentLop = null;
    currentPhong = null;
    showAllGV();
  } else if(VIEW_MODE === "phong"){
    currentGV = null;
    currentPhong = null;
    showAllLop();
  } else {
    currentGV = null;
    currentPhong = null;
    // luôn hiển thị tất cả lớp
    showAllLop();
  }

  // refresh danh sách tiết chưa phân theo khối hiện tại
  loadMonList();
}

/* ===== TKB theo Giáo viên ===== */
function buildTeacherSchedule(gvCode){
  const code = (gvCode||"").toString().trim();
  const sched = {};
  DAYS.forEach(d=>{
    sched[d] = {
      sang: Array.from({length:SANG}, ()=>[]),
      chieu: Array.from({length:CHIEU}, ()=>[])
    };
  });

  const lops = getFilteredLops();
  lops.forEach(l=>{
    const classId = l.id;
    const tkb = DATA.tkb?.[classId];
    if(!tkb) return;

    const classDisplay = (l.ten2 || l.ten || l.id);
    const classCanon = getLopCanonById(classId);

    for(const thu of DAYS){
      // sáng
      for(let ti=0; ti<SANG; ti++){
        const v = tkb?.[thu]?.sang?.[ti];
        if(!v || v === "OFF" || isFixed(v)) continue;
        const mon = cellMon(v);
        if(!mon) continue;
        const gv = getTeacherForClassMon(classCanon, mon);
        if(gv && gv === code){
          const room = getRoomForClassMon(classCanon, mon);
          sched[thu].sang[ti].push({classId, classDisplay, mon, room});
        }
      }
      // chiều
      for(let ti=0; ti<CHIEU; ti++){
        const v = tkb?.[thu]?.chieu?.[ti];
        if(!v || v === "OFF" || isFixed(v)) continue;
        const mon = cellMon(v);
        if(!mon) continue;
        const gv = getTeacherForClassMon(classCanon, mon);
        if(gv && gv === code){
          const room = getRoomForClassMon(classCanon, mon);
          sched[thu].chieu[ti].push({classId, classDisplay, mon, room});
        }
      }
    }
  });

  return sched;
}

function cellHTMLTeacher(entries, thu, buoi, ti){
  const arr = Array.isArray(entries) ? entries : [];
  const conflict = arr.length > 1;

  const lines = arr.map(e=>{
    const monShort = getMonShort(e.mon);
    const room = (e.room||"").toString().trim();
    const roomTxt = room ? ` (${room})` : "";
    return `${monShort}-${e.classDisplay}${roomTxt}`;
  });

  const htmlLines = lines.map(s=>escapeHtml(s)).join("<br>");
  const classIds = arr.map(e=>String(e.classId)).join(",");
  const one = arr.length === 1 ? arr[0] : null;
  const oneAttrs = one
    ? ` data-classid="${escapeHtml(String(one.classId))}" data-mon="${escapeHtml(String(one.mon || ""))}"`
    : "";

  return `<td class="${conflict?"tkb-gv-conflict":""}" data-classids="${escapeHtml(classIds)}" data-thu="${thu}" data-buoi="${buoi}" data-ti="${ti}"${oneAttrs} draggable="false">`+
         `<div class="tkb-gv-cell">${htmlLines}</div>`+
         `</td>`;
}

function bindTeacherCells(){
  document.querySelectorAll("#tkb td").forEach(td=>{
    bindSelectableCell(td);
    const ids = (td.dataset.classids||"").split(",").map(s=>s.trim()).filter(Boolean);
    if(!ids.length) return;
    td.style.cursor = "pointer";
    td.ondblclick = ()=>{
      if(ids.length === 1){
        setViewMode("lop");
        selectLop(ids[0]);
        return;
      }
      // nhiều lớp trong cùng tiết => báo xung đột
      const txt = (td.innerText || "").trim();
      alert("⚠ Trùng lịch (nhiều lớp cùng 1 tiết):\n" + txt);
    };
  });
}

function renderTKBTeacher(gvCode){
  const box = document.getElementById("tkb");
  if(!box) return;

  const code = (gvCode||"").toString().trim();
  const name = getTeacherNameByCode(code);
  const title = document.getElementById("titleLop");
  // Theo yêu cầu: chỉ hiển thị TÊN GV (nếu không có tên thì fallback mã)
  if(title) title.innerText = name || code;

  const sched = buildTeacherSchedule(code);

  let h = "<table class='table'><tr>";
  DAYS.forEach(d => h += `<th>${LABEL[d]}</th>`);
  h += "</tr>";

  const TOTAL = SANG + CHIEU;
  for(let row=0; row<TOTAL; row++){
    const isAfternoon = row >= SANG;
    const buoi = isAfternoon ? "chieu" : "sang";
    const ti = isAfternoon ? (row - SANG) : row;

    h += `<tr${row===SANG ? " class=\"split-row\"" : ""}>`;
    DAYS.forEach(d => {
      const entries = isAfternoon ? sched[d].chieu[ti] : sched[d].sang[ti];
      h += cellHTMLTeacher(entries, d, buoi, ti);
    });
    h += "</tr>";
  }

  h += "</table>";
  box.innerHTML = h;
  bindTeacherCells();
}


/* ===== TKB theo Phòng ===== */
function getRoomListForCurrentFilter(){
  const set = new Set();
  const lops = getFilteredLops();
  const classCanonSet = new Set(lops.map(l => getLopCanonById(l.id)));

  // Ưu tiên lấy từ bảng phân công phòng
  for(const [k,v] of Object.entries(DATA.pccmRoomMatrix || {})){
    const cls = (k||"").split("|")[0] || "";
    if(classCanonSet.size && cls && !classCanonSet.has(cls)) continue;
    const room = (v==null) ? "" : String(v).trim();
    if(room) set.add(room);
  }

  // Fallback: nếu chưa có phân công phòng, quét trong TKB hiện tại
  if(set.size === 0){
    const tkbs = DATA.tkb || {};
    for(const lopId of Object.keys(tkbs)){
      const tkb = tkbs[lopId];
      if(!tkb) continue;
      const canon = getLopCanonById(lopId);
      for(const thu of DAYS){
        for(const buoi of ["sang","chieu"]){
          const arr = tkb?.[thu]?.[buoi] || [];
          for(let ti=0; ti<arr.length; ti++){
            const v = arr[ti];
            if(!v || v === "OFF" || isFixed(v)) continue;
            const mon = cellMon(v);
            if(!mon) continue;
            const room = getRoomForClassMon(canon, mon);
            if(room) set.add(String(room).trim());
          }
        }
      }
    }
  }

  return Array.from(set).filter(Boolean).sort((a,b)=>a.localeCompare(b,'vi'));
}

function showAllPhong(){
  const box = document.getElementById("listLop");
  if(!box) return;
  box.innerHTML = "";

  const rooms = getRoomListForCurrentFilter();

  if(!rooms.length){
    currentPhong = null;
    updateViewButtonsActive();

    const t = document.getElementById("titleLop");
    if(t) t.innerText = "Chưa có phòng (hoặc chưa phân công phòng)";
    const tkbBox = document.getElementById("tkb");
    if(tkbBox) tkbBox.innerHTML = "";
    return;
  }

  rooms.forEach(room=>{
    const d = document.createElement("div");
    d.className = "lop-item";
    d.dataset.id = room;
    d.innerText = room;
    d.onclick = ()=>selectPhong(room);
    box.appendChild(d);
  });

  if(!currentPhong || !rooms.includes(currentPhong)) currentPhong = rooms[0];
  selectPhong(currentPhong);
}

function selectPhong(room){
  clearDragVisual();
  dragData = null;
  dragMon = "";

  currentPhong = (room||"").toString().trim();
  document.querySelectorAll("#listLop .lop-item").forEach(el=>{
    el.classList.toggle("active", (el.dataset.id||"") == currentPhong);
  });
  renderTKBPhong(currentPhong);
}

function buildRoomSchedule(roomName){
  const roomKey = (roomName||"").toString().trim();
  const sched = {};
  DAYS.forEach(d=>{
    sched[d] = {
      sang: Array.from({length:SANG}, ()=>[]),
      chieu: Array.from({length:CHIEU}, ()=>[])
    };
  });

  const lops = getFilteredLops();
  lops.forEach(l=>{
    const classId = l.id;
    const tkb = DATA.tkb?.[classId];
    if(!tkb) return;
    const classDisplay = (l.ten2 || l.ten || l.id);
    const classCanon = getLopCanonById(classId);

    for(const thu of DAYS){
      for(let ti=0; ti<SANG; ti++){
        const v = tkb?.[thu]?.sang?.[ti];
        if(!v || v === "OFF" || isFixed(v)) continue;
        const mon = cellMon(v);
        if(!mon) continue;
        const room = getRoomForClassMon(classCanon, mon);
        if(room && String(room).trim() === roomKey){
          const gv = getTeacherForClassMon(classCanon, mon);
          sched[thu].sang[ti].push({classId, classDisplay, mon, gv});
        }
      }
      for(let ti=0; ti<CHIEU; ti++){
        const v = tkb?.[thu]?.chieu?.[ti];
        if(!v || v === "OFF" || isFixed(v)) continue;
        const mon = cellMon(v);
        if(!mon) continue;
        const room = getRoomForClassMon(classCanon, mon);
        if(room && String(room).trim() === roomKey){
          const gv = getTeacherForClassMon(classCanon, mon);
          sched[thu].chieu[ti].push({classId, classDisplay, mon, gv});
        }
      }
    }
  });
  return sched;
}

function cellHTMLPhong(entries, thu, buoi, ti){
  const arr = Array.isArray(entries) ? entries : [];
  const conflict = arr.length > 1;

  const lines = arr.map(e=>{
    const monShort = getMonShort(e.mon);
    const gv = (e.gv||"").toString().trim();
    const gvTxt = gv ? ` (${gv})` : "";
    return `${monShort}-${e.classDisplay}${gvTxt}`;
  });
  const htmlLines = lines.map(s=>escapeHtml(s)).join("<br>");
  const classIds = arr.map(e=>String(e.classId)).join(",");
  const one = arr.length === 1 ? arr[0] : null;
  const oneAttrs = one
    ? ` data-classid="${escapeHtml(String(one.classId))}" data-mon="${escapeHtml(String(one.mon || ""))}"`
    : "";

  return `<td class="${conflict?"tkb-gv-conflict":""}" data-classids="${escapeHtml(classIds)}" data-thu="${thu}" data-buoi="${buoi}" data-ti="${ti}"${oneAttrs} draggable="false">`+
         `<div class="tkb-gv-cell">${htmlLines}</div>`+
         `</td>`;
}

function bindRoomCells(){
  document.querySelectorAll("#tkb td").forEach(td=>{
    bindSelectableCell(td);
    const ids = (td.dataset.classids||"").split(",").map(s=>s.trim()).filter(Boolean);
    if(!ids.length) return;
    td.style.cursor = "pointer";
    td.ondblclick = ()=>{
      if(ids.length === 1){
        setViewMode("lop");
        selectLop(ids[0]);
        return;
      }
      const txt = (td.innerText || "").trim();
      alert("⚠ Trùng phòng (nhiều lớp cùng 1 tiết):\n" + txt);
    };
  });
}

function renderTKBPhong(roomName){
  const box = document.getElementById("tkb");
  if(!box) return;

  const name = (roomName||"").toString().trim();
  const title = document.getElementById("titleLop");
  if(title) title.innerText = name || "";

  const sched = buildRoomSchedule(name);

  let h = "<table class='table'><tr>";
  DAYS.forEach(d => h += `<th>${LABEL[d]}</th>`);
  h += "</tr>";

  const TOTAL = SANG + CHIEU;
  for(let row=0; row<TOTAL; row++){
    const isAfternoon = row >= SANG;
    const buoi = isAfternoon ? "chieu" : "sang";
    const ti = isAfternoon ? (row - SANG) : row;

    h += `<tr${row===SANG ? " class=\"split-row\"" : ""}>`;
    DAYS.forEach(d => {
      const entries = isAfternoon ? sched[d].chieu[ti] : sched[d].sang[ti];
      h += cellHTMLPhong(entries, d, buoi, ti);
    });
    h += "</tr>";
  }
  h += "</table>";

  box.innerHTML = h;
  bindRoomCells();
}


/* ======================= INIT ======================= */
document.addEventListener("DOMContentLoaded", () => {
  // Migration dữ liệu cũ
  try{ migrateRemoveLegacyDefaultFixedEvents(); }catch(_){ }
  // Hotkeys: Ctrl/Cmd+C + Ctrl/Cmd+V (copy/paste ô NGHỈ)
  try{ installTKBHotkeysOnce(); }catch(_){ }

  initKhoiOptions();
  // Mặc định: xem theo Lớp
  setViewMode("lop");
  try{ initRightPanelCollapse(); }catch(_){ }
});

function initRightPanelCollapse(){
  const panel = document.getElementById("rightPanel");
  if(!panel) return;
  let collapsed = true;
  try{
    const saved = localStorage.getItem("tkbRightCollapsed");
    if(saved === "0") collapsed = false;
    if(saved === "1") collapsed = true;
    const savedWidth = Number(localStorage.getItem("tkbRightWidth") || 0);
    if(Number.isFinite(savedWidth) && savedWidth >= 240){
      panel.style.setProperty("--tkb-right-width", Math.max(240, Math.min(560, savedWidth)) + "px");
    }
  }catch(_){}
  panel.classList.toggle("is-collapsed", collapsed);
  updateRightPanelToggle();
  installRightPanelResize();
}

function updateRightPanelToggle(){
  const panel = document.getElementById("rightPanel");
  const btn = document.getElementById("rightPanelToggle");
  if(!panel || !btn) return;
  const collapsed = panel.classList.contains("is-collapsed");
  btn.textContent = collapsed ? "DS" : "";
  btn.title = collapsed ? "Mở bảng bên phải" : "Bấm để thu nhỏ, kéo ngang để đổi độ rộng";
}

function toggleRightPanel(force){
  const panel = document.getElementById("rightPanel");
  if(!panel) return;
  if(window.__tkbRightSuppressNextToggle && typeof force !== "boolean"){
    window.__tkbRightSuppressNextToggle = false;
    return;
  }
  const collapsed = (typeof force === "boolean") ? force : !panel.classList.contains("is-collapsed");
  panel.classList.toggle("is-collapsed", collapsed);
  try{ localStorage.setItem("tkbRightCollapsed", collapsed ? "1" : "0"); }catch(_){}
  updateRightPanelToggle();
}
window.toggleRightPanel = toggleRightPanel;

function installRightPanelResize(){
  const panel = document.getElementById("rightPanel");
  const btn = document.getElementById("rightPanelToggle");
  if(!panel || !btn || btn.__tkbResizeBound) return;
  btn.__tkbResizeBound = true;

  btn.addEventListener("pointerdown", (ev)=>{
    if(ev.button != null && ev.button !== 0) return;
    const startX = ev.clientX;
    const startWidth = panel.classList.contains("is-collapsed")
      ? 320
      : Math.max(240, panel.getBoundingClientRect().width || 320);
    let moved = false;

    const onMove = (mv)=>{
      const dx = mv.clientX - startX;
      if(!moved && Math.abs(dx) < 5) return;
      moved = true;
      panel.classList.remove("is-collapsed");
      const next = Math.max(240, Math.min(560, Math.round(startWidth - dx)));
      panel.style.setProperty("--tkb-right-width", next + "px");
      try{ localStorage.setItem("tkbRightCollapsed", "0"); }catch(_){}
      updateRightPanelToggle();
      mv.preventDefault();
    };

    const onUp = ()=>{
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerup", onUp);
      if(moved){
        const w = Math.round(panel.getBoundingClientRect().width || startWidth);
        try{ localStorage.setItem("tkbRightWidth", String(w)); }catch(_){}
        window.__tkbRightSuppressNextToggle = true;
      }
    };

    document.addEventListener("pointermove", onMove);
    document.addEventListener("pointerup", onUp);
  });
}

/* ======================= KHỐI ======================= */
function initKhoiOptions(){
  const sel = document.getElementById("chonKhoi");
  const btnBox = document.getElementById("khoiButtons");
  if(!sel) return;
  sel.innerHTML = `<option value="">Tất cả</option>`;

  // chuẩn hóa khối: luôn dùng "Khối N"
  // fallback: nếu l.khoi trống thì suy ra từ tên lớp (6A1 -> 6)
  const set = new Map();
  (DATA.lop||[]).forEach(l=>{
    const n = extractKhoiNumber(l?.khoi) || extractKhoiNumber(l?.ten2) || extractKhoiNumber(l?.ten);
    if(n) set.set("Khối "+n, "Khối "+n);
  });
  const khois = [...set.keys()].sort((a,b)=>Number(extractKhoiNumber(a))-Number(extractKhoiNumber(b)));
  khois.forEach(k=> sel.innerHTML += `<option value="${k}">${k}</option>`);

  // Render buttons (thay cho listbox)
  if(btnBox){
    const cur = sel.value || "";
    const mkBtn = (val, label) => {
      const safe = (val||"").replace(/\\/g,"\\\\").replace(/'/g,"\\'");
      const cls = (cur === (val||"")) ? "primary" : "";
      return `<button data-khoi="${val||""}" class="${cls}" onclick="chonKhoiBtn('${safe}')">${label}</button>`;
    };
    btnBox.innerHTML = [mkBtn("", "Tất cả"), ...khois.map(k=>mkBtn(k, k))].join("\n");
  }
}

function updateKhoiButtonsActive(){
  const sel = document.getElementById("chonKhoi");
  const btnBox = document.getElementById("khoiButtons");
  if(!btnBox || !sel) return;
  const cur = sel.value || "";
  btnBox.querySelectorAll("button[data-khoi]").forEach(b=>{
    if((b.getAttribute("data-khoi")||"") === cur) b.classList.add("primary");
    else b.classList.remove("primary");
  });
}

function chonKhoiBtn(khoi){
  const sel = document.getElementById("chonKhoi");
  if(!sel) return;
  sel.value = khoi || "";
  updateKhoiButtonsActive();

  // Nếu đang xem theo giáo viên thì chỉ cần reload danh sách GV + bảng TKB GV
  if(VIEW_MODE === "gv"){
    showAllGV();
    loadMonList();
    return;
  }

  // Mặc định: theo lớp
  if(sel.value) loadLopList();
  else showAllLop();
}

/* ======================= LỚP ======================= */
function showAllLop(){
  // reset khối filter
  const sel = document.getElementById("chonKhoi");
  if(sel) sel.value = "";
  updateKhoiButtonsActive();

  const box = document.getElementById("listLop");
  if(!box) return;
  box.innerHTML = "";

  const lops = (DATA.lop||[]).slice().sort((a,b)=>{
    const aa = (a.ten2||a.ten||"").toString();
    const bb = (b.ten2||b.ten||"").toString();
    return aa.localeCompare(bb,'vi');
  });

  lops.forEach(l=>{
    const d = document.createElement("div");
    d.className = "lop-item";
    d.dataset.id = l.id;
    d.innerText = l.ten2 || l.ten || l.id;
    d.onclick = ()=>selectLop(l.id);
    box.appendChild(d);
  });

  // tự mở lớp đầu tiên
  if(lops.length){
    selectLop(lops[0].id);
  }else{
    currentLop = null;
    const t = document.getElementById("titleLop");
    if(t) t.innerText = "Chưa có lớp";
    const tkbBox = document.getElementById("tkb");
    if(tkbBox) tkbBox.innerHTML = "";
    loadMonList();
  }
}

function loadLopList(){
  if(VIEW_MODE === "gv"){ showAllGV(); return; }

  const khoi = document.getElementById("chonKhoi").value; // "Khối N"
  updateKhoiButtonsActive();
  const box = document.getElementById("listLop");
  if(!box) return;
  box.innerHTML = "";
  if(!khoi) return;

  const kNum = extractKhoiNumber(khoi);
  const lops = (DATA.lop||[]).filter(l => (extractKhoiNumber(l?.khoi) || extractKhoiNumber(l?.ten2) || extractKhoiNumber(l?.ten)) === kNum)
    .sort((a,b)=> (a.ten2||a.ten||"").localeCompare(b.ten2||b.ten||"",'vi'));

  lops.forEach(l=>{
      const d = document.createElement("div");
      d.className = "lop-item";
      d.dataset.id = l.id;
      d.innerText = l.ten2 || l.ten || l.id;
      d.onclick = ()=>selectLop(l.id);
      box.appendChild(d);
    });

  // tự mở lớp đầu tiên trong khối
  if(lops.length) selectLop(lops[0].id);
  else {
    currentLop = null;
    const t = document.getElementById("titleLop");
    if(t) t.innerText = "Chưa có lớp";
    const tkbBox = document.getElementById("tkb");
    if(tkbBox) tkbBox.innerHTML = "";
    loadMonList();
  }
}

/* ======================= TIẾT CHUẨN THEO KHỐI ======================= */
function _monDisplayName(monKey){
  const raw = (monKey||"").toString().trim();
  if(!raw) return "";
  const mh = findMonHoc(raw);
  const ten = (mh && mh.ten) ? String(mh.ten).trim() : "";
  return ten || raw;
}

function _collectPCCMSubjectKeysForClass(lopCanon){
  const cls = (lopCanon||"").toString().trim();
  const out = new Set();
  if(!cls) return out;
  const prefix = `${cls}|`;

  const add = (mat)=>{
    if(!mat || typeof mat !== "object") return;
    for(const k of Object.keys(mat)){
      if(!k.startsWith(prefix)) continue;
      const monKey = k.slice(prefix.length);
      if(monKey) out.add(monKey);
    }
  };

  // GV / Tiết / Giới hạn / Phòng: hễ có trong phân công là coi như "có môn"
  add(DATA.pccmMatrix);
  add(DATA.pccmTietMatrix);
  add(DATA.pccmGioihanMatrix);
  add(DATA.pccmRoomMatrix);
  return out;
}

// Fallback: tìm Tiết chuẩn theo khối cho 1 môn (match theo tên/mã nếu có monhoc)
function _findTietChuanRow(khoiNum, monNameOrKey){
  const k = String(khoiNum||"");
  const raw = (monNameOrKey||"").toString().trim();
  if(!k || !raw) return null;

  const mh = findMonHoc(raw);
  const tries = [];
  tries.push(raw);
  if(mh){
    if(mh.ten) tries.push(String(mh.ten).trim());
    if(mh.ma) tries.push(String(mh.ma).trim());
    if(mh.ma2) tries.push(String(mh.ma2).trim());
    if(mh.id) tries.push(String(mh.id).trim());
  }

  const norm = (s)=> (s||"").toString().trim().toLowerCase();
  const tset = new Set(tries.filter(Boolean).map(norm));

  return (DATA.mon||[]).find(r=>{
    const rk = String(extractKhoiNumber(r?.khoi) || "");
    if(rk !== k) return false;
    const rt = norm(r?.ten);
    return rt && tset.has(rt);
  }) || null;
}

// PURE: không mutate CURRENT_*
// - Ưu tiên: lấy môn + số tiết + giới hạn từ bảng PHÂN CÔNG của lớp
// - Fallback: Tiết chuẩn theo khối (DATA.mon)
function computeMonsForClass(khoiNum, lopCanon=null){
  const k = String(khoiNum||"");
  const cls = (lopCanon||"").toString().trim();

  const map = new Map(); // normTen -> {ten, sotiet, gioihan}

  // 1) Base: tiết chuẩn theo khối (nếu có)
  (DATA.mon||[])
    .filter(m => String(extractKhoiNumber(m?.khoi) || "") === k)
    .forEach(m=>{
      const ten = (m.ten||"").toString().trim();
      const sotiet = Number(m.sotiet||0);
      const gioihan = Number(m.gioihan||1);
      if(!ten) return;
      const key = normKey(ten);
      if(!map.has(key)){
        map.set(key, {
          ten,
          sotiet: Number.isFinite(sotiet) ? sotiet : 0,
          gioihan: Number.isFinite(gioihan) ? gioihan : 1
        });
      }
    });

  // 2) Merge/override: môn từ phân công của lớp
  if(cls){
    const subKeys = _collectPCCMSubjectKeysForClass(cls);

    subKeys.forEach(monKey=>{
      const ten = _monDisplayName(monKey);
      if(!ten) return;
      const key = normKey(ten);
      if(!map.has(key)) map.set(key, {ten, sotiet: 0, gioihan: 1});
      const entry = map.get(key);

      // lấy số tiết / giới hạn ưu tiên từ bảng phân công
      const t = getSoTietForClassMon(cls, ten) || getSoTietForClassMon(cls, monKey);
      const g = getGioiHanForClassMon(cls, ten) || getGioiHanForClassMon(cls, monKey);

      if(t > 0) entry.sotiet = t;
      if(g > 0) entry.gioihan = g;

      // fallback nếu chưa có số tiết trong phân công
      if(!(entry.sotiet > 0) && k){
        const tc = _findTietChuanRow(k, ten) || _findTietChuanRow(k, monKey);
        const tt = Number(tc?.sotiet || 0);
        const gg = Number(tc?.gioihan || 0);
        if(tt > 0) entry.sotiet = tt;
        if(gg > 0) entry.gioihan = gg;
      }
    });

    // 3) Override lần cuối cho các môn base: nếu phân công có giá trị thì lấy theo phân công
    map.forEach(entry=>{
      const ten = entry.ten;
      const t = getSoTietForClassMon(cls, ten);
      const g = getGioiHanForClassMon(cls, ten);
      if(t > 0) entry.sotiet = t;
      if(g > 0) entry.gioihan = g;
    });
  }

  let mons = [...map.values()]
    .map(m=>({
      ten: (m.ten||"").toString().trim(),
      sotiet: Number(m.sotiet||0),
      gioihan: Math.max(1, Number(m.gioihan||1))
    }))
    .filter(m => m.ten && Number.isFinite(m.sotiet) && m.sotiet > 0)
    .sort((a,b)=>a.ten.localeCompare(b.ten,'vi'));

  // Theo yêu cầu: Chỉ hiện/xếp các môn đã được PHÂN CÔNG GIÁO VIÊN.
  // (Không có phân công => không đưa vào danh sách môn để tạo TKB)
  if(cls){
    mons = mons.filter(m=>{
      const gv = getTeacherForClassMon(cls, m.ten);
      return !!(gv && String(gv).trim());
    });
  }

  return mons;
}

function buildMonsForKhoi(khoiNum, lopCanon=null){
  const mons = computeMonsForClass(khoiNum, lopCanon);

  // cache meta (chỉ cho lớp đang chọn)
  CURRENT_MONS = mons;
  CURRENT_MON_META = {};
  mons.forEach(m => CURRENT_MON_META[m.ten] = {sotiet: m.sotiet, gioihan: m.gioihan || 1});
  return mons;
}

/* ======================= SELECT LỚP ======================= */
function selectLop(id){
  clearDragVisual();
  dragData = null;
  dragMon = "";
  currentLop = id;

  // reset chọn ô khi đổi lớp
  try{ clearCellSelection(); }catch(_){ }

  // active highlight ở danh sách lớp
  document.querySelectorAll("#listLop .lop-item").forEach(el=>{
    el.classList.toggle("active", (el.dataset.id||"") == id);
  });

  const lop = (DATA.lop||[]).find(x=>x.id==id);
  if(!lop) return;

  const lopKhoiNum = extractKhoiNumber(lop.khoi);
  const lopCanon = getLopCanonById(id);
  const mons = buildMonsForKhoi(lopKhoiNum, lopCanon);

  if(!DATA.tkb[id]){
    // Mặc định: KHÔNG tự động xếp vào TKB, chỉ tạo khung trống + cố định (nếu có)
    DATA.tkb[id] = taoTKBTheoConfig([], DATA.tkbConfig);
    saveStore();
  }

  renderTKB(id);
  loadMonList();
}



/* [MOVED -> phanmon-ops.js] Section: auto_sort_all */

/* ======================= RENDER TKB ======================= */
function renderTKB(id){
  const box = document.getElementById("tkb");
  if(!box) return;

  const tkb = DATA.tkb[id];
  const lop = (DATA.lop||[]).find(x=>x.id==id);
  const lopCanon = getLopCanonById(id);
  const __t = document.getElementById("titleLop");
  if (__t) __t.innerText = "TKB lớp " + (lop?.ten2||lop?.ten||id);

  let h = "<table class='table'><tr>";
  DAYS.forEach(d => h += `<th>${LABEL[d]}</th>`);
  h += "</tr>";

  // 10 ô / ngày (5 ô đầu: sáng tiết 1-5, 5 ô sau: chiều tiết 1-5)
  const TOTAL = SANG + CHIEU;
  for(let row=0; row<TOTAL; row++){
    const isAfternoon = row >= SANG;
    const buoi = isAfternoon ? "chieu" : "sang";
    const ti = isAfternoon ? (row - SANG) : row;

    h += `<tr${row===SANG ? " class=\"split-row\"" : ""}>`;
    DAYS.forEach(d => {
      const v = isAfternoon ? tkb[d].chieu[ti] : tkb[d].sang[ti];
      h += cellHTML(v, d, buoi, ti, lopCanon);
    });
    h += "</tr>";
  }

  h += "</table>";
  box.innerHTML = h;

  bindCells();
}

/* ======================= CELL ======================= */
function cellHTML(v, thu, buoi, ti, lopCanon){
  const off = (v === "OFF");
  const fixed = isFixed(v);
  const mon = off ? "" : (fixed ? (v.mon||"") : (cellMon(v)||""));
  // Hiển thị: Mã môn - Mã GV (để dễ nhìn, tránh dùng tên dài)
  let text = "";
  if(!off){
    const monShort = getMonShort(mon);
    const gv = getTeacherForClassMon(lopCanon, mon);
    text = gv ? `${monShort}-${gv}` : monShort;
  }

  // note: data-mon để highlight conflict
  return `<td class="${off?'tkb-off':''} ${fixed?'tkb-fixed':''}"
    data-thu="${thu}" data-buoi="${buoi}" data-ti="${ti}" data-mon="${escapeHtml(mon)}"
    draggable="${off?'false':'true'}">${escapeHtml(text)}</td>`;
}

function escapeHtml(str){
  return (str ?? "").toString()
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#39;");
}

/* ======================= CELL SELECT + MENU (NGHỈ) ======================= */
function cellKey(thu, buoi, ti, scope="", classId=""){
  if(scope || classId) return `${scope||""}|${classId||""}|${thu}|${buoi}|${ti}`;
  return `${thu}|${buoi}|${ti}`;
}
function parseCellKey(key){
  const parts = (key||"").split("|");
  if(parts.length >= 5){
    const [scope, classId, thu, buoi, ti] = parts;
    return {scope, classId, thu, buoi, ti: Number(ti)};
  }
  const [thu, buoi, ti] = parts;
  return {scope:"", classId:"", thu, buoi, ti: Number(ti)};
}
function cellScopeForTd(td){
  const table = td?.closest?.("table");
  if(table?.classList?.contains("tkb-main-table")) return "main";
  if(table?.classList?.contains("tkb-support-table")) return "support";
  return "single";
}
function cellClassIdForTd(td){
  const direct = (td?.dataset?.classid || "").toString().trim();
  if(direct) return direct;
  const ids = (td?.dataset?.classids || "").split(",").map(s=>s.trim()).filter(Boolean);
  if(ids.length === 1) return ids[0];
  const scope = cellScopeForTd(td);
  if(scope === "support") return "";
  if(VIEW_MODE === "lop" || VIEW_MODE === "phong") return (currentLop || "").toString();
  return "";
}
function cellKeyForTd(td){
  return cellKey(
    td?.dataset?.thu,
    td?.dataset?.buoi,
    td?.dataset?.ti,
    cellScopeForTd(td),
    cellClassIdForTd(td)
  );
}
function findTdByCellKey(key){
  let found = null;
  document.querySelectorAll("#tkb td[data-thu][data-buoi][data-ti]").forEach(td=>{
    if(!found && cellKeyForTd(td) === key) found = td;
  });
  return found;
}
function tdToPos(td){
  const thu = td?.dataset?.thu;
  const buoi = td?.dataset?.buoi;
  const ti = Number(td?.dataset?.ti);
  const col = DAYS.indexOf(thu);
  const row = (buoi === "chieu") ? (SANG + ti) : ti;
  return {thu, buoi, ti, row, col};
}
function posToKey(pos){
  return cellKey(pos.thu, pos.buoi, pos.ti, pos.scope || "", pos.classId || "");
}
function clearCellSelection(){
  TKB_CELL_SELECTION.clear();
  TKB_CELL_ANCHOR = null;
  TKB_CELL_ACTIVE = null;
  applyCellSelectionStyles();
}
function applyCellSelectionStyles(){
  document.querySelectorAll("#tkb td").forEach(td=>{
    if(!td.dataset.thu || !td.dataset.buoi || td.dataset.ti == null){
      td.classList.remove("tkb-selected");
      return;
    }
    const k = cellKeyForTd(td);
    td.classList.toggle("tkb-selected", TKB_CELL_SELECTION.has(k));
  });
}
function selectSingleCell(td){
  const pos = tdToPos(td);
  pos.scope = cellScopeForTd(td);
  pos.classId = cellClassIdForTd(td);
  const key = posToKey(pos);
  TKB_CELL_SELECTION = new Set([key]);
  TKB_CELL_ANCHOR = key;
  TKB_CELL_ACTIVE = key;
  applyCellSelectionStyles();
}
function toggleCellInSelection(td){
  const pos = tdToPos(td);
  pos.scope = cellScopeForTd(td);
  pos.classId = cellClassIdForTd(td);
  const key = posToKey(pos);
  if(TKB_CELL_SELECTION.has(key)) TKB_CELL_SELECTION.delete(key);
  else TKB_CELL_SELECTION.add(key);
  if(!TKB_CELL_ANCHOR) TKB_CELL_ANCHOR = key;
  TKB_CELL_ACTIVE = key;
  applyCellSelectionStyles();
}
function selectRange(anchorKey, toTd){
  if(!anchorKey) return selectSingleCell(toTd);
  const anchorTd = findTdByCellKey(anchorKey);
  if(!anchorTd) return selectSingleCell(toTd);
  const p1 = tdToPos(anchorTd);
  const p2 = tdToPos(toTd);
  const scope = cellScopeForTd(anchorTd);
  const table = anchorTd.closest("table");
  if(table && table !== toTd.closest("table")){
    return selectSingleCell(toTd);
  }

  const r1 = Math.min(p1.row, p2.row);
  const r2 = Math.max(p1.row, p2.row);
  const c1 = Math.min(p1.col, p2.col);
  const c2 = Math.max(p1.col, p2.col);

  const set = new Set();
  (table || document).querySelectorAll("td[data-thu][data-buoi][data-ti]").forEach(td=>{
    if(cellScopeForTd(td) !== scope) return;
    const p = tdToPos(td);
    if(p.row >= r1 && p.row <= r2 && p.col >= c1 && p.col <= c2){
      p.scope = cellScopeForTd(td);
      p.classId = cellClassIdForTd(td);
      set.add(posToKey(p));
    }
  });
  TKB_CELL_SELECTION = set;
  const activePos = tdToPos(toTd);
  activePos.scope = cellScopeForTd(toTd);
  activePos.classId = cellClassIdForTd(toTd);
  TKB_CELL_ACTIVE = posToKey(activePos);
  applyCellSelectionStyles();
}

function ensureCellMenu(){
  if(__CELL_MENU) return __CELL_MENU;
  const d = document.createElement("div");
  d.id = "tkbCellMenu";
  d.style.position = "fixed";
  d.style.zIndex = "10000";
  d.style.background = "#fff";
  d.style.border = "1px solid #c9d4ea";
  d.style.borderRadius = "10px";
  d.style.boxShadow = "0 10px 30px rgba(0,0,0,.2)";
  d.style.padding = "8px";
  d.style.display = "none";
  d.innerHTML = `
    <div style="font-size:12px;color:#555;margin-bottom:6px">Chọn thao tác</div>
    <select id="tkbCellMenuSelect" style="min-width:160px">
      <option value="">-- Chọn --</option>
      <option value="OFF">Nghỉ</option>
      <option value="CLEAR">Bỏ nghỉ</option>
    </select>
  `;
  document.body.appendChild(d);

  const sel = d.querySelector("#tkbCellMenuSelect");
  sel.onchange = ()=>{
    const v = (sel.value||"").toString();
    const key = __CELL_MENU_KEY;
    hideCellMenu();
    if(!key) return;
    if(v === "OFF") setOffByKey(key, true);
    else if(v === "CLEAR") setOffByKey(key, false);
  };

  // click outside -> close
  document.addEventListener("mousedown", (ev)=>{
    if(d.style.display === "none") return;
    if(d.contains(ev.target)) return;
    hideCellMenu();
  }, true);

  __CELL_MENU = d;
  return d;
}

function showCellMenuForTd(td, clientX, clientY){
  const key = cellKeyForTd(td);
  __CELL_MENU_KEY = key;
  const d = ensureCellMenu();
  const sel = d.querySelector("#tkbCellMenuSelect");
  if(sel) sel.value = "";

  // vị trí (tránh tràn màn hình)
  const pad = 8;
  const w = 200;
  const h = 78;
  let left = Math.min(window.innerWidth - w - pad, Math.max(pad, clientX));
  let top = Math.min(window.innerHeight - h - pad, Math.max(pad, clientY));
  d.style.left = `${left}px`;
  d.style.top = `${top}px`;
  d.style.display = "block";
}

function hideCellMenu(){
  if(__CELL_MENU){
    __CELL_MENU.style.display = "none";
  }
  __CELL_MENU_KEY = null;
}

function _cancelCellLongPress(){
  if(__CELL_LONGPRESS_TIMER){
    clearTimeout(__CELL_LONGPRESS_TIMER);
    __CELL_LONGPRESS_TIMER = null;
  }
}

function _startCellLongPress(td, clientX, clientY){
  _cancelCellLongPress();
  __CELL_LONGPRESS_FIRED = false;
  __CELL_LONGPRESS_TIMER = setTimeout(()=>{
    __CELL_LONGPRESS_FIRED = true;
    showCellMenuForTd(td, clientX, clientY);
  }, 500);
}

function setOffByKey(key, isOff, opts){
  return setOffByKeys([key], isOff, opts);
}

function userOffLockKey(thu, buoi, ti){
  return `${thu}|${buoi}|${Number(ti)}`;
}

function parseUserOffLockKey(key){
  const [thu, buoi, ti] = String(key || "").split("|");
  return {thu, buoi, ti: Number(ti)};
}

function normalizeUserOffList(classId){
  const id = String(classId || "");
  if(!id) return [];
  const raw = DATA.tkbUserOff?.[id];
  const values = Array.isArray(raw)
    ? raw
    : (raw && typeof raw === "object" ? Object.keys(raw).filter(k => raw[k]) : []);
  const set = new Set();
  for(const item of values){
    let thu, buoi, ti;
    if(typeof item === "string"){
      ({thu, buoi, ti} = parseUserOffLockKey(item));
    }else if(item && typeof item === "object"){
      thu = item.thu;
      buoi = item.buoi;
      ti = Number(item.ti);
    }
    if(!DAYS.includes(thu)) continue;
    if(buoi !== "sang" && buoi !== "chieu") continue;
    const max = buoi === "sang" ? SANG : CHIEU;
    if(!Number.isFinite(ti) || ti < 0 || ti >= max) continue;
    set.add(userOffLockKey(thu, buoi, ti));
  }
  const out = Array.from(set);
  DATA.tkbUserOff[id] = out;
  return out;
}

function addUserOffLock(classId, thu, buoi, ti){
  const id = String(classId || "");
  if(!id) return;
  const list = normalizeUserOffList(id);
  const key = userOffLockKey(thu, buoi, ti);
  if(!list.includes(key)) list.push(key);
  DATA.tkbUserOff[id] = list;
}

function removeUserOffLock(classId, thu, buoi, ti){
  const id = String(classId || "");
  if(!id) return;
  const key = userOffLockKey(thu, buoi, ti);
  DATA.tkbUserOff[id] = normalizeUserOffList(id).filter(x => x !== key);
}

function getUserOffPositionsForClass(classId){
  return normalizeUserOffList(classId).map(parseUserOffLockKey);
}

function syncUserOffLocksFromTkb(classId){
  const id = String(classId || "");
  const tkb = DATA.tkb?.[id];
  if(!id || !tkb) return;
  for(const thu of DAYS){
    for(const buoi of ["sang","chieu"]){
      const arr = tkb?.[thu]?.[buoi] || [];
      for(let ti=0; ti<arr.length; ti++){
        if(arr[ti] === "OFF") addUserOffLock(id, thu, buoi, ti);
      }
    }
  }
}

function syncAllUserOffLocksFromTkb(){
  for(const id of Object.keys(DATA.tkb || {})) syncUserOffLocksFromTkb(id);
}

function collectOffPositionsForClass(classId){
  syncUserOffLocksFromTkb(classId);
  const tkb = DATA.tkb?.[classId];
  const map = new Map();
  for(const o of getUserOffPositionsForClass(classId)){
    map.set(userOffLockKey(o.thu, o.buoi, o.ti), o);
  }
  if(tkb){
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const arr = tkb?.[thu]?.[buoi] || [];
        for(let ti=0; ti<arr.length; ti++){
          if(arr[ti] === "OFF"){
            const key = userOffLockKey(thu, buoi, ti);
            map.set(key, {thu, buoi, ti});
          }
        }
      }
    }
  }
  return Array.from(map.values());
}

function applyOffPositionsToTkb(tkb, positions){
  for(const o of (positions || [])){
    if(tkb?.[o.thu]?.[o.buoi] && Number.isFinite(Number(o.ti))){
      tkb[o.thu][o.buoi][Number(o.ti)] = "OFF";
    }
  }
  return tkb;
}

function makeEmptyTKBPreservingOff(classId, cfg){
  const offPositions = collectOffPositionsForClass(classId);
  return applyOffPositionsToTkb(taoTKBTheoConfig([], cfg), offPositions);
}

function reapplyAllUserOffLocks(){
  for(const id of Object.keys(DATA.tkb || {})){
    const tkb = DATA.tkb?.[id];
    if(tkb) applyOffPositionsToTkb(tkb, getUserOffPositionsForClass(id));
  }
}

try{
  syncAllUserOffLocksFromTkb();
  window.__tkbCollectOffPositionsForClass = collectOffPositionsForClass;
  window.__tkbApplyOffPositionsToTkb = applyOffPositionsToTkb;
  window.__tkbMakeEmptyTKBPreservingOff = makeEmptyTKBPreservingOff;
  window.__tkbReapplyAllUserOffLocks = reapplyAllUserOffLocks;
}catch(_){}

function setOffByKeys(keys, isOff, opts){
  const options = opts || {};
  let changed = false;

  for(const key of (keys||[])){
    const {classId, thu, buoi, ti} = parseCellKey(key);
    const targetLop = (classId || currentLop || "").toString();
    if(!targetLop) continue;
    const tkb = DATA.tkb?.[targetLop];
    if(!tkb) continue;
    if(!thu || !buoi || !Number.isFinite(ti)) continue;
    if(!tkb?.[thu]?.[buoi]) continue;

    const cur = tkb[thu][buoi][ti];
    if(isOff){
      // nếu đang cố định thì hỏi bỏ cố định (trừ khi batch đã xác nhận)
      if(isFixed(cur) && !options.skipConfirm){
        const ok = confirm("Tiết này đang CỐ ĐỊNH. Bỏ cố định và đặt NGHỈ?");
        if(!ok) return;
      }
      addUserOffLock(targetLop, thu, buoi, ti);
      if(cur !== "OFF"){
        tkb[thu][buoi][ti] = "OFF";
        changed = true;
      }
    } else {
      removeUserOffLock(targetLop, thu, buoi, ti);
      if(cur === "OFF"){
        tkb[thu][buoi][ti] = "";
        changed = true;
      }
    }
  }

  if(!changed) return;
  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }
  applyCellSelectionStyles();
}

function toggleFixedByKey(key){
  const {classId, thu, buoi, ti} = parseCellKey(key);
  const targetLop = (classId || currentLop || "").toString();
  if(!targetLop) return;
  if(!thu || !buoi || !Number.isFinite(ti)) return;
  const tkb = DATA.tkb?.[targetLop];
  if(!tkb || !tkb?.[thu]?.[buoi]) return;
  const cur = tkb[thu][buoi][ti];
  if(cur === "OFF") return;
  const mon = cellMon(cur);
  if(!mon) return;

  if(isFixed(cur)) tkb[thu][buoi][ti] = mon;
  else tkb[thu][buoi][ti] = {mon, fixed: true};

  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }
  applyCellSelectionStyles();
}

function getCellValueByKeyForCurrentLop(key){
  const {classId, thu, buoi, ti} = parseCellKey(key);
  const targetLop = (classId || currentLop || "").toString();
  if(!targetLop) return null;
  const tkb = DATA.tkb?.[targetLop];
  if(!tkb) return null;
  if(!thu || !buoi || !Number.isFinite(ti)) return null;
  if(!tkb?.[thu]?.[buoi]) return null;
  return tkb[thu][buoi][ti];
}

function cellPosFromKey(key){
  const p = parseCellKey(key);
  const col = DAYS.indexOf(p.thu);
  const row = (p.buoi === "chieu") ? (SANG + Number(p.ti)) : Number(p.ti);
  return {...p, row, col};
}

function keyFromCellPos(base, row, col){
  if(!Number.isFinite(row) || !Number.isFinite(col)) return "";
  if(row < 0 || row >= (SANG + CHIEU)) return "";
  if(col < 0 || col >= DAYS.length) return "";
  const thu = DAYS[col];
  const buoi = row >= SANG ? "chieu" : "sang";
  const ti = row >= SANG ? (row - SANG) : row;
  return cellKey(thu, buoi, ti, base.scope || "", base.classId || "");
}

function selectedKeysForClipboard(){
  return TKB_CELL_SELECTION.size ? [...TKB_CELL_SELECTION] : (TKB_CELL_ACTIVE ? [TKB_CELL_ACTIVE] : []);
}

function topLeftKeyFromKeys(keys){
  let best = "";
  let bestPos = null;
  for(const key of (keys || [])){
    const p = cellPosFromKey(key);
    if(!Number.isFinite(p.row) || !Number.isFinite(p.col)) continue;
    if(!bestPos || p.row < bestPos.row || (p.row === bestPos.row && p.col < bestPos.col)){
      best = key;
      bestPos = p;
    }
  }
  return best;
}

function buildOffPatternFromKeys(keys){
  const parsed = (keys || [])
    .map(key => ({key, pos: cellPosFromKey(key), value: getCellValueByKeyForCurrentLop(key)}))
    .filter(x => Number.isFinite(x.pos.row) && Number.isFinite(x.pos.col));
  if(!parsed.length) return null;

  const minRow = Math.min(...parsed.map(x => x.pos.row));
  const maxRow = Math.max(...parsed.map(x => x.pos.row));
  const minCol = Math.min(...parsed.map(x => x.pos.col));
  const maxCol = Math.max(...parsed.map(x => x.pos.col));
  const offsets = parsed
    .filter(x => x.value === "OFF")
    .map(x => ({dr: x.pos.row - minRow, dc: x.pos.col - minCol}));

  return {
    type: "OFF_PATTERN",
    height: maxRow - minRow + 1,
    width: maxCol - minCol + 1,
    offsets
  };
}

function keysFromOffPatternAt(pattern, anchorKey){
  const base = cellPosFromKey(anchorKey);
  if(!Number.isFinite(base.row) || !Number.isFinite(base.col)) return [];
  return (pattern?.offsets || [])
    .map(o => keyFromCellPos(base, base.row + Number(o.dr || 0), base.col + Number(o.dc || 0)))
    .filter(Boolean);
}

function tkbHandleCopy(){
  const keys = selectedKeysForClipboard();
  if(!keys.length) return;

  const pattern = buildOffPatternFromKeys(keys);
  if(pattern && pattern.offsets.length){
    TKB_CLIPBOARD = {type: "OFF_PATTERN", payload: pattern};
    try{ _setStatus(`Đã copy mẫu NGHỈ: ${pattern.offsets.length} ô`, "info"); }catch(_){ }
  } else {
    try{ _setStatus("Vùng chọn không có ô NGHỈ", "info"); }catch(_){ }
  }
}

function tkbHandlePaste(){
  if(TKB_CLIPBOARD?.type !== "OFF" && TKB_CLIPBOARD?.type !== "OFF_PATTERN") return;

  let keys = selectedKeysForClipboard();
  if(!keys.length) return;

  if(TKB_CLIPBOARD?.type === "OFF_PATTERN"){
    const pattern = TKB_CLIPBOARD.payload;
    const singleOffPattern = Number(pattern?.width || 0) === 1
      && Number(pattern?.height || 0) === 1
      && (pattern?.offsets || []).length === 1;

    if(!(singleOffPattern && keys.length > 1)){
      const anchorKey = TKB_CELL_ACTIVE || topLeftKeyFromKeys(keys);
      keys = keysFromOffPatternAt(pattern, anchorKey);
    }
  }

  if(!keys.length) return;

  // confirm 1 lần nếu dán vào các ô đang cố định
  let fixedCount = 0;
  for(const k of keys){
    const v = getCellValueByKeyForCurrentLop(k);
    if(isFixed(v)) fixedCount++;
  }
  let skipConfirm = false;
  if(fixedCount > 0){
    const ok = confirm(`Có ${fixedCount} tiết đang CỐ ĐỊNH. Bỏ cố định và dán NGHỈ?`);
    if(!ok) return;
    skipConfirm = true;
  }
  setOffByKeys(keys, true, {skipConfirm});
}

function deleteSelectedCells(){
  const keys = selectedKeysForClipboard();
  if(!keys.length) return;
  let changed = false;

  for(const key of keys){
    const {classId, thu, buoi, ti} = parseCellKey(key);
    const targetLop = (classId || currentLop || "").toString();
    if(!targetLop || !thu || !buoi || !Number.isFinite(ti)) continue;
    const tkb = DATA.tkb?.[targetLop];
    if(!tkb?.[thu]?.[buoi]) continue;
    const cur = tkb[thu][buoi][ti];
    if(cur === "" || cur == null) continue;

    if(cur === "OFF") removeUserOffLock(targetLop, thu, buoi, ti);
    tkb[thu][buoi][ti] = "";
    changed = true;
  }

  if(!changed) return;
  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }
  applyCellSelectionStyles();
}

function tkbHandleSetSelectedOff(){
  const keys = TKB_CELL_SELECTION.size ? [...TKB_CELL_SELECTION] : (TKB_CELL_ACTIVE ? [TKB_CELL_ACTIVE] : []);
  if(!keys.length) return;
  let fixedCount = 0;
  for(const k of keys){
    const v = getCellValueByKeyForCurrentLop(k);
    if(isFixed(v)) fixedCount++;
  }
  let skipConfirm = false;
  if(fixedCount > 0){
    const ok = confirm(`Có ${fixedCount} tiết đang CỐ ĐỊNH. Bỏ cố định và đặt NGHỈ?`);
    if(!ok) return;
    skipConfirm = true;
  }
  setOffByKeys(keys, true, {skipConfirm});
}

function installTKBHotkeysOnce(){
  if(window.__TKB_HOTKEYS_INSTALLED) return;
  window.__TKB_HOTKEYS_INSTALLED = true;
  document.addEventListener("keydown", (e)=>{
    if(!e) return;
    // Không bắt phím khi đang focus input/select
    const tag = (document.activeElement?.tagName||"").toUpperCase();
    if(tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return;

    // ESC: đóng menu
    if(e.key === "Escape"){
      hideCellMenu();
      return;
    }

    const k = (e.key||"").toLowerCase();
    if(k === "x" && !e.ctrlKey && !e.metaKey && !e.altKey){
      e.preventDefault();
      tkbHandleSetSelectedOff();
      return;
    }
    if(k === "delete" || k === "backspace"){
      e.preventDefault();
      deleteSelectedCells();
      return;
    }

    const isMod = (e.ctrlKey || e.metaKey);
    if(!isMod) return;
    if(k === "c"){
      e.preventDefault();
      tkbHandleCopy();
    } else if(k === "v"){
      e.preventDefault();
      tkbHandlePaste();
    }
  }, true);
}

function bindSelectableCell(td){
  if(!td || td.__tkbSelectableBound) return;
  if(!td.dataset || !td.dataset.thu || !td.dataset.buoi || td.dataset.ti == null) return;
  td.__tkbSelectableBound = true;

  td.addEventListener("click", (e)=>{
    if(td.__tkbCtrlFixedJustNow){
      td.__tkbCtrlFixedJustNow = false;
      try{ e.preventDefault(); e.stopImmediatePropagation(); }catch(_){}
    }
  }, true);

  td.addEventListener("mousedown", (e)=>{
    if(!e || e.button !== 0) return;

    try{ hideCellMenu(); }catch(_){ }
    try{
      const tag = (document.activeElement?.tagName || "").toUpperCase();
      if(tag === "SELECT" || tag === "INPUT" || tag === "TEXTAREA") document.activeElement.blur();
    }catch(_){ }

    const key = cellKeyForTd(td);
    const hasMon = !!(td.dataset.mon||"").trim();
    const isOff = td.classList.contains("tkb-off");

    if((e.ctrlKey || e.metaKey) && hasMon && !isOff){
      try{ e.preventDefault(); e.stopPropagation(); }catch(_){ }
      td.__tkbCtrlFixedJustNow = true;
      selectSingleCell(td);
      toggleFixedByKey(key);
      return;
    }

    // bắt đầu long-press (hiện listbox "Nghỉ")
    _startCellLongPress(td, e.clientX, e.clientY);

    if(e.shiftKey){
      if(!TKB_CELL_ANCHOR) TKB_CELL_ANCHOR = key;
      selectRange(TKB_CELL_ANCHOR, td);
    } else if(e.ctrlKey || e.metaKey){
      toggleCellInSelection(td);
    } else {
      selectSingleCell(td);
    }

    // drag-select chỉ khi ô rỗng/NGHỈ (để không đụng Drag môn học)
    TKB_DRAG_SELECTING = (!hasMon || isOff);
  });

  td.addEventListener("mouseenter", ()=>{
    if(!TKB_DRAG_SELECTING) return;
    try{ _cancelCellLongPress(); }catch(_){ }
    if(TKB_CELL_ANCHOR) selectRange(TKB_CELL_ANCHOR, td);
  });

  td.addEventListener("mouseup", ()=>{
    TKB_DRAG_SELECTING = false;
    _cancelCellLongPress();
  });
}

/* ======================= DRAG DROP ======================= */
function bindCells(){
  document.querySelectorAll("#tkb td").forEach(td=>{
    bindSelectableCell(td);
    td.ondragstart = (e)=>{
      // nếu user đang long-press thì huỷ để tránh menu bật khi drag
      try{ _cancelCellLongPress(); hideCellMenu(); }catch(_){ }
      let unfixedFromFixed = false;
      // OFF không được kéo
      if(td.classList.contains("tkb-off")) { e.preventDefault(); return; }

      // Nếu là tiết cố định: hỏi có bỏ cố định để kéo không?
      if(td.classList.contains("tkb-fixed")){
        const ok = confirm("Tiết này đang CỐ ĐỊNH. Bạn muốn BỎ cố định để kéo không?");
        if(!ok){ e.preventDefault(); return; }

        // Bỏ cố định trong dữ liệu (không render lại ngay để tránh giật khi đang drag)
        try{
          if(currentLop){
            const t = td.dataset;
            const tkb = DATA.tkb?.[currentLop];
            if(tkb && tkb?.[t.thu]?.[t.buoi]){
              const ti = Number(t.ti);
              const mon = (td.dataset.mon||"").trim();
              if(mon){
                tkb[t.thu][t.buoi][ti] = mon;
                td.classList.remove("tkb-fixed");
                unfixedFromFixed = true;
              }
            }
          }
        }catch(_){ /* ignore */ }
      }

      // KHÔNG lấy textContent vì text hiển thị có thể là "MÃMÔN-MÃGV".
      const val = (td.dataset.mon||"").trim();
      if(!val) { e.preventDefault(); return; }
      dragData = { type:"cell", from: td, val, _unfixedFromFixed: unfixedFromFixed };
      dragMon = val;
      applyDragVisual(dragMon, td);
    };

    td.ondragend = ()=>{
      clearDragVisual();
      // Nếu vừa bỏ cố định ở dragstart mà user thả (không drop), render lại để UI đồng bộ.
      if(dragData && dragData.type === "cell" && dragData._unfixedFromFixed){
        try{ saveStore(); }catch(_){ }
        try{ renderCurrentView(); loadMonList(); }catch(_){ }
      }
      dragData = null;
      dragMon = "";
    };

    td.ondragover = (e)=>{
      if(!dragData) return;
      e.preventDefault();
      const res = validateDrop(td, dragMon);
      setDropHint(td, res.ok && !res.warn);
    };

    td.ondragenter = ()=>{
      if(!dragData) return;
      td.classList.add("drag-over");
    };
    td.ondragleave = ()=>{
      td.classList.remove("drag-over", "drop-valid", "drop-invalid");
    };

    td.ondrop = (e)=>{
      if(!dragData) return;
      try{ if(e) e.preventDefault(); }catch(_){ }
      const res = validateDrop(td, dragMon);

      // Không hợp lệ => chặn luôn
      if(!res.ok){
        flashInvalid(td);
        showDropError(res, td);
        return;
      }

      // Có xung đột (GV/Phòng) => cho chọn thay thế
      if(res.warn && Array.isArray(res.conflicts) && res.conflicts.length){
        try{ showDropToast("⚠ " + (res.msg || "Có xung đột. Bạn có muốn thay thế không?"), td, "warn"); }catch(_){ }
        const ok = confirm(res.confirmText || buildReplaceConfirmText(res.conflicts));
        if(!ok){
          // người dùng hủy
          try{ showDropToast("Đã hủy thao tác.", td, "info"); }catch(_){ }
          flashInvalid(td);
          return;
        }
        // Thay thế: đưa các tiết trùng ở lớp kia về "Tiết chưa phân" (thực chất là xóa khỏi TKB lớp kia)
        clearConflictSlots(res.conflicts);
      }

      try{
        onDrop(td);
      }catch(err){

        console.error(err);
        flashInvalid(td);
        showDropError({ok:false, reason:"runtime", msg:(err && err.message) ? err.message : String(err)}, td);
      }
    };

    // right-click để xóa nhanh ô đang chọn
    td.oncontextmenu = (e)=>{
      if(td.classList.contains("tkb-off") || td.classList.contains("tkb-fixed")) return;
      e.preventDefault();
      const t = td.dataset;
      const ti = Number(t.ti);
      if(!currentLop) return;
      DATA.tkb[currentLop][t.thu][t.buoi][ti] = "";
      saveStore();
      renderCurrentView();
      loadMonList();
    };

    // Double-click: toggle cố định
    td.ondblclick = (e)=>{
      try{ e.preventDefault(); }catch(_){ }
      if(VIEW_MODE !== "lop") return;
      const key = cellKeyForTd(td);
      toggleFixedByKey(key);
    };

  });

  // re-apply selection highlight sau khi render lại
  applyCellSelectionStyles();
}

function flashInvalid(td){
  td.classList.add("drop-invalid");
  setTimeout(()=>td.classList.remove("drop-invalid"), 450);
}

let __DROP_TOAST_EL = null;
let __DROP_TOAST_TIMER = null;

function _ensureDropToastEl(){
  if(__DROP_TOAST_EL) return __DROP_TOAST_EL;
  const d = document.createElement("div");
  d.id = "dropToast";
  d.className = "drop-toast";
  d.style.display = "none";
  document.body.appendChild(d);
  __DROP_TOAST_EL = d;
  return d;
}

// Hiện nhắc nhở nhỏ gần ô đang thả (không chặn thao tác)
function showDropToast(msg, td, type="error"){
  const text = (msg||"").toString().trim();
  if(!text) return;
  const d = _ensureDropToastEl();
  d.classList.remove("ok","info","error");
  d.classList.add(type === "ok" ? "ok" : (type === "info" ? "info" : "error"));
  d.textContent = text;
  d.style.display = "block";

  // position (tránh tràn màn hình)
  const pad = 8;
  const r = td ? td.getBoundingClientRect() : {left: window.innerWidth/2, top: window.innerHeight/2, width: 0, height: 0};
  // đo size sau khi show
  const w = d.offsetWidth || 240;
  const h = d.offsetHeight || 48;

  let left = r.left + r.width + pad;
  let top  = r.top + pad;

  if(left + w > window.innerWidth - pad) left = r.left - w - pad;
  if(left < pad) left = pad;
  if(top + h > window.innerHeight - pad) top = window.innerHeight - h - pad;
  if(top < pad) top = pad;

  d.style.left = `${left}px`;
  d.style.top  = `${top}px`;

  if(__DROP_TOAST_TIMER) clearTimeout(__DROP_TOAST_TIMER);
  __DROP_TOAST_TIMER = setTimeout(()=>{
    if(__DROP_TOAST_EL) __DROP_TOAST_EL.style.display = "none";
  }, 1600);
}

function flashLopItemConflict(lopId){
  const id = (lopId == null) ? "" : String(lopId);
  if(!id) return;
  const els = document.querySelectorAll("#listLop .lop-item");
  els.forEach(el=>{
    if(String(el.dataset.id) === id){
      el.classList.add("flash-conflict");
      setTimeout(()=>el.classList.remove("flash-conflict"), 1400);
    }
  });
}

function showDropError(res, td){
  const reason = (res?.reason || "").toString();
  let msg = (res?.msg || "").toString().trim();

  if(!msg){
    switch(reason){
      case "no class": msg = "Chưa chọn lớp để xếp TKB."; break;
      case "empty": msg = "Chưa xác định môn học để thả."; break;
      case "locked": msg = "Ô này đang NGHỈ hoặc CỐ ĐỊNH."; break;
      case "wrong class": msg = "Tiết này thuộc lớp khác. Hãy chọn đúng lớp trước khi kéo."; break;
      case "exceed week total": msg = "Vượt số tiết/tuần của môn này."; break;
      case "exceed session limit": msg = "Giới hạn số tiết/môn trong buổi đã tắt."; break;
      case "split block":
      case "touch left":
      case "touch right":
        msg = "Môn này không được tách rời trong cùng buổi (các tiết phải LIỀN nhau).";
        break;
      case "teacher conflict": msg = "Trùng lịch giáo viên ở tiết này."; break;
      case "room conflict": msg = "Trùng phòng ở tiết này."; break;
      case "runtime": msg = "Có lỗi khi thả. Vui lòng thử lại."; break;
      default: msg = "Không thể thả vào ô này."; break;
    }
  }

  try{ showDropToast("⚠ " + msg, td, "error"); }catch(_){ }
  try{ _setStatus("⚠ " + msg, "error"); }catch(_){ }

  if(res?.conflictLopId != null){
    try{ flashLopItemConflict(res.conflictLopId); }catch(_){ }
  }
}


function buildReplaceConfirmText(conflicts){
  // conflicts: [{type:'teacher'|'room', gv, room, lopId, mon, thu, buoi, ti, msg}]
  const lines = [];
  const seen = new Set();
  for(const c of (conflicts || [])){
    const lop = getLopCanonById(c.lopId);
    const mon = getMonShort(c.mon || "");
    const key = `${c.type}|${c.lopId}|${c.thu}|${c.buoi}|${c.ti}|${mon}`;
    if(seen.has(key)) continue;
    seen.add(key);

    if(c.type === "teacher"){
      lines.push(`- Trùng GV ${c.gv || ""}: ${mon}-${lop}`);
    } else if(c.type === "room"){
      lines.push(`- Trùng phòng ${c.room || ""}: ${mon}-${lop}`);
    } else {
      lines.push(`- Xung đột: ${mon}-${lop}`);
    }
  }

  return (
    "⚠ Phát hiện xung đột ở tiết này:\n" +
    (lines.length ? lines.join("\n") : "- (Không rõ chi tiết)") +
    "\n\nBạn có muốn THAY THẾ không?\n" +
    "(Nếu thay thế, tiết trùng ở lớp kia sẽ được đưa về \"Tiết chưa phân\".)"
  );
}

function clearConflictSlots(conflicts){
  const uniqueLops = new Set();
  for(const c of (conflicts || [])){
    const lopId = c.lopId;
    if(lopId == null) continue;
    const tkbOther = DATA?.tkb?.[lopId];
    if(!tkbOther) continue;

    const thu = c.thu, buoi = c.buoi, ti = Number(c.ti);
    if(!thu || !buoi || !Number.isFinite(ti)) continue;

    const cell = tkbOther?.[thu]?.[buoi]?.[ti];
    // Không đụng tới OFF/cố định (trường hợp hi hữu)
    if(cell === "OFF") continue;
    if(cell && typeof cell === "object" && cell.fixed) continue;

    tkbOther[thu][buoi][ti] = "";
    uniqueLops.add(String(lopId));
  }

  // Nhấp nháy các lớp bị ảnh hưởng để user dễ thấy
  try{
    uniqueLops.forEach(id=>flashLopItemConflict(id));
  }catch(_){ }
}

function onDrop(td){
  if(!dragData) return;
  if(td.classList.contains("tkb-off") || td.classList.contains("tkb-fixed")) return;

  const t = td.dataset;
  const ti = Number(t.ti);
  const tkb = DATA.tkb[currentLop];

  // clear target
  tkb[t.thu][t.buoi][ti] = "";

  if(dragData.type === "mon"){
    tkb[t.thu][t.buoi][ti] = dragData.mon;
  } else if(dragData.type === "cell" || dragData.type === "pairTeacherCell"){
    if(dragData.classId != null && String(dragData.classId) !== String(currentLop)){
      throw new Error("Tiết kéo đang thuộc lớp khác với bảng lớp hiện tại.");
    }
    const s = dragData.from?.dataset;
    if(!s) throw new Error("Thiếu dữ liệu ô nguồn để kéo thả (dragData.from)");
    tkb[s.thu][s.buoi][Number(s.ti)] = "";
    tkb[t.thu][t.buoi][ti] = dragData.val;
  } else {
    throw new Error("Dữ liệu kéo thả không hợp lệ (dragData.type)");
  }

  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }

  clearDragVisual();
  dragData = null;
  dragMon = "";
}

function setDropHint(td, ok){
  td.classList.remove("drop-valid", "drop-invalid");
  td.classList.add(ok ? "drop-valid" : "drop-invalid");
}

function applyDragVisual(mon, excludeTd){
  clearDragVisual();

  // excludeTd có thể là <td> (khi kéo trong TKB) hoặc null (khi kéo từ "Tiết chưa phân")
  const isEl = !!(excludeTd && typeof excludeTd === "object" && excludeTd.classList);

  // mờ tất cả ô cùng môn để cảnh báo trùng
  document.querySelectorAll("#tkb td").forEach(td=>{
    if(isEl && td === excludeTd) return;
    const m = (td.dataset.mon || "").trim();
    if(m && m === mon) td.classList.add("conflict");
  });

  if(isEl) excludeTd.classList.add("drag-source");
}

function clearDragVisual(){
  document.querySelectorAll("#tkb td").forEach(td=>{
    td.classList.remove("conflict","drag-source","drag-over","drop-valid","drop-invalid");
  });
}

/* ======================= VALIDATION (KHÔNG TRÙNG MÔN TRONG 1 BUỔI) ======================= */
/*
  Quy tắc:
  - Trong 1 buổi (sáng hoặc chiều) của 1 ngày: 1 môn chỉ được xuất hiện trong 1 CỤM LIỀN NHAU.
    Ví dụ lim=2 => được phép 2 tiết liền nhau; KHÔNG cho phép "Toán - Văn - Toán" trong cùng buổi.
  - Số tiết trong buổi không vượt quá gioihan của môn (nếu không có => coi như 1)
  - Số tiết/tuần không vượt quá sotiet của môn (nếu có)
*/
function validateDrop(targetTd, mon){
  if(!currentLop) return {ok:false, reason:"no class"};
  if(!mon) return {ok:false, reason:"empty"};
  if(targetTd.classList.contains("tkb-off") || targetTd.classList.contains("tkb-fixed")) return {ok:false, reason:"locked"};

  // Nếu kéo từ "Tiết chưa phân" nhưng item thuộc lớp khác => không cho thả nhầm
  if(dragData && dragData.type === "mon" && dragData.classId != null && String(dragData.classId) !== String(currentLop)){
    const other = getLopCanonById(dragData.classId);
    return {ok:false, reason:"wrong class", msg:`Tiết này thuộc lớp ${other}. Hãy chọn lớp đó trước khi kéo.`, conflictLopId: dragData.classId};
  }
  if(dragData && dragData.type === "pairTeacherCell" && dragData.classId != null && String(dragData.classId) !== String(currentLop)){
    const other = getLopCanonById(dragData.classId);
    return {ok:false, reason:"wrong class", msg:`Tiết này thuộc lớp ${other}. Chỉ kéo trực tiếp lên bảng lớp khi bảng trên đang là lớp đó.`, conflictLopId: dragData.classId};
  }


  const tkb = DATA.tkb[currentLop];
  const tThu = targetTd.dataset.thu;
  const tBuoi = targetTd.dataset.buoi;
  const tTi = Number(targetTd.dataset.ti);

  const meta = getMonMeta(mon);
  const total = Number(meta.sotiet||0);
  const lim = Math.max(1, Number(meta.gioihan||1));

  // tổng tuần
  const used = countMon(mon);
  const targetVal = cellMon(tkb[tThu][tBuoi][tTi]);

  const src = (dragData && (dragData.type==="cell" || dragData.type==="pairTeacherCell")) ? dragData.from?.dataset : null;
  const srcThu = src?.thu;
  const srcBuoi = src?.buoi;
  const srcTi = src ? Number(src.ti) : -1;
  const srcVal = (src && srcThu && srcBuoi) ? cellMon(tkb[srcThu][srcBuoi][srcTi]) : "";

  // tính newUsed sau drop
  let newUsed = used;
  // remove source if it is the same mon
  if(srcVal === mon) newUsed -= 1;
  // remove target if target currently is same mon (vì ta clear target trước khi đặt)
  if(targetVal === mon) newUsed -= 1;
  // add one at target
  newUsed += 1;

  if(total > 0 && newUsed > total){
    return {ok:false, reason:"exceed week total"};
  }

  // xây arr mô phỏng cho buổi mục tiêu
  const arr = (tkb[tThu][tBuoi] || []).slice();

  // nếu kéo từ chính buổi mục tiêu, xóa vị trí nguồn
  if(srcThu === tThu && srcBuoi === tBuoi && srcTi >= 0){
    arr[srcTi] = "";
  }
  // xóa target rồi đặt
  arr[tTi] = mon;

  // kiểm tra không trùng tách rời + không quá giới hạn
  const idx = [];
  for(let i=0;i<arr.length;i++){
    if(cellMon(arr[i]) === mon) idx.push(i);
  }
  // (DISABLED) Không giới hạn số tiết của *môn* trong 1 buổi; chỉ giữ quy tắc LIỀN nhau.
  // nếu có >=2 tiết trong cùng buổi, phải liền nhau (1 cụm)
  for(let i=1;i<idx.length;i++){
    if(idx[i] !== idx[i-1] + 1){
      return {ok:false, reason:"split block"};
    }
  }

  // thêm một kiểm tra nhỏ: không cho đặt trùng "dính" ở ngoài cụm (phòng trường hợp data lạ)
  if(idx.length){
    const left = idx[0]-1;
    const right = idx[idx.length-1] + 1;
    if(left >= 0 && cellMon(arr[left]) === mon) return {ok:false, reason:"touch left"};
    if(right < arr.length && cellMon(arr[right]) === mon) return {ok:false, reason:"touch right"};
  }


  // ===== Tránh trùng lịch GV/Phòng (ràng buộc toàn trường) =====
  // NEW: nếu trùng thì KHÔNG chặn ngay, mà cho phép thả kèm confirm "Thay thế"
  const lopCanon = getLopCanonById(currentLop);

  const conflicts = [];

  const gv = getTeacherForClassMon(lopCanon, mon);
  const gvConflict = findTeacherConflictAtSlot(gv, tThu, tBuoi, tTi, currentLop);
  if(gvConflict){
    conflicts.push({
      type: "teacher",
      gv,
      lopId: gvConflict.lopId,
      mon: gvConflict.mon,
      thu: tThu,
      buoi: tBuoi,
      ti: tTi,
      msg: `Trùng GV ${gv} (đang dạy ${getMonShort(gvConflict.mon)}-${getLopCanonById(gvConflict.lopId)} ở tiết này)`
    });
  }

  const room = getRoomForClassMon(lopCanon, mon);
  const roomConflict = findRoomConflictAtSlot(room, tThu, tBuoi, tTi, currentLop);
  if(roomConflict){
    conflicts.push({
      type: "room",
      room,
      lopId: roomConflict.lopId,
      mon: roomConflict.mon,
      thu: tThu,
      buoi: tBuoi,
      ti: tTi,
      msg: `Trùng phòng ${room} (đang dùng bởi ${getMonShort(roomConflict.mon)}-${getLopCanonById(roomConflict.lopId)})`
    });
  }

  if(conflicts.length){
    // highlight lớp bị trùng
    try{
      conflicts.forEach(c=>flashLopItemConflict(c.lopId));
    }catch(_){ }

    const msg = (conflicts.length === 1)
      ? conflicts[0].msg
      : ("Có " + conflicts.length + " xung đột (GV/Phòng) ở tiết này.");

    return {
      ok: true,
      warn: true,
      reason: "conflict",
      msg,
      conflicts,
      conflictLopId: conflicts[0].lopId,
      confirmText: buildReplaceConfirmText(conflicts)
    };
  }

  return {ok:true};

}

/* ======================= MÔN LIST ======================= */
function countMonInTKB(tkb, mon){
  let c = 0;
  if(!tkb) return 0;
  DAYS.forEach(d=>["sang","chieu"].forEach(b=>{
    (tkb[d]?.[b] || []).forEach(x=>{ if(cellMon(x)===mon) c++; });
  }));
  return c;
}

// giữ API cũ (đếm trên lớp đang chọn)
function countMon(mon){
  return countMonInTKB(DATA.tkb[currentLop], mon);
}

function calcClassTKBPeriodStats(classId){
  const id = (classId || "").toString();
  if(!id) return {total:0, assigned:0, missing:0};

  const lop = (DATA.lop||[]).find(x=>String(x.id) === id);
  const classCanon = getLopCanonById(id);
  const khoiNum = extractKhoiNumber(lop?.khoi) || extractKhoiNumber(lop?.ten2) || extractKhoiNumber(lop?.ten) || "";
  const tkb = DATA.tkb?.[id];
  const mons = computeMonsForClass(khoiNum, classCanon) || [];

  let total = 0;
  let assigned = 0;
  for(const m of mons){
    const monName = (m?.ten || "").toString().trim();
    const req = Number(m?.sotiet || 0);
    if(!monName || !Number.isFinite(req) || req <= 0) continue;
    const used = countMonInTKB(tkb, monName);
    total += req;
    assigned += Math.min(req, Math.max(0, used));
  }

  if(total <= 0 && tkb){
    for(const d of DAYS){
      for(const buoi of ["sang","chieu"]){
        (tkb?.[d]?.[buoi] || []).forEach(v=>{
          if(v && v !== "OFF" && cellMon(v)) assigned++;
        });
      }
    }
  }

  return {
    total,
    assigned,
    missing: Math.max(0, total - assigned)
  };
}

/* ======================= TIẾT CHƯA PHÂN =======================
   - Hiển thị dạng: Lớp - Môn - GV
   - Sắp xếp theo lớp, sau đó theo môn
   - Khi còn_lại = 0 thì không hiển thị
============================================================== */
function goToUnassignedItem(classId, gvCode){
  const id = (classId || "").toString();
  const gv = (typeof resolveTeacherCode === "function")
    ? resolveTeacherCode(gvCode)
    : (gvCode || "").toString().trim();
  if(!id) return;
  if(VIEW_MODE !== "lop") setViewMode("lop");
  if(gv) currentGV = gv;
  selectLop(id);
  if(gv && typeof window.pairSelectTeacher === "function"){
    try{ window.pairSelectTeacher(gv); }catch(_){ }
  }
}

function loadMonList(){
  const box = document.getElementById("monList");
  if(!box) return;
  box.innerHTML = "";


  const otherBox = document.getElementById("monListOther");
  if(otherBox) otherBox.innerHTML = "";

  // Theo yêu cầu:
  // - Danh sách "Tiết chưa phân" chỉ hiển thị cho LỚP đang chọn (không hiển thị dạng mờ cho lớp khác)
  // - Không hiển thị các môn chưa phân công giáo viên
  if(false && (VIEW_MODE !== "lop" || !currentLop)){
    // vẫn render thống kê (bảng nằm dưới "Tiết chưa phân")
    renderStatsBox();
    return;
  }

  const khoiSel = document.getElementById("chonKhoi")?.value || "";
  const kFilter = extractKhoiNumber(khoiSel);

  const onlyClassId = String(currentLop);
  // Hien thi toan truong, khong loc rieng lop dang mo.
  const lops = Array.isArray(DATA.lop) ? DATA.lop : [];

  let tasks = [];
  lops.forEach(l=>{
    const classId = l.id;
    const classCanon = getLopCanonById(classId);
    if(!classCanon) return;

    // (Không bắt buộc, nhưng giữ hành vi lọc khối theo combobox)
    const khoiNum = extractKhoiNumber(l?.khoi) || extractKhoiNumber(l?.ten2) || extractKhoiNumber(l?.ten) || "";
    if(false && kFilter && String(khoiNum) !== String(kFilter)) return;

    const tkb = DATA.tkb?.[classId];

    const subjects = computeMonsForClass(khoiNum, classCanon) || [];
    // Override theo bảng phân công (nếu có)
    subjects.forEach(s=>{
      const t = getSoTietForClassMon(classCanon, s.ten);
      const g = getGioiHanForClassMon(classCanon, s.ten);
      if(t > 0) s.sotiet = t;
      if(g > 0) s.gioihan = g;
    });

    const countAssigned = (monName)=>{
      let c = 0;
      if(!tkb) return 0;
      for(const d of DAYS){
        for(const buoi of ["sang","chieu"]){
          (tkb?.[d]?.[buoi]||[]).forEach(v=>{
            if(!v || v === "OFF") return;
            const mon = cellMon(v);
            if(mon && mon === monName) c++;
          });
        }
      }
      return c;
    };

    subjects.forEach(s=>{
      const gv = getTeacherForClassMon(classCanon, s.ten);
      if(!gv) return; // <-- môn chưa có giáo viên => không hiển thị trong "tiết chưa phân"

      const used = countAssigned(s.ten);
      const remain = Math.max(0, Number(s.sotiet||0) - used);
      if(remain <= 0) return;

      tasks.push({
        classId,
        classCanon,
        className: (l.ten2 || l.ten || classId),
        mon: s.ten,
        remain,
        gv,
        room: getRoomForClassMon(classCanon, s.ten) || ""
      });
    });
  });

  // gộp theo môn (trong 1 lớp chỉ là an toàn)
  const map = new Map(); // key: classId|mon
  tasks.forEach(t=>{
    const k = `${t.classId}|${t.mon}`;
    if(!map.has(k)) map.set(k, {...t});
    else map.get(k).remain += Number(t.remain||0);
  });
  const tasksUniq = Array.from(map.values()).sort((a,b)=>{
    const c = (a.className||"").localeCompare((b.className||""),'vi');
    if(c) return c;
    const m = (a.mon||"").localeCompare((b.mon||""),'vi');
    if(m) return m;
    return 0;
  });

  if(!tasksUniq.length){
    box.innerHTML = `<div style="color:#999;font-size:12px;padding:6px 4px;">Không có tiết chưa phân.</div>`;
  }

  tasksUniq.forEach(t=>{
    const d = document.createElement("div");
    d.className = "mon-item";
    d.dataset.mon = t.mon;
    d.dataset.classid = String(t.classId);

    const monShort = getMonShort(t.mon);
    const gvTxt = (t.gv||"").toString().trim();
    const roomTxt = (t.room||"").toString().trim();
    const roomDisp = roomTxt ? ` (${roomTxt})` : "";

    const gvPart = gvTxt ? ` - ${escapeHtml(gvTxt)}` : "";
    d.innerHTML = `<b>${escapeHtml(t.className)} - ${escapeHtml(monShort)}${gvPart}</b>`+
                  `<span class="mon-item-meta">${escapeHtml(roomDisp)}</span>`;

    d.title = `${t.className} - ${t.mon}\nCòn: ${t.remain}\nGV: ${gvTxt}${roomDisp}`;

    // click vẫn giữ hành vi mở lớp (dù danh sách chỉ còn 1 lớp)
    d.onclick = ()=>goToUnassignedItem(t.classId, gvTxt);

    // draggable (chỉ có lớp đang chọn)
    d.draggable = (VIEW_MODE === "lop" && String(currentLop || "") === String(t.classId));
    d.ondragstart = (e)=>{
      dragMon = t.mon;
      // IMPORTANT: phải có type để onDrop() biết đây là drag từ "Tiết chưa phân"
      dragData = { type:"mon", classId: t.classId, mon: t.mon };
      // kéo từ panel => không có ô nguồn để highlight
      applyDragVisual(dragMon, null);
      try{ _setStatus("", "info"); }catch(_){ }
    };
    d.ondragend = ()=>{
      clearDragVisual();
      dragData = null;
      dragMon = "";
    };

    box.appendChild(d);
  });


  // luôn cập nhật thống kê phía dưới
  renderStatsBox();
}


/* ======================= TIẾT CHƯA PHÂN – CÁC LỚP KHÁC =======================
   - Hiển thị danh sách tiết chưa phân của các lớp KHÁC lớp đang chọn
   - Click để nhảy sang lớp đó (tiện bổ sung lại)
============================================================================= */
function renderOtherUnassignedList(kFilter){
  const otherBox = document.getElementById("monListOther");
  if(!otherBox) return;

  otherBox.innerHTML = "";

  if(VIEW_MODE !== "lop" || !currentLop){
    otherBox.innerHTML = `<div style="color:#999;font-size:12px;padding:6px 4px;">Chọn một lớp để xem.</div>`;
    return;
  }

  const curId = String(currentLop);
  const lopsAll = getFilteredLops().filter(l => String(l.id) !== curId);

  let tasks = [];

  lopsAll.forEach(l=>{
    const classId = l.id;
    const classCanon = getLopCanonById(classId);
    if(!classCanon) return;

    const khoiNum = extractKhoiNumber(l?.khoi) || extractKhoiNumber(l?.ten2) || extractKhoiNumber(l?.ten) || "";
    if(kFilter && String(khoiNum) !== String(kFilter)) return;

    const tkb = DATA.tkb?.[classId];

    const subjects = (DATA.mon||[])
      .filter(m => extractKhoiNumber(m?.khoi) === khoiNum)
      .map(m => ({
        ten: (m.ten||"").toString().trim(),
        sotiet: Number(m.sotiet||0),
        gioihan: Number(m.gioihan||1)
      }))
      .filter(m => m.ten && m.sotiet > 0);

    // Override theo bảng phân công (nếu có)
    subjects.forEach(s=>{
      const t = getSoTietForClassMon(classCanon, s.ten);
      const g = getGioiHanForClassMon(classCanon, s.ten);
      if(t > 0) s.sotiet = t;
      if(g > 0) s.gioihan = g;
    });

    const countAssigned = (monName)=>{
      let c = 0;
      if(!tkb) return 0;
      for(const d of DAYS){
        for(const buoi of ["sang","chieu"]){
          (tkb?.[d]?.[buoi]||[]).forEach(v=>{
            if(!v || v === "OFF") return;
            const mon = cellMon(v);
            if(mon && mon === monName) c++;
          });
        }
      }
      return c;
    };

    const className = (l.ten2 || l.ten || classId);

    subjects.forEach(s=>{
      const gv = getTeacherForClassMon(classCanon, s.ten);
      if(!gv) return; // giữ cùng hành vi: không hiển thị môn chưa có GV

      const used = countAssigned(s.ten);
      const remain = Math.max(0, Number(s.sotiet||0) - used);
      if(remain <= 0) return;

      tasks.push({
        classId,
        classCanon,
        className,
        mon: s.ten,
        remain,
        gv,
        room: getRoomForClassMon(classCanon, s.ten) || ""
      });
    });
  });

  // gộp theo lớp|môn
  const map = new Map();
  tasks.forEach(t=>{
    const k = `${t.classId}|${t.mon}`;
    if(!map.has(k)) map.set(k, {...t});
    else map.get(k).remain += Number(t.remain||0);
  });

  const list = Array.from(map.values()).sort((a,b)=>{
    const c = (a.className||"").localeCompare((b.className||""),'vi');
    if(c) return c;
    const m = (a.mon||"").localeCompare((b.mon||""),'vi');
    if(m) return m;
    // remain desc
    return (Number(b.remain||0) - Number(a.remain||0));
  });

  if(list.length === 0){
    otherBox.innerHTML = `<div style="color:#999;font-size:12px;padding:6px 4px;">Không có.</div>`;
    return;
  }

  const MAX_SHOW = 140;
  const show = list.slice(0, MAX_SHOW);

  show.forEach(t=>{
    const d = document.createElement("div");
    d.className = "mon-item mon-other";
    d.dataset.classid = String(t.classId);

    const monShort = getMonShort(t.mon);
    const gvTxt = (t.gv||"").toString().trim();
    const roomTxt = (t.room||"").toString().trim();
    const roomDisp = roomTxt ? ` (${roomTxt})` : "";
    const gvPart = gvTxt ? ` - ${escapeHtml(gvTxt)}` : "";

    d.innerHTML =
      `<b>${escapeHtml(t.className)}</b> `+
      `<span style="color:#666">— ${escapeHtml(monShort)} (${t.remain})</span> `+
      `<span style="color:#999">${escapeHtml((t.gv||"").toString().trim())}${escapeHtml(roomDisp)}</span>`;

    d.title = `${t.className} - ${t.mon}\nCòn: ${t.remain}\nGV: ${(t.gv||"").toString().trim()}${roomDisp}`;

    d.innerHTML =
      `<b>${escapeHtml(t.className)} - ${escapeHtml(monShort)}${gvPart}</b>`+
      `<span class="mon-item-meta">${escapeHtml(roomDisp)}</span>`;

    d.onclick = ()=>goToUnassignedItem(t.classId, gvTxt);

    otherBox.appendChild(d);
  });

  if(list.length > MAX_SHOW){
    const more = document.createElement("div");
    more.style.cssText = "color:#999;font-size:12px;padding:6px 4px;";
    more.textContent = `… còn ${list.length - MAX_SHOW} mục khác`;
    otherBox.appendChild(more);
  }
}


/* ======================= THỐNG KÊ BÊN PHẢI =======================
   - Hiển thị dưới "Tiết chưa phân"
   - Nội dung theo mẫu người dùng cung cấp
============================================================== */

function renderStatsBox(){
  const box = document.getElementById("statsBox");
  if(!box) return;

  const school = calcSchoolTKBStats();
  const gvStats = calcTeacherTKBStats();

  // helper in HTML
  const n = (v)=>{
    const num = Number(v||0);
    if(!Number.isFinite(num)) return "0";
    return String(Math.round(num));
  };

  box.innerHTML =
    `<div class="stats-title">Thống kê TKB toàn trường</div>`+
    `<div class="stats-grid-3">`+
      `<div>Số tiết: ${n(school.soTiet)}</div>`+
      `<div>Đã xếp: ${n(school.daXepTiet)}</div>`+
      `<div>Chưa xếp: ${n(school.chuaXepTiet)}</div>`+

      `<div>Lớp học: ${n(school.soLop)}</div>`+
      `<div>Đã xếp: ${n(school.daXepLop)}</div>`+
      `<div>Chưa xếp: ${n(school.chuaXepLop)}</div>`+

      `<div>Giáo viên: ${n(school.soGV)}</div>`+
      `<div>Đã xếp: ${n(school.daXepGV)}</div>`+
      `<div>Chưa xếp: ${n(school.chuaXepGV)}</div>`+

      `<div>Phòng học: ${n(school.soPhong)}</div>`+
      `<div>Đã xếp: ${n(school.daXepPhong)}</div>`+
      `<div>Chưa xếp: ${n(school.chuaXepPhong)}</div>`+
    `</div>`+

    `<div style="height:14px"></div>`+

    `<div class="stats-title">Thống kê TKB giáo viên</div>`+
    `<div class="stats-grid-2">`+
      `<div>Số tiết trống: ${n(gvStats.soTietTrong)}</div>`+
      `<div>TS buổi dạy: ${n(gvStats.tsBuoiDay)}</div>`+

      `<div>Số buổi trống 1 tiết: ${n(gvStats.soBuoiTrong1)}</div>`+
      `<div>TS ngày dạy: ${n(gvStats.tsNgayDay)}</div>`+

      `<div>Số buổi trống 2 tiết: ${n(gvStats.soBuoiTrong2)}</div>`+
      `<div></div>`+

      `<div>Số buổi dạy 1 tiết: ${n(gvStats.soBuoiDay1)}</div>`+
      `<div></div>`+

      `<div>Số buổi dạy 5 tiết: ${n(gvStats.soBuoiDay5)}</div>`+
      `<div></div>`+
    `</div>`;
}

function calcSchoolTKBStats(){
  const lops = Array.isArray(DATA.lop) ? DATA.lop : [];
  const tkbs = DATA.tkb || {};

  let soTiet = 0;
  let chuaXepTiet = 0;

  let soLop = lops.length;
  let daXepLop = 0;

  // gom thiếu theo GV (để tính Đã xếp/Chưa xếp giáo viên)
  const teacherMissing = new Map();
  const teacherRequired = new Map();
  const teacherSet = new Set();

  // rooms: tổng từ danh mục phòng nếu có, fallback từ phân công phòng
  const roomList = new Set(
    (Array.isArray(DATA.phong) ? DATA.phong : [])
      .map(p=>String(p?.ten||"").trim())
      .filter(Boolean)
  );
  const roomFromAssign = new Set(
    Object.values(DATA.pccmRoomMatrix||{})
      .map(r=>String(r||"").trim())
      .filter(Boolean)
  );
  const roomAll = (roomList.size ? roomList : roomFromAssign);
  const roomUsed = new Set();

  for(const lop of lops){
    const classId = lop.id;
    const khoiNum = extractKhoiNumber(lop?.khoi) || extractKhoiNumber(lop?.ten2) || extractKhoiNumber(lop?.ten) || "";
    const classCanon = getLopCanonById(classId);
    const mons = computeMonsForClass(khoiNum, classCanon) || [];
    const tkb = tkbs?.[classId];

    let remainForClass = 0;

    for(const m of mons){
      const monName = (m?.ten||"").toString().trim();
      if(!monName) continue;

      const req = Number(m?.sotiet||0);
      if(!Number.isFinite(req) || req <= 0) continue;

      const used = countMonInTKB(tkb, monName);
      const rem = Math.max(0, req - used);

      soTiet += req;
      chuaXepTiet += rem;
      remainForClass += rem;

      const gv = getTeacherForClassMon(classCanon, monName);
      if(gv){
        teacherSet.add(gv);
        teacherMissing.set(gv, (teacherMissing.get(gv)||0) + rem);
        teacherRequired.set(gv, (teacherRequired.get(gv)||0) + req);
      }

      const room = getRoomForClassMon(classCanon, monName);
      if(room) roomFromAssign.add(room);
    }

    if(remainForClass === 0) daXepLop++;

    // scan phòng đang dùng theo TKB (chỉ để tính Đã xếp/Chưa xếp phòng)
    if(tkb){
      for(const d of DAYS){
        for(const buoi of ["sang","chieu"]){
          const arr = (tkb?.[d]?.[buoi]||[]);
          for(let i=0;i<arr.length;i++){
            const v = arr[i];
            if(!v || v === "OFF") continue;
            const mon = cellMon(v);
            if(!mon) continue;
            const room = getRoomForClassMon(classCanon, mon);
            if(room) roomUsed.add(room);
          }
        }
      }
    }
  }

  // GV: chỉ tính những GV có phân công (teacherSet)
  let soGV = teacherSet.size;
  let daXepGV = 0;
  teacherSet.forEach(code=>{
    const req = teacherRequired.get(code) || 0;
    const miss = teacherMissing.get(code) || 0;
    // chỉ coi là "đã xếp" nếu có yêu cầu và không còn thiếu
    if(req > 0 && miss === 0) daXepGV++;
  });

  // Phòng: tổng từ danh mục hoặc phân công (roomAll)
  const soPhong = roomAll.size;
  let daXepPhong = 0;
  if(soPhong > 0){
    roomAll.forEach(r=>{ if(roomUsed.has(r)) daXepPhong++; });
  }

  const daXepTiet = soTiet - chuaXepTiet;

  return {
    soTiet,
    daXepTiet,
    chuaXepTiet,
    soLop,
    daXepLop,
    chuaXepLop: Math.max(0, soLop - daXepLop),
    soGV,
    daXepGV,
    chuaXepGV: Math.max(0, soGV - daXepGV),
    soPhong,
    daXepPhong,
    chuaXepPhong: Math.max(0, soPhong - daXepPhong)
  };
}

function _getAssignedTeacherCodes(){
  const set = new Set();
  const classCanonSet = new Set((DATA.lop||[]).map(l=>getLopCanonById(l.id)));
  for(const [k,v] of Object.entries(DATA.pccmMatrix || {})){
    const cls = (k||"").split("|")[0] || "";
    if(cls && classCanonSet.size && !classCanonSet.has(cls)) continue;
    const code = resolveTeacherCode(v);
    if(code) set.add(code);
  }
  if(set.size) return set;

  // fallback: danh sách GV trong dữ liệu
  (DATA.giaovien||[]).forEach(g=>{
    const c = resolveTeacherCode(g?.magv || g?.ten || "");
    if(c) set.add(c);
  });
  return set;
}

function calcTeacherTKBStats(){
  const teacherCodes = Array.from(_getAssignedTeacherCodes());
  const occ = {}; // code -> day -> buoi -> boolean[]

  teacherCodes.forEach(code=>{
    occ[code] = {};
    DAYS.forEach(d=>{
      occ[code][d] = {
        sang: Array.from({length:SANG}, ()=>false),
        chieu: Array.from({length:CHIEU}, ()=>false)
      };
    });
  });

  // Scan toàn bộ TKB để đánh dấu tiết dạy cho từng GV
  const lops = Array.isArray(DATA.lop) ? DATA.lop : [];
  for(const lop of lops){
    const classId = lop.id;
    const tkb = DATA.tkb?.[classId];
    if(!tkb) continue;
    const classCanon = getLopCanonById(classId);

    for(const d of DAYS){
      // sáng
      const as = (tkb?.[d]?.sang || []);
      for(let i=0;i<as.length;i++){
        const v = as[i];
        if(!v || v === "OFF") continue;
        const mon = cellMon(v);
        if(!mon) continue;
        const gv = getTeacherForClassMon(classCanon, mon);
        if(gv && occ[gv]) occ[gv][d].sang[i] = true;
      }
      // chiều
      const ac = (tkb?.[d]?.chieu || []);
      for(let i=0;i<ac.length;i++){
        const v = ac[i];
        if(!v || v === "OFF") continue;
        const mon = cellMon(v);
        if(!mon) continue;
        const gv = getTeacherForClassMon(classCanon, mon);
        if(gv && occ[gv]) occ[gv][d].chieu[i] = true;
      }
    }
  }

  // Tính thống kê theo mô tả:
  // - Số tiết trống = số buổi trống 1 tiết + số buổi trống 2 tiết.
  // - Buổi dạy 1 tiết: buổi có đúng 1 tiết dạy (đây là phần cần tối ưu)
  let soBuoiTrong1 = 0;
  let soBuoiTrong2 = 0;
  let soBuoiDay1 = 0;
  let soBuoiDay5 = 0;
  let tsBuoiDay = 0;
  let tsNgayDay = 0;

  const _countGaps = (arr)=>{
    const idx = [];
    for(let i=0;i<arr.length;i++) if(arr[i]) idx.push(i);
    if(!idx.length) return {tietDay:0, gaps:0};
    const first = idx[0];
    const last = idx[idx.length-1];
    const span = (last - first + 1);
    const tietDay = idx.length;
    const gaps = Math.max(0, span - tietDay);
    return {tietDay, gaps};
  };

  for(const code of teacherCodes){
    let dayCounted = 0;
    for(const d of DAYS){
      let dayHas = false;
      for(const buoi of ["sang","chieu"]){
        const arr = (occ[code]?.[d]?.[buoi] || []);
        const {tietDay, gaps} = _countGaps(arr);
        if(tietDay > 0){
          tsBuoiDay++;
          dayHas = true;

          if(tietDay === 1) soBuoiDay1++;
          if(tietDay === 5) soBuoiDay5++;

          if(gaps === 1) soBuoiTrong1++;
          if(gaps === 2) soBuoiTrong2++;
        }
      }
      if(dayHas) dayCounted++;
    }
    tsNgayDay += dayCounted;
  }

  return {
    soTietTrong: soBuoiTrong1 + soBuoiTrong2,
    soBuoiTrong1,
    soBuoiTrong2,
    soBuoiDay1,
    soBuoiDay5,
    tsBuoiDay,
    tsNgayDay
  };
}

/* ======================= XÓA TKB (INLINE MENU) =======================
   - Theo yêu cầu: không dùng hộp thoại, hiển thị listbox ngay tại toolbar
   - Có 2 lựa chọn: Xóa lớp hiện tại / Xóa TKB toàn trường
   - Cơ chế xác nhận inline (không dùng confirm/alert)
======================= */
let _deleteChoice = "";

function _setStatus(msg, type="error"){
  const el = document.getElementById("statusMsg");
  if(!el) return;
  el.textContent = msg || "";
  if(type === "ok") el.style.color = "#135200";
  else if(type === "info") el.style.color = "#2f54eb";
  else el.style.color = "#a8071a";
}

function _autoSortProgressYield(){
  return new Promise(resolve => setTimeout(resolve, 0));
}

if(typeof window !== "undefined" && typeof window.__AUTO_SORT_STOP_REQUESTED === "undefined"){
  window.__AUTO_SORT_STOP_REQUESTED = false;
}

function setAutoSortStopVisible(visible){
  const btn = document.getElementById("btnStopAutoSort");
  if(!btn) return;
  btn.classList.toggle("is-active", !!visible);
  btn.setAttribute("aria-hidden", visible ? "false" : "true");
  if(!visible){
    btn.disabled = false;
    btn.textContent = "Dừng";
  }
}

function resetAutoSortStopRequest(){
  window.__AUTO_SORT_STOP_REQUESTED = false;
  const btn = document.getElementById("btnStopAutoSort");
  if(btn){
    btn.disabled = false;
    btn.textContent = "Dừng";
  }
}

function requestStopAutoSort(){
  window.__AUTO_SORT_STOP_REQUESTED = true;
  const btn = document.getElementById("btnStopAutoSort");
  if(btn){
    btn.classList.add("is-active");
    btn.setAttribute("aria-hidden", "false");
    btn.disabled = true;
    btn.textContent = "Đang dừng";
  }
  try{ _setStatus("Đang dừng xếp...", "info"); }catch(_){ }
}

try{
  window.setAutoSortStopVisible = setAutoSortStopVisible;
  window.resetAutoSortStopRequest = resetAutoSortStopRequest;
  window.requestStopAutoSort = requestStopAutoSort;
}catch(_){ }

function setAutoSortProgress(percent, label){
  const wrap = document.getElementById("autoSortProgress");
  const fill = document.getElementById("autoSortProgressFill");
  const pct = document.getElementById("autoSortProgressPct");
  const text = wrap?.querySelector(".auto-sort-label");
  if(!wrap || !fill || !pct) return;
  const n = Math.max(0, Math.min(100, Math.round(Number(percent || 0))));
  const btn = document.getElementById("btnStopAutoSort");
  if(btn) btn.disabled = true;
  window.clearTimeout(window.__autoSortProgressHideTimer);
  setAutoSortStopVisible(true);
  if(!window.__AUTO_SORT_STOP_REQUESTED && n < 100){
    const btn = document.getElementById("btnStopAutoSort");
    if(btn){
      btn.disabled = false;
      btn.textContent = "Dừng";
    }
  }
  wrap.classList.add("is-active");
  wrap.setAttribute("aria-hidden", "false");
  fill.style.width = n + "%";
  pct.textContent = n + "%";
  if(text && label) text.textContent = label;
}

function finishAutoSortProgress(label){
  setAutoSortProgress(100, label || "Hoàn tất");
  window.clearTimeout(window.__autoSortProgressHideTimer);
  window.__autoSortProgressHideTimer = window.setTimeout(()=>{
    const wrap = document.getElementById("autoSortProgress");
    if(wrap){
      wrap.classList.remove("is-active");
      wrap.setAttribute("aria-hidden", "true");
    }
    setAutoSortStopVisible(false);
    resetAutoSortStopRequest();
  }, 2600);
}

function deleteCurrentClassTKB(){
  cancelDeleteMenu(true);
  if(!currentLop){
    _setStatus("Chưa chọn lớp để xóa.", "error");
    return;
  }

  const cfg = DATA.tkbConfig || {fixed:[], off:[]};
  DATA.tkb[currentLop] = makeEmptyTKBPreservingOff(currentLop, cfg);
  saveStore();
  renderCurrentView();
  loadMonList();

  const lop = (DATA.lop||[]).find(x=>x.id==currentLop);
  const name = (lop?.ten2||lop?.ten||currentLop);
  _setStatus(`✔ Đã xóa TKB lớp ${name}.`, "ok");
}

function deleteAllTKB(){
  cancelDeleteMenu(true);
  const cfg = DATA.tkbConfig || {fixed:[], off:[]};
  (DATA.lop||[]).forEach(l=>{
    DATA.tkb[l.id] = makeEmptyTKBPreservingOff(l.id, cfg);
  });
  saveStore();
  renderCurrentView();
  loadMonList();
  _setStatus("✔ Đã xóa TKB toàn trường.", "ok");
}

function toggleDeleteMenu(){
  const sel = document.getElementById("deleteSelect");
  if(!sel) return;
  const isOpen = (sel.style.display !== "none");
  if(isOpen){
    cancelDeleteMenu(true);
  } else {
    _setStatus("", "info");
    sel.value = "";
    sel.style.display = "inline-block";
    const confirmBox = document.getElementById("deleteConfirm");
    if(confirmBox) confirmBox.style.display = "none";
    _deleteChoice = "";
  }
}

// silent=true => chỉ đóng menu, không set status
function cancelDeleteMenu(silent=false){
  const sel = document.getElementById("deleteSelect");
  const confirmBox = document.getElementById("deleteConfirm");
  if(sel) sel.style.display = "none";
  if(confirmBox) confirmBox.style.display = "none";
  _deleteChoice = "";
  if(!silent) _setStatus("", "info");
}

function onDeleteSelectChange(){
  const sel = document.getElementById("deleteSelect");
  const confirmBox = document.getElementById("deleteConfirm");
  const txt = document.getElementById("deleteConfirmText");
  if(!sel) return;

  _deleteChoice = sel.value || "";
  if(!_deleteChoice){
    if(confirmBox) confirmBox.style.display = "none";
    return;
  }

  const label = (_deleteChoice === "school") ? "Xóa TKB toàn trường" : "Xóa TKB lớp hiện tại";
  if(txt) txt.textContent = `Xác nhận: ${label}?`;
  if(confirmBox) confirmBox.style.display = "inline-flex";
}

function confirmDeleteMenu(){
  const choice = _deleteChoice;
  if(!choice){ cancelDeleteMenu(true); return; }

  if(choice === "class"){
    if(!currentLop){
      _setStatus("Chưa chọn lớp để xóa.", "error");
      return;
    }
    const cfg = DATA.tkbConfig || {fixed:[], off:[]};
    DATA.tkb[currentLop] = makeEmptyTKBPreservingOff(currentLop, cfg);
    saveStore();
    renderCurrentView();
    loadMonList();
    const lop = (DATA.lop||[]).find(x=>x.id==currentLop);
    const name = (lop?.ten2||lop?.ten||currentLop);
    _setStatus(`✔ Đã xóa TKB lớp ${name}.`, "ok");
    cancelDeleteMenu(true);
    return;
  }

  if(choice === "school"){
    const cfg = DATA.tkbConfig || {fixed:[], off:[]};
    (DATA.lop||[]).forEach(l=>{
      DATA.tkb[l.id] = makeEmptyTKBPreservingOff(l.id, cfg);
    });
    saveStore();
    renderCurrentView();
    loadMonList();
    _setStatus("✔ Đã xóa TKB toàn trường.", "ok");
    cancelDeleteMenu(true);
    return;
  }

  cancelDeleteMenu(true);
}



/* [MOVED -> phanmon-ops.js] Section: xep_lai */



/* [MOVED -> phanmon-ops.js] Section: panel_and_constraints */

/* ======================= CHECK / EXPORT ======================= */
function showTKBError(){
  if(!currentLop){ alert("Chưa chọn lớp"); return; }

  const errors=[];
  CURRENT_MONS.forEach(m=>{
    const used = countMon(m.ten);
    if(used !== Number(m.sotiet||0)) errors.push(`${m.ten}: ${used}/${m.sotiet}`);
  });

  // check trùng môn trong 1 buổi (tách rời)
  const tkb = DATA.tkb[currentLop];
  DAYS.forEach(thu=>{
    ["sang","chieu"].forEach(buoi=>{
      const arr = tkb[thu][buoi] || [];
      const seen = {};
      for(let i=0;i<arr.length;i++){
        const mon = cellMon(arr[i]);
        if(!mon) continue;
        (seen[mon] ||= []).push(i);
      }
      Object.entries(seen).forEach(([mon, idx])=>{
        const lim = Math.max(1, Number(getMonMeta(mon).gioihan||1));
        if(idx.length > lim) errors.push(`${LABEL[thu]}-${buoi}: ${mon} vượt giới hạn (${idx.length}/${lim})`);
        for(let k=1;k<idx.length;k++){
          if(idx[k] !== idx[k-1]+1){
            errors.push(`${LABEL[thu]}-${buoi}: ${mon} bị tách rời (${idx.map(x=>x+1).join(",")})`);
            break;
          }
        }
      });
    });
  });

  if(!errors.length) alert("✔ Không thấy lỗi.");
  else alert("⚠ Lỗi:\n- " + errors.join("\n- "));
}

function exportExcel(){
  if(!currentLop){ alert("Chưa chọn lớp"); return; }
  const lop = (DATA.lop||[]).find(x=>x.id==currentLop);
  const tkb = DATA.tkb[currentLop];
  const rows = [];

  rows.push(["Tiết", ...DAYS.map(d=>LABEL[d])]);

  for(let i=0;i<SANG;i++){
    rows.push([`S${i+1}`, ...DAYS.map(d=>cellMon(tkb[d].sang[i]) || "")]);
  }
  rows.push(["", "CHIỀU", "", "", "", "", ""]);
  for(let i=0;i<CHIEU;i++){
    rows.push([`C${i+1}`, ...DAYS.map(d=>cellMon(tkb[d].chieu[i]) || "")]);
  }

  const ws = XLSX.utils.aoa_to_sheet(rows);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "TKB");
  XLSX.writeFile(wb, `TKB_${lop?.ten2||lop?.ten||currentLop}.xlsx`);
}

/* ======================= SAVE / BACK ======================= */
function saveTKB(){ saveStore(); }

function saveAndBack(){
  saveStore();
  backToMain();
}

function backToMain(){
  // Ưu tiên quay về trang vừa mở (sapxep.html)
  if (document.referrer) { location.href = document.referrer; return; }
  if (window.history && window.history.length > 1) { window.history.back(); return; }
  // fallback (phanmon nằm trong /pages/)
  location.href = "../index.html";
}





/* [MOVED -> phanmon-ops.js] Section: optimize_improvements */

/* =========================================================
   PATCH 2026-05-03: paired schedule views
   ========================================================= */
(function(){
  try{
    if(window.__TKB_PAIRED_VIEW_PATCH_20260503__) return;
    window.__TKB_PAIRED_VIEW_PATCH_20260503__ = true;

    const __origUpdateViewButtonsActive = updateViewButtonsActive;
    const __origRenderTKB = renderTKB;
    const __origRenderTKBTeacher = renderTKBTeacher;
    const __origRenderTKBPhong = renderTKBPhong;

    function pvSetButtonText(){
      const bL = document.getElementById("btnViewLop");
      const bG = document.getElementById("btnViewGV");
      const bP = document.getElementById("btnViewPhong");
      if(bL) bL.innerText = "Lớp - GV";
      if(bG) bG.innerText = "GV - Phòng";
      if(bP) bP.innerText = "Lớp - Phòng";
    }

    updateViewButtonsActive = function(){
      try{ __origUpdateViewButtonsActive(); }catch(e){}
      pvSetButtonText();
      const leftTitle = document.getElementById("leftTitle");
      if(leftTitle){
        if(VIEW_MODE === "gv") leftTitle.innerText = "Giáo viên";
        else if(VIEW_MODE === "phong") leftTitle.innerText = "Lớp";
        else leftTitle.innerText = "Lớp";
      }
    };

    function pvClassLabel(classId){
      const lop = (DATA.lop || []).find(x => String(x.id) === String(classId));
      return lop ? (lop.ten2 || lop.ten || lop.id) : (classId || "");
    }

    function pvTeacherLabel(code){
      const c = (code || "").toString().trim();
      const name = getTeacherNameByCode(c);
      return name ? `${c} - ${name}` : c;
    }

    function pvTeachersForClass(classId){
      const set = new Set();
      const tkb = DATA.tkb?.[classId];
      const canon = getLopCanonById(classId);
      const lop = (DATA.lop || []).find(x => String(x.id) === String(classId));
      const khoiNum = extractKhoiNumber(lop?.khoi) || extractKhoiNumber(lop?.ten2) || extractKhoiNumber(lop?.ten) || "";
      (computeMonsForClass(khoiNum, canon) || []).forEach(m=>{
        const mon = (m?.ten || "").toString().trim();
        if(!mon) return;
        const gv = getTeacherForClassMon(canon, mon);
        if(gv) set.add(String(gv).trim());
      });
      if(tkb){
        for(const thu of DAYS){
          for(const buoi of ["sang","chieu"]){
            const arr = tkb?.[thu]?.[buoi] || [];
            for(const cell of arr){
              if(!cell || cell === "OFF" || isFixed(cell)) continue;
              const mon = cellMon(cell);
              if(!mon) continue;
              const gv = getTeacherForClassMon(canon, mon);
              if(gv) set.add(String(gv).trim());
            }
          }
        }
      }
      const out = Array.from(set).filter(Boolean).sort((a,b)=>a.localeCompare(b,'vi'));
      if(out.length) return out;
      return getTeacherListForCurrentFilter().map(x => x.code).filter(Boolean);
    }

    function pvRoomsForTeacher(gvCode){
      const code = (gvCode || "").toString().trim();
      const set = new Set();
      const lops = getFilteredLops();
      for(const l of lops){
        const classId = l.id;
        const tkb = DATA.tkb?.[classId];
        if(!tkb) continue;
        const canon = getLopCanonById(classId);
        for(const thu of DAYS){
          for(const buoi of ["sang","chieu"]){
            const arr = tkb?.[thu]?.[buoi] || [];
            for(const cell of arr){
              if(!cell || cell === "OFF" || isFixed(cell)) continue;
              const mon = cellMon(cell);
              if(!mon) continue;
              const gv = getTeacherForClassMon(canon, mon);
              if(gv !== code) continue;
              const room = getRoomForClassMon(canon, mon);
              if(room) set.add(String(room).trim());
            }
          }
        }
      }
      const out = Array.from(set).filter(Boolean).sort((a,b)=>a.localeCompare(b,'vi'));
      if(out.length) return out;
      return getRoomListForCurrentFilter();
    }

    function pvRoomsForClass(classId){
      const set = new Set();
      const tkb = DATA.tkb?.[classId];
      const canon = getLopCanonById(classId);
      if(tkb){
        for(const thu of DAYS){
          for(const buoi of ["sang","chieu"]){
            const arr = tkb?.[thu]?.[buoi] || [];
            for(const cell of arr){
              if(!cell || cell === "OFF" || isFixed(cell)) continue;
              const mon = cellMon(cell);
              if(!mon) continue;
              const room = getRoomForClassMon(canon, mon);
              if(room) set.add(String(room).trim());
            }
          }
        }
      }
      return Array.from(set).filter(Boolean).sort((a,b)=>a.localeCompare(b,'vi'));
    }

    function pvClassesForRoom(roomName){
      const roomKey = (roomName || "").toString().trim();
      const set = new Set();
      const lops = getFilteredLops();
      for(const l of lops){
        const classId = l.id;
        const tkb = DATA.tkb?.[classId];
        if(!tkb) continue;
        const canon = getLopCanonById(classId);
        let hit = false;
        for(const thu of DAYS){
          for(const buoi of ["sang","chieu"]){
            const arr = tkb?.[thu]?.[buoi] || [];
            for(const cell of arr){
              if(!cell || cell === "OFF" || isFixed(cell)) continue;
              const mon = cellMon(cell);
              if(!mon) continue;
              const room = getRoomForClassMon(canon, mon);
              if(room && String(room).trim() === roomKey) hit = true;
            }
          }
        }
        if(hit) set.add(String(classId));
      }
      const out = Array.from(set);
      if(out.length) return out;
      return getFilteredLops().map(l => l.id);
    }

    function pvEnsureTeacherForClass(classId){
      const list = pvTeachersForClass(classId);
      if(!list.length){ currentGV = null; return ""; }
      if(!currentGV || !list.includes(currentGV)) currentGV = list[0];
      return currentGV;
    }

    function pvEnsureRoomForTeacher(gvCode){
      const list = pvRoomsForTeacher(gvCode);
      if(!list.length){ currentPhong = null; return ""; }
      if(!currentPhong || !list.includes(currentPhong)) currentPhong = list[0];
      return currentPhong;
    }

    function pvEnsureRoomForClass(classId){
      const list = pvRoomsForClass(classId);
      if(!list.length){ currentPhong = null; return ""; }
      if(!currentPhong || !list.includes(currentPhong)) currentPhong = list[0];
      return currentPhong;
    }

    function pvEnsureClassForRoom(roomName){
      const list = pvClassesForRoom(roomName);
      if(!list.length){ currentLop = null; return ""; }
      if(!currentLop || !list.includes(String(currentLop))) currentLop = list[0];
      return currentLop;
    }

    function pvTeacherCellHTML(entries, thu, buoi, ti){
      const arr = Array.isArray(entries) ? entries : [];
      const conflict = arr.length > 1;
      const lines = arr.map(e=>{
        const monShort = getMonShort(e.mon);
        const room = (e.room||"").toString().trim();
        const roomTxt = room ? ` (${room})` : "";
        return `${monShort}-${e.classDisplay}${roomTxt}`;
      });
      const htmlLines = lines.map(s=>escapeHtml(s)).join("<br>");
      const classIds = arr.map(e=>String(e.classId)).join(",");
      const one = arr.length === 1 ? arr[0] : null;
      const oneAttrs = one
        ? ` data-classid="${escapeHtml(String(one.classId))}" data-mon="${escapeHtml(String(one.mon || ""))}" draggable="true"`
        : ` draggable="false"`;
      return `<td class="${conflict?"tkb-gv-conflict":""} ${one?"tkb-pair-draggable":""}" data-pair-slot="teacher" data-classids="${escapeHtml(classIds)}" data-thu="${thu}" data-buoi="${buoi}" data-ti="${ti}"${oneAttrs}>`+
             `<div class="tkb-gv-cell">${htmlLines}</div>`+
             `</td>`;
    }

    function pvTeacherTableHTML(gvCode){
      const code = (gvCode || "").toString().trim();
      if(!code) return `<div class="tkb-pair-empty">Chưa chọn giáo viên</div>`;
      const sched = buildTeacherSchedule(code);
      let h = "<table class='table tkb-support-table'><tr>";
      DAYS.forEach(d => h += `<th>${LABEL[d]}</th>`);
      h += "</tr>";
      const TOTAL = SANG + CHIEU;
      for(let row=0; row<TOTAL; row++){
        const isAfternoon = row >= SANG;
        const buoi = isAfternoon ? "chieu" : "sang";
        const ti = isAfternoon ? (row - SANG) : row;
        h += `<tr${row===SANG ? " class=\"split-row\"" : ""}>`;
        DAYS.forEach(d => {
          const entries = isAfternoon ? sched[d].chieu[ti] : sched[d].sang[ti];
          h += pvTeacherCellHTML(entries, d, buoi, ti);
        });
        h += "</tr>";
      }
      return h + "</table>";
    }

    function pvRoomTableHTML(roomName){
      const room = (roomName || "").toString().trim();
      if(!room) return pvBlankTimetableHTML();
      const sched = buildRoomSchedule(room);
      let h = "<table class='table tkb-support-table'><tr>";
      DAYS.forEach(d => h += `<th>${LABEL[d]}</th>`);
      h += "</tr>";
      const TOTAL = SANG + CHIEU;
      for(let row=0; row<TOTAL; row++){
        const isAfternoon = row >= SANG;
        const buoi = isAfternoon ? "chieu" : "sang";
        const ti = isAfternoon ? (row - SANG) : row;
        h += `<tr${row===SANG ? " class=\"split-row\"" : ""}>`;
        DAYS.forEach(d => {
          const entries = isAfternoon ? sched[d].chieu[ti] : sched[d].sang[ti];
          h += cellHTMLPhong(entries, d, buoi, ti);
        });
        h += "</tr>";
      }
      return h + "</table>";
    }

    function pvBlankTimetableHTML(){
      let h = "<table class='table tkb-support-table'><tr>";
      DAYS.forEach(d => h += `<th>${LABEL[d]}</th>`);
      h += "</tr>";
      const TOTAL = SANG + CHIEU;
      for(let row=0; row<TOTAL; row++){
        h += `<tr${row===SANG ? " class=\"split-row\"" : ""}>`;
        DAYS.forEach(()=>{ h += `<td draggable="false"><div class="tkb-gv-cell"></div></td>`; });
        h += "</tr>";
      }
      return h + "</table>";
    }

    function pvSelectHTML(id, items, current, labelFn, onchange){
      const opts = (items || []).map(v => {
        const val = String(v || "");
        return `<option value="${escapeHtml(val)}" ${val===String(current||"")?"selected":""}>${escapeHtml(labelFn ? labelFn(val) : val)}</option>`;
      }).join("");
      return `<select id="${id}" onchange="${onchange}" oninput="${onchange}" onkeydown="pairSelectKeydown(event,this)">${opts}</select>`;
    }

    function pvSortedClassIds(current){
      const ids = [];
      const lops = getFilteredLops().slice().sort((a,b)=>{
        const aa = (a.ten2 || a.ten || a.id || "").toString();
        const bb = (b.ten2 || b.ten || b.id || "").toString();
        return aa.localeCompare(bb, "vi");
      });
      lops.forEach(l=>{
        const id = l?.id;
        if(id == null) return;
        if(!ids.some(x => String(x) === String(id))) ids.push(id);
      });
      if(current && !ids.some(x => String(x) === String(current))) ids.unshift(current);
      return ids;
    }

    function pvTeacherCodes(current){
      const codes = [];
      getTeacherListForCurrentFilter().forEach(t=>{
        const code = (t?.code || "").toString().trim();
        if(code && !codes.includes(code)) codes.push(code);
      });
      const cur = (current || "").toString().trim();
      if(cur && !codes.includes(cur)) codes.unshift(cur);
      return codes;
    }

    function pvClassMainTools(classId){
      return pvSelectHTML("pairMainClassSelect", pvSortedClassIds(classId), classId, pvClassLabel, "pairSelectMainClass(this.value)");
    }

    function pvClassStatsHTML(classId){
      const st = (typeof calcClassTKBPeriodStats === "function")
        ? calcClassTKBPeriodStats(classId)
        : {total:0, assigned:0};
      const n = (v)=>{
        const x = Number(v || 0);
        return Number.isFinite(x) ? String(Math.round(x)) : "0";
      };
      return `<div class="tkb-pair-class-stats">`+
        `<span>Tổng số tiết: <b>${n(st.total)}</b></span>`+
        `<span>Đã xếp: <b>${n(st.assigned)}</b></span>`+
      `</div>`;
    }

    function pvTeacherMainTools(gvCode){
      return pvSelectHTML("pairMainTeacherSelect", pvTeacherCodes(gvCode), gvCode, pvTeacherLabel, "pairSelectMainTeacher(this.value)");
    }

    function pvSetPairStack(box, className){
      if(!box) return;
      box.classList.add("tkb-pair-stack");
      box.classList.remove("tkb-pair-lop-gv", "tkb-pair-gv-phong", "tkb-pair-lop-phong");
      if(className) box.classList.add(className);
    }

    function pvRoleLabel(title){
      const t = (title || "").toString().toLowerCase();
      if(t.includes("giáo") || t.includes("giÃ¡o")) return "GV";
      if(t.includes("phòng") || t.includes("phÃ²ng")) return "Phòng";
      if(t.includes("lớp") || t.includes("lá»›p")) return "Lớp";
      return "";
    }

    function pvPane(title, tools, body, role){
      const label = pvRoleLabel(title);
      const head = tools ? `<div class="tkb-pair-toolbar"><div class="tkb-pair-tools">${tools || ""}</div></div>` : "";
      return `<section class="tkb-pair-pane ${role||""}">
        ${head}
        <div class="tkb-pair-body">${body || ""}</div>
      </section>`;
    }

    function pvWrapMainTable(box, title, tools, role){
      const table = box.querySelector("table.table");
      if(!table) return null;
      table.classList.add("tkb-main-table");
      const label = pvRoleLabel(title);
      const stats = (role === "main" && VIEW_MODE !== "gv") ? pvClassStatsHTML(currentLop) : "";
      const head = (tools || stats) ? `<div class="tkb-pair-toolbar"><div class="tkb-pair-tools">${tools || ""}</div>${stats}</div>` : "";
      const pane = document.createElement("section");
      pane.className = `tkb-pair-pane ${role || ""}`;
      pane.innerHTML = `${head}<div class="tkb-pair-body"></div>`;
      const body = pane.querySelector(".tkb-pair-body");
      body.appendChild(table);
      box.innerHTML = "";
      box.appendChild(pane);
      return pane;
    }

    function pvBindSupportNav(root){
      (root || document).querySelectorAll(".tkb-support-table td[data-thu][data-buoi][data-ti]").forEach(td=>{
        bindSelectableCell(td);
      });
      (root || document).querySelectorAll(".tkb-support-table td[data-classids]").forEach(td=>{
        const ids = (td.dataset.classids||"").split(",").map(s=>s.trim()).filter(Boolean);
        if(!ids.length) return;
        td.style.cursor = "pointer";
        const openClassFromSupport = ()=>{
          if(ids.length === 1){
            const keepGV = (currentGV || "").toString().trim();
            setViewMode("lop");
            if(keepGV) currentGV = keepGV;
            selectLop(ids[0]);
            if(keepGV && typeof window.pairSelectTeacher === "function"){
              try{ window.pairSelectTeacher(keepGV); }catch(_){ }
            }
            return;
          }
          alert("Trùng lịch:\n" + ((td.innerText || "").trim()));
        };
        td.onclick = (e)=>{
          if(e && (e.ctrlKey || e.metaKey || e.shiftKey)) return;
          openClassFromSupport();
        };
        td.ondblclick = openClassFromSupport;
      });
    }

    function pvPairDragInfo(){
      if(!dragData) return null;
      if(dragData.type === "pairTeacherCell"){
        const from = dragData.from?.dataset || {};
        return {
          type: "cell",
          classId: dragData.classId,
          mon: dragData.mon || dragData.val || "",
          val: dragData.val || dragData.mon || "",
          fromThu: from.thu,
          fromBuoi: from.buoi,
          fromTi: Number(from.ti)
        };
      }
      if(dragData.type === "cell"){
        const from = dragData.from?.dataset || {};
        return {
          type: "cell",
          classId: currentLop,
          mon: dragData.val || "",
          val: dragData.val || "",
          fromThu: from.thu,
          fromBuoi: from.buoi,
          fromTi: Number(from.ti)
        };
      }
      if(dragData.type === "mon"){
        return {
          type: "mon",
          classId: dragData.classId || currentLop,
          mon: dragData.mon || "",
          val: dragData.mon || ""
        };
      }
      return null;
    }

    function pvValidateSupportDrop(td){
      const info = pvPairDragInfo();
      if(!info || !info.classId || !info.mon) return {ok:false, reason:"empty"};
      const thu = td.dataset.thu;
      const buoi = td.dataset.buoi;
      const ti = Number(td.dataset.ti);
      const tkb = DATA?.tkb?.[info.classId];
      if(!tkb?.[thu]?.[buoi] || !Number.isFinite(ti)) return {ok:false, reason:"runtime", msg:"Không xác định được ô đích."};
      const targetVal = tkb[thu][buoi][ti];
      if(targetVal === "OFF" || isFixed(targetVal)) return {ok:false, reason:"locked"};
      if(currentGV){
        const canon = getLopCanonById(info.classId);
        const gv = getTeacherForClassMon(canon, info.mon);
        if(String(gv || "").trim() !== String(currentGV || "").trim()){
          return {ok:false, reason:"teacher conflict", msg:"Tiết này không thuộc giáo viên đang xem ở bảng dưới."};
        }
      }

      const oldLop = currentLop;
      try{
        currentLop = info.classId;
        return validateDrop(td, info.mon);
      }finally{
        currentLop = oldLop;
      }
    }

    function pvApplySupportDrop(td){
      const info = pvPairDragInfo();
      if(!info) return;
      const thu = td.dataset.thu;
      const buoi = td.dataset.buoi;
      const ti = Number(td.dataset.ti);
      const res = pvValidateSupportDrop(td);
      if(!res.ok){
        flashInvalid(td);
        showDropError(res, td);
        return;
      }
      if(res.warn && Array.isArray(res.conflicts) && res.conflicts.length){
        const ok = confirm(res.confirmText || buildReplaceConfirmText(res.conflicts));
        if(!ok){
          flashInvalid(td);
          return;
        }
        clearConflictSlots(res.conflicts);
      }

      const tkb = DATA?.tkb?.[info.classId];
      if(!tkb?.[thu]?.[buoi]) return;
      if(info.type === "cell" && info.fromThu && info.fromBuoi && Number.isFinite(info.fromTi)){
        tkb[info.fromThu][info.fromBuoi][info.fromTi] = "";
      }
      tkb[thu][buoi][ti] = info.val || info.mon;

      try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
      try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
      try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }
      clearDragVisual();
      dragData = null;
      dragMon = "";
    }

    function pvBindTeacherSupportDrag(root){
      (root || document).querySelectorAll(".tkb-support-table td[data-pair-slot='teacher']").forEach(td=>{
        td.ondragstart = (e)=>{
          const classId = (td.dataset.classid || "").toString().trim();
          const mon = (td.dataset.mon || "").toString().trim();
          const thu = td.dataset.thu;
          const buoi = td.dataset.buoi;
          const ti = Number(td.dataset.ti);
          if(!classId || !mon || !thu || !buoi || !Number.isFinite(ti)){
            try{ e.preventDefault(); }catch(_){}
            return;
          }
          const raw = DATA?.tkb?.[classId]?.[thu]?.[buoi]?.[ti];
          if(!raw || raw === "OFF" || isFixed(raw)){
            try{ e.preventDefault(); }catch(_){}
            return;
          }
          dragData = { type:"pairTeacherCell", classId, from:td, val:raw, mon };
          dragMon = mon;
          try{ e.dataTransfer.setData("text/plain", mon); }catch(_){}
          applyDragVisual(mon, td);
        };
        td.ondragend = ()=>{
          clearDragVisual();
          dragData = null;
          dragMon = "";
        };
        td.ondragover = (e)=>{
          if(!dragData) return;
          try{ e.preventDefault(); }catch(_){}
          const res = pvValidateSupportDrop(td);
          setDropHint(td, res.ok && !res.warn);
        };
        td.ondragenter = ()=>{
          if(!dragData) return;
          td.classList.add("drag-over");
        };
        td.ondragleave = ()=>{
          td.classList.remove("drag-over", "drop-valid", "drop-invalid");
        };
        td.ondrop = (e)=>{
          if(!dragData) return;
          try{ e.preventDefault(); }catch(_){}
          pvApplySupportDrop(td);
        };
      });
    }

    function pvUpdateTeacherSupport(classId){
      const root = document.getElementById("tkbPairSupport");
      if(!root) return;
      const gv = pvEnsureTeacherForClass(classId);
      const teachers = pvTeachersForClass(classId);
      const tools = pvSelectHTML("pairTeacherSelect", teachers, gv, pvTeacherLabel, "pairSelectTeacher(this.value)");
      root.innerHTML = pvPane("TKB giáo viên", tools, pvTeacherTableHTML(gv), "support");
      pvBindSupportNav(root);
      pvBindTeacherSupportDrag(root);
    }

    window.pairSelectTeacher = function(code){
      currentGV = (code || "").toString().trim();
      if(VIEW_MODE === "lop") pvUpdateTeacherSupport(currentLop);
      else renderCurrentView();
    };

    window.pairSelectRoom = function(room){
      currentPhong = (room || "").toString().trim();
      renderCurrentView();
    };

    window.pairSelectClass = function(classId){
      currentLop = (classId || "").toString();
      renderCurrentView();
    };

    window.pairSelectMainClass = function(classId){
      const id = (classId || "").toString();
      if(!id) return;
      selectLop(id);
    };

    window.pairSelectMainTeacher = function(code){
      const gv = (code || "").toString().trim();
      if(!gv) return;
      selectGV(gv);
    };

    window.pairSelectKeydown = function(e, sel){
      try{
        const key = e?.key || "";
        if(key !== "ArrowDown" && key !== "ArrowUp") return;
        if(!sel || !sel.options || sel.options.length <= 0) return;
        e.preventDefault();
        const dir = key === "ArrowDown" ? 1 : -1;
        const next = Math.max(0, Math.min(sel.options.length - 1, Number(sel.selectedIndex || 0) + dir));
        if(next === sel.selectedIndex) return;
        sel.selectedIndex = next;
        sel.dispatchEvent(new Event("change", {bubbles:true}));
      }catch(err){
        console.error("[phanmon] pair select keydown failed", err);
      }
    };

    renderTKB = function(id){
      if(VIEW_MODE === "phong"){
        return pvRenderClassRoomPair(id);
      }
      if(VIEW_MODE !== "lop"){
        return __origRenderTKB(id);
      }
      __origRenderTKB(id);
      const box = document.getElementById("tkb");
      if(!box) return;
      pvSetPairStack(box, "tkb-pair-lop-gv");
      const classTitle = "TKB lớp " + pvClassLabel(id);
      pvWrapMainTable(box, classTitle, pvClassMainTools(id), "main");
      try{
        const gv = pvEnsureTeacherForClass(id);
        const teachers = pvTeachersForClass(id);
        const tools = pvSelectHTML("pairTeacherSelect", teachers, gv, pvTeacherLabel, "pairSelectTeacher(this.value)");
        box.insertAdjacentHTML("beforeend", `<div id="tkbPairSupport">${pvPane("TKB giáo viên", tools, pvTeacherTableHTML(gv), "support")}</div>`);
      }catch(err){
        console.error("[phanmon] render teacher support failed", err);
        const fallback = '<div class="tkb-pair-empty">Chua tai duoc TKB giao vien</div>';
        box.insertAdjacentHTML("beforeend", `<div id="tkbPairSupport">${pvPane("TKB giáo viên", "", fallback, "support")}</div>`);
      }
      const mainTable = box.querySelector(".tkb-main-table");
      if(mainTable){
        mainTable.querySelectorAll("td[data-mon]").forEach(td=>{
          td.addEventListener("click", ()=>{
            const mon = td.dataset.mon || "";
            if(!mon) return;
            const gv2 = getTeacherForClassMon(getLopCanonById(id), mon);
            if(!gv2 || gv2 === currentGV) return;
            currentGV = gv2;
            pvUpdateTeacherSupport(id);
          });
        });
      }
      pvBindSupportNav(box);
      pvBindTeacherSupportDrag(box);
    };

    function pvRenderClassRoomPair(classId){
      const id = classId || currentLop || (getFilteredLops()[0]?.id);
      if(!id){
        const box0 = document.getElementById("tkb");
        if(box0) box0.innerHTML = "";
        return;
      }
      currentLop = id;
      __origRenderTKB(id);
      const box = document.getElementById("tkb");
      if(!box) return;
      pvSetPairStack(box, "tkb-pair-lop-phong");
      pvWrapMainTable(box, "TKB lớp " + pvClassLabel(id), pvClassMainTools(id), "main");
      const rooms = pvRoomsForClass(id);
      const room = pvEnsureRoomForClass(id);
      const toolsRoom = rooms.length ? pvSelectHTML("pairRoomSelect", rooms, room, null, "pairSelectRoom(this.value)") : "";
      box.insertAdjacentHTML("beforeend", `<div id="tkbPairSupport">${pvPane("TKB phòng", toolsRoom, pvRoomTableHTML(room), "support")}</div>`);
      pvBindSupportNav(box);
    }

    renderTKBTeacher = function(gvCode){
      if(VIEW_MODE !== "gv"){
        return __origRenderTKBTeacher(gvCode);
      }
      __origRenderTKBTeacher(gvCode);
      const box = document.getElementById("tkb");
      if(!box) return;
      pvSetPairStack(box, "tkb-pair-gv-phong");
      const gv = (gvCode || "").toString().trim();
      const title = "TKB giáo viên " + pvTeacherLabel(gv);
      const rooms = pvRoomsForTeacher(gv);
      const room = pvEnsureRoomForTeacher(gv);
      pvWrapMainTable(box, title, pvTeacherMainTools(gv), "main");
      const tools = pvSelectHTML("pairRoomSelect", rooms, room, null, "pairSelectRoom(this.value)");
      box.insertAdjacentHTML("beforeend", `<div id="tkbPairSupport">${pvPane("TKB phòng", tools, pvRoomTableHTML(room), "support")}</div>`);
      pvBindSupportNav(box);
    };

    renderTKBPhong = function(roomName){
      if(VIEW_MODE !== "phong"){
        return __origRenderTKBPhong(roomName);
      }
      currentPhong = (roomName || currentPhong || "").toString().trim();
      return pvRenderClassRoomPair(currentLop);
    };

    document.addEventListener("DOMContentLoaded", pvSetButtonText);
    pvSetButtonText();
  }catch(e){
    console.error("[phanmon] paired view patch failed", e);
  }
})();
