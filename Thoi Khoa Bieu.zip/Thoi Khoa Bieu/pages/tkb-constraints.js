/* =========================================================
   tkb-constraints.js — CLEAN FULL CONSTRAINTS 2026-04-30
   - Model sạch theo hướng VietSchool
   - Có nhóm dữ liệu dùng chung: lớp / giáo viên / môn / phòng
   - Hoàn thiện giao diện + dữ liệu + engine cho:
     1) Yêu cầu giáo viên
     2) Yêu cầu môn học
     3) Yêu cầu nhóm môn học
     4) Cố định tiết nghỉ
     5) Giới hạn số tiết / 1 thời điểm
     6) Xóa ràng buộc
   - Không mô phỏng nguyên xi giao diện desktop; ảnh SmartScheduler chỉ dùng để đối chiếu cấu trúc mục/cột.
   ========================================================= */
(function(){
  'use strict';

  const VERSION = 'constraints-integrated-autofix-v4-2026-05-01';
  const PANEL_ID = 'tkbConstraintsFullPanel';
  const STYLE_ID = 'tkbConstraintsFullStyle';
  const DAY_KEYS_DEFAULT = ['thu2','thu3','thu4','thu5','thu6','thu7'];
  const DAY_LABEL_DEFAULT = {thu2:'Thứ 2',thu3:'Thứ 3',thu4:'Thứ 4',thu5:'Thứ 5',thu6:'Thứ 6',thu7:'Thứ 7'};
  const SESSION_KEYS = ['sang','chieu'];
  const SESSION_LABEL = {sang:'Sáng', chieu:'Chiều'};

  const TEACHER_RULES = [
    ['maxDaysSessions', 'Giới hạn số ngày dạy & buổi dạy/1 tuần'],
    ['maxPeriods', 'Giới hạn số tiết dạy/1 buổi'],
    ['maxPeriodsClass', 'Giới hạn số tiết dạy/1 lớp/1 buổi'],
    ['lessonPlans', 'Giới hạn số giáo án/1 buổi'],
    ['maxMorningAfternoon', 'Giới hạn số buổi dạy sáng & chiều'],
    ['oneSessionPerDay', 'Chỉ dạy 1 buổi/1 ngày'],
    ['noMorningP5AfternoonP1', 'Không dạy tiết 5 buổi sáng & tiết 1 buổi chiều'],
    ['oneLocationPerSession', 'Chỉ dạy 1 địa điểm/1 buổi'],
    ['gapBetweenLocations', 'Có tiết trống giữa 2 địa điểm'],
    ['maxOneMovePerSession', 'Không di chuyển 2 lần/1 buổi giữa các địa điểm']
  ];

  const SUBJECT_RULES = [
    ['lessonBlocks', 'Số buổi học có tiết học xếp liền'],
    ['avoidBreakPairs', 'Tránh xếp tiết học xếp liền vào tiết 2-3, 3-4'],
    ['linkedDays', 'Tránh xếp tiết học xếp liền vào các thứ trong tuần'],
    ['sessionAllowed', 'Giới hạn buổi học của môn học'],
    ['weeklySessionPeriods', 'Giới hạn số tiết của môn học/1 buổi/1 tuần'],
    ['spacingDays', 'Học cách ngày'],
    ['maxPeriods', 'Giới hạn số tiết/1 buổi'],
    ['maxSessions', 'Giới hạn số buổi học'],
    ['globalLimit', 'Giới hạn số lớp học, giáo viên, phòng học'],
    ['fixedOff', 'Cố định tiết nghỉ môn học']
  ];

  const SUBJECT_GROUP_RULES = [
    ['sessionAllowed', 'Giới hạn buổi học'],
    ['weeklySessionPeriods', 'Giới hạn số tiết của nhóm môn học/1 buổi/1 tuần'],
    ['maxPeriods', 'Giới hạn số tiết/1 buổi'],
    ['maxSubjects', 'Giới hạn số môn học/1 buổi'],
    ['maxSessions', 'Giới hạn số buổi học'],
    ['globalLimit', 'Giới hạn số lớp học, giáo viên, phòng học'],
    ['groupLimit', 'Giới hạn nhóm lớp học, giáo viên, phòng học/1 buổi'],
    ['fixedOff', 'Cố định tiết nghỉ nhóm môn học']
  ];

  const FIXED_OFF_TYPES = [
    ['class', 'Cố định tiết nghỉ lớp học'],
    ['teacher', 'Cố định tiết nghỉ giáo viên'],
    ['subject', 'Cố định tiết nghỉ môn học'],
    ['room', 'Cố định tiết nghỉ phòng học']
  ];

  const state = {
    section: 'teacher',
    teacherRule: 'maxDaysSessions',
    subjectRule: 'lessonBlocks',
    subjectGroupRule: 'sessionAllowed',
    fixedType: 'class',
    groupType: 'subject',
    groupId: '',
    teacherGroup: '',
    teacherSubjectGroupId: '__all__',
    classGroup: '',
    subjectId: '',
    subjectGroupId: '',
    search: '',
    fixedSelected: { class:'', teacher:'', subject:'', room:'', subjectGroup:'' }
  };

  /* ===================== BASICS ===================== */
  function D(){
    try{
      if(typeof DATA !== 'undefined'){
        if(!DATA || typeof DATA !== 'object') DATA = {};
        return DATA;
      }
    }catch(_){ }
    window.DATA = window.DATA || {};
    return window.DATA;
  }
  function days(){ try{ if(typeof DAYS !== 'undefined' && Array.isArray(DAYS) && DAYS.length) return DAYS; }catch(_){ } return DAY_KEYS_DEFAULT; }
  function dayLabel(k){ try{ if(typeof LABEL !== 'undefined' && LABEL && LABEL[k]) return LABEL[k]; }catch(_){ } return DAY_LABEL_DEFAULT[k] || k; }
  function sessionLen(buoi){ try{ if(buoi === 'sang') return Number(typeof SANG !== 'undefined' ? SANG : 5) || 5; if(buoi === 'chieu') return Number(typeof CHIEU !== 'undefined' ? CHIEU : 5) || 5; }catch(_){ } return 5; }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch])); }
  function norm(s){ return String(s == null ? '' : s).normalize('NFC').trim().replace(/\s+/g,' ').toLowerCase(); }
  function cleanId(s, prefix){
    let x = String(s == null ? '' : s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/Đ/g,'D')
      .trim().toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'');
    if(!x) x = (prefix || 'group') + '_' + Date.now();
    return x;
  }
  function toInt(v, def){ if(v === '' || v == null) return def; const n = Number(v); return Number.isFinite(n) ? Math.round(n) : def; }
  function truthy(v){ return v === true || v === 'true' || v === 1 || v === '1' || v === 'on'; }
  function arrUnique(a){ return Array.from(new Set((a||[]).map(x => String(x == null ? '' : x).trim()).filter(Boolean))); }
  function slotKey(thu, buoi, ti){ return String(thu)+'|'+String(buoi)+'|'+String(Number(ti)); }
  function parseSlotKey(k){ const p = String(k||'').split('|'); return {thu:p[0]||'', buoi:p[1]||'', ti:Number(p[2]||0)}; }
  function getPath(obj, path, def){ let cur = obj; for(const p of String(path||'').split('.')){ if(!p) continue; if(cur == null || typeof cur !== 'object' || !(p in cur)) return def; cur = cur[p]; } return cur == null ? def : cur; }
  function setPath(obj, path, val){ const parts = String(path||'').split('.').filter(Boolean); let cur = obj; for(let i=0;i<parts.length-1;i++){ const p=parts[i]; if(!cur[p] || typeof cur[p] !== 'object') cur[p] = {}; cur=cur[p]; } if(parts.length) cur[parts[parts.length-1]] = val; }
  function delEmpty(obj){
    if(!obj || typeof obj !== 'object') return obj;
    Object.keys(obj).forEach(k=>{
      const v = obj[k];
      if(v && typeof v === 'object' && !Array.isArray(v)) delEmpty(v);
      if(v === '' || v == null || (typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length === 0)) delete obj[k];
    });
    return obj;
  }
  function saveStoreSafe(){ try{ if(typeof saveStore === 'function') saveStore(); else if(typeof window.saveStore === 'function') window.saveStore(); }catch(e){ console.warn('[tkb-constraints] saveStore failed', e); } }
  function rerenderSafe(){ try{ if(typeof renderCurrentView === 'function') renderCurrentView(); }catch(_){ } try{ if(typeof loadMonList === 'function') loadMonList(); }catch(_){ } }
  function cellMonSafe(v){
    try{ if(typeof cellMon === 'function') return String(cellMon(v) || '').trim(); }catch(_){ }
    try{ if(typeof window.cellMon === 'function') return String(window.cellMon(v) || '').trim(); }catch(_){ }
    if(v === 'OFF' || v === '' || v == null) return '';
    if(typeof v === 'string') return v.trim();
    if(v && typeof v === 'object' && v.mon) return String(v.mon || '').trim();
    return '';
  }
  function isFixedSafe(v){ try{ if(typeof isFixed === 'function') return !!isFixed(v); }catch(_){ } try{ if(typeof window.isFixed === 'function') return !!window.isFixed(v); }catch(_){ } return !!(v && typeof v === 'object' && v.fixed); }
  function classCanon(lopId){
    try{ if(typeof getLopCanonById === 'function') return String(getLopCanonById(lopId)||'').trim(); }catch(_){ }
    try{ if(typeof window.getLopCanonById === 'function') return String(window.getLopCanonById(lopId)||'').trim(); }catch(_){ }
    const lop = (D().lop || []).find(l => String(l.id) === String(lopId));
    return String((lop && (lop.ten2 || lop.ten || lop.id)) || lopId || '').trim();
  }
  function teacherOf(lopId, mon){
    try{ if(typeof getTeacherForClassMon === 'function') return String(getTeacherForClassMon(classCanon(lopId), mon) || '').trim(); }catch(_){ }
    try{ if(typeof window.getTeacherForClassMon === 'function') return String(window.getTeacherForClassMon(classCanon(lopId), mon) || '').trim(); }catch(_){ }
    const key1 = classCanon(lopId) + '|' + String(mon||'').trim();
    const key2 = String(lopId||'') + '|' + String(mon||'').trim();
    return String(D().pccmMatrix?.[key1] || D().pccmMatrix?.[key2] || '').trim();
  }
  function roomOf(lopId, mon){
    try{ if(typeof getRoomForClassMon === 'function') return String(getRoomForClassMon(classCanon(lopId), mon) || '').trim(); }catch(_){ }
    try{ if(typeof window.getRoomForClassMon === 'function') return String(window.getRoomForClassMon(classCanon(lopId), mon) || '').trim(); }catch(_){ }
    const key1 = classCanon(lopId) + '|' + String(mon||'').trim();
    const key2 = String(lopId||'') + '|' + String(mon||'').trim();
    return String(D().pccmRoomMatrix?.[key1] || D().pccmRoomMatrix?.[key2] || '').trim();
  }
  function teacherName(code){
    const c = String(code||'').trim(); if(!c) return '';
    try{ if(typeof getTeacherNameByCode === 'function') return String(getTeacherNameByCode(c) || c).trim(); }catch(_){ }
    try{ if(typeof window.getTeacherNameByCode === 'function') return String(window.getTeacherNameByCode(c) || c).trim(); }catch(_){ }
    const g = (D().giaovien || []).find(x => String(x.magv || x.ma || x.code || x.id || '').trim() === c);
    if(!g) return c;
    const full = `${g.hodem||''} ${g.ten||''}`.trim();
    return full ? `${c} - ${full}` : c;
  }
  function classNameOf(id){ const l = (D().lop || []).find(x => String(x.id) === String(id)); return String((l && (l.ten2 || l.ten || l.id)) || id || '').trim(); }
  function roomLocation(roomName, lopId){
    const r = String(roomName||'').trim();
    if(r){
      const p = (D().phong || []).find(x => [x.id,x.ma,x.ten,x.name].some(v => norm(v) === norm(r)));
      if(p){ const d = String(p.diadiem || p.diaDiem || p.khu || p.location || '').trim(); if(d) return d; }
      return r;
    }
    const l = (D().lop || []).find(x => String(x.id) === String(lopId));
    return String((l && (l.diadiem || l.diaDiem || l.khu || l.location)) || '').trim();
  }

  /* ===================== MODEL ===================== */
  function emptyModel(){
    return {
      version: VERSION,
      groups: { class:{}, teacher:{}, subject:{}, room:{} },
      teacher: {},
      subject: {},       // subject[subjectId].byClass[classId].rule...
      subjectGroup: {},  // subjectGroup[groupId].byClass[classId].rule...
      fixedOff: { class:{}, teacher:{}, subject:{}, room:{} },
      timeLimit: [],
      meta: { updatedAt: '' }
    };
  }
  function normalizeGroup(g){ if(Array.isArray(g)) return {name:'', items: arrUnique(g)}; if(!g || typeof g !== 'object') return {name:'', items:[]}; return { name:String(g.name || g.label || '').trim(), items: arrUnique(g.items || g.members || g.list || []) }; }
  function normalizeModel(c){
    const d = emptyModel();
    c.version = c.version || VERSION;
    c.groups = Object.assign({}, d.groups, c.groups || {});
    ['class','teacher','subject','room'].forEach(t=>{ c.groups[t] = c.groups[t] || {}; Object.keys(c.groups[t]).forEach(id=>{ c.groups[t][id] = normalizeGroup(c.groups[t][id]); if(!c.groups[t][id].name) c.groups[t][id].name = id; }); });
    c.teacher = c.teacher || {};
    c.subject = c.subject || {};
    c.subjectGroup = c.subjectGroup || {};
    c.fixedOff = Object.assign({}, d.fixedOff, c.fixedOff || {});
    ['class','teacher','subject','room'].forEach(t=>{ c.fixedOff[t] = c.fixedOff[t] || {}; });
    c.timeLimit = Array.isArray(c.timeLimit) ? c.timeLimit : [];
    c.meta = c.meta || {};
    // migrate từ các bản tạm cũ nếu có
    try{ if(c.teacherFinal && c.teacherFinal.rules && !Object.keys(c.teacher).length) c.teacher = JSON.parse(JSON.stringify(c.teacherFinal.rules || {})); }catch(_){ }
    try{ if(c.subjectFinal && c.subjectFinal.rules && !Object.keys(c.subject).length) c.subject = JSON.parse(JSON.stringify(c.subjectFinal.rules || {})); }catch(_){ }
    try{ if(c.subjectGroupFinal && c.subjectGroupFinal.rules && !Object.keys(c.subjectGroup).length) c.subjectGroup = JSON.parse(JSON.stringify(c.subjectGroupFinal.rules || {})); }catch(_){ }
    return c;
  }
  function model(){
    const data = D();
    if(!data.tkbConstraints || typeof data.tkbConstraints !== 'object' || data.tkbConstraints.__normalizedBy !== VERSION){
      data.tkbConstraints = normalizeModel(data.tkbConstraints || emptyModel());
      try{ Object.defineProperty(data.tkbConstraints, '__normalizedBy', {value: VERSION, writable: true, enumerable: false}); }
      catch(_){ data.tkbConstraints.__normalizedBy = VERSION; }
    }
    return data.tkbConstraints;
  }
  function touchSave(){ const c = model(); c.version = VERSION; c.meta.updatedAt = new Date().toISOString(); invalidateConstraintCache(); saveStoreSafe(); }

  /* ===================== DATA LISTS ===================== */
  function getClassList(){
    const map = new Map();
    (D().lop || []).forEach(l=>{ const id=String(l.id || l.ten2 || l.ten || '').trim(); if(id) map.set(id,{id,name:String(l.ten2 || l.ten || id).trim()}); });
    Object.keys(D().tkb || {}).forEach(id=>{ if(!map.has(id)) map.set(id,{id,name:classNameOf(id)}); });
    Object.keys(D().pccmMatrix || {}).forEach(k=>{ const cls=String(k).split('|')[0] || ''; if(cls && !Array.from(map.values()).some(x=>norm(x.name)===norm(cls))) map.set(cls,{id:cls,name:cls}); });
    return Array.from(map.values()).sort((a,b)=>a.name.localeCompare(b.name,'vi'));
  }
  function getTeacherList(){
    const sig = dataListSignature('teacher');
    if(__cache.teacherList && __cache.teacherListSig === sig) return __cache.teacherList;
    const map = new Map();
    (D().giaovien || []).forEach(g=>{ const id=String(g.magv || g.ma || g.code || g.id || g.ten || '').trim(); if(id) map.set(id,{id,name:teacherName(id)}); });
    Object.values(D().pccmMatrix || {}).forEach(v=>{ const id=String(v || '').trim(); if(id && !map.has(id)) map.set(id,{id,name:teacherName(id)}); });
    __cache.teacherList = Array.from(map.values()).sort((a,b)=>a.name.localeCompare(b.name,'vi'));
    __cache.teacherListSig = sig;
    return __cache.teacherList;
  }
  function getSubjectList(){
    // Cache danh sách môn: hàm này trước đây quét toàn bộ DATA.tkb mỗi lần canPlaceLesson, gây đơ khi tối ưu.
    try{
      const sig = quickTkbSignature();
      if(__cache.subjectList && __cache.subjectListSig === sig) return __cache.subjectList;
      const map = new Map();
      function add(x){ const id=String(x||'').trim(); if(id && !map.has(norm(id))) map.set(norm(id),{id,name:id}); }
      (D().monhoc || []).forEach(m=>{ add(m.ten || m.ma || m.ma2 || m.id); [m.ten,m.ma,m.ma2,m.id].forEach(add); });
      (D().mon || []).forEach(m=>{ add(m.ten || m.mon || m.ma || m.mamon || m.id); });
      Object.keys(D().pccmMatrix || {}).forEach(k=>{ const p=String(k).split('|'); add(p.slice(1).join('|')); });
      if(!map.size) Object.values(D().tkb || {}).forEach(tkb=>{ days().forEach(thu=>SESSION_KEYS.forEach(buoi=>(tkb?.[thu]?.[buoi]||[]).forEach(v=>add(cellMonSafe(v))))); });
      __cache.subjectList = Array.from(map.values()).sort((a,b)=>a.name.localeCompare(b.name,'vi'));
      __cache.subjectListSig = sig;
      __cache.subjectKeyMap.clear();
      return __cache.subjectList;
    }catch(_){ return []; }
  }
  function getRoomList(){
    const map = new Map(); function add(x){ const id=String(x||'').trim(); if(id && !map.has(norm(id))) map.set(norm(id),{id,name:id}); }
    (D().phong || []).forEach(p=>add(p.ten || p.ma || p.id || p.name)); Object.values(D().pccmRoomMatrix || {}).forEach(add);
    return Array.from(map.values()).sort((a,b)=>a.name.localeCompare(b.name,'vi'));
  }
  function listByType(type){ if(type==='class') return getClassList(); if(type==='teacher') return getTeacherList(); if(type==='subject') return getSubjectList(); if(type==='room') return getRoomList(); return []; }
  function itemName(type, id){ const x=listByType(type).find(i=>String(i.id)===String(id)); return x ? x.name : String(id||''); }
  function groupOptions(type, selected){ const c=model(); return Object.entries(c.groups[type] || {}).map(([id,g])=>`<option value="${esc(id)}" ${String(id)===String(selected)?'selected':''}>${esc(g.name || id)}</option>`).join(''); }
  function syncDefaultGroups(){
    const c = model(); const cls=getClassList(), teachers=getTeacherList(), subjects=getSubjectList(), rooms=getRoomList();
    if(!c.groups.class.all) c.groups.class.all = {name:'Tất cả lớp', items: cls.map(x=>x.id)}; else if(c.groups.class.all.name === 'Tất cả lớp') c.groups.class.all.items = cls.map(x=>x.id);
    if(!c.groups.teacher.all) c.groups.teacher.all = {name:'Tất cả giáo viên', items: teachers.map(x=>x.id)}; else if(c.groups.teacher.all.name === 'Tất cả giáo viên') c.groups.teacher.all.items = teachers.map(x=>x.id);
    if(!c.groups.subject.all) c.groups.subject.all = {name:'Tất cả môn học', items: subjects.map(x=>x.id)}; else if(c.groups.subject.all.name === 'Tất cả môn học') c.groups.subject.all.items = subjects.map(x=>x.id);
    if(!c.groups.room.all) c.groups.room.all = {name:'Tất cả phòng học', items: rooms.map(x=>x.id)}; else if(c.groups.room.all.name === 'Tất cả phòng học') c.groups.room.all.items = rooms.map(x=>x.id);
    cls.forEach(x=>{ const m=String(x.name||x.id).match(/\d+/); if(!m) return; const id='khoi_'+m[0]; if(!c.groups.class[id]) c.groups.class[id]={name:'Khối '+m[0],items:[]}; if(!c.groups.class[id].items.includes(x.id)) c.groups.class[id].items.push(x.id); });
    return c;
  }
  function groupItems(type, groupId){ const g=model().groups[type]?.[groupId]; return g && Array.isArray(g.items) ? g.items : []; }
  function classFilterRows(){ const all=getClassList(); const gid=state.classGroup || 'all'; const items = new Set(groupItems('class', gid)); if(gid && items.size) return all.filter(x=>items.has(x.id)); return all; }

  /* ===================== MATCHING HELPERS ===================== */
  function subjectAliases(mon){
    const s=String(mon||'').trim(); const out=new Set([norm(s)]);
    try{ const mh=(D().monhoc||[]).find(m=>[m.ten,m.ma,m.ma2,m.id].some(v=>norm(v)===norm(s))); if(mh) [mh.ten,mh.ma,mh.ma2,mh.id].forEach(v=>{ if(v) out.add(norm(v)); }); }catch(_){ }
    try{ const mh=(D().mon||[]).find(m=>[m.ten,m.mon,m.ma,m.mamon,m.id].some(v=>norm(v)===norm(s))); if(mh) [mh.ten,mh.mon,mh.ma,mh.mamon,mh.id].forEach(v=>{ if(v) out.add(norm(v)); }); }catch(_){ }
    return out;
  }
  function subjectMatches(a,b){ const A=subjectAliases(a); const B=subjectAliases(b); for(const x of A) if(B.has(x)) return true; return false; }
  function subjectKey(mon){
    const raw=String(mon||'').trim(); const key=norm(raw); if(__cache.subjectKeyMap.has(key)) return __cache.subjectKeyMap.get(key);
    const found=getSubjectList().find(x=>subjectMatches(x.id, raw)); const out=found ? found.id : raw;
    __cache.subjectKeyMap.set(key,out); return out;
  }
  function subjectInGroup(mon, groupId){ const g=model().groups.subject?.[groupId]; if(!g || !Array.isArray(g.items) || !g.items.length) return false; return g.items.some(it=>subjectMatches(it, mon)); }
  function subjectGroupsOf(mon){ const c=model(); return Object.keys(c.groups.subject || {}).filter(gid=>subjectInGroup(mon, gid)); }


  /* ===================== PERFORMANCE CACHE ===================== */
  let __cacheRev = 1;
  const __cache = { signature: '', allCells: null, byTeacher: null, classCells: null, subjectListSig: '', subjectList: null, teacherListSig: '', teacherList: null, teacherStatsSig: '', teacherStats: null, subjectKeyMap: new Map(), lastWarnAt: 0 };
  function invalidateConstraintCache(){ __cacheRev++; __cache.signature=''; __cache.allCells=null; __cache.byTeacher=null; __cache.classCells=null; __cache.subjectListSig=''; __cache.subjectList=null; __cache.teacherListSig=''; __cache.teacherList=null; __cache.teacherStatsSig=''; __cache.teacherStats=null; __cache.subjectKeyMap.clear(); }
  function dataListSignature(type){
    try{
      const d = D();
      if(type === 'teacher') return [
        __cacheRev,
        (d.giaovien || []).length,
        Object.keys(d.pccmMatrix || {}).length
      ].join('|');
      if(type === 'teacherStats') return [
        __cacheRev,
        (d.lop || []).length,
        (d.mon || []).length,
        (d.monhoc || []).length,
        Object.keys(d.pccmMatrix || {}).length,
        Object.keys(d.tkb || {}).length
      ].join('|');
    }catch(_){ }
    return String(__cacheRev);
  }
  function quickTkbSignature(){
    // RẤT QUAN TRỌNG: hàm này nằm trong hot path khi kéo-thả/xếp tự động.
    // Không được quét toàn bộ DATA.tkb ở đây, nếu không trang sẽ đứng khi quay lại sắp xếp.
    try{
      const m = model();
      return String(__cacheRev) + '|' + String(m.meta?.updatedAt || '') + '|' +
        Object.keys(m.teacher || {}).length + '|' + Object.keys(m.subject || {}).length + '|' +
        Object.keys(m.subjectGroup || {}).length + '|' + (m.timeLimit || []).length;
    }catch(_){ return String(__cacheRev); }
  }
  function buildScheduleIndex(){
    const sig=quickTkbSignature(); if(__cache.allCells && __cache.signature===sig) return __cache;
    __cache.signature=sig; __cache.allCells=[]; __cache.byTeacher=new Map(); __cache.classCells=new Map();
    const tkbs=D().tkb||{};
    for(const lopId of Object.keys(tkbs)){
      const classArr=[]; const tkb=tkbs[lopId]; if(!tkb) continue;
      for(const thu of days()) for(const buoi of SESSION_KEYS){ const arr=tkb?.[thu]?.[buoi]||[]; for(let ti=0; ti<arr.length; ti++){
        const v=arr[ti]; if(v==='OFF'||!v||isFixedSafe(v)) continue; const mon=cellMonSafe(v); if(!mon) continue;
        const teacher=teacherOf(lopId,mon); const room=roomOf(lopId,mon); const cell={lopId:String(lopId),mon,thu,buoi,ti:Number(ti),teacher,room,location:roomLocation(room,lopId)};
        __cache.allCells.push(cell); classArr.push(cell);
        if(teacher){ const k=String(teacher).trim(); if(!__cache.byTeacher.has(k)) __cache.byTeacher.set(k,[]); __cache.byTeacher.get(k).push(cell); }
      }}
      __cache.classCells.set(String(lopId), classArr);
    }
    return __cache;
  }
  function isSameSlotCell(cell, slot){ return !!slot && String(cell.lopId)===String(slot.lopId) && String(cell.thu)===String(slot.thu) && String(cell.buoi)===String(slot.buoi) && Number(cell.ti)===Number(slot.ti); }
  function targetSlotFromCtx(ctx){ return ctx ? {lopId:String(ctx.lopId||currentClassId()||''),thu:String(ctx.thu||''),buoi:String(ctx.buoi||''),ti:Number(ctx.ti)} : null; }
  function candidateCellFromCtx(ctx){ if(!ctx||!ctx.mon) return null; const t=targetSlotFromCtx(ctx); if(!t||!t.lopId) return null; const mon=String(ctx.mon||'').trim(); const teacher=teacherOf(t.lopId,mon); const room=roomOf(t.lopId,mon); return {lopId:t.lopId,mon,thu:t.thu,buoi:t.buoi,ti:t.ti,teacher,room,location:roomLocation(room,t.lopId),candidate:true}; }
  function scanClassCellsFromTkb(lopId, tkb){
    const out=[]; if(!tkb) return out;
    for(const thu of days()) for(const buoi of SESSION_KEYS){ const arr=tkb?.[thu]?.[buoi]||[]; for(let ti=0; ti<arr.length; ti++){
      const v=arr[ti]; if(v==='OFF'||!v||isFixedSafe(v)) continue; const mon=cellMonSafe(v); if(!mon) continue; const teacher=teacherOf(lopId,mon); const room=roomOf(lopId,mon); out.push({lopId:String(lopId),mon,thu,buoi,ti:Number(ti),teacher,room,location:roomLocation(room,lopId)});
    }}
    return out;
  }
  function sourceSlotFromCtx(ctx){ return sourceFromCtx(ctx||{}); }
  function classCellsAfterPlace(lopId, ctx, pred){
    const target=targetSlotFromCtx(Object.assign({},ctx||{},{lopId})); const src=sourceSlotFromCtx(ctx||{});
    let base;
    if(ctx && ctx.localTkb && String(lopId)===String(ctx.lopId||currentClassId())) base=scanClassCellsFromTkb(lopId,ctx.localTkb);
    else base=buildScheduleIndex().classCells.get(String(lopId))||[];
    const cand=candidateCellFromCtx(Object.assign({},ctx||{},{lopId})); const out=[];
    for(const cell of base){ if(isSameSlotCell(cell,src)||isSameSlotCell(cell,target)) continue; if(!pred||pred(cell)) out.push(cell); }
    if(cand && (!pred||pred(cand))) out.push(cand);
    return out;
  }
  /* ===================== SCHEDULE SCAN ===================== */
  function currentClassId(){ try{ if(typeof currentLop !== 'undefined' && currentLop != null) return String(currentLop); }catch(_){ } return String(window.currentLop || ''); }
  function inferClassIdFromTkb(ref){
    // Khi sapXepTuDongAll() chạy toàn trường, currentLop thường vẫn là lớp đang xem,
    // không phải lớp đang được engine xếp. Phải suy ngược classId từ object TKB truyền vào.
    try{
      if(!ref || !D().tkb) return '';
      for(const id of Object.keys(D().tkb || {})){
        if(D().tkb[id] === ref) return String(id);
      }
    }catch(_){ }
    return '';
  }
  function sourceFromCtx(ctx){ const s=ctx && ctx.src; if(!s) return null; return {lopId:String(ctx.lopId||currentClassId()||''), thu:String(s.thu||''), buoi:String(s.buoi||''), ti:Number(s.ti)}; }
  function getTkbForClass(lopId, ctx){ if(ctx && ctx.localTkb && String(lopId)===String(ctx.lopId || currentClassId())) return ctx.localTkb; return D().tkb?.[lopId]; }
  function allCellsAfterPlace(ctx, filterFn){
    const target=targetSlotFromCtx(ctx||{}); const src=sourceSlotFromCtx(ctx||{}); const cand=candidateCellFromCtx(ctx||{});
    let base=buildScheduleIndex().allCells || []; let local=[];
    if(ctx && ctx.localTkb && target && target.lopId){ base=base.filter(x=>String(x.lopId)!==String(target.lopId)); local=scanClassCellsFromTkb(target.lopId,ctx.localTkb); }
    const out=[];
    for(const cell of base.concat(local)){
      if(isSameSlotCell(cell,src)||isSameSlotCell(cell,target)) continue;
      if(!filterFn||filterFn(cell)) out.push(cell);
    }
    if(cand && (!filterFn||filterFn(cand))) out.push(cand);
    return out;
  }
  function countBy(cells,pred){ let n=0; cells.forEach(x=>{ if(pred(x)) n++; }); return n; }
  function uniqueCount(cells,fn){ const s=new Set(); cells.forEach(x=>{ const v=fn(x); if(v) s.add(v); }); return s.size; }
  function sessionCells(cells, thu, buoi){ return cells.filter(x=>x.thu===thu && x.buoi===buoi); }
  function indexesInSession(cells, thu, buoi, pred){ return cells.filter(x=>x.thu===thu && x.buoi===buoi && (!pred || pred(x))).map(x=>Number(x.ti)).sort((a,b)=>a-b); }
  function countConsecutiveBlocks(indexes, len){ let c=0; const s=new Set(indexes); for(const i of indexes){ let ok=true; for(let k=0;k<len;k++) if(!s.has(i+k)) ok=false; if(ok && !s.has(i-1)) c++; } return c; }
  function hasConsecutivePair(indexes){ const s=new Set(indexes); for(const i of indexes) if(s.has(i+1)) return true; return false; }
  function dayIndex(thu){ const i=days().indexOf(thu); return i>=0 ? i : 0; }

  /* ===================== FIXED OFF ===================== */
  function isFixedOff(type, id, thu, buoi, ti){ const obj=model().fixedOff?.[type]?.[id] || {}; return !!obj[slotKey(thu,buoi,ti)]; }
  function evalFixedOff(ctx){
    const msgs=[]; if(!ctx || !ctx.mon || !ctx.thu || !ctx.buoi || ctx.ti == null) return msgs;
    const lopId=String(ctx.lopId||currentClassId()||''); const mon=String(ctx.mon||'').trim(); const thu=String(ctx.thu), buoi=String(ctx.buoi), ti=Number(ctx.ti);
    const gv=teacherOf(lopId,mon); const room=roomOf(lopId,mon);
    if(isFixedOff('class',lopId,thu,buoi,ti)) msgs.push(`Lớp ${classNameOf(lopId)} cố định nghỉ ${dayLabel(thu)} ${SESSION_LABEL[buoi]} tiết ${ti+1}.`);
    if(gv && isFixedOff('teacher',gv,thu,buoi,ti)) msgs.push(`${teacherName(gv)} cố định nghỉ ${dayLabel(thu)} ${SESSION_LABEL[buoi]} tiết ${ti+1}.`);
    const sk=subjectKey(mon); if(sk && isFixedOff('subject',sk,thu,buoi,ti)) msgs.push(`Môn ${mon} cố định nghỉ ${dayLabel(thu)} ${SESSION_LABEL[buoi]} tiết ${ti+1}.`);
    if(room && isFixedOff('room',room,thu,buoi,ti)) msgs.push(`Phòng ${room} cố định nghỉ ${dayLabel(thu)} ${SESSION_LABEL[buoi]} tiết ${ti+1}.`);
    return msgs;
  }

  /* ===================== TEACHER ENGINE ===================== */
  function teacherCellsAfterPlace(teacher, ctx){
    const gv=String(teacher||'').trim(); if(!gv) return [];
    const idx=buildScheduleIndex(); const target=targetSlotFromCtx(ctx||{}); const src=sourceSlotFromCtx(ctx||{});
    let base=idx.byTeacher.get(gv)||[]; let local=[];
    if(ctx && ctx.localTkb && target && target.lopId){ base=base.filter(x=>String(x.lopId)!==String(target.lopId)); local=scanClassCellsFromTkb(target.lopId,ctx.localTkb).filter(x=>String(x.teacher||'').trim()===gv); }
    const cand=candidateCellFromCtx(ctx||{}); const out=[];
    for(const cell of base.concat(local)){ if(isSameSlotCell(cell,src)||isSameSlotCell(cell,target)) continue; out.push(cell); }
    if(cand && String(cand.teacher||'').trim()===gv) out.push(cand);
    return out;
  }
  function evalTeacherRule(ctx){
    const msgs=[]; if(!ctx || !ctx.mon || !ctx.thu || !ctx.buoi || ctx.ti == null) return msgs;
    const lopId=String(ctx.lopId||currentClassId()||''); if(!lopId) return msgs; const mon=String(ctx.mon||'').trim(); const gv=teacherOf(lopId,mon); if(!gv) return msgs;
    const r=model().teacher?.[gv]; if(!r || typeof r!=='object') return msgs;
    const cells=teacherCellsAfterPlace(gv,Object.assign({},ctx,{lopId,mon})); const thu=String(ctx.thu), buoi=String(ctx.buoi); const label=teacherName(gv); const add=m=>{ if(m && !msgs.includes(m)) msgs.push(m); };
    const maxDays=toInt(r.maxDaysSessions?.maxDays,0), maxSessions=toInt(r.maxDaysSessions?.maxSessions,0);
    if(maxDays>0){ const n=uniqueCount(cells,x=>x.thu); if(n>maxDays) add(`${label}: vượt giới hạn số ngày dạy/tuần (${n}/${maxDays}).`); }
    if(maxSessions>0){ const n=uniqueCount(cells,x=>x.thu+'|'+x.buoi); if(n>maxSessions) add(`${label}: vượt giới hạn số buổi dạy/tuần (${n}/${maxSessions}).`); }
    const limSess=toInt(getPath(r,`maxPeriods.${buoi}.${thu}`,0),0); if(limSess>0){ const n=countBy(cells,x=>x.thu===thu&&x.buoi===buoi); if(n>limSess) add(`${label}: ${dayLabel(thu)} ${SESSION_LABEL[buoi]} có ${n} tiết, vượt giới hạn ${limSess}.`); }
    const limDay=toInt(getPath(r,`maxPeriods.day.${thu}`,0),0); if(limDay>0){ const n=countBy(cells,x=>x.thu===thu); if(n>limDay) add(`${label}: ${dayLabel(thu)} có ${n} tiết, vượt giới hạn cả ngày ${limDay}.`); }
    const mpc = r.maxPeriodsClass || {};
    const matchedGroups = Array.from(new Set(['__all__', ...subjectGroupsOf(mon)]));
    let mpcRules = [];
    if(mpc && mpc.bySubjectGroup && typeof mpc.bySubjectGroup === 'object'){
      matchedGroups.forEach(gid=>{
        const conf = mpc.bySubjectGroup?.[gid];
        if(conf && typeof conf === 'object') mpcRules.push({ gid, conf });
      });
    }
    if(!mpcRules.length){
      const legacyGroup = String(mpc.subjectGroupId || '').trim();
      if(legacyGroup){
        if(legacyGroup === '__all__' || legacyGroup === 'all' || subjectInGroup(mon, legacyGroup)){
          mpcRules.push({ gid: legacyGroup || '__all__', conf: { perSession: mpc.perSession, perDay: mpc.perDay } });
        }
      }else if(Number(mpc.perSession || 0) > 0 || Number(mpc.perDay || 0) > 0){
        mpcRules.push({ gid: '__all__', conf: { perSession: mpc.perSession, perDay: mpc.perDay } });
      }
    }
    mpcRules.forEach(it=>{
      const gid = String(it.gid || '__all__').trim();
      const conf = it.conf || {};
      const matcher = (x)=>{
        if(String(x.lopId) !== String(lopId) || String(x.thu) !== String(thu)) return false;
        if(gid === '__all__' || gid === 'all') return true;
        return subjectInGroup(x.mon, gid);
      };
      const suffix = (gid === '__all__' || gid === 'all') ? 'tất cả môn học' : ('nhóm môn ' + (model().groups.subject?.[gid]?.name || gid));
      const limClassSess = toInt(conf.perSession,0);
      if(limClassSess>0){
        const n=countBy(cells,x=>matcher(x)&&x.buoi===buoi);
        if(n>limClassSess) add(`${label}: lớp ${classNameOf(lopId)} ${dayLabel(thu)} ${SESSION_LABEL[buoi]} có ${n} tiết thuộc ${suffix}, vượt giới hạn ${limClassSess}.`);
      }
      const limClassDay = toInt(conf.perDay,0);
      if(limClassDay>0){
        const n=countBy(cells,x=>matcher(x));
        if(n>limClassDay) add(`${label}: lớp ${classNameOf(lopId)} ${dayLabel(thu)} có ${n} tiết thuộc ${suffix}, vượt giới hạn cả ngày ${limClassDay}.`);
      }
    });
    const lpSess=toInt(getPath(r,`lessonPlans.${buoi}.${thu}`,0),0); if(lpSess>0){ const n=uniqueCount(cells.filter(x=>x.thu===thu&&x.buoi===buoi),x=>norm(x.mon)); if(n>lpSess) add(`${label}: ${dayLabel(thu)} ${SESSION_LABEL[buoi]} có ${n} giáo án, vượt giới hạn ${lpSess}.`); }
    const lpDay=toInt(getPath(r,`lessonPlans.day.${thu}`,0),0); if(lpDay>0){ const n=uniqueCount(cells.filter(x=>x.thu===thu),x=>norm(x.mon)); if(n>lpDay) add(`${label}: ${dayLabel(thu)} có ${n} giáo án, vượt giới hạn cả ngày ${lpDay}.`); }
    const maxMorning=toInt(r.maxMorningAfternoon?.morning,0), maxAfternoon=toInt(r.maxMorningAfternoon?.afternoon,0);
    if(maxMorning>0){ const n=uniqueCount(cells.filter(x=>x.buoi==='sang'),x=>x.thu+'|'+x.buoi); if(n>maxMorning) add(`${label}: dạy ${n} buổi sáng/tuần, vượt giới hạn ${maxMorning}.`); }
    if(maxAfternoon>0){ const n=uniqueCount(cells.filter(x=>x.buoi==='chieu'),x=>x.thu+'|'+x.buoi); if(n>maxAfternoon) add(`${label}: dạy ${n} buổi chiều/tuần, vượt giới hạn ${maxAfternoon}.`); }
    if(truthy(r.oneSessionPerDay?.[thu])){ const hasS=cells.some(x=>x.thu===thu&&x.buoi==='sang'), hasC=cells.some(x=>x.thu===thu&&x.buoi==='chieu'); if(hasS&&hasC) add(`${label}: ${dayLabel(thu)} đang bật chỉ dạy 1 buổi/ngày nhưng có cả sáng và chiều.`); }
    if(truthy(r.noMorningP5AfternoonP1?.[thu]) || truthy(r.noMorningP5AfternoonP1?.sang?.[thu]) || truthy(r.noMorningP5AfternoonP1?.chieu?.[thu])){ const hasP5=cells.some(x=>x.thu===thu&&x.buoi==='sang'&&Number(x.ti)===4), hasP1C=cells.some(x=>x.thu===thu&&x.buoi==='chieu'&&Number(x.ti)===0); if(hasP5&&hasP1C) add(`${label}: ${dayLabel(thu)} vi phạm không dạy tiết 5 sáng và tiết 1 chiều.`); }
    for(const ruleName of ['oneLocationPerSession','gapBetweenLocations','maxOneMovePerSession']){
      if(!truthy(getPath(r,`${ruleName}.${buoi}.${thu}`,false))) continue;
      const ss=sessionCells(cells,thu,buoi).slice().sort((a,b)=>a.ti-b.ti); const withLoc=ss.map(x=>Object.assign({},x,{loc:String(x.location||x.room||'').trim()})).filter(x=>x.loc); if(withLoc.length<=1) continue;
      if(ruleName==='oneLocationPerSession'){ const n=uniqueCount(withLoc,x=>norm(x.loc)); if(n>1) add(`${label}: ${dayLabel(thu)} ${SESSION_LABEL[buoi]} vi phạm chỉ dạy 1 địa điểm/1 buổi.`); }
      if(ruleName==='gapBetweenLocations'){ for(let i=1;i<withLoc.length;i++){ if(norm(withLoc[i].loc)!==norm(withLoc[i-1].loc)&&(Number(withLoc[i].ti)-Number(withLoc[i-1].ti)<=1)){ add(`${label}: ${dayLabel(thu)} ${SESSION_LABEL[buoi]} đổi địa điểm nhưng không có tiết trống để di chuyển.`); break; } } }
      if(ruleName==='maxOneMovePerSession'){ const seq=[]; withLoc.forEach(x=>{ const v=norm(x.loc); if(v && seq[seq.length-1]!==v) seq.push(v); }); if(seq.length>2) add(`${label}: ${dayLabel(thu)} ${SESSION_LABEL[buoi]} vi phạm không di chuyển 2 lần/1 buổi giữa các địa điểm.`); }
    }
    return msgs;
  }

  /* ===================== SUBJECT ENGINE ===================== */
  function subjectRuleObj(mon){ return model().subject?.[subjectKey(mon)] || {}; }
  function byClassRule(obj, lopId){ return obj?.byClass?.[lopId] || {}; }
  function subjectCellsAfterPlace(lopId, mon, ctx){ return classCellsAfterPlace(lopId, ctx, x=>subjectMatches(x.mon, mon)); }
  function evalSubjectRule(ctx){
    const msgs=[]; if(!ctx || !ctx.mon || !ctx.thu || !ctx.buoi || ctx.ti == null) return msgs;
    const lopId=String(ctx.lopId||currentClassId()||''); if(!lopId) return msgs; const mon=String(ctx.mon||'').trim(); const thu=String(ctx.thu), buoi=String(ctx.buoi), ti=Number(ctx.ti);
    const sobj=subjectRuleObj(mon); const r=byClassRule(sobj, lopId); if(!r || !Object.keys(r).length) return msgs;
    const cells=subjectCellsAfterPlace(lopId, mon, Object.assign({},ctx,{lopId,mon})); const add=m=>{ if(m && !msgs.includes(m)) msgs.push(m); };
    const name=`${classNameOf(lopId)} - ${mon}`;
    // giới hạn buổi học
    if(r.sessionAllowed){
      const allowS = r.sessionAllowed.allowMorning !== false;
      const allowC = r.sessionAllowed.allowAfternoon !== false;
      if(buoi==='sang' && !allowS) add(`${name}: môn học không được học buổi sáng.`);
      if(buoi==='chieu' && !allowC) add(`${name}: môn học không được học buổi chiều.`);
      if(truthy(r.sessionAllowed.oneSessionPerDay)){ const hasS=cells.some(x=>x.thu===thu&&x.buoi==='sang'), hasC=cells.some(x=>x.thu===thu&&x.buoi==='chieu'); if(hasS&&hasC) add(`${name}: chỉ học 1 buổi/ngày nhưng có cả sáng và chiều.`); }
    }
    // giới hạn số tiết sáng/chiều/tuần
    const wS=toInt(r.weeklySessionPeriods?.morning,0), wC=toInt(r.weeklySessionPeriods?.afternoon,0);
    if(wS>0){ const n=countBy(cells,x=>x.buoi==='sang'); if(n>wS) add(`${name}: số tiết buổi sáng/tuần ${n} vượt giới hạn ${wS}.`); }
    if(wC>0){ const n=countBy(cells,x=>x.buoi==='chieu'); if(n>wC) add(`${name}: số tiết buổi chiều/tuần ${n} vượt giới hạn ${wC}.`); }
    // học cách ngày
    const spacing=toInt(r.spacingDays?.days,0); if(spacing>0){
      const ds=Array.from(new Set(cells.map(x=>x.thu))).map(dayIndex).sort((a,b)=>a-b);
      for(let i=1;i<ds.length;i++){ if(ds[i]-ds[i-1] <= spacing){ add(`${name}: vi phạm học cách ${spacing} ngày.`); break; } }
    }
    // số tiết / buổi và ngày
    const limSess=toInt(getPath(r,`maxPeriods.${buoi}`,0),0); if(limSess>0){ const n=countBy(cells,x=>x.thu===thu&&x.buoi===buoi); if(n>limSess) add(`${name}: ${dayLabel(thu)} ${SESSION_LABEL[buoi]} có ${n} tiết, vượt giới hạn ${limSess}.`); }
    const limDay=toInt(getPath(r,'maxPeriods.day',0),0); if(limDay>0){ const n=countBy(cells,x=>x.thu===thu); if(n>limDay) add(`${name}: ${dayLabel(thu)} có ${n} tiết, vượt giới hạn cả ngày ${limDay}.`); }
    // số buổi học
    const maxS=toInt(r.maxSessions?.morning,0), maxC=toInt(r.maxSessions?.afternoon,0), maxAll=toInt(r.maxSessions?.day,0);
    if(maxS>0){ const n=uniqueCount(cells.filter(x=>x.buoi==='sang'),x=>x.thu+'|'+x.buoi); if(n>maxS) add(`${name}: số buổi sáng học môn ${n} vượt giới hạn ${maxS}.`); }
    if(maxC>0){ const n=uniqueCount(cells.filter(x=>x.buoi==='chieu'),x=>x.thu+'|'+x.buoi); if(n>maxC) add(`${name}: số buổi chiều học môn ${n} vượt giới hạn ${maxC}.`); }
    if(maxAll>0){ const n=uniqueCount(cells,x=>x.thu+'|'+x.buoi); if(n>maxAll) add(`${name}: số buổi học trong tuần ${n} vượt giới hạn ${maxAll}.`); }
    // tránh xếp liền vào 2-3/3-4
    if(r.avoidBreakPairs){ const idx=indexesInSession(cells,thu,buoi); const s=new Set(idx); if(buoi==='sang' && truthy(r.avoidBreakPairs.morning)){ if(s.has(1)&&s.has(2)) add(`${name}: tránh xếp liền tiết 2-3 buổi sáng.`); if(s.has(2)&&s.has(3)) add(`${name}: tránh xếp liền tiết 3-4 buổi sáng.`); } if(buoi==='chieu' && truthy(r.avoidBreakPairs.afternoon)){ if(s.has(1)&&s.has(2)) add(`${name}: tránh xếp liền tiết 2-3 buổi chiều.`); if(s.has(2)&&s.has(3)) add(`${name}: tránh xếp liền tiết 3-4 buổi chiều.`); } }
    // xếp liền vào các thứ trong tuần: nếu buổi đó có cặp liền và ô ngày/buổi không được tích thì báo
    if(r.linkedDays){ const idx=indexesInSession(cells,thu,buoi); if(hasConsecutivePair(idx) && truthy(getPath(r,`linkedDays.enabled`,false)) && !truthy(getPath(r,`linkedDays.${buoi}.${thu}`,false))) add(`${name}: tiết xếp liền không được phép vào ${dayLabel(thu)} ${SESSION_LABEL[buoi]}.`); }
    // tiết học xếp liền min/max: kiểm max khi đặt, min để validateAll báo sau
    if(r.lessonBlocks){ for(const len of [2,3,4,5]){ const max=toInt(r.lessonBlocks?.[len]?.max,0); if(max>0){ let blocks=0; for(const d of days()) for(const b of SESSION_KEYS){ const idx=indexesInSession(cells,d,b); blocks += countConsecutiveBlocks(idx,len); } if(blocks>max) add(`${name}: số buổi/cụm có ${len} tiết xếp liền vượt Max ${max}.`); } } }
    return msgs;
  }

  /* ===================== SUBJECT GROUP ENGINE ===================== */
  function groupCellsAfterPlace(lopId, groupId, ctx){ return classCellsAfterPlace(lopId, ctx, x=>subjectInGroup(x.mon, groupId)); }
  function evalSubjectGroupRule(ctx){
    const msgs=[]; if(!ctx || !ctx.mon || !ctx.thu || !ctx.buoi || ctx.ti == null) return msgs;
    const lopId=String(ctx.lopId||currentClassId()||''); if(!lopId) return msgs; const mon=String(ctx.mon||'').trim(); const thu=String(ctx.thu), buoi=String(ctx.buoi);
    for(const gid of subjectGroupsOf(mon)){
      const obj=model().subjectGroup?.[gid]; const r=byClassRule(obj, lopId); if(!r || !Object.keys(r).length) continue;
      const gname=model().groups.subject?.[gid]?.name || gid; const cells=groupCellsAfterPlace(lopId,gid,Object.assign({},ctx,{lopId,mon})); const name=`${classNameOf(lopId)} - nhóm ${gname}`; const add=m=>{ if(m && !msgs.includes(m)) msgs.push(m); };
      if(r.sessionAllowed){ const allowS=r.sessionAllowed.allowMorning!==false, allowC=r.sessionAllowed.allowAfternoon!==false; if(buoi==='sang'&&!allowS) add(`${name}: không được học buổi sáng.`); if(buoi==='chieu'&&!allowC) add(`${name}: không được học buổi chiều.`); if(truthy(r.sessionAllowed.oneSessionPerDay)){ const hasS=cells.some(x=>x.thu===thu&&x.buoi==='sang'), hasC=cells.some(x=>x.thu===thu&&x.buoi==='chieu'); if(hasS&&hasC) add(`${name}: chỉ học 1 buổi/ngày nhưng có cả sáng và chiều.`); } }
      const wS=toInt(r.weeklySessionPeriods?.morning,0), wC=toInt(r.weeklySessionPeriods?.afternoon,0); if(wS>0){ const n=countBy(cells,x=>x.buoi==='sang'); if(n>wS) add(`${name}: số tiết sáng/tuần ${n} vượt ${wS}.`); } if(wC>0){ const n=countBy(cells,x=>x.buoi==='chieu'); if(n>wC) add(`${name}: số tiết chiều/tuần ${n} vượt ${wC}.`); }
      const limSess=toInt(getPath(r,`maxPeriods.${buoi}`,0),0); if(limSess>0){ const n=countBy(cells,x=>x.thu===thu&&x.buoi===buoi); if(n>limSess) add(`${name}: ${dayLabel(thu)} ${SESSION_LABEL[buoi]} có ${n} tiết, vượt giới hạn ${limSess}.`); }
      const limDay=toInt(getPath(r,'maxPeriods.day',0),0); if(limDay>0){ const n=countBy(cells,x=>x.thu===thu); if(n>limDay) add(`${name}: ${dayLabel(thu)} có ${n} tiết, vượt giới hạn cả ngày ${limDay}.`); }
      const subSess=toInt(getPath(r,`maxSubjects.${buoi}`,0),0); if(subSess>0){ const n=uniqueCount(cells.filter(x=>x.thu===thu&&x.buoi===buoi),x=>norm(x.mon)); if(n>subSess) add(`${name}: ${dayLabel(thu)} ${SESSION_LABEL[buoi]} có ${n} môn khác nhau, vượt ${subSess}.`); }
      const subDay=toInt(getPath(r,'maxSubjects.day',0),0); if(subDay>0){ const n=uniqueCount(cells.filter(x=>x.thu===thu),x=>norm(x.mon)); if(n>subDay) add(`${name}: ${dayLabel(thu)} có ${n} môn khác nhau, vượt ${subDay}.`); }
      const maxS=toInt(r.maxSessions?.morning,0), maxC=toInt(r.maxSessions?.afternoon,0), maxAll=toInt(r.maxSessions?.day,0); if(maxS>0){ const n=uniqueCount(cells.filter(x=>x.buoi==='sang'),x=>x.thu+'|'+x.buoi); if(n>maxS) add(`${name}: số buổi sáng ${n} vượt ${maxS}.`); } if(maxC>0){ const n=uniqueCount(cells.filter(x=>x.buoi==='chieu'),x=>x.thu+'|'+x.buoi); if(n>maxC) add(`${name}: số buổi chiều ${n} vượt ${maxC}.`); } if(maxAll>0){ const n=uniqueCount(cells,x=>x.thu+'|'+x.buoi); if(n>maxAll) add(`${name}: số buổi học ${n} vượt ${maxAll}.`); }
    }
    return msgs;
  }

  /* ===================== GLOBAL LIMIT ENGINE ===================== */
  function matchLimitRule(cell, rule){
    if(!rule || !rule.targetType) return false;
    if(rule.targetType === 'subject') return subjectMatches(cell.mon, rule.targetId);
    if(rule.targetType === 'subjectGroup') return subjectInGroup(cell.mon, rule.targetId);
    if(rule.targetType === 'teacherGroup') return groupItems('teacher', rule.targetId).includes(String(cell.teacher||''));
    if(rule.targetType === 'classGroup') return groupItems('class', rule.targetId).includes(String(cell.lopId||''));
    if(rule.targetType === 'roomGroup') return groupItems('room', rule.targetId).includes(String(cell.room||''));
    return false;
  }
  function evalTimeLimit(ctx){
    const msgs=[]; const rules=model().timeLimit || []; if(!rules.length || !ctx || !ctx.mon) return msgs;
    const lopId=String(ctx.lopId||currentClassId()||''); const mon=String(ctx.mon||'').trim(); const thu=String(ctx.thu), buoi=String(ctx.buoi), ti=Number(ctx.ti);
    const all=allCellsAfterPlace(Object.assign({},ctx,{lopId,mon}));
    rules.forEach(rule=>{
      if(!matchLimitRule({lopId,mon,teacher:teacherOf(lopId,mon),room:roomOf(lopId,mon)}, rule)) return;
      const label=rule.name || 'Giới hạn số tiết/1 thời điểm';
      const cellsSlot=all.filter(x=>x.thu===thu&&x.buoi===buoi&&Number(x.ti)===ti&&matchLimitRule(x,rule));
      const cellsSess=all.filter(x=>x.thu===thu&&x.buoi===buoi&&matchLimitRule(x,rule));
      function chk(scope, cells){
        const conf=rule[scope] || {}; const suffix=scope==='perSlot'?'1 tiết':'1 buổi';
        const maxClass=toInt(conf.classes,0); if(maxClass>0){ const n=uniqueCount(cells,x=>x.lopId); if(n>maxClass) msgs.push(`${label}: số lớp/${suffix} = ${n}, vượt ${maxClass}.`); }
        const maxTeacher=toInt(conf.teachers,0); if(maxTeacher>0){ const n=uniqueCount(cells,x=>x.teacher); if(n>maxTeacher) msgs.push(`${label}: số giáo viên/${suffix} = ${n}, vượt ${maxTeacher}.`); }
        const maxRoom=toInt(conf.rooms,0); if(maxRoom>0){ const n=uniqueCount(cells,x=>x.room); if(n>maxRoom) msgs.push(`${label}: số phòng/${suffix} = ${n}, vượt ${maxRoom}.`); }
      }
      chk('perSlot', cellsSlot); chk('perSession', cellsSess);
    });
    return msgs;
  }
  function hasGlobalLimit(conf){
    if(!conf || typeof conf !== 'object') return false;
    const ps=conf.perSlot||{}, pe=conf.perSession||{};
    return toInt(ps.classes,0)>0 || toInt(ps.teachers,0)>0 || toInt(ps.rooms,0)>0 || toInt(pe.classes,0)>0 || toInt(pe.teachers,0)>0 || toInt(pe.rooms,0)>0;
  }
  function evalGlobalLimitFromSubject(ctx){
    const msgs=[]; if(!ctx || !ctx.mon) return msgs;
    const lopId=String(ctx.lopId||currentClassId()||''); const mon=String(ctx.mon||'').trim(); const thu=String(ctx.thu), buoi=String(ctx.buoi), ti=Number(ctx.ti);
    const sk=subjectKey(mon); const sr=model().subject?.[sk]?.globalLimit || {};
    const activeGroups=subjectGroupsOf(mon).map(gid=>({gid,conf:model().subjectGroup?.[gid]?.globalLimit||{}})).filter(x=>hasGlobalLimit(x.conf));
    if(!hasGlobalLimit(sr) && !activeGroups.length) return msgs;
    const all=allCellsAfterPlace(Object.assign({},ctx,{lopId,mon}));
    function check(conf,label,matcher){
      if(!hasGlobalLimit(conf)) return;
      const slot=all.filter(x=>x.thu===thu&&x.buoi===buoi&&Number(x.ti)===ti&&matcher(x));
      const sess=all.filter(x=>x.thu===thu&&x.buoi===buoi&&matcher(x));
      for(const [scope,cells] of [['perSlot',slot],['perSession',sess]]){ const c=conf[scope]||{}; const suffix=scope==='perSlot'?'1 tiết':'1 buổi'; const mc=toInt(c.classes,0); if(mc>0 && uniqueCount(cells,x=>x.lopId)>mc) msgs.push(`${label}: vượt giới hạn số lớp học/${suffix}.`); const mt=toInt(c.teachers,0); if(mt>0 && uniqueCount(cells,x=>x.teacher)>mt) msgs.push(`${label}: vượt giới hạn số giáo viên/${suffix}.`); const mr=toInt(c.rooms,0); if(mr>0 && uniqueCount(cells,x=>x.room)>mr) msgs.push(`${label}: vượt giới hạn số phòng học/${suffix}.`); }
    }
    check(sr, `Môn ${mon}`, x=>subjectMatches(x.mon,mon));
    for(const it of activeGroups){ const gname=model().groups.subject?.[it.gid]?.name || it.gid; check(it.conf, `Nhóm môn ${gname}`, x=>subjectInGroup(x.mon,it.gid)); }
    return msgs;
  }

  /* ===================== PUBLIC ENGINE ===================== */
  function _hotPathMode(ctx){
    const m = String(ctx?.mode || '').trim();
    return !(ctx && ctx.full === true) && (m === 'drag' || m === 'auto' || m === 'move' || !m);
  }
  function _hasAnyConstraint(){
    const c = model();
    return Object.keys(c.teacher || {}).length || Object.keys(c.subject || {}).length ||
      Object.keys(c.subjectGroup || {}).length || Object.keys(c.fixedOff?.class || {}).length ||
      Object.keys(c.fixedOff?.teacher || {}).length || Object.keys(c.fixedOff?.subject || {}).length ||
      Object.keys(c.fixedOff?.room || {}).length || (c.timeLimit || []).length;
  }
  function canPlaceLesson(ctx){
    const messages=[]; function addAll(arr){ (arr||[]).forEach(m=>{ if(m && !messages.includes(m)) messages.push(m); }); }
    if(!ctx || !ctx.mon || !_hasAnyConstraint()) return {ok:true, messages};
    const hot = _hotPathMode(ctx);
    const t0 = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
    function tooSlow(){
      const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
      return hot && (now - t0 > 24);
    }
    try{ addAll(evalFixedOff(ctx)); }catch(e){ console.warn('[tkb-constraints] fixed off eval failed', e); }
    if(tooSlow()) return {ok:messages.length===0, messages};
    try{ addAll(evalTeacherRule(ctx)); }catch(e){ console.warn('[tkb-constraints] teacher eval failed', e); }
    if(tooSlow()) return {ok:messages.length===0, messages};
    try{ addAll(evalSubjectRule(ctx)); }catch(e){ console.warn('[tkb-constraints] subject eval failed', e); }
    if(tooSlow()) return {ok:messages.length===0, messages};
    try{ addAll(evalSubjectGroupRule(ctx)); }catch(e){ console.warn('[tkb-constraints] subject group eval failed', e); }
    // Các ràng buộc global/timeLimit quét toàn trường. Không chạy trong hot path để tránh đứng khi quay lại sắp xếp.
    // Chúng vẫn được kiểm tra đầy đủ bằng nút Kiểm tra ràng buộc / validateAll(full=true).
    if(!hot){
      try{ addAll(evalGlobalLimitFromSubject(ctx)); }catch(e){ console.warn('[tkb-constraints] global subject limit eval failed', e); }
      try{ addAll(evalTimeLimit(ctx)); }catch(e){ console.warn('[tkb-constraints] time limit eval failed', e); }
    }
    return {ok:messages.length===0, messages};
  }
  function canPlaceCell(lopId, mon, thu, buoi, ti, opts){ return canPlaceLesson(Object.assign({}, opts || {}, {lopId, mon, thu, buoi, ti:Number(ti)})); }
  function validateAll(maxItems){
    const max=Number(maxItems||1000); const out=[]; const seen=new Set();
    function add(item){ if(!item || out.length>=max) return; const key=[item.lopId||'',item.mon||'',item.thu||'',item.buoi||'',item.ti,item.message||''].join('|'); if(seen.has(key)) return; seen.add(key); out.push(item); }
    const tkbs=D().tkb || {};
    for(const lopId of Object.keys(tkbs)){ const tkb=tkbs[lopId]; for(const thu of days()) for(const buoi of SESSION_KEYS){ const arr=tkb?.[thu]?.[buoi]||[]; for(let ti=0;ti<arr.length;ti++){ const v=arr[ti]; if(v==='OFF'||!v||isFixedSafe(v)) continue; const mon=cellMonSafe(v); if(!mon) continue; const res=canPlaceLesson({lopId,mon,thu,buoi,ti,full:true,mode:'validate'}); (res.messages||[]).forEach(message=>add({lopId,className:classNameOf(lopId),mon,thu,buoi,ti,message})); if(out.length>=max) return out; } } }
    // hậu kiểm Min số buổi/cụm xếp liền cho môn học
    try{
      const c=model();
      Object.keys(c.subject||{}).forEach(sk=>{ const sobj=c.subject[sk]; Object.keys(sobj.byClass||{}).forEach(lopId=>{ const r=sobj.byClass[lopId]; if(!r.lessonBlocks) return; const cells=subjectCellsAfterPlace(lopId,sk,{lopId,mon:sk}); for(const len of [2,3,4,5]){ const min=toInt(r.lessonBlocks?.[len]?.min,0); if(min>0){ let blocks=0; for(const d of days()) for(const b of SESSION_KEYS) blocks += countConsecutiveBlocks(indexesInSession(cells,d,b),len); if(blocks<min) add({lopId,className:classNameOf(lopId),mon:sk,message:`${classNameOf(lopId)} - ${sk}: số buổi/cụm có ${len} tiết xếp liền ${blocks}, chưa đạt Min ${min}.`}); } } }); });
    }catch(e){ console.warn('[tkb-constraints] post validate failed', e); }
    return out;
  }

  /* ===================== UI STYLE ===================== */
  function injectStyle(){
    if(document.getElementById(STYLE_ID)) return;
    const css=document.createElement('style'); css.id=STYLE_ID; css.textContent = `
      #${PANEL_ID}{position:fixed;inset:4vh 3vw;z-index:1000000;background:#fff;border:1px solid #d8dfef;border-radius:14px;box-shadow:0 18px 60px rgba(22,34,66,.28);display:grid;grid-template-rows:auto 1fr;overflow:hidden;font-family:Arial,sans-serif;color:#172033}
      #${PANEL_ID}.rb-page-panel{inset:0;border:0;border-radius:0;box-shadow:none;grid-template-rows:auto auto 1fr}
      #${PANEL_ID} .rb-top{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid #e3e8f5;background:#f7f9fe} #${PANEL_ID} .rb-title{font-weight:800;font-size:16px;flex:1}
      #${PANEL_ID}.rb-page-panel .rb-top{padding:4px 8px;background:#f5f5f5;border-bottom:1px solid #d5d5d5}
      #${PANEL_ID}.rb-page-panel .rb-title{font-size:13px}
      #${PANEL_ID} .rb-menubar{display:flex;align-items:center;gap:2px;padding:3px 6px;border-bottom:1px solid #d6d6d6;background:#fff;font-size:12px}
      #${PANEL_ID} .rb-menubar button{border:0;background:transparent;border-radius:2px;padding:4px 8px;font-size:12px}
      #${PANEL_ID} .rb-menubar button:hover{background:#e9f1ff}
      #${PANEL_ID} .rb-ribbon{display:flex;align-items:center;gap:4px;padding:4px 6px;border-bottom:1px solid #d6d6d6;background:#fafafa}
      #${PANEL_ID} .rb-tool{width:30px;height:26px;display:inline-flex;align-items:center;justify-content:center;border:1px solid #d4d4d4;border-radius:2px;background:#fff;color:#333;font-size:16px;padding:0}
      #${PANEL_ID} .rb-tool:hover{background:#eef4ff}
      #${PANEL_ID} .rb-tool.danger{background:#fff;border-color:#ffd6d6;color:#d73a49}
      #${PANEL_ID} .rb-tool.primary{background:#fff;border-color:#d4d4d4;color:#7b3fb0}
      #${PANEL_ID} .rb-tool-sep{width:1px;height:24px;background:#d8d8d8;margin:0 3px}
      #${PANEL_ID} button{border:1px solid #c9d4ea;background:#fff;border-radius:8px;padding:7px 11px;cursor:pointer;font-size:13px} #${PANEL_ID} button:hover{background:#eef4ff} #${PANEL_ID} .primary{background:#295bff;color:white;border-color:#295bff} #${PANEL_ID} .danger{background:#fff1f0;color:#a8071a;border-color:#ffccc7}
      #${PANEL_ID}.rb-page-panel .rb-tool{border-radius:5px;background:linear-gradient(#fff,#f3f5f9);box-shadow:0 1px 0 rgba(0,0,0,.04)}
      #${PANEL_ID}.rb-page-panel .rb-tool.primary{background:linear-gradient(#fff,#f5f0ff);color:#8e44ad;border-color:#d9c5ef}
      #${PANEL_ID}.rb-page-panel .rb-tool.danger{background:linear-gradient(#fff,#fff5f5);color:#d73a49;border-color:#ffc9c9}
      #${PANEL_ID} .rb-main{min-height:0;display:grid;grid-template-columns:292px 1fr;overflow:hidden} #${PANEL_ID} .rb-nav{border-right:1px solid #e3e8f5;background:#fbfcff;overflow:auto;padding:10px} #${PANEL_ID} .rb-nav h4{font-size:12px;color:#63708a;text-transform:uppercase;margin:11px 6px 6px}
      #${PANEL_ID} .rb-main-page{grid-template-columns:1fr}
      #${PANEL_ID}.rb-page-panel .rb-content{padding:6px}
      #${PANEL_ID}.rb-page-panel .rb-teacher-screen h3{display:none}
      #${PANEL_ID}.rb-page-panel .rb-desktop-wrap{max-height:calc(100vh - 132px)}
      #${PANEL_ID}.rb-page-panel .table-wrap{max-height:calc(100vh - 132px)}
      #${PANEL_ID} .rb-nav button{display:block;width:100%;text-align:left;margin:3px 0;border:0;background:transparent;padding:9px 10px;border-radius:9px;line-height:1.25} #${PANEL_ID} .rb-nav button.active{background:#eaf0ff;color:#143fc4;font-weight:700}
      #${PANEL_ID} .rb-content{min-width:0;overflow:auto;padding:14px;background:#fff} #${PANEL_ID} .hint{font-size:12px;color:#5f6f89;background:#f7faff;border:1px solid #e0e8fb;padding:9px 10px;border-radius:10px;margin:8px 0 12px;line-height:1.45}
      #${PANEL_ID} .toolbar{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:8px 0 12px;background:#f8faff;border:1px solid #e7ecf7;padding:8px;border-radius:10px} #${PANEL_ID} select,#${PANEL_ID} input[type=text],#${PANEL_ID} input[type=number]{border:1px solid #c9d4ea;border-radius:7px;padding:6px 8px;background:#fff;font-size:13px} #${PANEL_ID} input[type=number]{width:68px;text-align:center}
      #${PANEL_ID} .table-wrap{overflow:auto;border:1px solid #dfe6f4;border-radius:10px;max-height:calc(84vh - 210px)} #${PANEL_ID} table{border-collapse:collapse;width:max-content;min-width:100%;font-size:12px} #${PANEL_ID} th,#${PANEL_ID} td{border:1px solid #e2e7f2;padding:6px 7px;text-align:center;vertical-align:middle;background:#fff} #${PANEL_ID} th{position:sticky;top:0;z-index:1;background:#f0f4ff;font-weight:700;color:#26324a} #${PANEL_ID} td:first-child,#${PANEL_ID} th:first-child{position:sticky;left:0;z-index:2;text-align:left;background:#fff} #${PANEL_ID} th:first-child{z-index:3;background:#f0f4ff}
      #${PANEL_ID} .muted{color:#778399;font-size:12px} #${PANEL_ID} .grid2{display:grid;grid-template-columns:minmax(260px,360px) 1fr;gap:12px;align-items:start} #${PANEL_ID} .box{border:1px solid #dfe6f4;border-radius:12px;padding:12px;background:#fff} #${PANEL_ID} .check-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:5px 10px;max-height:390px;overflow:auto;padding:6px;border:1px solid #eef2fb;border-radius:10px} #${PANEL_ID} .check-list label{display:flex;align-items:center;gap:5px;font-size:12px;white-space:nowrap} #${PANEL_ID} pre{white-space:pre-wrap;line-height:1.4;background:#fbfcff;border:1px solid #e0e6f3;border-radius:10px;padding:10px;max-height:520px;overflow:auto}
      #${PANEL_ID} .rb-teacher-screen h3{margin:0 0 8px}
      #${PANEL_ID} .rb-teacher-toolbar{gap:10px;background:#f8f8fb;border-color:#d8ddec;padding:8px 10px}
      #${PANEL_ID} .rb-teacher-toolbar label{display:flex;align-items:center;gap:6px}
      #${PANEL_ID} .rb-toolbar-spacer{flex:1 1 auto}
      #${PANEL_ID} .rb-desktop-wrap{border-radius:0;max-height:calc(84vh - 170px)}
      #${PANEL_ID} .rb-desktop-table{font-size:12px}
      #${PANEL_ID} .rb-desktop-table th,#${PANEL_ID} .rb-desktop-table td{padding:4px 6px;min-width:42px}
      #${PANEL_ID} .rb-desktop-table td input[type=number]{width:64px;min-width:64px;height:24px;padding:2px 4px}
      #${PANEL_ID} .rb-desktop-table td select{height:24px}
      #${PANEL_ID} .rb-desktop-table .rb-tt{min-width:34px;width:34px;text-align:center}
      #${PANEL_ID} .rb-desktop-table .rb-name{min-width:130px}
      #${PANEL_ID} .rb-desktop-table .rb-total{color:#d10000;font-weight:700}
      #${PANEL_ID} .rb-desktop-table .rb-check input{transform:scale(.95)}
      #${PANEL_ID} .rb-desktop-table thead th{background:#f7f7fb}
      #${PANEL_ID} .rb-fixedoff-screen{display:grid;grid-template-columns:156px 1fr;gap:8px;align-items:start}
      #${PANEL_ID} .rb-fixedoff-list{border:1px solid #d7d7d7;background:#fff;max-height:calc(100vh - 188px);overflow:auto}
      #${PANEL_ID} .rb-fixedoff-item{display:block;width:100%;padding:5px 7px;border:0;border-bottom:1px solid #ececec;background:#fff;text-align:left;border-radius:0;font-size:12px}
      #${PANEL_ID} .rb-fixedoff-item:hover{background:#f6f9ff}
      #${PANEL_ID} .rb-fixedoff-item.active{background:#d8d8d8;color:#111;font-weight:700}
      #${PANEL_ID} .rb-fixedoff-main{min-width:0}
      #${PANEL_ID} .rb-fixedoff-titlebar{display:flex;align-items:flex-start;justify-content:space-between;gap:8px;margin-bottom:6px}
      #${PANEL_ID} .rb-fixedoff-titlebar h3{margin:0;font-size:15px}
      #${PANEL_ID} .rb-fixedoff-total{font-style:italic;font-weight:700;color:#444;white-space:nowrap;font-size:12px}
      #${PANEL_ID} .rb-fixedoff-top{border:1px solid #d6d6d6;max-height:190px;overflow:auto;background:#fff}
      #${PANEL_ID} .rb-fixedoff-top table{width:100%;min-width:100%;font-size:12px}
      #${PANEL_ID} .rb-fixedoff-top th,#${PANEL_ID} .rb-fixedoff-top td{padding:5px 6px;border:1px solid #d9d9d9}
      #${PANEL_ID} .rb-fixedoff-grid{border:1px solid #d6d6d6;margin-top:10px;background:#fff}
      #${PANEL_ID} .rb-fixedoff-grid table{width:100%;min-width:100%;table-layout:fixed;font-size:12px}
      #${PANEL_ID} .rb-fixedoff-grid th,#${PANEL_ID} .rb-fixedoff-grid td{border:1px solid #d9d9d9;padding:0;height:26px;text-align:center;vertical-align:middle}
      #${PANEL_ID} .rb-fixedoff-grid thead th{background:#fff;font-size:12px;font-weight:800}
      #${PANEL_ID} .rb-fixedoff-grid td{cursor:pointer;background:#fff;color:#333}
      #${PANEL_ID} .rb-fixedoff-grid td.off{background:#fdfdfd;color:#222}
      #${PANEL_ID} .rb-fixedoff-grid td.off .rb-off-text{display:inline-block}
      #${PANEL_ID} .rb-fixedoff-grid .rb-off-text{display:none}
      #${PANEL_ID} .rb-fixedoff-grid tr.sep td{border-top:2px solid #5876d3}

#${PANEL_ID} .rb-menu-pop{position:fixed;z-index:1000002;min-width:220px;background:#f5f5f5;border:1px solid #cfcfcf;border-radius:4px;box-shadow:0 8px 22px rgba(0,0,0,.18);padding:4px}
#${PANEL_ID} .rb-menu-item{position:relative;display:flex;align-items:center;justify-content:space-between;gap:12px;padding:6px 10px;border-radius:3px;font-size:12px;cursor:pointer;white-space:nowrap}
#${PANEL_ID} .rb-menu-item:hover{background:#dce8ff}
#${PANEL_ID} .rb-menu-item.sep{height:1px;padding:0;margin:4px 0;background:#d9d9d9;cursor:default}
#${PANEL_ID} .rb-menu-item.head{font-weight:700;color:#333;background:transparent;cursor:default}
#${PANEL_ID} .rb-menu-arrow{opacity:.7}
#${PANEL_ID} .rb-clear-screen{display:grid;gap:10px;max-width:920px}
#${PANEL_ID} .rb-clear-grid{display:grid;grid-template-columns:repeat(2,minmax(240px,1fr));gap:10px}
#${PANEL_ID} .rb-clear-card{display:flex;flex-direction:column;align-items:flex-start;gap:4px;border:1px solid #d8d8d8;border-radius:8px;padding:10px;background:#fff}
#${PANEL_ID} .rb-clear-card b{font-size:13px}
#${PANEL_ID} .rb-clear-card span{font-size:11px;color:#666;line-height:1.4}
#${PANEL_ID} .rb-clear-card button{margin-top:4px;border-radius:6px;padding:5px 10px;font-size:12px}
#${PANEL_ID}.rb-page-panel .rb-tool{font-size:14px}
    `; document.head.appendChild(css);
  }

  /* ===================== UI COMMON ===================== */
  function closePanel(){ document.getElementById(PANEL_ID)?.remove(); invalidateConstraintCache(); try{ setTimeout(()=>{ try{ if(typeof renderCurrentView==='function') renderCurrentView(); }catch(_){} },0); }catch(_){} }
  function setPanelRoute(opts){
    opts = opts || {};
    if(opts.section) state.section = opts.section;
    const r = opts.rule || opts.teacherRule || opts.subjectRule || opts.subjectGroupRule || opts.fixedType || '';
    if(state.section==='teacher' && r) state.teacherRule = r;
    if(state.section==='subject' && r) state.subjectRule = r;
    if(state.section==='subjectGroup' && r) state.subjectGroupRule = r;
    if(state.section==='fixedOff' && r) state.fixedType = r;
  }

function menuRoute(label, section, rule){ return {label, action:()=>openPanel({page:true,title:label,section,rule})}; }
function buildMenuTree(){
  return [
    {label:'Yêu cầu của giáo viên', children:[
      menuRoute('Giới hạn số ngày dạy & buổi dạy/1 tuần','teacher','maxDaysSessions'),
      menuRoute('Giới hạn số tiết dạy/1 buổi','teacher','maxPeriods'),
      menuRoute('Giới hạn số tiết dạy/1 buổi/1 lớp','teacher','maxPeriodsClass'),
      menuRoute('Giới hạn số giáo án/1 buổi','teacher','lessonPlans'),
      menuRoute('Giới hạn số buổi dạy sáng & chiều','teacher','maxMorningAfternoon'),
      menuRoute('Chỉ dạy 1 buổi/1 ngày','teacher','oneSessionPerDay'),
      menuRoute('Không dạy tiết 5 sáng & tiết 1 chiều/1 ngày','teacher','noMorningP5AfternoonP1'),
      menuRoute('Chỉ dạy 1 địa điểm/1 buổi','teacher','oneLocationPerSession'),
      menuRoute('Có tiết trống giữa 2 địa điểm','teacher','gapBetweenLocations'),
      menuRoute('Không di chuyển 2 lần/1 buổi giữa các địa điểm','teacher','maxOneMovePerSession')
    ]},
    {label:'Yêu cầu của môn học', children:[
      {label:'Yêu cầu tiết học xếp liền', heading:true},
      menuRoute('Số buổi học có tiết học xếp liền','subject','lessonBlocks'),
      menuRoute('Tránh xếp tiết 2-3','subject','avoidBreakPairs'),
      menuRoute('Tránh xếp tiết 3-4','subject','avoidBreakPairs'),
      menuRoute('Tránh xếp vào các thứ trong tuần','subject','linkedDays'),
      {label:'Yêu cầu đối với lớp học 2 ca', heading:true},
      menuRoute('Giới hạn buổi học của môn học','subject','sessionAllowed'),
      menuRoute('Giới hạn số tiết của môn học/1 buổi/1 tuần','subject','weeklySessionPeriods'),
      {label:'Yêu cầu đối với các nhóm', heading:true},
      menuRoute('Giới hạn nhóm lớp học/1 buổi','subject','groupLimit'),
      menuRoute('Giới hạn nhóm giáo viên/1 buổi','subject','groupLimit'),
      menuRoute('Giới hạn nhóm phòng học/1 buổi','subject','groupLimit'),
      {label:'Yêu cầu khác', heading:true},
      menuRoute('Học cách ngày','subject','spacingDays'),
      menuRoute('Giới hạn số tiết/1 buổi','subject','maxPeriods'),
      menuRoute('Giới hạn số buổi học','subject','maxSessions'),
      menuRoute('Giới hạn số lớp học, giáo viên, phòng học','subject','globalLimit'),
      {label:'Cố định tiết nghỉ môn học', action:()=>openPanel({page:true,title:'Cố định tiết nghỉ môn học',section:'fixedOff',rule:'subject'})}
    ]},
    {label:'Yêu cầu của nhóm môn học', children:[
      {label:'Yêu cầu đối với lớp học 2 ca', heading:true},
      menuRoute('Giới hạn buổi học của nhóm môn học','subjectGroup','sessionAllowed'),
      menuRoute('Giới hạn số tiết của nhóm môn học/1 buổi/1 tuần','subjectGroup','weeklySessionPeriods'),
      {label:'Yêu cầu đối với các nhóm', heading:true},
      menuRoute('Giới hạn nhóm lớp học/1 buổi','subjectGroup','groupLimit'),
      menuRoute('Giới hạn nhóm giáo viên/1 buổi','subjectGroup','groupLimit'),
      menuRoute('Giới hạn nhóm phòng học/1 buổi','subjectGroup','groupLimit'),
      {label:'Yêu cầu khác', heading:true},
      menuRoute('Giới hạn số tiết/1 buổi','subjectGroup','maxPeriods'),
      menuRoute('Giới hạn số môn học/1 buổi','subjectGroup','maxSubjects'),
      menuRoute('Giới hạn số buổi học','subjectGroup','maxSessions'),
      menuRoute('Giới hạn số lớp học, giáo viên, phòng học','subjectGroup','globalLimit'),
      {label:'Cố định tiết nghỉ nhóm môn học', action:()=>openPanel({page:true,title:'Cố định tiết nghỉ nhóm môn học',section:'fixedOff',rule:'subjectGroup'})}
    ]},
    {label:'Cố định tiết nghỉ', children:[
      {label:'Cố định tiết nghỉ lớp học', action:()=>openPanel({page:true,title:'Cố định tiết nghỉ lớp học',section:'fixedOff',rule:'class'})},
      {label:'Cố định tiết nghỉ giáo viên', action:()=>openPanel({page:true,title:'Cố định tiết nghỉ giáo viên',section:'fixedOff',rule:'teacher'})},
      {label:'Cố định tiết nghỉ môn học', action:()=>openPanel({page:true,title:'Cố định tiết nghỉ môn học',section:'fixedOff',rule:'subject'})},
      {label:'Cố định tiết nghỉ phòng học', action:()=>openPanel({page:true,title:'Cố định tiết nghỉ phòng học',section:'fixedOff',rule:'room'})}
    ]},
    {label:'Giới hạn số tiết/1 thời điểm', children:[
      {label:'Giới hạn theo nhóm lớp học', action:()=>openPanel({page:true,title:'Giới hạn số tiết/1 thời điểm',section:'timeLimit'})},
      {label:'Giới hạn theo nhóm giáo viên', action:()=>openPanel({page:true,title:'Giới hạn số tiết/1 thời điểm',section:'timeLimit'})},
      {label:'Giới hạn theo nhóm môn học', action:()=>openPanel({page:true,title:'Giới hạn số tiết/1 thời điểm',section:'timeLimit'})},
      {label:'Giới hạn theo nhóm phòng học', action:()=>openPanel({page:true,title:'Giới hạn số tiết/1 thời điểm',section:'timeLimit'})}
    ]},
    {label:'Xóa ràng buộc TKB ...', action:()=>openPanel({page:true,title:'Xóa ràng buộc TKB',section:'clear'})}
  ];
}
function closeRbMenus(){ document.querySelectorAll('.rb-menu-pop').forEach(x=>x.remove()); }
function buildMenuPopup(items, left, top, level){
  const pop=document.createElement('div'); pop.className='rb-menu-pop'; pop.dataset.level=String(level||0); pop.style.left=Math.round(left)+'px'; pop.style.top=Math.round(top)+'px';
  items.forEach(it=>{
    if(it.sep){ const d=document.createElement('div'); d.className='rb-menu-item sep'; pop.appendChild(d); return; }
    const row=document.createElement('div'); row.className='rb-menu-item'+(it.heading?' head':''); row.innerHTML=`<span>${esc(it.label||'')}</span>${it.children?'<span class="rb-menu-arrow">▶</span>':''}`;
    if(!it.heading){
      row.addEventListener('mouseenter',()=>{
        document.querySelectorAll(`.rb-menu-pop`).forEach(p=>{ if(Number(p.dataset.level||0) > (level||0)) p.remove(); });
        if(it.children){ const r=row.getBoundingClientRect(); const next=buildMenuPopup(it.children, r.right-2, r.top-4, (level||0)+1); document.body.appendChild(next); }
      });
      row.addEventListener('click',(e)=>{ e.stopPropagation(); if(it.children) return; closeRbMenus(); try{ it.action && it.action(); }catch(_){} });
    }
    pop.appendChild(row);
  });
  return pop;
}
window.openRangBuocMenu = function(anchor){
  closeRbMenus();
  const rect = anchor.getBoundingClientRect();
  const root = buildMenuPopup(buildMenuTree(), rect.left, rect.bottom+2, 0);
  document.body.appendChild(root);
  const closer=(ev)=>{ if(!ev.target.closest('.rb-menu-pop') && !ev.target.closest('[data-rb-menu]')){ closeRbMenus(); document.removeEventListener('mousedown', closer, true); } };
  document.addEventListener('mousedown', closer, true);
};

  function openPanel(opts){
    opts = opts || {};
    closePanel(); injectStyle(); syncDefaultGroups(); setPanelRoute(opts);
    const pageMode = opts.page === true;
    const menuHtml = pageMode ? `<div class="rb-menubar"><button type="button" data-rb-menu>Ràng buộc TKB ▾</button><span>${esc(opts.title || '')}</span></div>` : ``;
    const ribbonHtml = pageMode ? `<div class="rb-ribbon" role="toolbar" aria-label="Công cụ ràng buộc">
      <button type="button" class="rb-tool danger" data-rb-close title="Tắt">×</button>
      <button type="button" class="rb-tool primary" data-rb-save title="Lưu">▣</button>
      <span class="rb-tool-sep"></span>
      <button type="button" class="rb-tool" data-rb-clear-current title="Xóa sạch">⌫</button>
      <button type="button" class="rb-tool" data-rb-cut title="Cắt">✂</button>
      <button type="button" class="rb-tool" data-rb-copy title="Copy">⧉</button>
    </div>` : ``;
    const mainHtml = pageMode
      ? `<div class="rb-main rb-main-page"><div class="rb-content" data-rb-body></div></div>`
      : `<div class="rb-main"><div class="rb-nav" data-rb-nav></div><div class="rb-content" data-rb-body></div></div>`;
    const topActions = pageMode ? `` : `<button type="button" class="primary" data-rb-save>Lưu</button><button type="button" data-rb-check>Kiểm tra ràng buộc</button><button type="button" data-rb-close>Đóng</button>`;
    const w=document.createElement('div'); w.id=PANEL_ID; if(pageMode) w.className='rb-page-panel'; w.innerHTML=`<div class="rb-top"><div class="rb-title">${esc(opts.title || 'Ràng buộc TKB')}</div>${topActions}</div>${menuHtml}${ribbonHtml}${mainHtml}`;
    document.body.appendChild(w);
    w.querySelectorAll('[data-rb-save]').forEach(b=>b.onclick=()=>saveCurrentFromUI(true));
    w.querySelectorAll('[data-rb-close]').forEach(b=>b.onclick=closePanel);
    const checkBtn = w.querySelector('[data-rb-check]');
    if(checkBtn) checkBtn.onclick=()=>{ saveCurrentFromUI(false); state.section='check'; render(); };
    const menuBtn = w.querySelector('[data-rb-menu]');
    if(menuBtn) menuBtn.onclick=()=>{ if(typeof window.openRangBuocMenu === 'function') window.openRangBuocMenu(menuBtn); };
    const clearBtn = w.querySelector('[data-rb-clear-current]');
    if(clearBtn) clearBtn.onclick=clearCurrentRule;
    const copyBtn = w.querySelector('[data-rb-copy]');
    if(copyBtn){ copyBtn.onclick=copyCurrentRule; window.__rbCopyBtn = copyBtn; }
    const cutBtn = w.querySelector('[data-rb-cut]');
    if(cutBtn) cutBtn.onclick=()=>{ copyCurrentRule(false); clearCurrentRule(); };
    render();
  }
  function navButton(label, section, rule){ const active=state.section===section && (!rule || state.teacherRule===rule || state.subjectRule===rule || state.subjectGroupRule===rule || state.fixedType===rule); return `<button type="button" class="${active?'active':''}" data-section="${esc(section)}" data-rule="${esc(rule||'')}">${esc(label)}</button>`; }
  function updateFixedOffRibbon(){ const btn = window.__rbCopyBtn || document.querySelector(`#${PANEL_ID} [data-rb-copy]`); if(!btn) return; if(state.section==='fixedOff' && (state.fixedType==='class' || state.fixedType==='subject')){ btn.title='Đồng bộ'; btn.textContent='⇄'; } else { btn.title='Copy'; btn.textContent='⧉'; } }
  function renderNav(){ const nav=document.querySelector(`#${PANEL_ID} [data-rb-nav]`); if(!nav) return; nav.innerHTML=`<h4>Dữ liệu nền</h4>${navButton('Nhóm lớp / giáo viên / môn / phòng','groups')}<h4>Yêu cầu của giáo viên</h4>${TEACHER_RULES.map(r=>navButton(r[1],'teacher',r[0])).join('')}<h4>Yêu cầu của môn học</h4>${SUBJECT_RULES.map(r=>navButton(r[1],'subject',r[0])).join('')}<h4>Yêu cầu của nhóm môn học</h4>${SUBJECT_GROUP_RULES.map(r=>navButton(r[1],'subjectGroup',r[0])).join('')}<h4>Cố định tiết nghỉ</h4>${FIXED_OFF_TYPES.map(r=>navButton(r[1],'fixedOff',r[0])).join('')}<h4>Công cụ</h4>${navButton('Giới hạn số tiết/1 thời điểm','timeLimit')}${navButton('Kiểm tra ràng buộc','check')}${navButton('Xóa ràng buộc TKB','clear')}`; nav.querySelectorAll('button[data-section]').forEach(b=>{ b.onclick=()=>{ state.section=b.dataset.section; const r=b.dataset.rule; if(state.section==='teacher'&&r) state.teacherRule=r; if(state.section==='subject'&&r) state.subjectRule=r; if(state.section==='subjectGroup'&&r) state.subjectGroupRule=r; if(state.section==='fixedOff'&&r) state.fixedType=r; render(); }; }); }
  function render(){ renderNav(); updateFixedOffRibbon(); const body=document.querySelector(`#${PANEL_ID} [data-rb-body]`); if(!body) return; if(state.section==='groups') body.innerHTML=renderGroups(); else if(state.section==='teacher') body.innerHTML=renderTeacherRule(state.teacherRule); else if(state.section==='subject') body.innerHTML=renderSubjectRule(state.subjectRule); else if(state.section==='subjectGroup') body.innerHTML=renderSubjectGroupRule(state.subjectGroupRule); else if(state.section==='fixedOff') body.innerHTML=renderFixedOff(state.fixedType); else if(state.section==='timeLimit') body.innerHTML=renderTimeLimit(); else if(state.section==='check') body.innerHTML=renderCheck(); else if(state.section==='clear') body.innerHTML=renderClear(); bindBodyEvents(); }
  function isPagePanel(){ return !!document.getElementById(PANEL_ID)?.classList.contains('rb-page-panel'); }
  function localActionButtons(){ return isPagePanel() ? '' : `<button type="button" class="primary" data-rb-save-current>Lưu mục này</button><button type="button" class="danger" data-rb-clear-current>Xóa dữ liệu mục này</button>`; }
  function selectSubjectToolbar(){ const list=getSubjectList(); if(!state.subjectId && list.length) state.subjectId=list[0].id; return `<div class="toolbar"><label>Môn học <select data-subject-id>${list.map(x=>`<option value="${esc(x.id)}" ${x.id===state.subjectId?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label><label>Nhóm lớp <select data-class-group-filter><option value="">Tất cả lớp</option>${groupOptions('class',state.classGroup)}</select></label>${localActionButtons()}</div>`; }
  function selectSubjectGroupToolbar(){ const opts=Object.entries(model().groups.subject||{}); if(!state.subjectGroupId && opts.length) state.subjectGroupId=opts[0][0]; return `<div class="toolbar"><label>Nhóm môn học <select data-subject-group-id>${opts.map(([id,g])=>`<option value="${esc(id)}" ${id===state.subjectGroupId?'selected':''}>${esc(g.name||id)}</option>`).join('')}</select></label><label>Nhóm lớp <select data-class-group-filter><option value="">Tất cả lớp</option>${groupOptions('class',state.classGroup)}</select></label>${localActionButtons()}</div>`; }

  function teacherFilterToolbar(rule){
    const subjectGroupOptions = [['__all__','Tất cả môn học'], ...Object.entries(model().groups.subject||{}).map(([id,g])=>[id,g.name||id])];
    if(rule === 'maxPeriodsClass' && !state.teacherSubjectGroupId) state.teacherSubjectGroupId = '__all__';
    return `<div class="toolbar rb-teacher-toolbar">`+
      `<label>Nhóm giáo viên <select data-teacher-group-filter><option value="">(Chọn tất cả)</option>${groupOptions('teacher',state.teacherGroup)}</select></label>`+
      (rule === 'maxPeriodsClass'
        ? `<label>Nhóm môn học <select data-teacher-subject-group-filter>${subjectGroupOptions.map(o=>`<option value="${esc(o[0])}" ${String(o[0])===String(state.teacherSubjectGroupId||'__all__')?'selected':''}>${esc(o[1])}</option>`).join('')}</select></label>`
        : ``)+
      `<span class="rb-toolbar-spacer"></span>`+
      localActionButtons()+
    `</div>`;
  }
  function filteredTeachers(){ let arr=getTeacherList(); if(state.teacherGroup){ const set=new Set(groupItems('teacher',state.teacherGroup)); arr=arr.filter(x=>set.has(x.id)); } const q=norm(state.search); if(q) arr=arr.filter(x=>norm(x.id).includes(q)||norm(x.name).includes(q)); return arr; }
  function inputNum(tid,path,val){ return `<input type="number" data-tid="${esc(tid)}" data-path="${esc(path)}" min="0" value="${esc(val == null ? '' : val)}">`; }
  function inputCheck(tid,path,val){ return `<input type="checkbox" data-tid="${esc(tid)}" data-path="${esc(path)}" ${truthy(val)?'checked':''}>`; }
  function inputSelect(tid,path,val,options){ return `<select data-tid="${esc(tid)}" data-path="${esc(path)}">${options.map(o=>`<option value="${esc(o[0])}" ${String(o[0])===String(val)?'selected':''}>${esc(o[1])}</option>`).join('')}</select>`; }
  function thDaysGrouped(colspan){ return days().map(d=>`<th colspan="${colspan}">${esc(dayLabel(d))}</th>`).join(''); }
  function tableEmpty(msg){ return `<div class="hint">${esc(msg || 'Chưa có dữ liệu.')}</div>`; }

  /* ===================== UI TEACHER ===================== */
  function teacherRuleObj(id){ return model().teacher?.[id] || {}; }
  function shortDayLabel(d){
    const map={thu2:'T2',thu3:'T3',thu4:'T4',thu5:'T5',thu6:'T6',thu7:'T7'};
    return map[d] || dayLabel(d);
  }
  function classShiftCode(lop){
    const raw = norm(lop?.buoi || lop?.buoihoc || lop?.session || lop?.shift || '');
    if(!raw) return '';
    if(raw.includes('song') || raw.includes('2 ca') || raw === 'sc' || raw.includes('sáng chiều') || raw.includes('sang chieu')) return 'SC';
    if(raw.includes('sáng') || raw.includes('sang')) return 'S';
    if(raw.includes('chiều') || raw.includes('chieu')) return 'C';
    return '';
  }
  function monWeeklyPeriods(monName){
    const key = subjectKey(monName);
    let best = 0;
    (D().mon || []).forEach(m=>{
      const ten = String(m.ten || m.mon || m.mamon || m.ma || m.id || '').trim();
      if(ten && subjectMatches(ten, key)){
        const n = Number(m.sotiet || m.soTiet || m.tiet || 0);
        if(Number.isFinite(n) && n > best) best = n;
      }
    });
    (D().monhoc || []).forEach(m=>{
      const ten = String(m.ten || m.mon || m.ma || m.ma2 || m.id || '').trim();
      if(ten && subjectMatches(ten, key)){
        const n = Number(m.sotiet || m.soTiet || m.tiet || 0);
        if(Number.isFinite(n) && n > best) best = n;
      }
    });
    return best;
  }
  function subjectPeriodMap(){
    const map = new Map();
    function addAlias(alias, n){
      const k = norm(alias);
      const val = Number(n || 0);
      if(!k || !Number.isFinite(val)) return;
      if(val > Number(map.get(k) || 0)) map.set(k, val);
    }
    function addRecord(m){
      const n = Number(m?.sotiet || m?.soTiet || m?.tiet || 0);
      [m?.ten,m?.mon,m?.mamon,m?.ma,m?.ma2,m?.id].forEach(v=>addAlias(v,n));
    }
    (D().mon || []).forEach(addRecord);
    (D().monhoc || []).forEach(addRecord);
    return map;
  }
  function buildTeacherStatsCache(){
    const sig = dataListSignature('teacherStats') + '|' + quickTkbSignature();
    if(__cache.teacherStats && __cache.teacherStatsSig === sig) return __cache.teacherStats;
    const out = new Map();
    const ensure = id => {
      const code = String(id || '').trim();
      if(!out.has(code)) out.set(code, { S:0, C:0, SC:0, TS:0, days:0, sessions:0, _aS:0, _aC:0, _aSC:0, _aTS:0, _sS:0, _sC:0, _sSC:0, _sTS:0, _daySet:new Set(), _sesSet:new Set() });
      return out.get(code);
    };
    const periodBySubject = subjectPeriodMap();
    const lopById = new Map((D().lop || []).map(l => [String(l.id), l]));
    const lopByCanon = new Map((D().lop || []).map(l => [norm(classCanon(l.id)), l]));
    const seen = new Set();
    for(const [k, v] of Object.entries(D().pccmMatrix || {})){
      const code = String(v || '').trim();
      if(!code) continue;
      const parts = String(k).split('|');
      const cls = String(parts[0] || '').trim();
      const mon = String(parts.slice(1).join('|') || '').trim();
      if(!cls || !mon) continue;
      const uniq = code + '|' + norm(cls) + '|' + norm(mon);
      if(seen.has(uniq)) continue;
      seen.add(uniq);
      const stat = ensure(code);
      const lop = lopByCanon.get(norm(cls)) || lopById.get(cls) || null;
      const shift = classShiftCode(lop);
      const n = Number(periodBySubject.get(norm(mon)) || 0);
      if(shift === 'S') stat._aS += n;
      else if(shift === 'C') stat._aC += n;
      else if(shift === 'SC') stat._aSC += n;
      else stat._aSC += n;
      stat._aTS += n;
    }
    const idx = buildScheduleIndex();
    if(idx.byTeacher && typeof idx.byTeacher.forEach === 'function'){
      idx.byTeacher.forEach((cells, code)=>{
        const stat = ensure(code);
        cells.forEach(cell=>{
          if(cell.buoi === 'sang') stat._sS += 1;
          else if(cell.buoi === 'chieu') stat._sC += 1;
          stat._sTS += 1;
          stat._daySet.add(String(cell.thu));
          stat._sesSet.add(String(cell.thu) + '|' + String(cell.buoi));
        });
      });
    }
    out.forEach(stat=>{
      const useSchedule = Number(stat._sTS || 0) > 0;
      stat.S = useSchedule ? Number(stat._sS || 0) : Number(stat._aS || 0);
      stat.C = useSchedule ? Number(stat._sC || 0) : Number(stat._aC || 0);
      stat.SC = useSchedule ? Number(stat._sSC || 0) : Number(stat._aSC || 0);
      stat.TS = useSchedule ? Number(stat._sTS || 0) : Number(stat._aTS || 0);
      stat.days = stat._daySet.size;
      stat.sessions = stat._sesSet.size;
      delete stat._aS;
      delete stat._aC;
      delete stat._aSC;
      delete stat._aTS;
      delete stat._sS;
      delete stat._sC;
      delete stat._sSC;
      delete stat._sTS;
      delete stat._daySet;
      delete stat._sesSet;
    });
    __cache.teacherStats = out;
    __cache.teacherStatsSig = sig;
    return out;
  }
  function teacherStatsFromAssignments(teacherId){
    const code = String(teacherId || '').trim();
    const stats = { S:0, C:0, SC:0, TS:0, days:0, sessions:0 };
    if(!code) return stats;
    const lopById = new Map((D().lop || []).map(l => [String(l.id), l]));
    const lopByCanon = new Map((D().lop || []).map(l => [norm(classCanon(l.id)), l]));
    const pccm = D().pccmMatrix || {};
    const seen = new Set();
    for(const [k, v] of Object.entries(pccm)){
      if(String(v || '').trim() !== code) continue;
      const parts = String(k).split('|');
      const cls = String(parts[0] || '').trim();
      const mon = String(parts.slice(1).join('|') || '').trim();
      if(!cls || !mon) continue;
      const uniq = norm(cls) + '|' + norm(mon);
      if(seen.has(uniq)) continue;
      seen.add(uniq);
      const lop = lopByCanon.get(norm(cls)) || lopById.get(cls) || null;
      const shift = classShiftCode(lop);
      const n = monWeeklyPeriods(mon);
      if(shift === 'S') stats.S += n;
      else if(shift === 'C') stats.C += n;
      else if(shift === 'SC') stats.SC += n;
      else stats.SC += n;
      stats.TS += n;
    }
    return stats;
  }
  function teacherStatsFromSchedule(teacherId){
    const code = String(teacherId || '').trim();
    const stats = { S:0, C:0, SC:0, TS:0, days:0, sessions:0 };
    if(!code) return stats;
    const idx = buildScheduleIndex();
    const cells = idx.byTeacher?.get(code) || [];
    const daySet = new Set();
    const sesSet = new Set();
    cells.forEach(cell=>{
      if(cell.buoi === 'sang') stats.S += 1;
      else if(cell.buoi === 'chieu') stats.C += 1;
      stats.TS += 1;
      daySet.add(String(cell.thu));
      sesSet.add(String(cell.thu) + '|' + String(cell.buoi));
    });
    stats.days = daySet.size;
    stats.sessions = sesSet.size;
    return stats;
  }
  function teacherStats(id){
    const cached = buildTeacherStatsCache().get(String(id || '').trim());
    if(cached){
      return {
        S: Number(cached.S || 0),
        C: Number(cached.C || 0),
        SC: Number(cached.SC || 0),
        TS: Number(cached.TS || 0),
        days: Number(cached.days || 0),
        sessions: Number(cached.sessions || 0)
      };
    }
    const a = teacherStatsFromAssignments(id);
    const s = teacherStatsFromSchedule(id);
    // Ưu tiên tuyệt đối số tiết thực tế từ TKB đã xếp để người dùng dễ đối chiếu.
    // Chỉ fallback sang phân công chuyên môn khi giáo viên chưa có tiết nào trên TKB.
    const useSchedule = Number(s.TS || 0) > 0;
    const out = useSchedule ? {
      S: Number(s.S || 0),
      C: Number(s.C || 0),
      SC: Number(s.SC || 0),
      TS: Number(s.TS || 0),
      days: Number(s.days || 0),
      sessions: Number(s.sessions || 0)
    } : {
      S: Number(a.S || 0),
      C: Number(a.C || 0),
      SC: Number(a.SC || 0),
      TS: Number(a.TS || 0),
      days: Number(s.days || 0),
      sessions: Number(s.sessions || 0)
    };
    return out;
  }
  function statText(v){ return Number(v || 0) > 0 ? String(Number(v || 0)) : ''; }
  function teacherIndexCell(i){ return `<td class="rb-tt">${i+1}</td>`; }
  function teacherNameCell(t){ return `<td class="rb-name"><b>${esc(t.name)}</b></td>`; }
  function teacherStatsCells(t){
    const s = teacherStats(t.id);
    return `<td>${statText(s.S)}</td><td>${statText(s.C)}</td><td>${statText(s.SC)}</td><td class="rb-total">${statText(s.TS)}</td>`;
  }
  function teacherHeaderStats(){ return `<th colspan="4">Số tiết</th>`; }
  function teacherHeaderStatsSub(){ return `<th>S</th><th>C</th><th>SC</th><th>TS</th>`; }
  function renderTeacherRule(rule){
    const title=(TEACHER_RULES.find(x=>x[0]===rule)||[])[1]||'Yêu cầu giáo viên';
    const rows=filteredTeachers();
    return `<div class="rb-teacher-screen"><h3>${esc(title)}</h3>${teacherFilterToolbar(rule)}${rows.length?teacherRuleTable(rule,rows):tableEmpty('Chưa có giáo viên.')}</div>`;
  }
  function teacherRuleTable(rule,rows){
    if(rule==='maxDaysSessions'){
      return `<div class="table-wrap rb-desktop-wrap"><table class="rb-desktop-table"><thead><tr><th rowspan="2">TT</th><th rowspan="2">Giáo viên</th>${teacherHeaderStats()}<th rowspan="2">Giới hạn số ngày dạy/1 tuần</th><th rowspan="2">Giới hạn số buổi dạy/1 tuần</th></tr><tr>${teacherHeaderStatsSub()}</tr></thead><tbody>${rows.map((t,i)=>{const r=teacherRuleObj(t.id);return `<tr>${teacherIndexCell(i)}${teacherNameCell(t)}${teacherStatsCells(t)}<td>${inputNum(t.id,'maxDaysSessions.maxDays',getPath(r,'maxDaysSessions.maxDays',''))}</td><td>${inputNum(t.id,'maxDaysSessions.maxSessions',getPath(r,'maxDaysSessions.maxSessions',''))}</td></tr>`;}).join('')}</tbody></table></div>`;
    }
    if(rule==='maxPeriods') return teacherDaySessionNumberTable(rows,'maxPeriods');
    if(rule==='lessonPlans') return teacherDaySessionNumberTable(rows,'lessonPlans');
    if(rule==='maxPeriodsClass'){
      const sgid = String(state.teacherSubjectGroupId || '__all__');
      return `<div class="table-wrap rb-desktop-wrap"><table class="rb-desktop-table"><thead><tr><th rowspan="2">TT</th><th rowspan="2">Giáo viên</th>${teacherHeaderStats()}<th rowspan="2">Giới hạn số tiết dạy/1 lớp/1 buổi</th><th rowspan="2">Giới hạn số tiết dạy/1 lớp/1 ngày</th></tr><tr>${teacherHeaderStatsSub()}</tr></thead><tbody>${rows.map((t,i)=>{const r=teacherRuleObj(t.id);return `<tr>${teacherIndexCell(i)}${teacherNameCell(t)}${teacherStatsCells(t)}<td>${inputNum(t.id,'maxPeriodsClass.bySubjectGroup.'+sgid+'.perSession',getPath(r,'maxPeriodsClass.bySubjectGroup.'+sgid+'.perSession',sgid==='__all__'?getPath(r,'maxPeriodsClass.perSession',''):''))}</td><td>${inputNum(t.id,'maxPeriodsClass.bySubjectGroup.'+sgid+'.perDay',getPath(r,'maxPeriodsClass.bySubjectGroup.'+sgid+'.perDay',sgid==='__all__'?getPath(r,'maxPeriodsClass.perDay',''):''))}</td></tr>`;}).join('')}</tbody></table></div>`;
    }
    if(rule==='maxMorningAfternoon'){
      return `<div class="table-wrap rb-desktop-wrap"><table class="rb-desktop-table"><thead><tr><th rowspan="2">TT</th><th rowspan="2">Giáo viên</th>${teacherHeaderStats()}<th rowspan="2">Giới hạn số buổi dạy sáng</th><th rowspan="2">Giới hạn số buổi dạy chiều</th></tr><tr>${teacherHeaderStatsSub()}</tr></thead><tbody>${rows.map((t,i)=>{const r=teacherRuleObj(t.id);return `<tr>${teacherIndexCell(i)}${teacherNameCell(t)}${teacherStatsCells(t)}<td>${inputNum(t.id,'maxMorningAfternoon.morning',getPath(r,'maxMorningAfternoon.morning',''))}</td><td>${inputNum(t.id,'maxMorningAfternoon.afternoon',getPath(r,'maxMorningAfternoon.afternoon',''))}</td></tr>`;}).join('')}</tbody></table></div>`;
    }
    if(rule==='oneSessionPerDay') return teacherDayCheckTable(rows,rule,{mode:'day'});
    if(rule==='noMorningP5AfternoonP1') return teacherDayCheckTable(rows,rule,{mode:'sessionNoMorning'});
    if(['oneLocationPerSession','gapBetweenLocations','maxOneMovePerSession'].includes(rule)) return teacherDayCheckTable(rows,rule,{mode:'session'});
    return '';
  }
  function teacherDaySessionNumberTable(rows,base){
    return `<div class="table-wrap rb-desktop-wrap"><table class="rb-desktop-table"><thead><tr><th rowspan="2">TT</th><th rowspan="2">Giáo viên</th>${teacherHeaderStats()}<th colspan="${days().length}">Buổi sáng</th><th colspan="${days().length}">Buổi chiều</th><th colspan="${days().length}">Cả ngày (sáng & chiều)</th></tr><tr>${teacherHeaderStatsSub()}${days().map(d=>`<th>${shortDayLabel(d)}</th>`).join('')}${days().map(d=>`<th>${shortDayLabel(d)}</th>`).join('')}${days().map(d=>`<th>${shortDayLabel(d)}</th>`).join('')}</tr></thead><tbody>${rows.map((t,i)=>{const r=teacherRuleObj(t.id);return `<tr>${teacherIndexCell(i)}${teacherNameCell(t)}${teacherStatsCells(t)}${days().map(d=>`<td>${inputNum(t.id,base+'.sang.'+d,getPath(r,base+'.sang.'+d,''))}</td>`).join('')}${days().map(d=>`<td>${inputNum(t.id,base+'.chieu.'+d,getPath(r,base+'.chieu.'+d,''))}</td>`).join('')}${days().map(d=>`<td>${inputNum(t.id,base+'.day.'+d,getPath(r,base+'.day.'+d,''))}</td>`).join('')}</tr>`;}).join('')}</tbody></table></div>`;
  }
  function teacherDayCheckTable(rows,base,opts){
    const mode = opts?.mode || 'day';
    if(mode === 'day'){
      return `<div class="table-wrap rb-desktop-wrap"><table class="rb-desktop-table"><thead><tr><th>TT</th><th>Giáo viên</th>${days().map(d=>`<th>${esc(dayLabel(d))}</th>`).join('')}</tr></thead><tbody>${rows.map((t,i)=>{const r=teacherRuleObj(t.id);return `<tr>${teacherIndexCell(i)}${teacherNameCell(t)}${days().map(d=>`<td class="rb-check">${inputCheck(t.id,base+'.'+d,getPath(r,base+'.'+d,false))}</td>`).join('')}</tr>`;}).join('')}</tbody></table></div>`;
    }
    if(mode === 'sessionNoMorning'){
      return `<div class="table-wrap rb-desktop-wrap"><table class="rb-desktop-table"><thead><tr><th rowspan="2">TT</th><th rowspan="2">Giáo viên</th><th colspan="${days().length}">Buổi sáng</th><th colspan="${days().length}">Buổi chiều</th></tr><tr>${days().map(d=>`<th>${shortDayLabel(d)}</th>`).join('')}${days().map(d=>`<th>${shortDayLabel(d)}</th>`).join('')}</tr></thead><tbody>${rows.map((t,i)=>{const r=teacherRuleObj(t.id);return `<tr>${teacherIndexCell(i)}${teacherNameCell(t)}${days().map(d=>`<td class="rb-check">${inputCheck(t.id,base+'.sang.'+d,getPath(r,base+'.sang.'+d,getPath(r,base+'.'+d,false)))}</td>`).join('')}${days().map(d=>`<td class="rb-check">${inputCheck(t.id,base+'.chieu.'+d,getPath(r,base+'.chieu.'+d,getPath(r,base+'.'+d,false)))}</td>`).join('')}</tr>`;}).join('')}</tbody></table></div>`;
    }
    return `<div class="table-wrap rb-desktop-wrap"><table class="rb-desktop-table"><thead><tr><th rowspan="2">TT</th><th rowspan="2">Giáo viên</th><th colspan="${days().length}">Buổi sáng</th><th colspan="${days().length}">Buổi chiều</th></tr><tr>${days().map(d=>`<th>${shortDayLabel(d)}</th>`).join('')}${days().map(d=>`<th>${shortDayLabel(d)}</th>`).join('')}</tr></thead><tbody>${rows.map((t,i)=>{const r=teacherRuleObj(t.id);return `<tr>${teacherIndexCell(i)}${teacherNameCell(t)}${days().map(d=>`<td class="rb-check">${inputCheck(t.id,base+'.sang.'+d,getPath(r,base+'.sang.'+d,false))}</td>`).join('')}${days().map(d=>`<td class="rb-check">${inputCheck(t.id,base+'.chieu.'+d,getPath(r,base+'.chieu.'+d,false))}</td>`).join('')}</tr>`;}).join('')}</tbody></table></div>`;
  }

  /* ===================== UI SUBJECT/SUBJECT GROUP ===================== */
  function renderSubjectRule(rule){ const title=(SUBJECT_RULES.find(x=>x[0]===rule)||[])[1]||'Yêu cầu môn học'; return `<h3>${esc(title)}</h3>${selectSubjectToolbar()}${subjectHint(rule)}${subjectTable(rule,false)}`; }
  function renderSubjectGroupRule(rule){ const title=(SUBJECT_GROUP_RULES.find(x=>x[0]===rule)||[])[1]||'Yêu cầu nhóm môn học'; return `<h3>${esc(title)}</h3>${selectSubjectGroupToolbar()}${subjectGroupHint(rule)}${subjectTable(rule,true)}`; }
  function subjectHint(rule){ const m={lessonBlocks:'Đặt Min/Max số buổi/cụm có 2,3,4,5 tiết xếp liền. Min chủ yếu được kiểm tra sau khi xếp.',avoidBreakPairs:'Tránh cặp tiết liền rơi vào tiết 2-3 hoặc 3-4 theo buổi.',linkedDays:'Bật “áp dụng” rồi tích các thứ/buổi cho phép có tiết xếp liền.',sessionAllowed:'Cho phép học sáng/chiều hoặc chỉ học 1 buổi/ngày.',weeklySessionPeriods:'Giới hạn tổng số tiết sáng/chiều trong tuần.',spacingDays:'Chặn học quá gần ngày nhau.',maxPeriods:'Giới hạn số tiết của môn trong 1 buổi và 1 ngày.',maxSessions:'Giới hạn số buổi học trong tuần.',globalLimit:'Giới hạn số lớp/giáo viên/phòng của môn tại 1 tiết hoặc 1 buổi.',fixedOff:'Cố định tiết nghỉ của môn học.'}; return `<div class="hint">${esc(m[rule]||'')}</div>`; }
  function subjectGroupHint(rule){ const m={sessionAllowed:'Cho phép nhóm môn chỉ học sáng/chiều hoặc chỉ học 1 buổi/ngày.',weeklySessionPeriods:'Giới hạn tổng số tiết của cả nhóm môn theo sáng/chiều trong tuần.',maxPeriods:'Giới hạn số tiết thuộc nhóm môn trong 1 buổi và 1 ngày.',maxSubjects:'Giới hạn số môn khác nhau thuộc nhóm trong 1 buổi/ngày.',maxSessions:'Giới hạn số buổi học của nhóm môn trong tuần.',globalLimit:'Giới hạn số lớp/giáo viên/phòng của nhóm môn tại 1 tiết hoặc 1 buổi.',groupLimit:'Rule nâng cao cho nhóm lớp/GV/phòng trong 1 buổi.',fixedOff:'Cố định tiết nghỉ cho nhóm môn.'}; return `<div class="hint">${esc(m[rule]||'')}</div>`; }
  function getRuleContainer(isGroup){ const c=model(); if(isGroup){ const gid=state.subjectGroupId || Object.keys(c.groups.subject||{})[0] || ''; state.subjectGroupId=gid; c.subjectGroup[gid]=c.subjectGroup[gid]||{byClass:{}}; return c.subjectGroup[gid]; } const sid=state.subjectId || (getSubjectList()[0]?.id || ''); state.subjectId=sid; c.subject[sid]=c.subject[sid]||{byClass:{}}; return c.subject[sid]; }
  function inputC(prefix,id,path,val){ return `<input type="number" data-cid="${esc(id)}" data-path="${esc(path)}" min="0" value="${esc(val == null ? '' : val)}">`; }
  function checkC(prefix,id,path,val){ return `<input type="checkbox" data-cid="${esc(id)}" data-path="${esc(path)}" ${truthy(val)?'checked':''}>`; }
  function subjectTable(rule,isGroup){ if(rule==='fixedOff') return renderFixedOff(isGroup?'subjectGroup':'subject'); const rows=classFilterRows(); const container=getRuleContainer(isGroup); if(!rows.length) return tableEmpty('Chưa có lớp.'); const rowRule=cls=>container.byClass?.[cls.id]||{}; if(rule==='sessionAllowed') return `<div class="table-wrap"><table><thead><tr><th>Lớp</th><th>Học buổi sáng</th><th>Học buổi chiều</th><th>Chỉ học 1 buổi/ngày</th></tr></thead><tbody>${rows.map(cls=>{const r=rowRule(cls);return `<tr><td><b>${esc(cls.name)}</b></td><td>${checkC('',cls.id,'sessionAllowed.allowMorning',getPath(r,'sessionAllowed.allowMorning',true))}</td><td>${checkC('',cls.id,'sessionAllowed.allowAfternoon',getPath(r,'sessionAllowed.allowAfternoon',true))}</td><td>${checkC('',cls.id,'sessionAllowed.oneSessionPerDay',getPath(r,'sessionAllowed.oneSessionPerDay',false))}</td></tr>`;}).join('')}</tbody></table></div>`; if(rule==='weeklySessionPeriods') return `<div class="table-wrap"><table><thead><tr><th>Lớp</th><th>Số tiết</th><th>Giới hạn tiết sáng/tuần</th><th>Giới hạn tiết chiều/tuần</th></tr></thead><tbody>${rows.map(cls=>{const r=rowRule(cls);return `<tr><td><b>${esc(cls.name)}</b></td><td class="muted">-</td><td>${inputC('',cls.id,'weeklySessionPeriods.morning',getPath(r,'weeklySessionPeriods.morning',''))}</td><td>${inputC('',cls.id,'weeklySessionPeriods.afternoon',getPath(r,'weeklySessionPeriods.afternoon',''))}</td></tr>`;}).join('')}</tbody></table></div>`; if(rule==='maxPeriods') return simpleClassNumberTable(rows,rowRule,[['maxPeriods.sang','Buổi sáng'],['maxPeriods.chieu','Buổi chiều'],['maxPeriods.day','Cả ngày']]); if(rule==='maxSessions') return simpleClassNumberTable(rows,rowRule,[['maxSessions.morning','Buổi sáng'],['maxSessions.afternoon','Buổi chiều'],['maxSessions.day','Cả ngày']]); if(rule==='maxSubjects') return simpleClassNumberTable(rows,rowRule,[['maxSubjects.sang','Buổi sáng'],['maxSubjects.chieu','Buổi chiều'],['maxSubjects.day','Cả ngày']]); if(rule==='spacingDays') return simpleClassNumberTable(rows,rowRule,[['spacingDays.days','Học cách ngày']]); if(rule==='avoidBreakPairs') return `<div class="table-wrap"><table><thead><tr><th>Lớp</th><th>Buổi sáng</th><th>Buổi chiều</th></tr></thead><tbody>${rows.map(cls=>{const r=rowRule(cls);return `<tr><td><b>${esc(cls.name)}</b></td><td>${checkC('',cls.id,'avoidBreakPairs.morning',getPath(r,'avoidBreakPairs.morning',false))}</td><td>${checkC('',cls.id,'avoidBreakPairs.afternoon',getPath(r,'avoidBreakPairs.afternoon',false))}</td></tr>`;}).join('')}</tbody></table></div>`; if(rule==='linkedDays') return `<div class="table-wrap"><table><thead><tr><th rowspan="2">Lớp</th><th rowspan="2">Áp dụng</th>${thDaysGrouped(2)}</tr><tr>${days().map(()=>`<th>S</th><th>C</th>`).join('')}</tr></thead><tbody>${rows.map(cls=>{const r=rowRule(cls);return `<tr><td><b>${esc(cls.name)}</b></td><td>${checkC('',cls.id,'linkedDays.enabled',getPath(r,'linkedDays.enabled',false))}</td>${days().map(d=>`<td>${checkC('',cls.id,'linkedDays.sang.'+d,getPath(r,'linkedDays.sang.'+d,false))}</td><td>${checkC('',cls.id,'linkedDays.chieu.'+d,getPath(r,'linkedDays.chieu.'+d,false))}</td>`).join('')}</tr>`;}).join('')}</tbody></table></div>`; if(rule==='lessonBlocks') return `<div class="table-wrap"><table><thead><tr><th rowspan="2">Lớp</th>${[2,3,4,5].map(n=>`<th colspan="2">${n} tiết xếp liền</th>`).join('')}</tr><tr>${[2,3,4,5].map(()=>`<th>Min</th><th>Max</th>`).join('')}</tr></thead><tbody>${rows.map(cls=>{const r=rowRule(cls);return `<tr><td><b>${esc(cls.name)}</b></td>${[2,3,4,5].map(n=>`<td>${inputC('',cls.id,'lessonBlocks.'+n+'.min',getPath(r,'lessonBlocks.'+n+'.min',''))}</td><td>${inputC('',cls.id,'lessonBlocks.'+n+'.max',getPath(r,'lessonBlocks.'+n+'.max',''))}</td>`).join('')}</tr>`;}).join('')}</tbody></table></div>`; if(rule==='globalLimit'||rule==='groupLimit') return renderGlobalLimitTable(isGroup?'subjectGroup':'subject', rule); return ''; }
  function simpleClassNumberTable(rows,rowRule,cols){ return `<div class="table-wrap"><table><thead><tr><th>Lớp</th>${cols.map(c=>`<th>${esc(c[1])}</th>`).join('')}</tr></thead><tbody>${rows.map(cls=>{const r=rowRule(cls);return `<tr><td><b>${esc(cls.name)}</b></td>${cols.map(c=>`<td>${inputC('',cls.id,c[0],getPath(r,c[0],''))}</td>`).join('')}</tr>`;}).join('')}</tbody></table></div>`; }
  function renderGlobalLimitTable(scope, rule){ const rootKey=scope==='subjectGroup'?state.subjectGroupId:state.subjectId; const obj=scope==='subjectGroup'?(model().subjectGroup[rootKey]=model().subjectGroup[rootKey]||{}):(model().subject[rootKey]=model().subject[rootKey]||{}); const base=rule==='groupLimit'?'groupLimit':'globalLimit'; const conf=obj[base]||{}; const fake='global'; function cell(path){ return `<input type="number" data-global-scope="${esc(scope)}" data-global-root="${esc(rootKey)}" data-global-base="${esc(base)}" data-path="${esc(path)}" min="0" value="${esc(getPath(conf,path,''))}">`; } return `<div class="table-wrap"><table><thead><tr><th>Phạm vi</th><th>Lớp học</th><th>Giáo viên</th><th>Phòng học</th></tr></thead><tbody><tr><td><b>/1 tiết</b></td><td>${cell('perSlot.classes')}</td><td>${cell('perSlot.teachers')}</td><td>${cell('perSlot.rooms')}</td></tr><tr><td><b>/1 buổi</b></td><td>${cell('perSession.classes')}</td><td>${cell('perSession.teachers')}</td><td>${cell('perSession.rooms')}</td></tr></tbody></table></div>`; }

  /* ===================== UI FIXED OFF / TIME LIMIT ===================== */
  

function getClassGroupIdFromClassName(name){ const m=String(name||'').match(/\d+/); return m ? ('khoi_'+m[0]) : ''; }
function syncFixedOffFromSelectedClass(){
  if(state.fixedType !== 'class') return alert('Đồng bộ hiện chỉ áp dụng cho Cố định tiết nghỉ lớp học.');
  const list = fixedOffListForType('class'); const selected = ensureFixedSelected('class', list); if(!selected) return alert('Chưa chọn lớp để đồng bộ.');
  const sourceName = itemName('class', selected) || selected; const gid = getClassGroupIdFromClassName(sourceName); const targetItems = gid ? groupItems('class', gid) : [];
  const sameKhoi = list.filter(it => targetItems.includes(it.id) && String(it.id)!==String(selected)); if(!sameKhoi.length) return alert('Không tìm thấy lớp khác cùng khối để đồng bộ.');
  if(!confirm(`Đồng bộ tiết nghỉ của lớp ${sourceName} cho ${sameKhoi.length} lớp còn lại trong ${gid.replace('khoi_','Khối ')}?`)) return;
  const c=model(); const srcOff = Object.assign({}, c.fixedOff?.class?.[selected] || {});
  sameKhoi.forEach(it=>{ c.fixedOff.class[it.id]=Object.assign({}, srcOff); days().forEach(thu=>['sang','chieu'].forEach(buoi=>{ const len=sessionLen(buoi); for(let ti=0; ti<len; ti++){ syncClassFixedOffCell(it.id, thu, buoi, ti, !!srcOff[slotKey(thu,buoi,ti)]); } })); });
  touchSave(); rerenderSafe(); render(); alert(`Đã đồng bộ tiết nghỉ từ lớp ${sourceName} cho ${sameKhoi.length} lớp cùng khối.`);
}
function syncFixedOffFromSelectedSubject(){
  if(state.fixedType !== 'subject') return alert('Đồng bộ hiện chỉ áp dụng cho Cố định tiết nghỉ môn học.');
  const list = fixedOffListForType('subject'); const selected = ensureFixedSelected('subject', list); if(!selected) return alert('Chưa chọn môn để đồng bộ.');
  const selectedName = itemName('subject', selected) || selected; const m = String(selectedName).match(/\d+/); if(!m) return alert('Không xác định được khối của môn đang chọn để đồng bộ.');
  const khoi = m[0]; if(!confirm(`Đồng bộ tiết nghỉ cho các môn thuộc khối ${khoi}?`)) return;
  const c=model(); const srcOff = Object.assign({}, c.fixedOff?.subject?.[selected] || {});
  const targets = list.filter(it=>{ const mm = String(itemName('subject', it.id)||it.id).match(/\d+/); return mm && mm[0]===khoi && String(it.id)!==String(selected); });
  targets.forEach(it=>{ c.fixedOff.subject[it.id]=Object.assign({}, srcOff); });
  touchSave(); rerenderSafe(); render(); alert(`Đã đồng bộ tiết nghỉ của môn ${selectedName} cho ${targets.length} môn cùng khối ${khoi}.`);
}

  function fixedOffDisplayName(type,id){
    if(type==='class') return 'Lớp ' + itemName(type,id);
    if(type==='teacher') return 'Giáo viên ' + itemName(type,id);
    if(type==='subject') return 'Môn ' + itemName(type,id);
    if(type==='room') return 'Phòng ' + itemName(type,id);
    if(type==='subjectGroup') return 'Nhóm môn ' + itemName(type,id);
    return itemName(type,id);
  }
  function fixedOffListForType(type){
    if(type==='subjectGroup') return Object.entries(model().groups.subject||{}).map(([id,g])=>({id,name:g.name||id}));
    return listByType(type);
  }
  function ensureFixedSelected(type,list){
    state.fixedSelected = state.fixedSelected || { class:'', teacher:'', subject:'', room:'', subjectGroup:'' };
    let id = state.fixedSelected[type] || '';
    if(!list.some(x=>String(x.id)===String(id))) id = list[0]?.id || '';
    state.fixedSelected[type] = id;
    return id;
  }
  function getTkbCellRaw(lopId, thu, buoi, ti){ return D().tkb?.[lopId]?.[thu]?.[buoi]?.[ti]; }
  function ensureTkbSession(lopId, thu, buoi){
    const d=D(); d.tkb=d.tkb||{}; d.tkb[lopId]=d.tkb[lopId]||{}; d.tkb[lopId][thu]=d.tkb[lopId][thu]||{};
    let arr=d.tkb[lopId][thu][buoi];
    if(!Array.isArray(arr)) arr=d.tkb[lopId][thu][buoi]=[];
    const len=sessionLen(buoi);
    while(arr.length<len) arr.push('');
    return arr;
  }
  function setFixedOffFlag(type,id,thu,buoi,ti,checked){
    const c=model(); c.fixedOff[type]=c.fixedOff[type]||{}; c.fixedOff[type][id]=c.fixedOff[type][id]||{};
    const sk=slotKey(thu,buoi,ti);
    if(checked) c.fixedOff[type][id][sk]=true; else delete c.fixedOff[type][id][sk];
    delEmpty(c.fixedOff[type][id]); if(Object.keys(c.fixedOff[type][id]||{}).length===0) delete c.fixedOff[type][id];
  }
  function syncClassFixedOffCell(lopId, thu, buoi, ti, checked){
    const arr=ensureTkbSession(lopId,thu,buoi); const cur=arr[ti];
    if(checked){
      if(cur==null || cur==='' || cur==='OFF' || !isFixedSafe(cur)) arr[ti]='OFF';
    }else{
      if(cur==='OFF') arr[ti]='';
    }
  }
  function fixedOffSlotChecked(type,id,thu,buoi,ti){
    if(type==='class'){
      const v=getTkbCellRaw(id,thu,buoi,ti);
      if(v==='OFF') return true;
    }
    return isFixedOff(type,id,thu,buoi,ti);
  }
  function fixedOffTopRows(type,id){
    const idx=buildScheduleIndex();
    let cells=[];
    if(type==='class') cells=(idx.classCells.get(String(id))||[]).slice();
    else if(type==='teacher') cells=(idx.byTeacher.get(String(id))||[]).slice();
    else if(type==='subject') cells=(idx.allCells||[]).filter(c=>norm(c.mon)===norm(id));
    else if(type==='room') cells=(idx.allCells||[]).filter(c=>norm(c.room)===norm(id));
    else if(type==='subjectGroup'){
      const items=(model().groups.subject?.[id]?.items||[]).map(norm);
      cells=(idx.allCells||[]).filter(c=>items.includes(norm(c.mon)));
    }
    const map=new Map();
    const keyOf = type==='class' ? (c=>norm(c.mon)) : type==='teacher' ? (c=>norm(c.mon)+'|'+String(c.lopId)) : type==='subject' ? (c=>String(c.lopId)) : type==='room' ? (c=>norm(c.mon)+'|'+String(c.lopId)) : (c=>norm(c.mon)+'|'+String(c.lopId));
    cells.forEach(c=>{
      const k=keyOf(c); if(!map.has(k)) map.set(k,{mon:c.mon, lopId:c.lopId, teacher:c.teacher, room:c.room, count:0});
      map.get(k).count += 1;
    });
    const rows=Array.from(map.values()).sort((a,b)=>String(a.mon||a.lopId).localeCompare(String(b.mon||b.lopId),'vi'));
    const s=cells.filter(c=>c.buoi==='sang').length, ch=cells.filter(c=>c.buoi==='chieu').length;
    return {rows,total:cells.length,s,c:ch,sc:0};
  }
  function fixedOffTopTable(type,id){
    const meta=fixedOffTopRows(type,id); const rows=meta.rows;
    let heads=[], body='';
    if(type==='class'){
      heads=['TT','Môn học','Giáo viên','Phòng học','Số tiết'];
      body=rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.mon||'')}</td><td>${esc(teacherName(r.teacher)||r.teacher||'')}</td><td>${esc(r.room||'')}</td><td>${esc(r.count)}</td></tr>`).join('');
    }else if(type==='teacher'){
      heads=['TT','Môn học','Lớp học','Phòng học','Số tiết'];
      body=rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.mon||'')}</td><td>${esc(classNameOf(r.lopId)||r.lopId||'')}</td><td>${esc(r.room||'')}</td><td>${esc(r.count)}</td></tr>`).join('');
    }else if(type==='subject' || type==='subjectGroup'){
      heads=['TT','Lớp học','Giáo viên','Phòng học','Số tiết'];
      body=rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(classNameOf(r.lopId)||r.lopId||'')}</td><td>${esc(teacherName(r.teacher)||r.teacher||'')}</td><td>${esc(r.room||'')}</td><td>${esc(r.count)}</td></tr>`).join('');
    }else if(type==='room'){
      heads=['TT','Môn học','Lớp học','Giáo viên','Số tiết'];
      body=rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.mon||'')}</td><td>${esc(classNameOf(r.lopId)||r.lopId||'')}</td><td>${esc(teacherName(r.teacher)||r.teacher||'')}</td><td>${esc(r.count)}</td></tr>`).join('');
    }
    if(!body) body=`<tr><td colspan="${heads.length}" class="muted">Chưa có dữ liệu.</td></tr>`;
    return `<div class="rb-fixedoff-titlebar"><h3>${esc(fixedOffDisplayName(type,id))}</h3><div class="rb-fixedoff-total">Tổng số tiết ${meta.total} (S: ${meta.s}. C: ${meta.c}. Sc: ${meta.sc})</div></div><div class="rb-fixedoff-top"><table><thead><tr>${heads.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${body}</tbody></table></div>`;
  }
  function fixedOffGrid(type,id){
    const rows=[];
    for(let i=0;i<sessionLen('sang');i++) rows.push({buoi:'sang',ti:i,sep:false});
    for(let i=0;i<sessionLen('chieu');i++) rows.push({buoi:'chieu',ti:i,sep:i===0});
    return `<div class="rb-fixedoff-grid"><table><thead><tr>${days().map(d=>`<th>${esc(dayLabel(d)).toUpperCase()}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr class="${r.sep?'sep':''}">${days().map(d=>{ const checked=fixedOffSlotChecked(type,id,d,r.buoi,r.ti); return `<td class="${checked?'off':''}" data-fo-toggle="1" data-off-type="${esc(type)}" data-off-id="${esc(id)}" data-slot="${esc(slotKey(d,r.buoi,r.ti))}"><span class="rb-off-text">Nghỉ</span></td>`; }).join('')}</tr>`).join('')}</tbody></table></div>`;
  }
  function renderFixedOff(type){
    const list=fixedOffListForType(type);
    if(!list.length) return tableEmpty('Chưa có dữ liệu.');
    const selected=ensureFixedSelected(type,list);
    const note = (type==='class' || type==='subject') ? `<div class="hint" style="margin:0 0 8px 0;padding:6px 8px">Dùng nút <b>⇄ Đồng bộ</b> trên thanh công cụ để đồng bộ nhanh theo khối.</div>` : ``;
    return `<div class="rb-fixedoff-screen"><div class="rb-fixedoff-list">${list.map(it=>`<button type="button" class="rb-fixedoff-item ${String(it.id)===String(selected)?'active':''}" data-fo-select="${esc(it.id)}">${esc(it.name)}</button>`).join('')}</div><div class="rb-fixedoff-main">${note}${fixedOffTopTable(type,selected)}${fixedOffGrid(type,selected)}</div></div>`;
  }
  function renderFixedOffGroupSubject(){ return renderFixedOff('subjectGroup'); }
  function renderTimeLimit(){ const c=model(); return `<h3>Giới hạn số tiết/1 thời điểm</h3><div class="hint">Dùng để giới hạn số lớp / giáo viên / phòng của một môn hoặc nhóm môn tại cùng 1 tiết hoặc 1 buổi.</div><div class="toolbar"><button type="button" class="primary" data-add-time-limit>Thêm dòng</button></div><div class="table-wrap"><table><thead><tr><th>Tên</th><th>Áp dụng cho</th><th>Đối tượng</th><th>Lớp/1 tiết</th><th>GV/1 tiết</th><th>Phòng/1 tiết</th><th>Lớp/1 buổi</th><th>GV/1 buổi</th><th>Phòng/1 buổi</th><th>Xóa</th></tr></thead><tbody>${(c.timeLimit||[]).map((r,i)=>timeLimitRow(r,i)).join('')||'<tr><td colspan="10" class="muted">Chưa có giới hạn.</td></tr>'}</tbody></table></div>`; }
  function timeLimitRow(r,i){ const targets=[['subject','Môn học'],['subjectGroup','Nhóm môn'],['teacherGroup','Nhóm giáo viên'],['classGroup','Nhóm lớp'],['roomGroup','Nhóm phòng']]; function targetOpts(){ return targets.map(t=>`<option value="${t[0]}" ${r.targetType===t[0]?'selected':''}>${t[1]}</option>`).join(''); } function itemOpts(){ let type='subject'; if(r.targetType==='subjectGroup') type='subject'; else if(r.targetType==='teacherGroup') type='teacher'; else if(r.targetType==='classGroup') type='class'; else if(r.targetType==='roomGroup') type='room'; if(r.targetType==='subject') return getSubjectList().map(x=>`<option value="${esc(x.id)}" ${r.targetId===x.id?'selected':''}>${esc(x.name)}</option>`).join(''); return groupOptions(type,r.targetId); } return `<tr><td><input type="text" data-tl="${i}" data-field="name" value="${esc(r.name||'')}"></td><td><select data-tl="${i}" data-field="targetType">${targetOpts()}</select></td><td><select data-tl="${i}" data-field="targetId">${itemOpts()}</select></td>${['perSlot.classes','perSlot.teachers','perSlot.rooms','perSession.classes','perSession.teachers','perSession.rooms'].map(p=>`<td><input type="number" data-tl="${i}" data-field="${p}" value="${esc(getPath(r,p,''))}" min="0"></td>`).join('')}<td><button type="button" class="danger" data-del-tl="${i}">Xóa</button></td></tr>`; }

  /* ===================== SAVE UI ===================== */
  function bindBodyEvents(){ const root=document.getElementById(PANEL_ID); if(!root) return;
    const gt=root.querySelector('[data-rb-group-type]'); if(gt) gt.onchange=()=>{state.groupType=gt.value;state.groupId='';render();}; const gid=root.querySelector('[data-rb-group-id]'); if(gid) gid.onchange=()=>{state.groupId=gid.value;render();}; const saveG=root.querySelector('[data-rb-save-group]'); if(saveG) saveG.onclick=saveGroupFromUI; const newG=root.querySelector('[data-rb-new-group]'); if(newG) newG.onclick=()=>{state.groupId=''; const n=root.querySelector('[data-rb-group-name]'); if(n)n.value=''; root.querySelectorAll('[data-rb-group-items] input').forEach(x=>x.checked=false);}; const delG=root.querySelector('[data-rb-delete-group]'); if(delG) delG.onclick=deleteGroupFromUI;
    const tg=root.querySelector('[data-teacher-group-filter]'); if(tg) tg.onchange=()=>{state.teacherGroup=tg.value;render();}; const tsg=root.querySelector('[data-teacher-subject-group-filter]'); if(tsg) tsg.onchange=()=>{state.teacherSubjectGroupId=tsg.value || '__all__'; render();}; const ts=root.querySelector('[data-teacher-search]'); if(ts) ts.oninput=()=>{state.search=ts.value;render();}; const cg=root.querySelector('[data-class-group-filter]'); if(cg) cg.onchange=()=>{state.classGroup=cg.value;render();}; const sid=root.querySelector('[data-subject-id]'); if(sid) sid.onchange=()=>{state.subjectId=sid.value;render();}; const sgid=root.querySelector('[data-subject-group-id]'); if(sgid) sgid.onchange=()=>{state.subjectGroupId=sgid.value;render();}; const saveCur=root.querySelector('[data-rb-save-current]'); if(saveCur) saveCur.onclick=()=>saveCurrentFromUI(true); const clearCur=root.querySelector('[data-rb-clear-current]'); if(clearCur) clearCur.onclick=clearCurrentRule;
    const addTL=root.querySelector('[data-add-time-limit]'); if(addTL) addTL.onclick=()=>{model().timeLimit.push({name:'',targetType:'subject',targetId:'',perSlot:{},perSession:{}}); touchSave(); render();}; root.querySelectorAll('[data-del-tl]').forEach(b=>b.onclick=()=>{model().timeLimit.splice(Number(b.dataset.delTl),1); touchSave(); render();}); root.querySelectorAll('[data-tl]').forEach(el=>el.onchange=()=>saveCurrentFromUI(false));
    root.querySelectorAll('[data-fo-select]').forEach(b=>b.onclick=()=>{ state.fixedSelected = state.fixedSelected || {}; state.fixedSelected[state.fixedType]=b.dataset.foSelect||''; render(); });
    root.querySelectorAll('[data-fo-toggle][data-off-type][data-off-id][data-slot]').forEach(el=>el.onclick=()=>{ const type=el.dataset.offType, id=el.dataset.offId; const parts=String(el.dataset.slot||'').split('|'); const thu=parts[0]||'', buoi=parts[1]||'', ti=Number(parts[2]||0); const checked=!el.classList.contains('off'); setFixedOffFlag(type,id,thu,buoi,ti,checked); if(type==='class') syncClassFixedOffCell(id,thu,buoi,ti,checked); touchSave(); rerenderSafe(); render(); });
    const clearAll=root.querySelector('[data-rb-clear-all]'); if(clearAll) clearAll.onclick=clearAllConstraints; ['teacher','subject','subjectGroup','fixedOff','timeLimit'].forEach(k=>{ const b=root.querySelector(`[data-clear-${k}]`); if(b) b.onclick=()=>clearSection(k); });
  }
  function saveGroupFromUI(){ const root=document.getElementById(PANEL_ID); if(!root)return; const type=state.groupType||'subject'; const name=String(root.querySelector('[data-rb-group-name]')?.value||'').trim(); if(!name){alert('Nhập tên nhóm.');return;} const id=state.groupId||cleanId(name,type); const items=Array.from(root.querySelectorAll('[data-rb-group-items] input:checked')).map(x=>x.value); model().groups[type][id]={name,items}; state.groupId=id; touchSave(); render(); }
  function deleteGroupFromUI(){ const type=state.groupType||'subject', id=state.groupId; if(!id)return; if(!confirm('Xóa nhóm này?'))return; delete model().groups[type][id]; state.groupId=''; touchSave(); render(); }
  function saveCurrentFromUI(showMsg){ const root=document.getElementById(PANEL_ID); if(!root)return; const c=model();
    // teacher
    root.querySelectorAll('[data-tid][data-path]').forEach(el=>{ const tid=el.dataset.tid, path=el.dataset.path; c.teacher[tid]=c.teacher[tid]||{}; let val=el.type==='checkbox'?!!el.checked:(el.tagName==='SELECT'?String(el.value||'').trim():(el.value===''?'':toInt(el.value,''))); setPath(c.teacher[tid],path,val); delEmpty(c.teacher[tid]); if(Object.keys(c.teacher[tid]).length===0) delete c.teacher[tid]; });
    // subject / subjectGroup by class
    const isSG=state.section==='subjectGroup'; const container=(state.section==='subject')?getRuleContainer(false):(state.section==='subjectGroup'?getRuleContainer(true):null); if(container){ container.byClass=container.byClass||{}; root.querySelectorAll('[data-cid][data-path]').forEach(el=>{ const cid=el.dataset.cid, path=el.dataset.path; container.byClass[cid]=container.byClass[cid]||{}; let val=el.type==='checkbox'?!!el.checked:(el.value===''?'':toInt(el.value,'')); setPath(container.byClass[cid],path,val); delEmpty(container.byClass[cid]); if(Object.keys(container.byClass[cid]).length===0) delete container.byClass[cid]; }); }
    // global limits embedded in subject / subjectGroup
    root.querySelectorAll('[data-global-scope][data-path]').forEach(el=>{ const scope=el.dataset.globalScope, rootId=el.dataset.globalRoot, base=el.dataset.globalBase, path=el.dataset.path; const obj=scope==='subjectGroup'?(c.subjectGroup[rootId]=c.subjectGroup[rootId]||{}):(c.subject[rootId]=c.subject[rootId]||{}); obj[base]=obj[base]||{}; setPath(obj[base],path,el.value===''?'':toInt(el.value,'')); delEmpty(obj[base]); });
    // fixed off
    root.querySelectorAll('[data-off-type][data-off-id][data-slot]').forEach(el=>{ const type=el.dataset.offType, id=el.dataset.offId, sk=el.dataset.slot; c.fixedOff[type]=c.fixedOff[type]||{}; c.fixedOff[type][id]=c.fixedOff[type][id]||{}; if(el.checked) c.fixedOff[type][id][sk]=true; else delete c.fixedOff[type][id][sk]; delEmpty(c.fixedOff[type][id]); if(Object.keys(c.fixedOff[type][id]).length===0) delete c.fixedOff[type][id]; });
    // time limit
    root.querySelectorAll('[data-tl][data-field]').forEach(el=>{ const i=Number(el.dataset.tl), f=el.dataset.field; c.timeLimit[i]=c.timeLimit[i]||{}; let val=el.tagName==='SELECT'||el.type==='text'?String(el.value||'').trim():(el.value===''?'':toInt(el.value,'')); setPath(c.timeLimit[i],f,val); }); c.timeLimit.forEach(r=>delEmpty(r));
    touchSave(); if(showMsg!==false) alert('Đã lưu ràng buộc.'); }
  function currentRulePayload(){
    const root=document.getElementById(PANEL_ID);
    const fields=[];
    if(root){
      root.querySelectorAll('[data-tid][data-path],[data-cid][data-path],[data-off-type][data-off-id][data-slot],[data-tl][data-field],[data-global-scope][data-path]').forEach(el=>{
        const item={};
        Array.from(el.attributes).forEach(a=>{ if(a.name.indexOf('data-')===0) item[a.name.replace(/^data-/,'')]=a.value; });
        item.value = el.type === 'checkbox' ? !!el.checked : String(el.value || '');
        fields.push(item);
      });
    }
    return {section:state.section,teacherRule:state.teacherRule,subjectRule:state.subjectRule,subjectGroupRule:state.subjectGroupRule,fixedType:state.fixedType,fields};
  }
  function copyCurrentRule(showMsg){
    if(state.section==='fixedOff' && state.fixedType==='class') return syncFixedOffFromSelectedClass();
    if(state.section==='fixedOff' && state.fixedType==='subject') return syncFixedOffFromSelectedSubject();
    const text=JSON.stringify(currentRulePayload(),null,2);
    const done=()=>{ if(showMsg!==false) alert('Đã copy dữ liệu mục hiện tại.'); };
    try{
      if(navigator.clipboard && navigator.clipboard.writeText){
        navigator.clipboard.writeText(text).then(done).catch(()=>{ window.prompt('Copy dữ liệu ràng buộc:', text); done(); });
      }else{
        window.prompt('Copy dữ liệu ràng buộc:', text); done();
      }
    }catch(_){
      window.prompt('Copy dữ liệu ràng buộc:', text); done();
    }
  }
  function clearCurrentRule(){ if(!confirm('Xóa dữ liệu mục này?')) return; const c=model(); if(state.section==='teacher'){ filteredTeachers().forEach(t=>{ if(c.teacher[t.id]){ if(state.teacherRule==='maxPeriodsClass' && c.teacher[t.id].maxPeriodsClass && c.teacher[t.id].maxPeriodsClass.bySubjectGroup){ const gid=String(state.teacherSubjectGroupId||'__all__'); delete c.teacher[t.id].maxPeriodsClass.bySubjectGroup[gid]; delEmpty(c.teacher[t.id].maxPeriodsClass.bySubjectGroup); delEmpty(c.teacher[t.id].maxPeriodsClass); } else { delete c.teacher[t.id][state.teacherRule]; } delEmpty(c.teacher[t.id]); if(!Object.keys(c.teacher[t.id]).length) delete c.teacher[t.id]; } }); } else if(state.section==='subject'){ const obj=getRuleContainer(false); Object.keys(obj.byClass||{}).forEach(cid=>{ delete obj.byClass[cid][state.subjectRule]; delEmpty(obj.byClass[cid]); if(!Object.keys(obj.byClass[cid]).length) delete obj.byClass[cid]; }); } else if(state.section==='subjectGroup'){ const obj=getRuleContainer(true); Object.keys(obj.byClass||{}).forEach(cid=>{ delete obj.byClass[cid][state.subjectGroupRule]; delEmpty(obj.byClass[cid]); if(!Object.keys(obj.byClass[cid]).length) delete obj.byClass[cid]; }); } touchSave(); render(); }
  function renderCheck(){ const arr=validateAll(300); return `<h3>Kiểm tra ràng buộc</h3><div class="hint">Chỉ khi bấm kiểm tra mới quét toàn bộ TKB. Kéo-thả/xếp tự động chỉ kiểm tra nhanh ô đang đặt.</div><div class="box"><b>Kết quả: ${arr.length} vi phạm${arr.length>=300?' (hiển thị 300 lỗi đầu để tránh đứng trang)':''}</b><pre>${esc(arr.length?arr.map((x,i)=>`${i+1}. ${x.className||x.lopId||''} ${x.mon?('['+x.mon+'] '):''}${x.thu?dayLabel(x.thu)+' '+SESSION_LABEL[x.buoi]+' tiết '+(Number(x.ti)+1)+': ':''}${x.message||''}`).join('\n'):'Không phát hiện vi phạm ràng buộc.')}</pre></div>`; }
  function renderClear(){ return `<div class="rb-clear-screen"><h3>Xóa ràng buộc TKB</h3><div class="hint">Chỉ xóa dữ liệu ràng buộc. Không xóa TKB đã xếp, PCCM và danh mục.</div><div class="rb-clear-grid"><div class="rb-clear-card"><b>Yêu cầu của giáo viên</b><span>Xóa toàn bộ ràng buộc trong nhóm yêu cầu giáo viên.</span><button type="button" class="danger" data-clear-teacher>Xóa mục này</button></div><div class="rb-clear-card"><b>Yêu cầu của môn học</b><span>Xóa toàn bộ ràng buộc trong nhóm yêu cầu môn học.</span><button type="button" class="danger" data-clear-subject>Xóa mục này</button></div><div class="rb-clear-card"><b>Yêu cầu của nhóm môn học</b><span>Xóa toàn bộ ràng buộc trong nhóm môn học.</span><button type="button" class="danger" data-clear-subjectGroup>Xóa mục này</button></div><div class="rb-clear-card"><b>Cố định tiết nghỉ</b><span>Xóa dữ liệu cố định nghỉ lớp, giáo viên, môn và phòng.</span><button type="button" class="danger" data-clear-fixedOff>Xóa mục này</button></div><div class="rb-clear-card"><b>Giới hạn số tiết/1 thời điểm</b><span>Xóa toàn bộ giới hạn theo lớp, giáo viên, môn và phòng.</span><button type="button" class="danger" data-clear-timeLimit>Xóa mục này</button></div><div class="rb-clear-card"><b>Toàn bộ ràng buộc TKB</b><span>Khôi phục toàn bộ dữ liệu ràng buộc về trạng thái trống.</span><button type="button" class="danger" data-rb-clear-all>Xóa toàn bộ</button></div></div></div>`; }
  function clearSection(k){ if(!confirm('Xóa mục này?'))return; const c=model(); if(k==='teacher') c.teacher={}; if(k==='subject') c.subject={}; if(k==='subjectGroup') c.subjectGroup={}; if(k==='fixedOff') c.fixedOff={class:{},teacher:{},subject:{},room:{},subjectGroup:{}}; if(k==='timeLimit') c.timeLimit=[]; touchSave(); render(); }
  function clearAllConstraints(){ if(!confirm('Xóa toàn bộ ràng buộc TKB?'))return; D().tkbConstraints=emptyModel(); syncDefaultGroups(); touchSave(); render(); }

  /* ===================== HOOKS ===================== */
  function installHooks(){
    window.toggleRangBuoc=openPanel; window.openRangBuocTKB=openPanel;
    try{
      if(typeof window.saveStore === 'function' && !window.saveStore.__tkbConstraintsInvalidateWrapped){
        const oldSave = window.saveStore;
        window.saveStore = function(){ invalidateConstraintCache(); return oldSave.apply(this, arguments); };
        window.saveStore.__tkbConstraintsInvalidateWrapped = true;
      }
    }catch(e){ console.warn('[tkb-constraints] saveStore hook failed', e); }
    try{ if(typeof validateDrop==='function' && !validateDrop.__tkbConstraintsFullWrapped){ const old=validateDrop; const wrapped=function(targetTd,mon){ const base=old.apply(this,arguments); if(base && base.ok===false) return base; try{ const thu=targetTd?.dataset?.thu, buoi=targetTd?.dataset?.buoi, ti=Number(targetTd?.dataset?.ti); const src=(typeof dragData!=='undefined' && dragData && dragData.type==='cell') ? dragData.from?.dataset : null; const res=canPlaceLesson({lopId:currentClassId(),mon,thu,buoi,ti,src,mode:'drag'}); if(!res.ok) return {ok:false,reason:'tkb-constraints',msg:(res.messages||[]).join('\n')}; }catch(e){ console.warn('[tkb-constraints] validateDrop hook failed',e); } return base; }; wrapped.__tkbConstraintsFullWrapped=true; window.validateDrop=wrapped; } }catch(e){ console.warn('[tkb-constraints] install validateDrop hook failed',e); }
    try{ if(typeof taoTKBBoSungTheoConfig==='function' && !taoTKBBoSungTheoConfig.__tkbConstraintsFullWrapped){ const old=taoTKBBoSungTheoConfig; const wrapped=function(existingTkb,mons,config,extraCanPlaceCell,extraScoreBlock){ const lopId=inferClassIdFromTkb(existingTkb) || currentClassId(); invalidateConstraintCache(); const combined=function(thu,buoi,ti,mon){ if(typeof extraCanPlaceCell==='function' && !extraCanPlaceCell(thu,buoi,ti,mon)) return false; if(!lopId){ return true; } const res=canPlaceLesson({lopId,mon,thu,buoi,ti,localTkb:existingTkb,mode:'auto'}); return !!res.ok; }; const ret=old.call(this,existingTkb,mons,config,combined,extraScoreBlock); invalidateConstraintCache(); return ret; }; wrapped.__tkbConstraintsFullWrapped=true; window.taoTKBBoSungTheoConfig=wrapped; } }catch(e){ console.warn('[tkb-constraints] install auto schedule hook failed',e); }
  }

  function debugCanPlace(lopId, mon, thu, buoi, ti){
    const res = canPlaceLesson({lopId, mon, thu, buoi, ti:Number(ti), full:true, mode:'debug'});
    try{ console.log('[TKBConstraints debugCanPlace]', {lopId, mon, thu, buoi, ti, result:res}); }catch(_){ }
    return res;
  }
  function openPage(opts){ return openPanel(Object.assign({page:true}, opts || {})); }
  const API={version:VERSION,get:model,save:touchSave,open:openPanel,openPage,close:closePanel,render,syncDefaultGroups,canPlaceLesson,canPlaceCell,validateAll,explain:validateAll,score:function(){return validateAll(1000).length;},teacherCellsAfterPlace,inferClassIdFromTkb,debugCanPlace};
  window.TKBConstraints=API; window.TKBConstraintsFull=API;
  try{ injectStyle(); syncDefaultGroups(); installHooks(); console.log('[tkb-constraints] loaded', VERSION); }catch(e){ console.warn('[tkb-constraints] init failed',e); }
})();
