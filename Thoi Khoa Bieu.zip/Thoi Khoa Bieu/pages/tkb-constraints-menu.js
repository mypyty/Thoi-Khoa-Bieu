(function(){
  'use strict';

  const MENU_ID = 'tkbConstraintsDropdownMenu';
  const STYLE_ID = 'tkbConstraintsDropdownStyle';

  const teacherCommon = [
    ['maxDaysSessions', 'Giới hạn số ngày dạy & buổi dạy/1 tuần'],
    ['maxPeriods', 'Giới hạn số tiết dạy/1 buổi'],
    ['maxPeriodsClass', 'Giới hạn số tiết dạy/1 lớp'],
    ['lessonPlans', 'Giới hạn số giáo án/1 buổi']
  ];
  const teacherTwoShift = [
    ['maxMorningAfternoon', 'Giới hạn số buổi dạy sáng & chiều'],
    ['oneSessionPerDay', 'Chỉ dạy 1 buổi/1 ngày'],
    ['noMorningP5AfternoonP1', 'Không dạy tiết 5 sáng & tiết 1 chiều/1 ngày']
  ];
  const teacherLocations = [
    ['oneLocationPerSession', 'Chỉ dạy 1 địa điểm/1 buổi'],
    ['gapBetweenLocations', 'Có tiết trống giữa 2 địa điểm'],
    ['maxOneMovePerSession', 'Không di chuyển 2 lần/1 buổi giữa các địa điểm']
  ];
  const subjectRules = [
    ['lessonBlocks', 'Số buổi học có tiết học xếp liền'],
    ['avoidBreakPairs', 'Tránh xếp tiết học liền vào tiết 2-3, 3-4'],
    ['linkedDays', 'Tránh xếp tiết học liền vào các thứ trong tuần'],
    ['sessionAllowed', 'Giới hạn buổi học của môn học'],
    ['weeklySessionPeriods', 'Giới hạn số tiết của môn học/1 buổi/1 tuần'],
    ['spacingDays', 'Học cách ngày'],
    ['maxPeriods', 'Giới hạn số tiết/1 buổi'],
    ['maxSessions', 'Giới hạn số buổi học'],
    ['globalLimit', 'Giới hạn số lớp học, giáo viên, phòng học'],
    ['fixedOff', 'Cố định tiết nghỉ môn học']
  ];
  const subjectGroupRules = [
    ['sessionAllowed', 'Giới hạn buổi học'],
    ['weeklySessionPeriods', 'Giới hạn số tiết của nhóm môn học/1 buổi/1 tuần'],
    ['maxPeriods', 'Giới hạn số tiết/1 buổi'],
    ['maxSubjects', 'Giới hạn số môn học/1 buổi'],
    ['maxSessions', 'Giới hạn số buổi học'],
    ['globalLimit', 'Giới hạn số lớp học, giáo viên, phòng học'],
    ['groupLimit', 'Giới hạn nhóm lớp học, giáo viên, phòng học/1 buổi'],
    ['fixedOff', 'Cố định tiết nghỉ nhóm môn học']
  ];
  const fixedOffRules = [
    ['class', 'Cố định tiết nghỉ lớp học'],
    ['teacher', 'Cố định tiết nghỉ giáo viên'],
    ['subject', 'Cố định tiết nghỉ môn học'],
    ['room', 'Cố định tiết nghỉ phòng học']
  ];

  function esc(s){
    return String(s == null ? '' : s).replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
  }

  function ensureStyle(){
    if(document.getElementById(STYLE_ID)) return;
    const st = document.createElement('style');
    st.id = STYLE_ID;
    st.textContent = `
      #${MENU_ID}{position:fixed;z-index:1000002;min-width:228px;background:#fff;border:1px solid #cfd6e3;box-shadow:0 8px 22px rgba(0,0,0,.18);font:13px "Segoe UI",Arial,sans-serif;color:#222}
      #${MENU_ID},#${MENU_ID} ul{list-style:none;margin:0;padding:4px 0}
      #${MENU_ID} li{position:relative;white-space:nowrap}
      #${MENU_ID} button{width:100%;display:flex;align-items:center;justify-content:space-between;gap:18px;border:0;background:transparent;border-radius:0;padding:7px 28px 7px 14px;text-align:left;color:inherit;font:inherit;cursor:default}
      #${MENU_ID} button:hover,#${MENU_ID} li:hover>button{background:#e8f0ff}
      #${MENU_ID} .rb-menu-arrow{position:absolute;right:9px}
      #${MENU_ID} .rb-menu-sep{height:1px;background:#d8d8d8;margin:4px 0}
      #${MENU_ID} .rb-menu-head{padding:6px 14px 4px;font-weight:700;color:#333}
      #${MENU_ID} .rb-menu-sub{display:none;position:absolute;left:100%;top:-5px;min-width:322px;background:#fff;border:1px solid #cfd6e3;box-shadow:0 8px 22px rgba(0,0,0,.18);padding:4px 0}
      #${MENU_ID} li:hover>.rb-menu-sub{display:block}
      #${MENU_ID} .rb-menu-danger{font-weight:700}
    `;
    document.head.appendChild(st);
  }

  function openPage(section, rule, title){
    closeMenu();
    const api = window.TKBConstraints || window.TKBConstraintsFull;
    if(!api || typeof api.openPage !== 'function'){
      alert('Chưa tải xong module ràng buộc TKB.');
      return;
    }
    api.openPage({section, rule, title: title || 'Ràng buộc TKB'});
  }

  function rows(section, list){
    return list.map(([rule, label]) => `<li><button type="button" data-rb-open="${esc(section)}" data-rb-rule="${esc(rule)}" data-rb-title="${esc(label)}">${esc(label)}</button></li>`).join('');
  }

  function buildMenu(){
    return `
      <ul>
        <li>
          <button type="button">Yêu cầu của giáo viên <span class="rb-menu-arrow">›</span></button>
          <ul class="rb-menu-sub">
            <li class="rb-menu-head">Yêu cầu chung</li>
            ${rows('teacher', teacherCommon)}
            <li class="rb-menu-sep"></li>
            <li class="rb-menu-head">Yêu cầu của giáo viên dạy 2 ca</li>
            ${rows('teacher', teacherTwoShift)}
            <li class="rb-menu-sep"></li>
            <li class="rb-menu-head">Yêu cầu của giáo viên dạy nhiều địa điểm</li>
            ${rows('teacher', teacherLocations)}
          </ul>
        </li>
        <li>
          <button type="button">Yêu cầu của môn học <span class="rb-menu-arrow">›</span></button>
          <ul class="rb-menu-sub">${rows('subject', subjectRules)}</ul>
        </li>
        <li>
          <button type="button">Yêu cầu của nhóm môn học <span class="rb-menu-arrow">›</span></button>
          <ul class="rb-menu-sub">${rows('subjectGroup', subjectGroupRules)}</ul>
        </li>
        <li class="rb-menu-sep"></li>
        <li>
          <button type="button">Cố định tiết nghỉ <span class="rb-menu-arrow">›</span></button>
          <ul class="rb-menu-sub">${rows('fixedOff', fixedOffRules)}</ul>
        </li>
        <li>
          <button type="button" data-rb-open="timeLimit" data-rb-title="Giới hạn số tiết/1 thời điểm">Giới hạn số tiết/1 thời điểm <span class="rb-menu-arrow">›</span></button>
        </li>
        <li class="rb-menu-sep"></li>
        <li><button type="button" class="rb-menu-danger" data-rb-open="clear" data-rb-title="Xóa ràng buộc TKB">Xóa ràng buộc TKB ...</button></li>
      </ul>
    `;
  }

  function closeMenu(){
    document.getElementById(MENU_ID)?.remove();
    document.removeEventListener('click', closeMenu, true);
    window.removeEventListener('resize', closeMenu);
    window.removeEventListener('scroll', closeMenu, true);
  }

  function toggleMenu(anchor){
    const old = document.getElementById(MENU_ID);
    if(old){ closeMenu(); return; }
    ensureStyle();
    const menu = document.createElement('div');
    menu.id = MENU_ID;
    menu.innerHTML = buildMenu();
    document.body.appendChild(menu);
    const rect = (anchor || document.activeElement || document.body).getBoundingClientRect();
    const left = Math.min(rect.left, window.innerWidth - menu.offsetWidth - 8);
    const top = Math.min(rect.bottom + 2, window.innerHeight - menu.offsetHeight - 8);
    menu.style.left = Math.max(4, left) + 'px';
    menu.style.top = Math.max(4, top) + 'px';
    menu.addEventListener('click', ev => {
      ev.stopPropagation();
      const btn = ev.target.closest('[data-rb-open]');
      if(!btn) return;
      openPage(btn.dataset.rbOpen, btn.dataset.rbRule || '', btn.dataset.rbTitle || '');
    });
    setTimeout(() => document.addEventListener('click', closeMenu, true), 0);
    window.addEventListener('resize', closeMenu);
    window.addEventListener('scroll', closeMenu, true);
  }

  window.toggleRangBuoc = function(){
    toggleMenu(document.activeElement);
  };
  window.openRangBuocMenu = toggleMenu;
})();
