/* =========================================================
   phanmon-ops.merged.js
   - Generated: 2026-03-05
   - Contains: phanmon-ops.js + phanmon-ops.hotfix.js
   - Extra patch: _calcOptimizeCompliance allowedMaxGap (limitTietTrong=2 => maxGap<=1)
   ========================================================= */
(function(){ try{ window.__PHANMON_OPS_MERGED = "merged+hotfix-2026-03-05-43b48000f29f"; }catch(e){} })();


// ===== HARD LOCK GLOBAL =====
window.__HARD_LOCKED_TEACHERS = window.__HARD_LOCKED_TEACHERS || new Set();
window.__PHANMON_OPS_VERSION = 'optimized3-fix-rebuild-2026-03-03';
function _isHardLockedTeacherName(gv){
  try{
    if(!gv) return false;
    const t = String(gv).trim();
    return (window.__HARD_LOCKED_TEACHERS && typeof window.__HARD_LOCKED_TEACHERS.has==="function" && window.__HARD_LOCKED_TEACHERS.has(t));
  }catch(e){}
  return false;
}


// ===============================
// HARD LOCK BY TARGET (no "packed" requirement)
// Mục tiêu: GV đã đạt phân phối tối ưu (vd 20 => 5-5-5-5, 18 => 5-5-4-4) thì khóa cứng,
// tuyệt đối không dùng làm nguồn swap/move để vá lỗi người khác.
// ===============================
function _buildLockedTeachersByTarget(opt, lessonsMap, occ){
  const locked = new Set();
  if(!lessonsMap || !occ) return locked;

  // Chỉ khóa khi:
  // - đạt đúng target (5-5-4-4...)
  // - VÀ các buổi đều packed (không xé/gap)
  // - VÀ không có buổi 1 tiết (tránh khóa nhầm làm kẹt tối ưu)
  for(const teacher of Object.keys(lessonsMap)){
    const T = (lessonsMap[teacher]||[]).length;
    if(T < 6) continue;

    const target = _targetSessionSizesOptimal(T);
    if(!target || target.length===0) continue;

    const occT = occ?.[teacher] || {};
    const counts = [];
    let okPacked = true;
    let hasSmall = false;

    for(const dayKey of Object.keys(occT)){
      const byBuoi = occT[dayKey] || {};
      for(const buoiKey of Object.keys(byBuoi)){
        const slots = byBuoi[buoiKey] || [];
        const mm = _teacherSessionMetrics(slots);
        if(mm.count<=0) continue;
        counts.push(mm.count);
        if(mm.maxGap > 0) okPacked = false;
        if(mm.count < 2) hasSmall = true;
      }
    }

    if(!okPacked) continue;
    if(hasSmall) continue;

    if(counts.length === target.length && _multisetEq(counts, target)){
      locked.add(String(teacher));
    }
  }

  opt.lockedTeachers = locked;
  try{ window.__HARD_LOCKED_TEACHERS = locked; }catch(e){}
  return locked;
}


function _isTeacherHardLocked(opt, teacher){
  try{
    if(!teacher) return false;
    const t = String(teacher);
    if(opt?.lockedTeachers && typeof opt.lockedTeachers.has === "function"){
      return opt.lockedTeachers.has(t);
    }
  }catch(e){}
  return false;
}


// ===============================
// REPACK TEACHER SESSIONS (PACK-FIRST)
// Dữ liệu lớn: ưu tiên giảm số buổi của GV và full 5 (vd 16 => 5-5-3-3; 18 => 5-5-5-3).
// Chỉ dùng MOVE vào ô trống (không swap) để "merge" các buổi nhỏ vào buổi lớn.
// Nếu đạt target thì hard-lock GV để tránh bị xé lại.
// ===============================

function _targetSessionSizesOptimal(T){
  // Mục tiêu: giảm số buổi về Smin=ceil(T/5) và tránh buổi nhỏ (<4) nếu có thể.
  // Mặc định: phân phối theo base/extra => ví dụ 18 -> 5-5-4-4.
  // Ngoại lệ theo yêu cầu: 16 ưu tiên 5-5-3-3.
  if(!Number.isFinite(T) || T<=0) return [];
  if(T<=5) return [T];

  // special-case: 16 => 5-5-3-3
  if(T===16) return [5,5,3,3];

  const S = Math.ceil(T/5);
  const base = Math.floor(T / S);
  const extra = T - base*S;

  let sizes = [];
  for(let i=0;i<extra;i++) sizes.push(base+1);
  for(let i=extra;i<S;i++) sizes.push(base);

  // sort desc: ưu tiên đặt buổi lớn trước
  sizes.sort((a,b)=>b-a);
  return sizes;
}

function _multisetEq(a,b){
  if(!Array.isArray(a)||!Array.isArray(b)) return false;
  if(a.length!==b.length) return false;
  const aa=[...a].sort((x,y)=>x-y);
  const bb=[...b].sort((x,y)=>x-y);
  for(let i=0;i<aa.length;i++) if(aa[i]!==bb[i]) return false;
  return true;
}


function _teacherMeetsTargetDistribution(gv, occ, totalGV){
  try{
    const T = Number(totalGV||0);
    if(T<=0) return true;
    // GV <=5 tiết: luôn coi là đạt (1 buổi), không tính lỗi.
    if(T<=5) return true;
    const target = (typeof _targetSessionSizesByRemainder==="function") ? _targetSessionSizesByRemainder(T) : [];
    if(!target.length) return false;
    const counts = [];
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const slots = occ?.[gv]?.[thu]?.[buoi] || [];
        const c = _countTrue(slots);
        if(c>0) counts.push(c);
      }
    }
    return (typeof _multisetEqNums==="function") ? _multisetEqNums(counts, target) : _multisetEqNums(counts, target);
  }catch(e){
    return false;
  }
}

function _teacherSessionCountsFromOcc(occT){
  // occT: occ[teacher][thu][buoi] -> boolean[]
  const out = [];
  if(!occT) return out;
  for(const thu of Object.keys(occT)){
    for(const buoi of Object.keys(occT[thu]||{})){
      const arr = occT[thu][buoi] || [];
      const c = _countTrue(arr);
      if(c>0) out.push({thu, buoi, count:c});
    }
  }
  return out;
}

function _tryMergeSmallSessionsForTeacher(teacher, opt){
  // Merge các buổi nhỏ (1/2/3) vào các buổi lớn của chính GV bằng MOVE vào ô trống trong lớp.
  // Return true nếu có thay đổi.
  const built = _buildTeacherOccAll();
  const occ = built.occ || {};
  const roomOcc = built.roomOcc;
  const lessons = built.lessons || {};
  const tkbs = DATA.tkb || {};

  const ls = lessons[teacher] || [];
  const T = ls.length;
  if(T < 6) return false; // nhỏ quá không cần merge mạnh

  const target = _targetSessionSizesOptimal(T);
  if(target.length<=1) return false;

  const sess = _teacherSessionCountsFromOcc(occ[teacher]);
  if(sess.length<=1) return false;

  // Nếu đang nhiều buổi hơn target (bị xé) thì cố merge
    if(sess.length < target.length) return false;
  if(sess.length === target.length){
    const minCountNow = Math.min(...sess.map(x=>x.count));
    const minTarget = Math.min(...target);
    if(minCountNow >= minTarget) return false;
    // vẫn thử merge nhẹ để nâng buổi nhỏ lên mức target
  }

  // sort: nguồn buổi nhỏ trước
  sess.sort((a,b)=>a.count-b.count);

  // build list buổi đích: buổi có count < 5, ưu tiên count lớn (để full 5 nhanh)
  let dest = [...sess].filter(s=>s.count<5).sort((a,b)=>b.count-a.count);

  // helper: list lessons in a given session
  function lessonsInSession(thu,buoi){
    return (ls||[]).filter(l=>String(l.thu)===String(thu) && String(l.buoi)===String(buoi));
  }

  // try move one lesson from (thuS,buoiS,tiS,classId,mon) to (thuD,buoiD,tiD empty)
  function tryMoveLessonToSession(lesson, thuD, buoiD){
  const classId = lesson.classId;
  const mon = lesson.mon;
  const thuS = lesson.thu, buoiS = lesson.buoi, tiS = lesson.ti;

  const tkb = tkbs[classId];
  if(!tkb || !tkb[thuD] || !tkb[thuD][buoiD]) return false;

  const arrD = tkb[thuD][buoiD];

  let bestTiD = -1;
  let bestScore = -1e18;

  for(let tiD=0; tiD<arrD.length; tiD++){
    const v = arrD[tiD];
    if(v==="OFF" || isFixed(v)) continue;
    if(cellMon(v)) continue;

    if(occ?.[teacher]?.[thuD]?.[buoiD]?.[tiD]) continue;

    const canon = getLopCanonById(classId);
    const roomName = getRoomForClassMon(canon, mon);
    if(roomName){
      const keyRoom = `${roomName}|${thuD}|${buoiD}|${tiD}`;
      const cur = roomOcc?.get(keyRoom);
      if(cur && cur.count>0){
        if(String(cur.owner||"") !== String(classId)) continue;
      }
    }

    const arrS = tkb?.[thuS]?.[buoiS];
    if(!arrS) continue;
    const vS = arrS[tiS];
    if(vS==="OFF" || isFixed(vS)) continue;
    if(cellMon(vS) !== mon) continue;

    const curSlots = (occ?.[teacher]?.[thuD]?.[buoiD] || []).slice();
    curSlots[tiD] = true;
    const mm = _teacherSessionMetrics(curSlots);

    const score = (mm.maxGap===0 ? 10000 : 0) - mm.totalGaps*200 - mm.maxGap*400 + mm.count*10;
    if(score > bestScore){
      bestScore = score;
      bestTiD = tiD;
    }
  }

  if(bestTiD < 0) return false;

  const arrS = tkb?.[thuS]?.[buoiS];
  if(!arrS) return false;
  arrS[tiS] = "";
  arrD[bestTiD] = mon;
  return true;
}


  // Iterate source sessions from smallest; try move its lessons into dest sessions
  for(const s of sess){
    if(s.count >= 4) continue; // focus 1-3 first (đẩy về 4/5 và xóa buổi nhỏ)
    const srcLessons = lessonsInSession(s.thu, s.buoi);
    if(srcLessons.length===0) continue;

    for(const lesson of srcLessons){
      let moved = false;
      // refresh dest list each time based on latest occ
      const rebuilt = _buildTeacherOccAll();
      const occ2 = rebuilt.occ || {};
      const sess2 = _teacherSessionCountsFromOcc(occ2[teacher]);
      dest = [...sess2].filter(x=>x.count<5).sort((a,b)=>b.count-a.count);

      for(const d of dest){
        if(String(d.thu)===String(s.thu) && String(d.buoi)===String(s.buoi)) continue;
        if(tryMoveLessonToSession(lesson, d.thu, d.buoi)){
          moved = true
          break
        }
      }
      if(moved){
        return true;
      }
    }
  }
  return false;
}



// ===== FIX (2026-03): Chuẩn hoá limitTietBuoi =====
// Quy ước toàn file: opt.limitTietBuoi là MIN tiết/buổi thực tế.
// - 0: tắt ràng buộc
// - 2: không có GV 1 tiết/buổi
// - 3: không có GV 1–2 tiết/buổi
// - 4: không có GV 1–2–3 tiết/buổi
function _uiMinTietBuoi(opt){
  const v0 = Number(opt?.limitTietBuoi || 0);
  if(!Number.isFinite(v0) || v0 <= 0) return 0;
  const v = Math.round(v0);
  // Backward compatibility: nếu ai đó truyền 1 (UI cũ) => hiểu là min=2
  return (v <= 1) ? 2 : v;
}

// ===== FIX (2026-02): Min tiết/buổi hiệu lực theo từng GV (tránh vô nghiệm + tránh phá 3-3 với GV 6 tiết) =====
// Quy tắc:
// - Nếu GV không đủ điều kiện đạt min theo UI => bỏ qua ràng buộc cho GV đó (không phát sinh lỗi, không cố sửa).
 // - Với GV có tổng tiết nhỏ (vd 6) và UI min=4: chọn số buổi tối thiểu S = ceil(T/5), rồi giảm min xuống floor(T/S) (vd 6 -> S=2 -> min=3 => ưu tiên 3-3).
function _effectiveMinTietBuoiForTeacher(opt, teacher, lessonsMap){
  const uiMin = _uiMinTietBuoi(opt);
  if(uiMin <= 0) return 0;

  const ls = (lessonsMap?.[teacher] || []);
  const T = ls.length;
  // Nếu tổng tiết không đủ để đạt min theo UI thì bỏ qua ràng buộc (không phát sinh lỗi)
  if(uiMin > 0 && T < uiMin) return 0;
  if(T <= 0) return 0;

  // số buổi tối thiểu để "pack" (mỗi buổi tối đa 5)
  const S = Math.max(1, Math.ceil(T / 5));
  const packMin = Math.floor(T / S); // min tốt nhất khi gom ít buổi nhất

  // Nếu ngay cả packMin < 2 (vd T=1) thì bỏ qua.
  if(packMin < 2) return 0;

  // Nếu uiMin quá cao khiến vô nghiệm / gây phá cấu trúc (vd T=6, uiMin=4) => hạ xuống packMin.
  const eff = Math.min(uiMin, packMin);

  // Nếu eff < 2 thì bỏ qua ràng buộc (special case)
  return eff >= 2 ? eff : 0;
}

window.__PHANMON_OPS_VERSION = "pack-lock-target-2026-02-26";
function _normTeacher(x){ return (x==null?"":String(x)).trim().toLowerCase(); }
console.log("[phanmon-ops] loaded", window.__PHANMON_OPS_VERSION);

// phanmon-ops.js
// Tách từ phanmon.js để nhẹ file gốc.
// Chứa: heuristic tối ưu theo GV, tối ưu nâng cao, tối ưu 1 tiết/buổi, sắp xếp tự động, xếp lại lớp,
// panel tối ưu + ràng buộc, và các cải tiến/tiện ích liên quan.
//
// Lưu ý: file này phụ thuộc các biến/hàm global đã có trong phanmon.js (DATA, DAYS, SANG, CHIEU, ...).



/* ===== MOVED SECTION: heuristic_optimize (from phanmon.js:13352-65386) ===== */

/* ======================= HEURISTIC: ƯU TIÊN TKB THEO GIÁO VIÊN =======================
   Theo yêu cầu:
   - 5 tiết đầu = 1 buổi, 5 tiết sau = 1 buổi
   - Hạn chế GV bị: 1 tiết/buổi
   - Hạn chế khoảng trống >= 2 tiết giữa 2 tiết dạy trong cùng buổi
   - Một buổi không nên có quá 2 tiết trống

   Cơ chế:
   - Khi engine đặt 1 block, sẽ chấm điểm vị trí (extraScoreBlock)
   - Điểm càng cao càng ưu tiên
   - Nếu không có vị trí đẹp, vẫn có thể đặt ở vị trí kém hơn (không làm "kẹt" việc xếp)
======================= */

function _buildTeacherOccBase(teacherCode, ignoreLopId){
  const gv = (teacherCode||"").toString().trim();
  const occ = {};
  DAYS.forEach(d=>{
    occ[d] = {
      sang: Array(SANG).fill(false),
      chieu: Array(CHIEU).fill(false)
    };
  });
  if(!gv) return occ;

  const tkbs = DATA.tkb || {};
  for(const lopId of Object.keys(tkbs)){
    if(ignoreLopId && String(lopId) === String(ignoreLopId)) continue;
    const tkb = tkbs[lopId];
    if(!tkb) continue;
    const canon = getLopCanonById(lopId);

    for(const thu of DAYS){
      for(let ti=0; ti<SANG; ti++){
        const v = tkb?.[thu]?.sang?.[ti];
        if(!v || v === "OFF" || isFixed(v)) continue;
        const mon = cellMon(v);
        if(!mon) continue;
        const gv2 = getTeacherForClassMon(canon, mon);
        if(gv2 && gv2 === gv) occ[thu].sang[ti] = true;
      }
      for(let ti=0; ti<CHIEU; ti++){
        const v = tkb?.[thu]?.chieu?.[ti];
        if(!v || v === "OFF" || isFixed(v)) continue;
        const mon = cellMon(v);
        if(!mon) continue;
        const gv2 = getTeacherForClassMon(canon, mon);
        if(gv2 && gv2 === gv) occ[thu].chieu[ti] = true;
      }
    }
  }

  return occ;
}

function _scoreTeacherSession(slots){
  // slots: boolean[] length 5
  const pos = [];
  for(let i=0; i<slots.length; i++) if(slots[i]) pos.push(i);
  if(pos.length === 0) return 0;

  let score = 0;

  // Ưu tiên có >=2 tiết/buổi, phạt mạnh trường hợp 1 tiết/buổi
  if(pos.length === 1){
    // Phạt RẤT NẶNG để thuật toán né nếu còn bất kỳ lựa chọn khác.
    // (Vẫn có trường hợp dữ liệu/constraint khiến không thể tránh 1 tiết/buổi)
    score -= 5000;
    return score;
  }

  // Phạt khoảng trống lớn (>=2) giữa 2 tiết
  let totalGaps = 0;
  for(let j=1; j<pos.length; j++){
    const gap = pos[j] - pos[j-1] - 1;
    totalGaps += gap;
    if(gap >= 2) score -= 120 * gap;
    else if(gap === 1) score -= 12;
    else score += 6; // liền nhau
  }

  // Một buổi không nên có từ 2 tiết trống trở lên (>=2)
  if(totalGaps >= 2) score -= 80 * (totalGaps - 1);

  // Thưởng nhẹ khi buổi đó có nhiều tiết (đỡ "đi 1 tiết")
  score += pos.length * 2;
  return score;
}

function makeExtraScoreBlockForTeacherQuality(classId, lopCanon){
  const baseCache = new Map(); // gv -> occ
  const monToGV = new Map();   // mon -> gv

  const teacherOfMon = (monName)=>{
    const key = (monName||"").toString().trim();
    if(!key) return "";
    if(monToGV.has(key)) return monToGV.get(key) || "";
    const gv = getTeacherForClassMon(lopCanon, key);
    monToGV.set(key, gv || "");
    return gv || "";
  };

  const getBase = (gv)=>{
    const code = (gv||"").toString().trim();
    if(!code) return null;
    if(!baseCache.has(code)) baseCache.set(code, _buildTeacherOccBase(code, classId));
    return baseCache.get(code);
  };

  // extraScoreBlock(localTkb, thu, buoi, startIdx, monName, len) => number
  return function(localTkb, thu, buoi, startIdx, monName, len){
    const gv = teacherOfMon(monName);
    if(!gv) return 0;
    const base = getBase(gv);
    if(!base) return 0;

    const isSang = (buoi === "sang");
    const sessionLen = isSang ? SANG : CHIEU;
    const slots = (base?.[thu]?.[buoi] || Array(sessionLen).fill(false)).slice();

    // cộng thêm các tiết GV đã có trong localTkb (lớp đang xếp)
    const arrLocal = localTkb?.[thu]?.[buoi] || [];
    for(let ti=0; ti<sessionLen; ti++){
      const v = arrLocal[ti];
      if(!v || v === "OFF" || isFixed(v)) continue;
      const mon = cellMon(v);
      if(!mon) continue;
      const gv2 = teacherOfMon(mon);
      if(gv2 && gv2 === gv) slots[ti] = true;
    }

    // giả lập đặt block vào vị trí ứng viên
    for(let k=0; k<(len||1); k++){
      const idx = Number(startIdx) + k;
      if(idx >= 0 && idx < sessionLen) slots[idx] = true;
    }

    return _scoreTeacherSession(slots);
  };
}

/* ======================= EXTRA SCORE: RẢI ĐỀU CẢ TUẦN (ƯU TIÊN ĐỦ 12 BUỔI) =======================
   - Áp dụng cho: Sắp xếp tự động / Xếp lại lớp
   - Mục tiêu: tránh dồn tiết về đầu tuần hoặc chỉ 1 buổi; ưu tiên dùng đủ 12 buổi (6 sáng + 6 chiều)
   - Ghi chú: điểm "đẹp GV" được GIẢM trọng số để không cản việc rải buổi
================================================================================================ */
function makeExtraScoreBlockForTeacherQualityAndSpread(classId, lopCanon, opt){
  const teacherScoreFn = (typeof makeExtraScoreBlockForTeacherQuality === "function")
    ? makeExtraScoreBlockForTeacherQuality(classId, lopCanon)
    : null;

  const cfg = Object.assign({
    teacherWeight: 0.06,   // giảm ảnh hưởng điểm GV
    bonusNewSession: 0,   // (PACK) tắt thưởng mở buổi mới của LỚP
    bonusNewDay: 0,       // (PACK) tắt thưởng mở ngày mới của LỚP
    wDayBalance: 0,       // (PACK) tắt rải theo ngày
    wBuoiBalance: 0,      // (PACK) tắt cân bằng sáng/chiều
    wSessionQuad: 22       // phạt buổi bị nhồi (bình phương số tiết/buổi)
  }, opt || {});

  function _countAssignedInArr(arr){
    let c = 0;
    const a = Array.isArray(arr) ? arr : [];
    for(let i=0;i<a.length;i++){
      const v = a[i];
      if(v === "OFF") continue;
      if(typeof cellMon === "function"){
        if(cellMon(v)) c++;
      }else{
        if(v && v !== "") c++;
      }
    }
    return c;
  }

  function _buildSpreadStats(localTkb){
    const days = (typeof DAYS !== "undefined" && Array.isArray(DAYS) && DAYS.length) ? DAYS : [];
    const sessCnt = {};
    let total = 0;
    let totalSang = 0;
    let totalChieu = 0;

    for(const d of days){
      sessCnt[d] = { sang: 0, chieu: 0 };
      for(const buoi of ["sang","chieu"]){
        const arr = localTkb?.[d]?.[buoi] || [];
        const c = _countAssignedInArr(arr);
        sessCnt[d][buoi] = c;
        total += c;
        if(buoi === "sang") totalSang += c;
        else totalChieu += c;
      }
    }
    return { sessCnt, total, totalSang, totalChieu, daysLen: days.length || 1 };
  }

  // extraScoreBlock(localTkb, thu, buoi, startIdx, monName, len) => number
  return function(localTkb, thu, buoi, startIdx, monName, len){
    let score = 0;

    // (1) Điểm GV (giảm trọng số)
    if(typeof teacherScoreFn === "function"){
      try{
        const t = Number(teacherScoreFn(localTkb, thu, buoi, startIdx, monName, len));
        if(Number.isFinite(t)) score += t * Number(cfg.teacherWeight || 0);
      }catch(_){}
    }

    // (2) Điểm rải đều theo tuần (LỚP)
    try{
      const st = _buildSpreadStats(localTkb);
      const sess = st.sessCnt?.[thu]?.[buoi] ?? 0;
      const dayTotal = (st.sessCnt?.[thu]?.sang||0) + (st.sessCnt?.[thu]?.chieu||0);
      const avgDay = st.total / (st.daysLen || 1);
      const avgBuoi = st.total / 2;
      const buoiTotal = (buoi === "sang") ? st.totalSang : st.totalChieu;
      const postSess = sess + Number(len || 0);

      // mở buổi / ngày mới
      if(sess === 0) score += cfg.bonusNewSession;
      if(dayTotal === 0) score += cfg.bonusNewDay;

      // cân bằng theo ngày & sáng/chiều
      score += (avgDay - dayTotal) * cfg.wDayBalance;
      score += (avgBuoi - buoiTotal) * cfg.wBuoiBalance;

      // phạt buổi bị nhồi quá nhiều tiết
      score -= (postSess * postSess) * cfg.wSessionQuad;
    }catch(_){}

    return score;
  };
}


/* ======================= TỐI ƯU CHẤT LƯỢNG TKB GIÁO VIÊN (HẬU XẾP) =======================
   Mục tiêu:
   - Hạn chế GV phải đi dạy 1 tiết / 1 buổi (5 tiết)
   - Hạn chế khoảng trống lớn giữa các tiết trong cùng buổi
   Cách làm:
   - Quét các buổi GV đang có đúng 1 tiết
   - Thử HOÁN ĐỔI / DI CHUYỂN (trong cùng 1 lớp) sang buổi khác mà GV đã có tiết,
     đồng thời tránh tạo ra GV khác bị 1 tiết/buổi.
   Lưu ý: Với một số dữ liệu/constraint (OFF/fixed, trùng phòng/GV, tổng tiết quá ít) có thể không thể loại bỏ 100%.
*/

function _countTrue(slots){
  let c = 0;
  for(let i=0;i<(slots||[]).length;i++) if(slots[i]) c++;
  return c;
}

function _isPackedSessionSlots(slots){
  if(!Array.isArray(slots)) return true;
  let first=-1,last=-1,c=0;
  for(let i=0;i<slots.length;i++){
    if(slots[i]){
      c++;
      if(first<0) first=i;
      last=i;
    }
  }
  if(c<=1) return true;
  return (last-first+1)===c;
}
function _badSessionsCountForTeacher(occ, gv, k){
  let b=0;
  for(const thu of DAYS){
    for(const buoi of ["sang","chieu"]){
      const slots = occ?.[gv]?.[thu]?.[buoi];
      if(!Array.isArray(slots)) continue;
      const c=_countTrue(slots);
      if(c>0 && c<k) b++;
    }
  }
  return b;
}

function _collectTeacherSessions(occ, gv){
  const out = [];
  for(const thu of DAYS){
    for(const buoi of ["sang","chieu"]){
      const slots = occ?.[gv]?.[thu]?.[buoi];
      if(!Array.isArray(slots)) continue;
      const c = _countTrue(slots);
      if(c>0) out.push({thu, buoi, count: c, len: slots.length});
    }
  }
  return out;
}
function _teacherTotalOccForTeacher(occ, gv){
  let c = 0;
  for(const thu of DAYS){
    for(const buoi of ["sang","chieu"]){
      const slots = occ?.[gv]?.[thu]?.[buoi] || [];
      for(const v of slots) if(v) c++;
    }
  }
  return c;
}
function _teacherMaxSessionLen(occ, gv){
  let L = 0;
  for(const thu of DAYS){
    for(const buoi of ["sang","chieu"]){
      const slots = occ?.[gv]?.[thu]?.[buoi];
      if(Array.isArray(slots)) L = Math.max(L, slots.length);
    }
  }
  return L || 5;
}
function _hasBadSessionForTeacher(occ, gv, k){
  for(const thu of DAYS){
    for(const buoi of ["sang","chieu"]){
      const slots = occ?.[gv]?.[thu]?.[buoi] || [];
      const cnt = _countTrue(slots);
      if(cnt>0 && cnt<k) return true;
    }
  }
  return false;
}
function _multisetEqual(a, b){
  if(a.length !== b.length) return false;
  const x = a.slice().sort((p,q)=>q-p);
  const y = b.slice().sort((p,q)=>q-p);
  for(let i=0;i<x.length;i++) if(x[i] !== y[i]) return false;
  return true;
}
function _planTargetsBalanced(T, S, L, k){
  if(S<=0) return [];
  if(T < k*S) return [];
  if(T > L*S) return [];
  const base = Math.floor(T / S);
  let rem = T - base*S;
  const a = Array(S).fill(base);
  for(let i=0;i<S && rem>0;i++){ a[i]++; rem--; }
  // fix bounds
  for(let loop=0; loop<50; loop++){
    let changed=false;
    for(let i=0;i<a.length;i++){
      while(a[i] > L){
        const j = a.findIndex((v,idx)=>idx!==i && v < L);
        if(j<0) return [];
        a[i]--; a[j]++; changed=true;
      }
    }
    for(let i=0;i<a.length;i++){
      while(a[i] < k){
        let maxI=0;
        for(let t=1;t<a.length;t++) if(a[t] > a[maxI]) maxI=t;
        if(a[maxI] <= k) return [];
        a[maxI]--; a[i]++; changed=true;
      }
    }
    if(!changed) break;
  }
  a.sort((x,y)=>y-x);
  return a;
}

// LOCK theo tiêu chí bạn chốt:
// - GV ít tiết (T<=L) mà đang gói gọn 1 buổi => LOCK luôn (không xé 4->1-3, 5->2-3, 4->2-2)
// - GV đạt Smin + pattern cân bằng (vd 9=>5-4, 10=>5-5, 12=>4-4-4 hoặc 5-4-3 tùy cân bằng) và không có buổi <k => LOCK
function _computeLockedTeachers(occ, k){
  const locked = new Set();
  const kk = Number(k||0);

  for(const gvRaw of Object.keys(occ || {})){
    const gv = _normTeacher(gvRaw);
    if(!gv) continue;

    const T = _teacherTotalOccForTeacher(occ, gvRaw);
    if(T <= 0) continue;

    const sessions = _collectTeacherSessions(occ, gvRaw);
    if(!sessions.length) continue;

    const L = _teacherMaxSessionLen(occ, gvRaw);

    if(T <= L && sessions.length === 1){
      locked.add(gv);
      continue;
    }

    // Ưu tiên khóa nhóm ít tiết theo chuẩn k=3:
    // - 6 tiết => 3-3 là tối ưu (2 buổi), nhưng chỉ khóa nếu các buổi đều PACKED (không có gap nội bộ)
    // - 7 tiết => 4-3 hoặc 3-4 là tối ưu (2 buổi), cũng yêu cầu PACKED
    if(kk === 3){
      if(T === 6 && sessions.length === 2){
        const counts = sessions.map(s=>s.count).slice().sort((a,b)=>b-a);
        if(counts[0]===3 && counts[1]===3){
          const packed = sessions.every(ss => _isPackedSessionSlots(occ?.[gvRaw]?.[ss.thu]?.[ss.buoi] || []));
          if(packed){ locked.add(gv); continue; }
        }
      }
      if(T === 7 && sessions.length === 2){
        const counts = sessions.map(s=>s.count).slice().sort((a,b)=>b-a);
        if(counts[0]===4 && counts[1]===3){
          const packed = sessions.every(ss => _isPackedSessionSlots(occ?.[gvRaw]?.[ss.thu]?.[ss.buoi] || []));
          if(packed){ locked.add(gv); continue; }
        }
      }
    }

    if(kk > 0){
      if(T < kk) continue;
      const Smin = Math.ceil(T / L);
      if(sessions.length !== Smin) continue;
      if(_hasBadSessionForTeacher(occ, gvRaw, kk)) continue;

      const targets = _planTargetsBalanced(T, Smin, L, kk);
      if(!targets.length) continue;

      const counts = sessions.map(s=>s.count);
      if(_multisetEqual(counts, targets)){
        locked.add(gv);
      }
    }
  }
  return locked;
}


function _isContiguousIdx(idx){
  if(!idx || idx.length <= 1) return true;
  const a = idx.slice().sort((x,y)=>x-y);
  for(let i=1;i<a.length;i++) if(a[i] !== a[i-1] + 1) return false;
  return true;
}

function _sessionIdxOfMon(arr, mon){
  const out = [];
  const m = (mon||"").toString().trim();
  if(!m) return out;
  for(let i=0;i<(arr||[]).length;i++){
    if(cellMon(arr[i]) === m) out.push(i);
  }
  return out;
}

function _getGioihanForLopIdMon(lopId, lopCanon, mon){
  const g = getGioiHanForClassMon(lopCanon, mon);
  if(g && Number(g) > 0) return Number(g);

  // fallback theo bảng "Tiết chuẩn" (DATA.mon) theo khối của lớp
  const lop = (DATA.lop||[]).find(x => String(x.id) === String(lopId));
  const khoiNum = extractKhoiNumber(lop?.khoi) || extractKhoiNumber(lop?.ten2) || extractKhoiNumber(lop?.ten) || 0;
  const monName = (mon||"").toString().trim();
  const row = (DATA.mon||[]).find(m => extractKhoiNumber(m?.khoi) === khoiNum && String(m?.ten||"").toString().trim() === monName);
  const gg = Number(row?.gioihan || 0);
  if(Number.isFinite(gg) && gg > 0) return gg;

  return 99;
}

function _validateSubjectInSession(arr, mon, gioihan){
  const m = (mon||"").toString().trim();
  if(!m) return true;
  const idx = _sessionIdxOfMon(arr, m);
  if(idx.length === 0) return true;
  const lim = Number(gioihan || 99);
  if(idx.length > lim) return false;
  return _isContiguousIdx(idx);
}

function _ensureTeacherOccObj(occ, gv){
  const code = (gv||"").toString().trim();
  if(!code) return null;
  if(!occ[code]){
    occ[code] = {};
    DAYS.forEach(d=>{
      occ[code][d] = {
        sang: Array(SANG).fill(false),
        chieu: Array(CHIEU).fill(false)
      };
    });
  }
  return occ[code];
}

function _buildTeacherOccAll(){
  const occ = {};
  const lessons = {};

  // Map key: "ROOM|thu|buoi|ti" -> {count, owner}
  // owner: lớp đầu tiên chiếm phòng ở slot đó (để ignore khi đang kiểm tra trong cùng lớp)
  const roomOcc = new Map();

  const tkbs = DATA.tkb || {};
  for(const lopId of Object.keys(tkbs)){
    const tkb = tkbs[lopId];
    if(!tkb) continue;
    const canon = getLopCanonById(lopId);

    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const arr = tkb?.[thu]?.[buoi] || [];
        for(let ti=0; ti<arr.length; ti++){
          const v = arr[ti];
          if(!v || v === "OFF") continue;

          const mon = cellMon(v);
          if(!mon) continue;

          const fixed = isFixed(v);

          // 1) Teacher occupancy: vẫn tính cả tiết cố định NẾU có GV phân công (để tránh xung đột)
          const gv = getTeacherForClassMon(canon, mon);
          if(gv){
            _ensureTeacherOccObj(occ, gv);
            occ[gv][thu][buoi][ti] = true;
            // Lessons movable: bỏ qua các ô fixed
            if(!fixed){
              if(!lessons[gv]) lessons[gv] = [];
              lessons[gv].push({ teacher: gv, classId: lopId, canon, thu, buoi, ti, mon });
            }
          }

          // 2) Room occupancy: tính cả fixed (nếu môn đó có phòng)
          const room = getRoomForClassMon(canon, mon);
          if(room){
            const key = `${room}|${thu}|${buoi}|${ti}`;
            const cur = roomOcc.get(key) || { count: 0, owner: null };
            cur.count += 1;
            if(cur.owner == null) cur.owner = String(lopId);
            roomOcc.set(key, cur);
          }
        }
      }
    }
  }

  return { occ, lessons, roomOcc };

}


// Bản nâng cấp: lấy thêm lessonByKey để tối ưu "1 tiết/buổi" có thể cập nhật nhanh (không cần rebuild liên tục)
function _buildTeacherOccAllV2(){
  const occ = {};
  const lessons = {};
  const lessonByKey = {};
  const roomOcc = new Map();

  const tkbs = DATA.tkb || {};
  for(const lopId of Object.keys(tkbs)){
    const tkb = tkbs[lopId];
    if(!tkb) continue;
    const canon = getLopCanonById(lopId);

    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const arr = tkb?.[thu]?.[buoi] || [];
        for(let ti=0; ti<arr.length; ti++){
          const v = arr[ti];
          if(!v || v === "OFF") continue;

          const mon = cellMon(v);
          if(!mon) continue;

          const fixed = isFixed(v);

          const gv = getTeacherForClassMon(canon, mon);
          if(gv){
            _ensureTeacherOccObj(occ, gv);
            occ[gv][thu][buoi][ti] = true;

            if(!fixed){
              const obj = { teacher: gv, classId: lopId, canon, thu, buoi, ti, mon };
              if(!lessons[gv]) lessons[gv] = [];
              lessons[gv].push(obj);
              lessonByKey[`${lopId}|${thu}|${buoi}|${ti}`] = obj;
            }
          }

          // Room occupancy (giữ tương thích, nhưng tối ưu buổi-1 sẽ không phụ thuộc mạnh vào roomOcc)
          const room = getRoomForClassMon(canon, mon);
          if(room){
            const key = `${room}|${thu}|${buoi}|${ti}`;
            const cur = roomOcc.get(key) || { count: 0, owner: null };
            cur.count += 1;
            if(cur.owner == null) cur.owner = String(lopId);
            roomOcc.set(key, cur);
          }
        }
      }
    }
  }

  return { occ, lessons, roomOcc, lessonByKey };
}

function _periodOrderAround(center, len){
  const out = [];
  const c = Number(center);
  const L = Number(len);
  if(!Number.isFinite(c) || !Number.isFinite(L) || L <= 0) return out;
  for(let k=1; k<L; k++){
    const a = c - k;
    const b = c + k;
    if(a >= 0) out.push(a);
    if(b < L) out.push(b);
  }
  return out;
}

function _findTeacherCellAtSlot(gv, thu, buoi, ti){
  const t = (gv||"").toString().trim();
  if(!t) return null;
  const tkbs = DATA.tkb || {};
  for(const lopId of Object.keys(tkbs)){
    const tkb = tkbs[lopId];
    const v = tkb?.[thu]?.[buoi]?.[ti];
    if(!v || v === "OFF") continue;
    const mon = cellMon(v);
    if(!mon) continue;
    const canon = getLopCanonById(lopId);
    const gv2 = getTeacherForClassMon(canon, mon);
    if(gv2 && gv2 === t){
      return { classId: lopId, canon, mon, fixed: isFixed(v) };
    }
  }
  return null;
}

function _canSwapWithinClass(classId, canon, thu1, buoi1, ti1, thu2, buoi2, ti2, mon1, mon2){
  const tkb = DATA.tkb?.[classId];
  if(!tkb) return false;

  const v1 = tkb?.[thu1]?.[buoi1]?.[ti1];
  const v2 = tkb?.[thu2]?.[buoi2]?.[ti2];
  if(!v1 || !v2) return false;
  if(v1 === "OFF" || v2 === "OFF") return false;
  if(isFixed(v1) || isFixed(v2)) return false;

  const a1 = (tkb?.[thu1]?.[buoi1] || []).slice();
  const a2 = (tkb?.[thu2]?.[buoi2] || []).slice();
  a1[ti1] = mon2;
  a2[ti2] = mon1;

  const lim1 = _getGioihanForLopIdMon(classId, canon, mon1);
  const lim2 = _getGioihanForLopIdMon(classId, canon, mon2);

  // validate cả 2 môn ở cả 2 buổi (tránh phá contiguity / giới hạn)
  if(!_validateSubjectInSession(a1, mon1, lim1)) return false;
  if(!_validateSubjectInSession(a1, mon2, lim2)) return false;
  if(!_validateSubjectInSession(a2, mon1, lim1)) return false;
  if(!_validateSubjectInSession(a2, mon2, lim2)) return false;

  return true;
}

function _pickLonelySessionBuoi1(occ, lessons, preferAfternoon){
  const prefer = (preferAfternoon !== false);
  const gvList = Object.keys(occ || {});
  for(const gv of gvList){

    // Tổng tiết/tuần theo occ (tính cả fixed)
    let totalGV = 0;
    for(const d of DAYS){
      totalGV += _countTrue(occ?.[gv]?.[d]?.sang || []);
      totalGV += _countTrue(occ?.[gv]?.[d]?.chieu || []);
    }

    // Nếu GV đã đạt phân phối tối ưu theo thuật toán (hoặc GV ≤5 tiết) thì KHÔNG coi là lỗi và không đưa vào danh sách sửa.
    if(_teacherMeetsTargetDistribution(gv, occ, totalGV)) continue;
    // bỏ qua GV có tổng tiết ≤ 1
    const total = (lessons?.[gv]?.length || 0) + 0; // lessons là movable; nếu GV chỉ có 1 tiết/tuần thì thường cũng movable
    // Nếu GV có fixed-only thì total có thể thấp; xử lý bằng cách tính từ occ
    let totalOcc = 0;
    for(const thu of DAYS){
      totalOcc += _countTrue(occ?.[gv]?.[thu]?.sang || []);
      totalOcc += _countTrue(occ?.[gv]?.[thu]?.chieu || []);
    }
    if(totalOcc <= 1) continue;

    for(const thu of DAYS){
      const order = prefer ? ["chieu","sang"] : ["sang","chieu"];
      for(const buoi of order){
        const slots = occ?.[gv]?.[thu]?.[buoi] || [];
        if(_countTrue(slots) !== 1) continue;
        const ti = slots.findIndex(x=>!!x);
        if(ti < 0) continue;
        return { teacher: gv, thu, buoi, tiLonely: ti };
      }
    }
  }
  return null;
}

function _priorityBorrowSourceSessionBuoi1(count){
  const c = Number(count || 0);
  if(c === 2) return 0;
  if(c === 3) return 1;
  if(c === 4) return 2;
  if(c >= 5) return 3;
  if(c === 1) return 10;
  return 20 + c;
}

function _buoi1HardOpt(){
  return { limitTietBuoi: 2, limitTietTrong: 1 };
}

function _sumSessionBadnessForTeacherMove(occ, gv, fromPos, toPos, opt){
  try{
    if(!gv || !fromPos || !toPos) return Number.POSITIVE_INFINITY;
    const gocc = occ?.[gv];
    if(!gocc) return Number.POSITIVE_INFINITY;
    const keys = new Map();
    const addKey = (thu, buoi)=>{ if(thu && buoi) keys.set(`${thu}|${buoi}`, { thu, buoi }); };
    addKey(fromPos.thu, fromPos.buoi);
    addKey(toPos.thu, toPos.buoi);
    let before = 0;
    let after = 0;
    for(const it of keys.values()){
      const base = ((gocc?.[it.thu]?.[it.buoi]) || []).slice();
      before += _sessionBadnessAdv(base, opt);
      const next = base.slice();
      if(it.thu === fromPos.thu && it.buoi === fromPos.buoi && Number.isFinite(fromPos.ti)) next[fromPos.ti] = false;
      if(it.thu === toPos.thu && it.buoi === toPos.buoi && Number.isFinite(toPos.ti)) next[toPos.ti] = true;
      after += _sessionBadnessAdv(next, opt);
    }
    return after - before;
  }catch(e){
    return Number.POSITIVE_INFINITY;
  }
}

function _canBorrowLockedTeacherSlotBuoi1(occ, gv, fromPos, toPos){
  const delta = _sumSessionBadnessForTeacherMove(occ, gv, fromPos, toPos, _buoi1HardOpt());
  return Number.isFinite(delta) && delta <= 0;
}

function _countSingleSessionsBuoi1(occ){
  let n = 0;
  for(const gv of Object.keys(occ || {})){
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const c = _countTrue(occ?.[gv]?.[thu]?.[buoi] || []);
        if(c === 1) n++;
      }
    }
  }
  return n;
}

function _totalSessionBadnessBuoi1(occ){
  let bad = 0;
  const opt = _buoi1HardOpt();
  for(const gv of Object.keys(occ || {})){
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const slots = occ?.[gv]?.[thu]?.[buoi] || [];
        bad += _sessionBadnessAdv(slots, opt);
      }
    }
  }
  return bad;
}

function _countTotalSessionsBuoi1(occ){
  let n = 0;
  for(const gv of Object.keys(occ || {})){
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        if(_countTrue(occ?.[gv]?.[thu]?.[buoi] || []) > 0) n++;
      }
    }
  }
  return n;
}

function _stateScoreBuoi1(occ){
  return {
    totalSessions: _countTotalSessionsBuoi1(occ),
    singles: _countSingleSessionsBuoi1(occ),
    badness: _totalSessionBadnessBuoi1(occ)
  };
}

function _isBetterStateScoreBuoi1(after, before){
  if(!after || !before) return false;
  if(after.totalSessions > before.totalSessions) return false;
  if(after.singles > before.singles) return false;
  if(after.badness > before.badness) return false;
  return (after.totalSessions < before.totalSessions) ||
         (after.singles < before.singles) ||
         (after.badness < before.badness);
}

function _isNonWorseStateScoreBuoi1(after, before){
  if(!after || !before) return false;
  if(after.totalSessions > before.totalSessions) return false;
  if(after.singles > before.singles) return false;
  if(after.badness > before.badness) return false;
  return true;
}

function _teacherStateScoreBuoi1(occ, gv){
  const out = { totalSessions: 0, singles: 0, badness: 0 };
  if(!gv) return out;
  const opt = _buoi1HardOpt();
  for(const thu of DAYS){
    for(const buoi of ["sang","chieu"]){
      const slots = occ?.[gv]?.[thu]?.[buoi] || [];
      const c = _countTrue(slots);
      if(c > 0) out.totalSessions++;
      if(c === 1) out.singles++;
      out.badness += _sessionBadnessAdv(slots, opt);
    }
  }
  return out;
}

function _isNonWorseTeacherStructureBuoi1(after, before){
  if(!after || !before) return false;
  if(after.totalSessions > before.totalSessions) return false;
  if(after.singles > before.singles) return false;
  if(after.badness > before.badness) return false;
  return true;
}


function _validateClassSessionAfterChangesBuoi1(classId, canon, changes){
  try{
    const tkb = DATA.tkb?.[classId];
    if(!tkb) return false;
    const sessionMap = new Map();
    const subjectMap = new Map();
    for(const ch of (changes || [])){
      if(!ch || !ch.thu || !ch.buoi || !Number.isFinite(Number(ch.ti))) return false;
      const vOld = tkb?.[ch.thu]?.[ch.buoi]?.[ch.ti];
      if(!vOld || vOld === 'OFF') return false;
      if(isFixed(vOld)) return false;
      const key = `${ch.thu}|${ch.buoi}`;
      if(!sessionMap.has(key)) sessionMap.set(key, (tkb?.[ch.thu]?.[ch.buoi] || []).slice());
      sessionMap.get(key)[Number(ch.ti)] = ch.mon;
      if(!subjectMap.has(key)) subjectMap.set(key, new Set());
      const sm = subjectMap.get(key);
      const oldMon = cellMon(vOld);
      if(oldMon) sm.add(oldMon);
      if(ch.mon) sm.add(ch.mon);
    }
    for(const [key, arr] of sessionMap.entries()){
      const subs = Array.from(subjectMap.get(key) || []);
      for(const mon of subs){
        if(!mon) continue;
        const lim = _getGioihanForLopIdMon(classId, canon, mon);
        if(!_validateSubjectInSession(arr, mon, lim)) return false;
      }
    }
    return true;
  }catch(e){
    return false;
  }
}

function _tryRerouteLockedTeacherSlotBuoi1(params){
  try{
    const built = params?.built;
    const occ = built?.occ;
    const lessonByKey = built?.lessonByKey;
    const lessons = built?.lessons;
    const movingTeacher = (params?.movingTeacher || '').toString().trim();
    const movingLesson = params?.movingLesson;
    const lockedLesson = params?.lockedLesson;
    const sourcePos = params?.sourcePos;
    const targetPos = params?.targetPos;
    const returnTxn = !!params?.returnTxn;
    if(!occ || !lessonByKey || !lessons || !movingTeacher || !movingLesson || !lockedLesson || !sourcePos || !targetPos) return returnTxn ? null : false;

    const gvX = (lockedLesson.teacher || '').toString().trim();
    if(!gvX || gvX === movingTeacher) return returnTxn ? null : false;
    if(!_canBorrowLockedTeacherSlotBuoi1(occ, gvX, targetPos, sourcePos)) return returnTxn ? null : false;
    if(occ?.[movingTeacher]?.[targetPos.thu]?.[targetPos.buoi]?.[targetPos.ti]) return returnTxn ? null : false;
    if(occ?.[gvX]?.[sourcePos.thu]?.[sourcePos.buoi]?.[sourcePos.ti]) return returnTxn ? null : false;
    const cntX_tar = _countTrue(occ?.[gvX]?.[targetPos.thu]?.[targetPos.buoi] || []);
    if(cntX_tar === 2) return returnTxn ? null : false;
    const cntX_src = _countTrue(occ?.[gvX]?.[sourcePos.thu]?.[sourcePos.buoi] || []);
    if(cntX_src === 0) return returnTxn ? null : false;

    const keySrc = `${movingLesson.classId}|${sourcePos.thu}|${sourcePos.buoi}|${sourcePos.ti}`;
    const keyTar = `${lockedLesson.classId}|${targetPos.thu}|${targetPos.buoi}|${targetPos.ti}`;
    const srcLesson = lessonByKey[keySrc];
    const tarLesson = lessonByKey[keyTar];
    if(!srcLesson || !tarLesson) return returnTxn ? null : false;

    const tkbSrc = DATA.tkb?.[movingLesson.classId];
    const tkbTar = DATA.tkb?.[lockedLesson.classId];
    if(!tkbSrc || !tkbTar) return returnTxn ? null : false;
    const vSrc = tkbSrc?.[sourcePos.thu]?.[sourcePos.buoi]?.[sourcePos.ti];
    const vTar = tkbTar?.[targetPos.thu]?.[targetPos.buoi]?.[targetPos.ti];
    if(!vSrc || !vTar || vSrc === 'OFF' || vTar === 'OFF') return returnTxn ? null : false;
    if(isFixed(vSrc) || isFixed(vTar)) return returnTxn ? null : false;

    const scoreBeforeTxn = _stateScoreBuoi1(occ);
    const scoreBeforeLocked = _teacherStateScoreBuoi1(occ, gvX);

    const altList = (lessons?.[gvX] || []).slice().filter(l => {
      if(!l) return false;
      if(String(l.classId) === String(lockedLesson.classId) && l.thu === targetPos.thu && l.buoi === targetPos.buoi && Number(l.ti) === Number(targetPos.ti)) return false;
      const k = `${l.classId}|${l.thu}|${l.buoi}|${l.ti}`;
      return !!lessonByKey[k];
    });
    altList.sort((a,b)=>{
      const ca = _countTrue(occ?.[gvX]?.[a.thu]?.[a.buoi] || []);
      const cb = _countTrue(occ?.[gvX]?.[b.thu]?.[b.buoi] || []);
      const sa = (ca >= 5) ? 0 : (ca >= 4 ? 1 : (ca >= 3 ? 2 : 3));
      const sb = (cb >= 5) ? 0 : (cb >= 4 ? 1 : (cb >= 3 ? 2 : 3));
      if(sa !== sb) return sa - sb;
      if(ca !== cb) return cb - ca;
      if(a.classId !== b.classId) return String(a.classId).localeCompare(String(b.classId));
      const da = DAYS.indexOf(a.thu) - DAYS.indexOf(b.thu);
      if(da) return da;
      if(a.buoi !== b.buoi) return a.buoi.localeCompare(b.buoi);
      return Number(a.ti) - Number(b.ti);
    });

    const roomOcc = built?.roomOcc;
    let best = null;

    function evaluateRank(scoreAfterTxn, scoreAfterLocked, alt){
      const srcCount = _countTrue(occ?.[gvX]?.[alt.thu]?.[alt.buoi] || []);
      return [
        scoreAfterTxn.totalSessions - scoreBeforeTxn.totalSessions,
        scoreAfterTxn.singles - scoreBeforeTxn.singles,
        scoreAfterTxn.badness - scoreBeforeTxn.badness,
        scoreAfterLocked.totalSessions - scoreBeforeLocked.totalSessions,
        scoreAfterLocked.singles - scoreBeforeLocked.singles,
        scoreAfterLocked.badness - scoreBeforeLocked.badness,
        srcCount >= 5 ? 0 : (srcCount >= 4 ? 1 : (srcCount >= 3 ? 2 : 3)),
        srcCount >= 5 ? -srcCount : -srcCount,
        DAYS.indexOf(alt.thu),
        alt.buoi === 'sang' ? 0 : 1,
        Number(alt.ti)
      ];
    }

    function isRankBetter(a, b){
      if(!b) return true;
      const ra = a.rank || [];
      const rb = b.rank || [];
      const n = Math.max(ra.length, rb.length);
      for(let i=0;i<n;i++){
        const va = Number.isFinite(ra[i]) ? ra[i] : 0;
        const vb = Number.isFinite(rb[i]) ? rb[i] : 0;
        if(va !== vb) return va < vb;
      }
      return false;
    }

    function applyCandidate(alt){
      const keyAlt = `${alt.classId}|${alt.thu}|${alt.buoi}|${alt.ti}`;
      const altLesson = lessonByKey[keyAlt];
      if(!altLesson) return null;
      const tkbAlt = DATA.tkb?.[alt.classId];
      if(!tkbAlt) return null;
      const vAlt = tkbAlt?.[alt.thu]?.[alt.buoi]?.[alt.ti];
      if(!vAlt || vAlt === 'OFF' || isFixed(vAlt)) return null;
      const monAlt = (altLesson.mon || '').toString().trim();
      const monTar = (tarLesson.mon || '').toString().trim();
      const monSrc = (srcLesson.mon || '').toString().trim();
      if(!monAlt || !monTar || !monSrc) return null;
      if(monAlt === monSrc) return null;

      const cntAltSrc = _countTrue(occ?.[gvX]?.[alt.thu]?.[alt.buoi] || []);
      const cntAltTar = _countTrue(occ?.[gvX]?.[sourcePos.thu]?.[sourcePos.buoi] || []);
      if(cntAltSrc === 2) return null;
      if(cntAltTar === 0) return null;

      if(!_validateClassSessionAfterChangesBuoi1(movingLesson.classId, movingLesson.canon, [
        { thu: sourcePos.thu, buoi: sourcePos.buoi, ti: sourcePos.ti, mon: monAlt },
        { thu: targetPos.thu, buoi: targetPos.buoi, ti: targetPos.ti, mon: monSrc }
      ])) return null;

      if(!_validateClassSessionAfterChangesBuoi1(altLesson.classId, altLesson.canon, [
        { thu: alt.thu, buoi: alt.buoi, ti: alt.ti, mon: monTar }
      ])) return null;

      const roomAltAtSrc = getRoomForClassMon(movingLesson.canon, monAlt);
      const roomSrcAtTar = getRoomForClassMon(movingLesson.canon, monSrc);
      const roomTarAtAlt = getRoomForClassMon(altLesson.canon, monTar);
      if(roomAltAtSrc && _roomConflictQuick(roomOcc, roomAltAtSrc, sourcePos.thu, sourcePos.buoi, sourcePos.ti, movingLesson.classId)) return null;
      if(roomSrcAtTar && _roomConflictQuick(roomOcc, roomSrcAtTar, targetPos.thu, targetPos.buoi, targetPos.ti, movingLesson.classId)) return null;
      if(roomTarAtAlt && _roomConflictQuick(roomOcc, roomTarAtAlt, alt.thu, alt.buoi, alt.ti, altLesson.classId)) return null;

      const oldSrcPos = { thu: srcLesson.thu, buoi: srcLesson.buoi, ti: srcLesson.ti };
      const oldTarPos = { thu: tarLesson.thu, buoi: tarLesson.buoi, ti: tarLesson.ti };
      const oldAltPos = { thu: altLesson.thu, buoi: altLesson.buoi, ti: altLesson.ti };
      const newSrcKey = `${srcLesson.classId}|${targetPos.thu}|${targetPos.buoi}|${targetPos.ti}`;
      const newTarKey = `${tarLesson.classId}|${alt.thu}|${alt.buoi}|${alt.ti}`;
      const newAltKey = `${altLesson.classId}|${sourcePos.thu}|${sourcePos.buoi}|${sourcePos.ti}`;

      const rollback = ()=>{
        tkbSrc[sourcePos.thu][sourcePos.buoi][sourcePos.ti] = vSrc;
        tkbTar[targetPos.thu][targetPos.buoi][targetPos.ti] = vTar;
        tkbAlt[alt.thu][alt.buoi][alt.ti] = vAlt;

        occ[movingTeacher][sourcePos.thu][sourcePos.buoi][sourcePos.ti] = true;
        occ[movingTeacher][targetPos.thu][targetPos.buoi][targetPos.ti] = false;
        occ[gvX][targetPos.thu][targetPos.buoi][targetPos.ti] = true;
        occ[gvX][sourcePos.thu][sourcePos.buoi][sourcePos.ti] = false;

        delete lessonByKey[newSrcKey];
        delete lessonByKey[newTarKey];
        delete lessonByKey[newAltKey];

        srcLesson.thu = oldSrcPos.thu; srcLesson.buoi = oldSrcPos.buoi; srcLesson.ti = oldSrcPos.ti;
        tarLesson.thu = oldTarPos.thu; tarLesson.buoi = oldTarPos.buoi; tarLesson.ti = oldTarPos.ti;
        altLesson.thu = oldAltPos.thu; altLesson.buoi = oldAltPos.buoi; altLesson.ti = oldAltPos.ti;

        lessonByKey[keySrc] = srcLesson;
        lessonByKey[keyTar] = tarLesson;
        lessonByKey[keyAlt] = altLesson;
      };

      tkbSrc[sourcePos.thu][sourcePos.buoi][sourcePos.ti] = monAlt;
      tkbSrc[targetPos.thu][targetPos.buoi][targetPos.ti] = monSrc;
      tkbAlt[alt.thu][alt.buoi][alt.ti] = monTar;

      occ[movingTeacher][sourcePos.thu][sourcePos.buoi][sourcePos.ti] = false;
      occ[movingTeacher][targetPos.thu][targetPos.buoi][targetPos.ti] = true;
      occ[gvX][targetPos.thu][targetPos.buoi][targetPos.ti] = false;
      occ[gvX][sourcePos.thu][sourcePos.buoi][sourcePos.ti] = true;

      delete lessonByKey[keySrc];
      delete lessonByKey[keyTar];
      delete lessonByKey[keyAlt];

      srcLesson.thu = targetPos.thu; srcLesson.buoi = targetPos.buoi; srcLesson.ti = targetPos.ti;
      tarLesson.thu = alt.thu; tarLesson.buoi = alt.buoi; tarLesson.ti = alt.ti;
      altLesson.thu = sourcePos.thu; altLesson.buoi = sourcePos.buoi; altLesson.ti = sourcePos.ti;

      lessonByKey[newSrcKey] = srcLesson;
      lessonByKey[newTarKey] = tarLesson;
      lessonByKey[newAltKey] = altLesson;

      return { rollback, alt, altLesson };
    }

    for(const alt of altList){
      const applied = applyCandidate(alt);
      if(!applied) continue;

      const scoreAfterTxn = _stateScoreBuoi1(occ);
      const scoreAfterLocked = _teacherStateScoreBuoi1(occ, gvX);
      const okGlobal = _isNonWorseStateScoreBuoi1(scoreAfterTxn, scoreBeforeTxn);
      const okLocked = _isNonWorseTeacherStructureBuoi1(scoreAfterLocked, scoreBeforeLocked);
      const rank = evaluateRank(scoreAfterTxn, scoreAfterLocked, alt);
      const candidate = { applied, rank };
      applied.rollback();

      if(!okGlobal || !okLocked) continue;
      if(isRankBetter(candidate, best)) best = candidate;
    }

    if(!best) return returnTxn ? null : false;

    const finalApplied = applyCandidate(best.applied.alt);
    if(!finalApplied) return returnTxn ? null : false;
    if(returnTxn){
      return { ok: true, rollback: finalApplied.rollback };
    }
    return true;
  }catch(e){}
  return !!params?.returnTxn ? null : false;
}

function _tryAddSecondLessonIntoSessionBuoi1(target, built){
  const gv = (target?.teacher||"").toString().trim();
  const thu = target?.thu;
  const buoi = target?.buoi;
  const tiLonely = Number(target?.tiLonely);
  if(!gv || !thu || (buoi!=="sang" && buoi!=="chieu") || !Number.isFinite(tiLonely)) return false;

  const occ = built.occ;
  const lessons = built.lessons;
  const lessonByKey = built.lessonByKey;

  const len = (buoi === "chieu") ? CHIEU : SANG;
  const periodOrder = _periodOrderAround(tiLonely, len);
  if(!periodOrder.length) return false;

  // Theo yêu cầu: ưu tiên lấy từ buổi có 2 tiết trước, rồi 3 tiết...
  const list = (lessons?.[gv] || []).slice();
  list.sort((a,b)=>{
    const ca = _countTrue(occ?.[gv]?.[a.thu]?.[a.buoi] || []);
    const cb = _countTrue(occ?.[gv]?.[b.thu]?.[b.buoi] || []);
    const pa = _priorityBorrowSourceSessionBuoi1(ca);
    const pb = _priorityBorrowSourceSessionBuoi1(cb);
    if(pa !== pb) return pa - pb;
    if(ca !== cb) return ca - cb;
    if(a.buoi !== b.buoi) return a.buoi.localeCompare(b.buoi);
    return DAYS.indexOf(a.thu) - DAYS.indexOf(b.thu);
  });

  const MAX_LESSON_TRY = 120;
  let tried = 0;

  for(const l2 of list){
    try{ if(typeof __OPT_PANEL_STATE !== "undefined" && __OPT_PANEL_STATE?.cancel) return false; }catch(e){}
    if(tried++ >= MAX_LESSON_TRY) break;

    // không dùng lesson đang ở chính buổi lẻ này
    if(l2.thu === thu && l2.buoi === buoi) continue;

    const srcCount = _countTrue(occ?.[gv]?.[l2.thu]?.[l2.buoi] || []);
    if(srcCount <= 0) continue;

    const tkb2 = DATA.tkb?.[l2.classId];
    if(!tkb2) continue;

    // Thử đặt vào các tiết gần (ưu tiên cạnh tiết lẻ để nhìn đẹp)
    for(const ti2 of periodOrder){
      try{ if(typeof __OPT_PANEL_STATE !== "undefined" && __OPT_PANEL_STATE?.cancel) return false; }catch(e){}
      if(ti2 === tiLonely) continue;
      if(occ?.[gv]?.[thu]?.[buoi]?.[ti2]) continue;

      const keyTar = `${l2.classId}|${thu}|${buoi}|${ti2}`;
      const tarLesson = lessonByKey[keyTar];
      if(!tarLesson) continue; // chỉ xử lý nhanh bằng swap ở ô đã có tiết

      const gvX = (tarLesson.teacher||"").toString().trim();
      if(!gvX || gvX === gv) continue;

      // GV đã khóa: ưu tiên reroute bằng một tiết khác của chính GV đó; nếu không được mới xét direct borrow
      if(built?.lockedTeachers && built.lockedTeachers.size && built.lockedTeachers.has(_normTeacher(gvX))){
        const scoreBeforeReroute = _stateScoreBuoi1(occ);
        const reroutedTxn = _tryRerouteLockedTeacherSlotBuoi1({
          built,
          movingTeacher: gv,
          movingLesson: l2,
          lockedLesson: tarLesson,
          sourcePos: { thu: l2.thu, buoi: l2.buoi, ti: l2.ti },
          targetPos: { thu, buoi, ti: ti2 },
          returnTxn: true
        });
        if(reroutedTxn && reroutedTxn.ok){
          if(srcCount === 2){
            const remainSlots = occ?.[gv]?.[l2.thu]?.[l2.buoi] || [];
            const remainTi = remainSlots.findIndex(x => !!x);
            if(remainTi >= 0){
              const okRemain = _tryMoveLonelyLessonOutBuoi1({
                teacher: gv,
                thu: l2.thu,
                buoi: l2.buoi,
                tiLonely: remainTi
              }, built);
              if(!okRemain){
                reroutedTxn.rollback();
                continue;
              }
            }
          }
          const scoreAfterReroute = _stateScoreBuoi1(occ);
          if(!_isBetterStateScoreBuoi1(scoreAfterReroute, scoreBeforeReroute)){
            reroutedTxn.rollback();
            continue;
          }
          return true;
        }
        const okLockedBorrow = _canBorrowLockedTeacherSlotBuoi1(occ, gvX,
          { thu, buoi, ti: ti2 },
          { thu: l2.thu, buoi: l2.buoi, ti: l2.ti }
        );
        if(!okLockedBorrow) continue;
      }

      // Tránh làm GV khác bị "lẻ" mới hoặc tạo buổi mới
      const cntX_tar = _countTrue(occ?.[gvX]?.[thu]?.[buoi] || []);
      if(cntX_tar === 2) continue; // 2 -> 1
      const cntX_src = _countTrue(occ?.[gvX]?.[l2.thu]?.[l2.buoi] || []);
      if(cntX_src === 0) continue; // 0 -> 1

      // GV X phải rảnh ở slot nguồn của l2
      if(occ?.[gvX]?.[l2.thu]?.[l2.buoi]?.[l2.ti]) continue;

      const vSrc = tkb2?.[l2.thu]?.[l2.buoi]?.[l2.ti];
      const vTar = tkb2?.[thu]?.[buoi]?.[ti2];
      if(!vSrc || !vTar || vSrc === "OFF" || vTar === "OFF") continue;
      if(isFixed(vSrc) || isFixed(vTar)) continue;

      const mon2 = (l2.mon||"").toString().trim();
      const monX = (tarLesson.mon||"").toString().trim();
      if(!mon2 || !monX || mon2 === monX) continue;

      if(!_canSwapWithinClass(l2.classId, l2.canon, l2.thu, l2.buoi, l2.ti, thu, buoi, ti2, mon2, monX)) continue;

      const keySrc = `${l2.classId}|${l2.thu}|${l2.buoi}|${l2.ti}`;
      const keyTar2 = `${l2.classId}|${thu}|${buoi}|${ti2}`;
      const srcLesson = lessonByKey[keySrc];
      const targetLesson = lessonByKey[keyTar2];
      if(!srcLesson || !targetLesson) continue;

      const oldSrc = { thu: srcLesson.thu, buoi: srcLesson.buoi, ti: srcLesson.ti };
      const oldTar = { thu: targetLesson.thu, buoi: targetLesson.buoi, ti: targetLesson.ti };

      function rollbackSwap(){
        tkb2[l2.thu][l2.buoi][l2.ti] = vSrc;
        tkb2[thu][buoi][ti2] = vTar;

        occ[gv][l2.thu][l2.buoi][l2.ti] = true;
        occ[gv][thu][buoi][ti2] = false;

        occ[gvX][thu][buoi][ti2] = true;
        occ[gvX][l2.thu][l2.buoi][l2.ti] = false;

        delete lessonByKey[`${srcLesson.classId}|${srcLesson.thu}|${srcLesson.buoi}|${srcLesson.ti}`];
        delete lessonByKey[`${targetLesson.classId}|${targetLesson.thu}|${targetLesson.buoi}|${targetLesson.ti}`];

        srcLesson.thu = oldSrc.thu; srcLesson.buoi = oldSrc.buoi; srcLesson.ti = oldSrc.ti;
        targetLesson.thu = oldTar.thu; targetLesson.buoi = oldTar.buoi; targetLesson.ti = oldTar.ti;

        lessonByKey[keySrc] = srcLesson;
        lessonByKey[keyTar2] = targetLesson;
      }

      // Apply swap trong lớp l2.classId
      tkb2[l2.thu][l2.buoi][l2.ti] = monX;
      tkb2[thu][buoi][ti2] = mon2;

      occ[gv][l2.thu][l2.buoi][l2.ti] = false;
      occ[gv][thu][buoi][ti2] = true;

      occ[gvX][thu][buoi][ti2] = false;
      occ[gvX][l2.thu][l2.buoi][l2.ti] = true;

      delete lessonByKey[keySrc];
      delete lessonByKey[keyTar2];

      srcLesson.thu = thu; srcLesson.buoi = buoi; srcLesson.ti = ti2;
      targetLesson.thu = oldSrc.thu; targetLesson.buoi = oldSrc.buoi; targetLesson.ti = oldSrc.ti;

      lessonByKey[`${srcLesson.classId}|${srcLesson.thu}|${srcLesson.buoi}|${srcLesson.ti}`] = srcLesson;
      lessonByKey[`${targetLesson.classId}|${targetLesson.thu}|${targetLesson.buoi}|${targetLesson.ti}`] = targetLesson;

      // Nếu lấy từ buổi có đúng 2 tiết thì phải xử lý tiếp tiết còn lại sang 1 buổi đã có tiết.
      if(srcCount === 2){
        const remainSlots = occ?.[gv]?.[l2.thu]?.[l2.buoi] || [];
        const remainTi = remainSlots.findIndex(x => !!x);
        if(remainTi >= 0){
          const okRemain = _tryMoveLonelyLessonOutBuoi1({
            teacher: gv,
            thu: l2.thu,
            buoi: l2.buoi,
            tiLonely: remainTi
          }, built);
          if(!okRemain){
            rollbackSwap();
            continue;
          }
        }
      }

      return true;
    }
  }

  return false;
}

function _tryMoveLonelyLessonOutBuoi1(target, built){
  const gv = (target?.teacher||"").toString().trim();
  const thu1 = target?.thu;
  const buoi1 = target?.buoi;
  const ti1 = Number(target?.tiLonely);
  if(!gv || !thu1 || (buoi1!=="sang" && buoi1!=="chieu") || !Number.isFinite(ti1)) return false;

  const occ = built.occ;
  const lessonByKey = built.lessonByKey;

  const info = _findTeacherCellAtSlot(gv, thu1, buoi1, ti1);
  if(!info) return false;
  if(info.fixed) return false; // không move được tiết fixed

  const classId = info.classId;
  const canon = info.canon;
  const mon1 = info.mon;

  const keyL1 = `${classId}|${thu1}|${buoi1}|${ti1}`;
  const l1 = lessonByKey[keyL1];
  if(!l1) return false; // không movable

  const tkb = DATA.tkb?.[classId];
  if(!tkb) return false;

  // mục tiêu: chuyển tiết lẻ sang 1 buổi khác mà GV đang có tiết (>=1), ưu tiên buổi có 1 tiết (để thành 2)
  const targets = [];
  for(const thu2 of DAYS){
    for(const buoi2 of ["sang","chieu"]){
      if(thu2 === thu1 && buoi2 === buoi1) continue;
      const c = _countTrue(occ?.[gv]?.[thu2]?.[buoi2] || []);
      if(c >= 1) targets.push({thu: thu2, buoi: buoi2, c});
    }
  }
  targets.sort((a,b)=>{
    const aa = (a.c === 1) ? 0 : 1;
    const bb = (b.c === 1) ? 0 : 1;
    if(aa !== bb) return aa - bb;
    if(a.c !== b.c) return b.c - a.c;
    return DAYS.indexOf(a.thu) - DAYS.indexOf(b.thu);
  });

  for(const t of targets){
    try{ if(typeof __OPT_PANEL_STATE !== "undefined" && __OPT_PANEL_STATE?.cancel) return false; }catch(e){}
    const thu2 = t.thu, buoi2 = t.buoi;
    const arr2 = tkb?.[thu2]?.[buoi2] || [];
    for(let ti2=0; ti2<arr2.length; ti2++){
      try{ if(typeof __OPT_PANEL_STATE !== "undefined" && __OPT_PANEL_STATE?.cancel) return false; }catch(e){}
      const v2 = arr2[ti2];
      if(!v2 || v2 === "OFF" || isFixed(v2)) continue;

      if(occ?.[gv]?.[thu2]?.[buoi2]?.[ti2]) continue; // GV bận ở slot đích

      const mon2 = cellMon(v2);
      if(!mon2 || mon2 === mon1) continue;

      const keyL2 = `${classId}|${thu2}|${buoi2}|${ti2}`;
      const l2 = lessonByKey[keyL2];
      if(!l2) continue;

      const gvB = (l2.teacher||"").toString().trim();
      if(!gvB || gvB === gv) continue;


      // GV đã khóa: ưu tiên reroute bằng tiết khác của chính GV đó trước khi swap trực tiếp
      if(built?.lockedTeachers && built.lockedTeachers.size && built.lockedTeachers.has(_normTeacher(gvB))){
        const scoreBeforeReroute = _stateScoreBuoi1(occ);
        const reroutedTxn = _tryRerouteLockedTeacherSlotBuoi1({
          built,
          movingTeacher: gv,
          movingLesson: l1,
          lockedLesson: l2,
          sourcePos: { thu: thu1, buoi: buoi1, ti: ti1 },
          targetPos: { thu: thu2, buoi: buoi2, ti: ti2 },
          returnTxn: true
        });
        if(reroutedTxn && reroutedTxn.ok){
          const scoreAfterReroute = _stateScoreBuoi1(occ);
          if(_isBetterStateScoreBuoi1(scoreAfterReroute, scoreBeforeReroute)) return true;
          reroutedTxn.rollback();
        }
        const okLockedBorrow = _canBorrowLockedTeacherSlotBuoi1(occ, gvB,
          { thu: thu2, buoi: buoi2, ti: ti2 },
          { thu: thu1, buoi: buoi1, ti: ti1 }
        );
        if(!okLockedBorrow) continue;
      }
      // GV B phải rảnh ở slot nguồn (thu1/buoi1/ti1)
      if(occ?.[gvB]?.[thu1]?.[buoi1]?.[ti1]) continue;

      // tránh làm GV B bị lẻ mới
      const cntB_src = _countTrue(occ?.[gvB]?.[thu2]?.[buoi2] || []);
      if(cntB_src === 2) continue; // 2 -> 1
      const cntB_tar = _countTrue(occ?.[gvB]?.[thu1]?.[buoi1] || []);
      if(cntB_tar === 0) continue; // 0 -> 1

      // validate trong lớp này sau khi swap
      if(!_canSwapWithinClass(classId, canon, thu1, buoi1, ti1, thu2, buoi2, ti2, mon1, mon2)) continue;

      // Apply swap
      tkb[thu1][buoi1][ti1] = mon2;
      tkb[thu2][buoi2][ti2] = mon1;

      // Update occ
      occ[gv][thu1][buoi1][ti1] = false;
      occ[gv][thu2][buoi2][ti2] = true;

      occ[gvB][thu2][buoi2][ti2] = false;
      occ[gvB][thu1][buoi1][ti1] = true;

      // Update lesson objects + index
      delete lessonByKey[keyL1];
      delete lessonByKey[keyL2];

      l1.thu = thu2; l1.buoi = buoi2; l1.ti = ti2;
      l2.thu = thu1; l2.buoi = buoi1; l2.ti = ti1;

      lessonByKey[`${l1.classId}|${l1.thu}|${l1.buoi}|${l1.ti}`] = l1;
      lessonByKey[`${l2.classId}|${l2.thu}|${l2.buoi}|${l2.ti}`] = l2;

      return true;
    }
  }

  return false;
}

function _roomConflictQuick(roomOcc, room, thu, buoi, ti, ignoreLopId){
  if(!roomOcc || !room) return false;
  try{
    const key = `${room}|${thu}|${buoi}|${ti}`;
    const cur = roomOcc.get(key);
    if(!cur || !cur.count) return false;
    if(cur.count === 1 && String(cur.owner) === String(ignoreLopId)) return false;
    return true;
  }catch(e){
    return false;
  }
}

function _findSingleSessionLessons(occ, lessons){
  const out = [];
  for(const gv of Object.keys(occ || {})){
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const slots = occ?.[gv]?.[thu]?.[buoi] || [];
        const c = _countTrue(slots);
        if(c !== 1) continue;
        const ti = slots.findIndex(x=>!!x);
        if(ti < 0) continue;
        const one = (lessons?.[gv] || []).find(l => l.thu===thu && l.buoi===buoi && Number(l.ti)===Number(ti));
        if(!one) continue;
        out.push(one);
      }
    }
  }

  // ổn định thứ tự để dễ debug
  out.sort((a,b)=>{
    const g = String(a.teacher).localeCompare(String(b.teacher),'vi');
    if(g) return g;
    const d = DAYS.indexOf(a.thu) - DAYS.indexOf(b.thu);
    if(d) return d;
    if(a.buoi !== b.buoi) return a.buoi.localeCompare(b.buoi);
    return Number(a.ti)-Number(b.ti);
  });
  return out;
}

function _teacherSessionSlots(occ, gv, thu, buoi){
  const len = (buoi === "chieu") ? CHIEU : SANG;
  const slots = occ?.[gv]?.[thu]?.[buoi];
  return Array.isArray(slots) ? slots.slice() : Array(len).fill(false);
}

function _sessionScoreFromOcc(occ, gv, thu, buoi){
  const slots = occ?.[gv]?.[thu]?.[buoi];
  if(!Array.isArray(slots)) return 0;
  return _scoreTeacherSession(slots);
}

function _tryFixSingleLesson(one, occ, roomOcc){
  const gvA = (one?.teacher||"").toString().trim();
  const classId = one?.classId;
  const thu1 = one?.thu;
  const buoi1 = one?.buoi;
  const ti1 = Number(one?.ti);
  const mon1 = (one?.mon||"").toString().trim();
  if(!gvA || !classId || !thu1 || (buoi1!=='sang' && buoi1!=='chieu') || !mon1 || !Number.isFinite(ti1)) return false;
  // HARD-LOCK: không đụng vào GV đã khóa
  if(_isHardLockedTeacherName(gvA)) return false;

  const tkb = DATA.tkb?.[classId];
  if(!tkb) return false;

  // đảm bảo ô nguồn vẫn đúng và có thể di chuyển
  const v1 = tkb?.[thu1]?.[buoi1]?.[ti1];
  if(!v1 || v1 === "OFF" || isFixed(v1)) return false;
  if(cellMon(v1) !== mon1) return false;

  const canon = getLopCanonById(classId);
  const room1 = getRoomForClassMon(canon, mon1);
  const lim1  = _getGioihanForLopIdMon(classId, canon, mon1);

  // các buổi mục tiêu: GV A đã có ít nhất 1 tiết ở buổi đó
  const targets = [];
  for(const thu2 of DAYS){
    for(const buoi2 of ["sang","chieu"]){
      if(thu2 === thu1 && buoi2 === buoi1) continue;
      const c = _countTrue(occ?.[gvA]?.[thu2]?.[buoi2] || []);
      if(c >= 1) targets.push({thu: thu2, buoi: buoi2, c});
    }
  }
  // ưu tiên buổi đang có 1 tiết (để thành 2), rồi đến buổi có nhiều tiết
  targets.sort((a,b)=>{
    const aa = (a.c === 1) ? 0 : 1;
    const bb = (b.c === 1) ? 0 : 1;
    if(aa !== bb) return aa - bb;
    if(a.c !== b.c) return b.c - a.c;
    const d = DAYS.indexOf(a.thu) - DAYS.indexOf(b.thu);
    if(d) return d;
    return a.buoi.localeCompare(b.buoi);
  });

  let best = null; // {thu,buoi,ti,mon2,delta,kind}
  let bestDelta = 0;

  const preA1 = _sessionScoreFromOcc(occ, gvA, thu1, buoi1);

  for(const t of targets){
    const thu2 = t.thu;
    const buoi2 = t.buoi;
    const arr2 = tkb?.[thu2]?.[buoi2] || [];
    for(let ti2=0; ti2<arr2.length; ti2++){
      const v2 = arr2[ti2];
      if(v2 === "OFF" || isFixed(v2)) continue;

      const mon2 = cellMon(v2); // "" nếu rỗng
      if(mon2 && mon2 === mon1) continue; // swap cùng môn thường không giúp

      // GV A phải rảnh ở slot mới (toàn trường)
      if(occ?.[gvA]?.[thu2]?.[buoi2]?.[ti2]) continue;
      if(room1 && _roomConflictQuick(roomOcc, room1, thu2, buoi2, ti2, classId)) continue;

      if(!mon2){
        // MOVE sang ô trống
        const arrS = (tkb?.[thu1]?.[buoi1] || []).slice();
        const arrT = (tkb?.[thu2]?.[buoi2] || []).slice();
        arrS[ti1] = "";
        arrT[ti2] = mon1;

        if(!_validateSubjectInSession(arrS, mon1, lim1)) continue;
        if(!_validateSubjectInSession(arrT, mon1, lim1)) continue;

        const preA2 = _sessionScoreFromOcc(occ, gvA, thu2, buoi2);
        const postS = _teacherSessionSlots(occ, gvA, thu1, buoi1); postS[ti1] = false;
        const postT = _teacherSessionSlots(occ, gvA, thu2, buoi2); postT[ti2] = true;
        const postA1 = _scoreTeacherSession(postS);
        const postA2 = _scoreTeacherSession(postT);

        const delta = (postA1 + postA2) - (preA1 + preA2);
        if(delta > bestDelta){
          bestDelta = delta;
best = { thu: thu2, buoi: buoi2, ti: ti2, mon2: "", kind: "move" };
        }
        continue;
      }

      // SWAP với ô đang có môn khác
      const gvB = getTeacherForClassMon(canon, mon2);
        if(_isHardLockedTeacherName(gvB)) continue;
      if(_isHardLockedTeacherName(gvB)) continue;
      if(!gvB || gvB === gvA) continue;
      // tránh tạo GV B đi 1 tiết/buổi ở buổi nguồn
      const cntBsrc = _countTrue(occ?.[gvB]?.[thu1]?.[buoi1] || []);
      if(cntBsrc < 1) continue;

      // GV B phải rảnh ở slot nguồn (toàn trường)
      if(occ?.[gvB]?.[thu1]?.[buoi1]?.[ti1]) continue;

      const room2 = getRoomForClassMon(canon, mon2);
      if(room2 && _roomConflictQuick(roomOcc, room2, thu1, buoi1, ti1, classId)) continue;
      if(room1 && _roomConflictQuick(roomOcc, room1, thu2, buoi2, ti2, classId)) continue;

      const lim2 = _getGioihanForLopIdMon(classId, canon, mon2);

      // validate session trong lớp sau khi swap
      const arrS = (tkb?.[thu1]?.[buoi1] || []).slice();
      const arrT = (tkb?.[thu2]?.[buoi2] || []).slice();
      arrS[ti1] = mon2;
      arrT[ti2] = mon1;

      if(!_validateSubjectInSession(arrS, mon1, lim1)) continue;
      if(!_validateSubjectInSession(arrS, mon2, lim2)) continue;
      if(!_validateSubjectInSession(arrT, mon1, lim1)) continue;
      if(!_validateSubjectInSession(arrT, mon2, lim2)) continue;

      const preA2 = _sessionScoreFromOcc(occ, gvA, thu2, buoi2);
      const preB1 = _sessionScoreFromOcc(occ, gvB, thu1, buoi1);
      const preB2 = _sessionScoreFromOcc(occ, gvB, thu2, buoi2);

      const postA_src = _teacherSessionSlots(occ, gvA, thu1, buoi1); postA_src[ti1] = false;
      const postA_tar = _teacherSessionSlots(occ, gvA, thu2, buoi2); postA_tar[ti2] = true;
      const postB_src = _teacherSessionSlots(occ, gvB, thu1, buoi1); postB_src[ti1] = true;
      const postB_tar = _teacherSessionSlots(occ, gvB, thu2, buoi2); postB_tar[ti2] = false;

      const postA1 = _scoreTeacherSession(postA_src);
      const postA2 = _scoreTeacherSession(postA_tar);
      const postB1 = _scoreTeacherSession(postB_src);
      const postB2 = _scoreTeacherSession(postB_tar);

      const delta = (postA1 + postA2 + postB1 + postB2) - (preA1 + preA2 + preB1 + preB2);
      if(delta > bestDelta){
        bestDelta = delta;
        best = { thu: thu2, buoi: buoi2, ti: ti2, mon2, kind: "swap" };
      }
    }
  }

  if(!best) return false;

  // Apply best move/swap
  if(best.kind === "move"){
    tkb[thu1][buoi1][ti1] = "";
    tkb[best.thu][best.buoi][best.ti] = mon1;
    return true;
  }

  if(best.kind === "swap"){
    tkb[thu1][buoi1][ti1] = best.mon2;
    tkb[best.thu][best.buoi][best.ti] = mon1;
    return true;
  }

  return false;
}

function optimizeTeacherScheduleQuality(opts={}){
  const maxSwaps = Number(opts.maxSwaps ?? 80);
  const maxIters = Number(opts.maxIters ?? 250);
  let swaps = 0;

  for(let iter=0; iter<maxIters; iter++){
    if(swaps >= maxSwaps) break;

    const built = _buildTeacherOccAll();
    const occ = built.occ;
    const lessons = built.lessons;
    const roomOcc = built.roomOcc;
    const singles = _findSingleSessionLessons(occ, lessons);
    if(!singles.length) break;

    let fixedOne = false;
    for(const one of singles){
      if(_tryFixSingleLesson(one, occ, roomOcc)){
        swaps++;
        fixedOne = true;
        break; // rebuild occ rồi tiếp tục
      }
    }

    if(!fixedOne) break;
  }

  return swaps;
}


/* =======================
   OPTIMIZE (TIẾT/BUỔI = 1) — tách riêng theo yêu cầu
   - Quét liên tục toàn bộ TKB, nơi nào GV đi dạy lẻ 1 tiết/buổi thì cố gắng hoán đổi/dời tiết
   - Nếu GV chỉ dạy <= 1 tiết/tuần thì bỏ qua
   - Ưu tiên xử lý buổi chiều trước buổi sáng
======================= */

function _findSingleSessionLessonsBuoi1(occ, lessons, opts={}){
  const preferAfternoon = (opts.preferAfternoon !== false);
  const out = [];

  for(const gv of Object.keys(occ || {})){
    const total = (lessons?.[gv] || []).length;
    if(total <= 1) continue; // GV chỉ 1 tiết/tuần -> bỏ qua

    for(const thu of DAYS){
      const buoiOrder = preferAfternoon ? ["chieu","sang"] : ["sang","chieu"];
      for(const buoi of buoiOrder){
        const slots = occ?.[gv]?.[thu]?.[buoi] || [];
        const c = _countTrue(slots);
        if(c !== 1) continue;
        const ti = slots.findIndex(x=>!!x);
        if(ti < 0) continue;

        const one = (lessons?.[gv] || []).find(l => l.thu===thu && l.buoi===buoi && Number(l.ti)===Number(ti));
        if(one) out.push(one);
      }
    }
  }

  // ổn định thứ tự + ưu tiên chiều
  out.sort((a,b)=>{
    const ba = (a.buoi === "chieu") ? 0 : 1;
    const bb = (b.buoi === "chieu") ? 0 : 1;
    if(ba !== bb) return ba - bb;

    const g = String(a.teacher).localeCompare(String(b.teacher),'vi');
    if(g) return g;

    const d = DAYS.indexOf(a.thu) - DAYS.indexOf(b.thu);
    if(d) return d;

    return Number(a.ti) - Number(b.ti);
  });

  return out;
}

function optimizeTeacherScheduleQualityBuoi1(opts={}){
  const maxSwaps = Number(opts.maxSwaps ?? 80);
  const timeBudgetMs = Number(opts.timeBudgetMs ?? 25);
  const preferAfternoon = (opts.preferAfternoon !== false);

  const startTs = Date.now();
  const built = _buildTeacherOccAllV2();
  const occ = built.occ;


  // Cache danh sách GV đã khóa để các thao tác swap/move KHÔNG làm vỡ các GV FULL/Near-FULL
  try{
    built.lockedTeachers = _computeLockedTeachers(occ, 0);
  }catch(e){
    built.lockedTeachers = new Set();
  }
  let swaps = 0;
  let failStreak = 0;
  while(swaps < maxSwaps){
    try{
      if(typeof __OPT_PANEL_STATE !== "undefined" && __OPT_PANEL_STATE?.cancel) break;
    }catch(e){}

    if((Date.now() - startTs) >= timeBudgetMs) break;

    const target = _pickLonelySessionBuoi1(occ, built.lessons, preferAfternoon);
    if(!target) break;

    // Ưu tiên đúng yêu cầu: ghép thêm tiết vào buổi lẻ để không còn "1 tiết/buổi"
    const ok = _tryAddSecondLessonIntoSessionBuoi1(target, built) || _tryMoveLonelyLessonOutBuoi1(target, built);
    if(!ok){
      failStreak += 1;
      if(failStreak >= 8) break;
      continue;
    }

    failStreak = 0;
    swaps += 1;
  }

  return swaps;
}




/* =======================
   OPTIMIZE (NÂNG CAO) — theo tuỳ chọn người dùng
   - limitTietBuoi: 1/2/3  (hạn chế GV phải đi dạy lẻ 1..N tiết/buổi)
   - limitTietTrong: 2/1  (hạn chế tiết trống trong buổi)
   - scopeClassId: "" -> toàn trường, hoặc id lớp -> chỉ tối ưu trong 1 lớp
   Ghi chú: đây là heuristic "best-effort" (không cần 100%).
======================= */

function _teacherSessionMetrics(slots){
  const pos = [];
  for(let i=0;i<slots.length;i++) if(!!slots[i]) pos.push(i);
  const count = pos.length;
  let totalGaps = 0;
  let maxGap = 0;
  for(let i=1;i<pos.length;i++){
    const gap = pos[i] - pos[i-1] - 1;
    if(gap > 0){
      totalGaps += gap;
      if(gap > maxGap) maxGap = gap;
    }
  }
  return {count, totalGaps, maxGap, pos};
}

function _isBadTeacherSessionAdv(slots, opt){
  const m = _teacherSessionMetrics(slots || []);
  if(m.count === 0) return false;

  const limBuoi = Number(opt?.limitTietBuoi || 0);
  const uiMinBuoi = _uiMinTietBuoi(opt);
  const limTrong = Number(opt?.limitTietTrong || 0);
  // Chỉ hỗ trợ mức 1/2
  const limTrong2 = limTrong;

  if(uiMinBuoi > 0 && m.count < uiMinBuoi) return true;

  if(limTrong2 === 1){
    // 1: cố gắng không còn trống
    if(m.totalGaps > 0) return true;
  } else if(limTrong2 === 2){
    // 2: cho phép tối đa 1 tiết trống
    if(m.totalGaps >= 2 || m.maxGap >= 2) return true;
  } else if(limTrong2 === 3){
    // 3: cho phép tối đa 2 tiết trống
    if(m.totalGaps >= 3 || m.maxGap >= 3) return true;
  }

  return false;
}

function _scoreTeacherSessionAdv(slots, opt){
  const s = Array.isArray(slots) ? slots : [];
  const m = _teacherSessionMetrics(s);
  if(m.count === 0) return 0;

  const limBuoi = Number(opt?.limitTietBuoi || 0);
  const uiMinBuoi = _uiMinTietBuoi(opt);
  const limTrong = Number(opt?.limitTietTrong || 0);
  const limTrong2 = limTrong;

  let score = 0;
  // thưởng nhẹ cho buổi có nhiều tiết (giảm số buổi phải đi dạy)
  score += m.count * 10;

  // phạt buổi dạy "ít tiết" theo tuỳ chọn (1..N)
  const effMinBuoi = _uiMinTietBuoi(opt);
  if(effMinBuoi > 0 && m.count < effMinBuoi){
    score -= 1000;
  }

  // phạt tiết trống
  if(m.totalGaps > 0){
    if(limTrong2 === 1){
      // cố gắng... không còn trống
      score -= 520 * m.totalGaps + 220 * m.maxGap;
    } else if(limTrong2 === 2){
      // cho phép 0..1 trống nhỏ; phạt mạnh khi có >=2 hoặc gap >=2
      score -= 90 * m.totalGaps;
      if(m.totalGaps >= 2) score -= 260 * (m.totalGaps - 1);
      if(m.maxGap >= 2) score -= 280 * (m.maxGap - 1);
    } else if(limTrong2 === 3){
      // cho phép 0..2 trống nhỏ; phạt mạnh khi có >=3 hoặc gap >=3
      score -= 70 * m.totalGaps;
      if(m.totalGaps >= 3) score -= 180 * (m.totalGaps - 2);
      if(m.maxGap >= 3) score -= 200 * (m.maxGap - 2);
    } else {
      score -= 60 * m.totalGaps;
    }
  } else {
    // contiguous
    if(m.count >= 2) score += 35;
  }
  // spread theo ngày trong tuần (ưu tiên rải đều)
  const spreadW = Number(opt?.spreadWeight || 0);
  if(spreadW > 0 && opt?.__occGv && opt?.__thu){
    try{
      const occGv = opt.__occGv;
      const days = (typeof DAYS !== "undefined" && Array.isArray(DAYS)) ? DAYS : Object.keys(occGv||{});
      if(days && days.length){
        const counts = days.map(d=>{
          const o = occGv?.[d] || {};
          return _countTrue(o.sang||[]) + _countTrue(o.chieu||[]);
        });
        const avg = counts.reduce((a,b)=>a+b,0) / (counts.length||1);
        const dayCount = _countTrue((occGv?.[opt.__thu]?.sang)||[]) + _countTrue((occGv?.[opt.__thu]?.chieu)||[]);
        score -= spreadW * Math.abs(dayCount - avg);
      }
    }catch(_){}
  }


  return score;
}

function _sessionBadnessAdv(slots, opt){
  const m = _teacherSessionMetrics(slots || []);
  if(m.count === 0) return 0;

  const limBuoi = Number(opt?.limitTietBuoi || 0);
  const uiMinBuoi = _uiMinTietBuoi(opt);
  const limTrong = Number(opt?.limitTietTrong || 0);

  let bad = 0;

  // Buổi dạy < k tiết (nếu bật)
  const effMinBuoi = _uiMinTietBuoi(opt);
  if(effMinBuoi > 0 && m.count < effMinBuoi){
    bad += 1000 + (effMinBuoi - m.count) * 250;
  }

  // Tiết trống (hard constraint)
  if(limTrong === 1){
    // chọn 1: phải 0 gap
    if(m.totalGaps > 0 || m.maxGap > 0){
      bad += 800 + m.totalGaps * 250 + m.maxGap * 300;
    }
  } else if(limTrong === 2){
    // chọn 2: cho phép tối đa 1 gap => lỗi khi >=2
    const excessTotal = Math.max(0, m.totalGaps - 1);
    const excessMax   = Math.max(0, m.maxGap - 1);
    if(excessTotal > 0 || excessMax > 0){
      bad += 650 + excessTotal * 220 + excessMax * 320;
    }
  }

  return bad;
}


function _findBadSessionLessonsAdv(occ, lessons, opt){
  const out = [];
  const gvList = Object.keys(occ || {});
  const limBuoi = Number(opt?.limitTietBuoi || 0);
  const uiMinBuoi = _uiMinTietBuoi(opt);
  const limTrong = Number(opt?.limitTietTrong||0);

  for(const gv of gvList){
    const totalLessons = _teacherTotalTietByOcc(occ, gv);
    // Feasibility: can we partition totalLessons into sessions of size [limBuoi..5] ?
    // If impossible, disable limitTietBuoi for this teacher (otherwise optimizer will loop on an impossible constraint).
    const k = uiMinBuoi;
    const minSessions = (totalLessons > 0) ? Math.ceil(totalLessons / 5) : 0;
    const maxSessions = (k > 0) ? Math.floor(totalLessons / k) : Infinity;
    const feasible = (k <= 0) ? true : (totalLessons === 0 ? true : (minSessions <= maxSessions));
    const skipBuoiForGV = (k > 0 && !feasible);
    const effOpt = skipBuoiForGV ? ({...opt, limitTietBuoi: 0}) : opt;

    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const slots = occ?.[gv]?.[thu]?.[buoi] || [];
        if(!_isBadTeacherSessionAdv(slots, effOpt)) continue;
        const m = _teacherSessionMetrics(slots);

        let sev = 0;
        if(!skipBuoiForGV && uiMinBuoi > 0 && m.count < uiMinBuoi) sev += 100 + (uiMinBuoi - m.count + 1) * 20;
        if(limTrong === 1 && m.totalGaps > 0) sev += 120 + m.totalGaps * 25;
        if(limTrong === 2 && (m.totalGaps >= 2 || m.maxGap >= 2)) sev += 80 + m.totalGaps * 18 + m.maxGap * 22;
        if(limTrong === 3 && (m.totalGaps >= 3 || m.maxGap >= 3)) sev += 55 + m.totalGaps * 12 + m.maxGap * 16;

        const arr = (lessons?.[gv] || []).filter(l => l.thu === thu && l.buoi === buoi);
        for(const one of arr){
          out.push({...one, _sev: sev});
        }
      }
    }
  }

  out.sort((a,b)=> (b._sev||0) - (a._sev||0));
  return out;
}

function _getSlotsFromOcc(occ, gv, thu, buoi){
  const len = (buoi === "chieu") ? CHIEU : SANG;
  const s = occ?.[gv]?.[thu]?.[buoi];
  if(Array.isArray(s) && s.length === len) return s.slice();
  return Array(len).fill(false);
}

// ===== NEW (2026-02): KÉO "TIẾT ĐÔI" (cùng môn + cùng lớp của GV) =====
// Mục tiêu:
// - Khi tối ưu theo k (ví dụ k=3), nếu một buổi của GV bị thiếu (<k)
//   nhưng có buổi khác đang full (>=k+2, thường là 5) thì kéo NGUYÊN CẶP 2 tiết
//   (cùng môn+cùng lớp, 2 tiết liền nhau) sang 2 ô trống liên tiếp ở buổi thiếu.
// - Không tạo "tiết lẻ" trong buổi nguồn: sau khi kéo, số tiết còn lại của cặp đó
//   trong buổi nguồn phải là 0 hoặc >=2 (không được còn lại 1).

function _findConsecutiveFreePairsForTeacher(occ, gv, thu, buoi){
  const slots = occ?.[gv]?.[thu]?.[buoi] || [];
  const len = slots.length;
  const pairs = [];
  for(let i=0;i<len-1;i++){
    if(!slots[i] && !slots[i+1]) pairs.push([i,i+1]);
  }
  // Ưu tiên 1-2 (index 0-1), rồi 2-3...
  pairs.sort((a,b)=>a[0]-b[0]);
  return pairs;
}

function _countSamePairInSession(lessonsOfGv, thu, buoi, classId, mon){
  const arr = Array.isArray(lessonsOfGv) ? lessonsOfGv : [];
  let c=0;
  for(const l of arr){
    if(String(l?.thu)===String(thu) && String(l?.buoi)===String(buoi) && String(l?.classId)===String(classId) && String(l?.mon)===String(mon)) c++;
  }
  return c;
}

function _findDoublePairsInSession(lessonsOfGv, thu, buoi){
  // returns [{classId, mon, ti0, ti1}] where ti1=ti0+1
  const arr = (Array.isArray(lessonsOfGv) ? lessonsOfGv : []).filter(l=>String(l?.thu)===String(thu) && String(l?.buoi)===String(buoi));
  // group by classId|mon
  const map = new Map();
  for(const l of arr){
    const classId = String(l?.classId||"");
    const mon = String(l?.mon||"");
    const ti = Number(l?.ti);
    if(!classId || !mon || !Number.isFinite(ti)) continue;
    const k = classId + "|" + mon;
    if(!map.has(k)) map.set(k, []);
    map.get(k).push(ti);
  }
  const out=[];
  for(const [k, tis] of map.entries()){
    tis.sort((a,b)=>a-b);
    for(let i=0;i<tis.length-1;i++){
      if(tis[i+1] === tis[i] + 1){
        const [classId, mon] = k.split("|");
        out.push({classId, mon, ti0: tis[i], ti1: tis[i+1]});
      }
    }
  }
  // Ưu tiên cặp sớm (tiết 1-2) để ít phá buổi nguồn
  out.sort((a,b)=>a.ti0-b.ti0);
  return out;
}

function _canMovePairIntoClassSession(tkb, classId, thuTo, buoiTo, tiA, mon, canon, roomOcc, roomName){
  const arr = tkb?.[thuTo]?.[buoiTo];
  if(!Array.isArray(arr) || !arr.length) return false;
  if(tiA < 0 || tiA+1 >= arr.length) return false;

  // phải trống & không OFF/fixed
  const v0 = arr[tiA], v1 = arr[tiA+1];
  if(v0 === "OFF" || v1 === "OFF" || isFixed(v0) || isFixed(v1)) return false;
  if(cellMon(v0) || cellMon(v1)) return false;

  // check phòng
  if(roomName){
    if(_roomConflictQuick(roomOcc, roomName, thuTo, buoiTo, tiA, classId)) return false;
    if(_roomConflictQuick(roomOcc, roomName, thuTo, buoiTo, tiA+1, classId)) return false;
  }

  // validate gioihan/1 cụm trong buổi
  const lim = _getGioihanForLopIdMon(classId, canon, mon);
  const copy = arr.slice();
  copy[tiA] = mon;
  copy[tiA+1] = mon;
  return _validateSubjectInSession(copy, mon, lim);
}

function _tryPullDoublePairToBadSession(gv, thuBad, buoiBad, occ, roomOcc, opt){
  const limBuoi = Number(opt?.limitTietBuoi || 0);
  const uiMinBuoi = _uiMinTietBuoi(opt);
  if(_uiMinTietBuoi(opt) <= 0) return false;

  const badCount = _countTrue(occ?.[gv]?.[thuBad]?.[buoiBad] || []);
  if(badCount >= limBuoi) return false; // không thiếu

  // cần ít nhất 1 tiết đang có trong buổi để kéo đôi qua sẽ đạt >=k (case 0 tiết thì kéo đôi vẫn <k)
  if(badCount <= 0 && limBuoi >= 3) return false;

  const freePairs = _findConsecutiveFreePairsForTeacher(occ, gv, thuBad, buoiBad);
  if(!freePairs.length) return false;

  const lessonsMap = opt?.__lessons;
  const lessonsOfGv = lessonsMap?.[gv] || [];

  // chọn buổi nguồn: count >= limBuoi + 2 (ví dụ k=3 => >=5)
  const sources = [];
  for(const thuSrc of DAYS){
    for(const buoiSrc of ["sang","chieu"]){
      if(String(thuSrc)===String(thuBad) && String(buoiSrc)===String(buoiBad)) continue;
      const c = _countTrue(occ?.[gv]?.[thuSrc]?.[buoiSrc] || []);
      if(c >= limBuoi + 2) sources.push({thu: thuSrc, buoi: buoiSrc, c});
    }
  }
  // ưu tiên buổi full 5 trước
  sources.sort((a,b)=>b.c-a.c);
  if(!sources.length) return false;

  // thử từng cặp trống ở buổi thiếu (ưu tiên tiết 1-2)
  for(const [tiA, tiB] of freePairs){
    // tìm một "tiết đôi" hợp lệ ở buổi nguồn
    for(const src of sources){
      const pairs = _findDoublePairsInSession(lessonsOfGv, src.thu, src.buoi);
      if(!pairs.length) continue;

      for(const p of pairs){
        // tránh tạo tiết lẻ ở buổi nguồn cho đúng môn+lớp này
        const totalSame = _countSamePairInSession(lessonsOfGv, src.thu, src.buoi, p.classId, p.mon);
        const remain = totalSame - 2;
        if(remain === 1) continue;

        const tkb = DATA.tkb?.[p.classId];
        if(!tkb) continue;
        const canon = getLopCanonById(p.classId);
        const roomName = getRoomForClassMon(canon, p.mon);

        // check nguồn còn đúng 2 ô đó và không fixed/off
        const srcArr = tkb?.[src.thu]?.[src.buoi];
        if(!Array.isArray(srcArr) || p.ti0<0 || p.ti1>=srcArr.length) continue;
        const vS0 = srcArr[p.ti0], vS1 = srcArr[p.ti1];
        if(vS0 === "OFF" || vS1 === "OFF" || isFixed(vS0) || isFixed(vS1)) continue;
        const mS0 = cellMon(vS0), mS1 = cellMon(vS1);
        if(mS0 !== p.mon || mS1 !== p.mon) continue;

        // destination must be empty in that class schedule at thuBad/buoiBad/tiA-tiB
        if(!_canMovePairIntoClassSession(tkb, p.classId, thuBad, buoiBad, tiA, p.mon, canon, roomOcc, roomName)) continue;

        // teacher must be free at destination (already by freePairs)
        if(occ?.[gv]?.[thuBad]?.[buoiBad]?.[tiA] || occ?.[gv]?.[thuBad]?.[buoiBad]?.[tiB]) continue;

        // apply: clear source, set dest
        tkb[src.thu][src.buoi][p.ti0] = "";
        tkb[src.thu][src.buoi][p.ti1] = "";
        tkb[thuBad][buoiBad][tiA] = p.mon;
        tkb[thuBad][buoiBad][tiB] = p.mon;
        return true;
      }
    }
  }
  return false;
}

function _tryImproveLessonAdv(one, occ, roomOcc, opt){
const kBuoi = Number(opt?.limitTietBuoi || 0);

function _guardNoNewBadSession(gv, thuFrom, buoiFrom, thuTo, buoiTo, k){
  if(k<=0) return true;
  const fromSlots = occ?.[gv]?.[thuFrom]?.[buoiFrom] || [];
  const toSlots   = occ?.[gv]?.[thuTo]?.[buoiTo] || [];
  const cFrom = _countTrue(fromSlots);
  const cTo   = _countTrue(toSlots);

  // (1) Không tạo buổi mới trong nhánh tối ưu này
  if(cTo === 0) return false;

  // (2) Không được làm buổi nguồn trở thành "xấu" 1-2 tiết
  // - Nếu buổi nguồn đang tốt (>=k): rút 1 không được thành (1..k-1)
  if(cFrom >= k){
    const after = cFrom - 1;
    if(after > 0 && after < k) return false;
    return true;
  }

  // - Nếu buổi nguồn đang xấu (1..k-1): chỉ cho phép rút nếu nó về 0 (xóa buổi xấu).
  //   Tránh trường hợp 2 -> 1 (gây ra 2-3-1), hoặc 1 -> 0 thì OK.
  if(cFrom > 0 && cFrom < k){
    const after = cFrom - 1;
    if(after !== 0) return false;
    return true;
  }

  return true;
}
  try{
    const gvA = (one?.teacher || "").toString().trim();
    const classId = (one?.classId || "").toString();
    const thu1 = String(one?.thu || "");
    const buoi1 = String(one?.buoi || "");
    const ti1 = Number(one?.ti);
    const mon1 = (one?.mon || "").toString().trim();

    
// Guard cứng: GV ít tiết đang gói gọn 1 buổi thì không xé ra (tránh 4->1-3, 5->2-3, 4->2-2...)
try{
  const Tt = _teacherTotalOccForTeacher(occ, one.teacher);
  const ss = _collectTeacherSessions(occ, one.teacher);
  const Ll = _teacherMaxSessionLen(occ, one.teacher);
  if(Tt > 0 && Tt <= Ll && ss.length === 1){
    return false;
  }
}catch(e){}
if(!gvA || !classId || !thu1 || !buoi1 || !Number.isFinite(ti1) || !mon1) return false;

    const tkb = DATA.tkb?.[classId];
    if(!tkb) return false;

    const arr1 = tkb?.[thu1]?.[buoi1];
    if(!Array.isArray(arr1) || !arr1.length) return false;
    const v1 = arr1[ti1];
    if(!v1 || v1 === "OFF" || isFixed(v1)) return false;
    if(cellMon(v1) !== mon1) return false;

    const canon = getLopCanonById(classId);
    const lim1 = _getGioihanForLopIdMon(classId, canon, mon1);
    const room1 = getRoomForClassMon(canon, mon1);

    const limBuoi = Number(opt?.limitTietBuoi || 0);
    const uiMinBuoi = _uiMinTietBuoi(opt);
    const guardMin = (uiMinBuoi > 0) ? uiMinBuoi : ((Number(opt?.limitTietTrong || 0) > 0) ? 2 : 0);

    // (NEW) Nếu buổi hiện tại của GV đang thiếu (<k), thử kéo 1 "tiết đôi" (2 tiết liền)
    // từ một buổi full (>=k+2, thường là 5) sang 2 ô trống liên tiếp của buổi thiếu.
    // Đây là bước "bổ sung" ưu tiên, giúp xử lý ca 1/2 tiết mà các buổi khác đã full,
    // đồng thời KHÔNG cắt tiết đôi.
    if(limBuoi > 0){
      const curCount = _countTrue(occ?.[gvA]?.[thu1]?.[buoi1] || []);
      if(curCount < limBuoi){
        if(_tryPullDoublePairToBadSession(gvA, thu1, buoi1, occ, roomOcc, opt)) return true;
      }
    }

    // Targets: chỉ xem những buổi mà GV A đã có tiết (để dồn), + cho phép cùng buổi để lấp trống
    const targets = [];
    for(const thu2 of DAYS){
      for(const buoi2 of ["sang","chieu"]){
        const c = _countTrue(occ?.[gvA]?.[thu2]?.[buoi2] || []);
        if(c >= 1) targets.push({thu:thu2, buoi:buoi2, c});
      }
    }
    if(!targets.length) return false;

    const srcSlots = occ?.[gvA]?.[thu1]?.[buoi1] || [];
    const srcHasGap = _teacherSessionMetrics(srcSlots).totalGaps > 0;

    targets.sort((a,b)=>{
      const aSame = (a.thu === thu1 && a.buoi === buoi1);
      const bSame = (b.thu === thu1 && b.buoi === buoi1);
      if(srcHasGap && aSame !== bSame) return aSame ? -1 : 1;
      if(!srcHasGap && aSame !== bSame) return aSame ? 1 : -1;

      if(limBuoi > 0 && !aSame && !bSame){
        const aPostGood = (a.c + 1) > limBuoi;
        const bPostGood = (b.c + 1) > limBuoi;
        if(aPostGood !== bPostGood) return aPostGood ? -1 : 1;
      }

      if(a.c !== b.c) return b.c - a.c;
      const da = DAYS.indexOf(a.thu) - DAYS.indexOf(b.thu);
      if(da) return da;
      return a.buoi.localeCompare(b.buoi);
    });

    let best = null;
    let bestDelta = 0;
    let bestBad = 0;

    function sessKey(thu, buoi){ return `${thu}|${buoi}`; }

    function scoreFor(teacher, thu, buoi, after, gvB, thu2, buoi2, ti2){
      const slots = _getSlotsFromOcc(occ, teacher, thu, buoi);
      if(after){
        // áp dụng biến đổi theo move/swap
        if(teacher === gvA){
          if(thu === thu1 && buoi === buoi1) slots[ti1] = false;
          if(thu === thu2 && buoi === buoi2) slots[ti2] = true;
        }
        if(gvB && teacher === gvB){
          if(thu === thu1 && buoi === buoi1) slots[ti1] = true;
          if(thu === thu2 && buoi === buoi2) slots[ti2] = false;
        }
      }
      {
      // kèm metadata để score có thể phạt "rải đều"
      const opt2 = (opt && opt.spreadWeight) ? Object.assign({}, opt, { __occGv: occ?.[teacher], __thu: thu }) : opt;
      return _scoreTeacherSessionAdv(slots, opt2);
    }
    }

    function calcDelta(gvB, thu2, buoi2, ti2){
      // GV A: 2 buổi (có thể trùng)
      const setA = new Map();
      setA.set(sessKey(thu1,buoi1), {thu:thu1, buoi:buoi1});
      setA.set(sessKey(thu2,buoi2), {thu:thu2, buoi:buoi2});
      let preA = 0, postA = 0;
      for(const s of setA.values()){
        preA += scoreFor(gvA, s.thu, s.buoi, false, gvB, thu2, buoi2, ti2);
        postA += scoreFor(gvA, s.thu, s.buoi, true, gvB, thu2, buoi2, ti2);
      }

      let preB = 0, postB = 0;
      if(gvB){
        const setB = new Map();
        setB.set(sessKey(thu1,buoi1), {thu:thu1, buoi:buoi1});
        setB.set(sessKey(thu2,buoi2), {thu:thu2, buoi:buoi2});
        for(const s of setB.values()){
          preB += scoreFor(gvB, s.thu, s.buoi, false, gvB, thu2, buoi2, ti2);
          postB += scoreFor(gvB, s.thu, s.buoi, true, gvB, thu2, buoi2, ti2);
        }
      }

      return (postA + postB) - (preA + preB);
    }

    function badFor(teacher, thu, buoi, after, gvB, thu2, buoi2, ti2){
      const slots = _getSlotsFromOcc(occ, teacher, thu, buoi);
      if(after){
        if(teacher === gvA){
          if(thu === thu1 && buoi === buoi1) slots[ti1] = false;
          if(thu === thu2 && buoi === buoi2) slots[ti2] = true;
        }
        if(gvB && teacher === gvB){
          if(thu === thu1 && buoi === buoi1) slots[ti1] = true;
          if(thu === thu2 && buoi === buoi2) slots[ti2] = false;
        }
      }
      return _sessionBadnessAdv(slots, opt);
    }

    function calcBadDelta(gvB, thu2, buoi2, ti2){
      // trả về mức CẢI THIỆN badness (dương là tốt)
      const setA = new Map();
      setA.set(sessKey(thu1,buoi1), {thu:thu1, buoi:buoi1});
      setA.set(sessKey(thu2,buoi2), {thu:thu2, buoi:buoi2});
      let preA = 0, postA = 0;
      for(const s of setA.values()){
        preA  += badFor(gvA, s.thu, s.buoi, false, gvB, thu2, buoi2, ti2);
        postA += badFor(gvA, s.thu, s.buoi, true,  gvB, thu2, buoi2, ti2);
      }

      let preB = 0, postB = 0;
      if(gvB){
        const setB = new Map();
        setB.set(sessKey(thu1,buoi1), {thu:thu1, buoi:buoi1});
        setB.set(sessKey(thu2,buoi2), {thu:thu2, buoi:buoi2});
        for(const s of setB.values()){
          preB  += badFor(gvB, s.thu, s.buoi, false, gvB, thu2, buoi2, ti2);
          postB += badFor(gvB, s.thu, s.buoi, true,  gvB, thu2, buoi2, ti2);
        }
      }

      const pre = preA + preB;
      const post = postA + postB;
      return pre - post;
    }


    for(const t of targets){
      const thu2 = t.thu;
      const buoi2 = t.buoi;
      const arr2 = tkb?.[thu2]?.[buoi2];
      if(!Array.isArray(arr2) || !arr2.length) continue;

      for(let ti2=0; ti2<arr2.length; ti2++){
        if(thu2 === thu1 && buoi2 === buoi1 && ti2 === ti1) continue;

        const v2 = arr2[ti2];
        if(v2 === "OFF" || isFixed(v2)) continue;

        const mon2 = cellMon(v2);
        if(mon2 && mon2 === mon1) continue;

        // GV A không được trùng tại ô đích (toàn trường)
        if(occ?.[gvA]?.[thu2]?.[buoi2]?.[ti2]) continue;
        if(room1 && _roomConflictQuick(roomOcc, room1, thu2, buoi2, ti2, classId)) continue;

        // ==== MOVE (ô đích rỗng) ====
        if(!mon2){
          if(guardMin > 0 && !(thu2 === thu1 && buoi2 === buoi1)){
            if(!_guardNoNewBadSession(gvA, thu1, buoi1, thu2, buoi2, guardMin)) continue;
          }

          // validate môn trong buổi (gioihan/không tách rời)
          if(thu2 === thu1 && buoi2 === buoi1){
            const copy = arr1.slice();
            copy[ti1] = "";
            copy[ti2] = mon1;
            if(!_validateSubjectInSession(copy, mon1, lim1)) continue;
          } else {
            const copy1 = arr1.slice();
            const copy2 = arr2.slice();
            copy1[ti1] = "";
            copy2[ti2] = mon1;
            if(!_validateSubjectInSession(copy1, mon1, lim1)) continue;
            if(!_validateSubjectInSession(copy2, mon1, lim1)) continue;
          }

          const delta = calcDelta("", thu2, buoi2, ti2);
          const badImp = (opt && opt.hardTrong) ? calcBadDelta("", thu2, buoi2, ti2) : 0;
          if((opt && opt.hardTrong) ? (badImp > bestBad || (badImp === bestBad && delta > bestDelta)) : (delta > bestDelta)){
            bestDelta = delta;
bestBad = badImp;
            best = {type:"move", thu2, buoi2, ti2};
          }
          continue;
        }

        // ==== SWAP (đổi với môn khác) ====
        const gvB = getTeacherForClassMon(canon, mon2);
        if(!gvB || gvB === gvA) continue;

        // GV B phải rảnh tại ô nguồn
        if(occ?.[gvB]?.[thu1]?.[buoi1]?.[ti1]) continue;

        const lim2 = _getGioihanForLopIdMon(classId, canon, mon2);
        const room2 = getRoomForClassMon(canon, mon2);
        if(room2 && _roomConflictQuick(roomOcc, room2, thu1, buoi1, ti1, classId)) continue;

        if(guardMin > 0 && !(thu2 === thu1 && buoi2 === buoi1)){
          if(!_guardNoNewBadSession(gvA, thu1, buoi1, thu2, buoi2, guardMin)) continue;
          if(!_guardNoNewBadSession(gvB, thu2, buoi2, thu1, buoi1, guardMin)) continue;
        }

        // validate môn trong buổi (gioihan/không tách rời)
        if(thu2 === thu1 && buoi2 === buoi1){
          const copy = arr1.slice();
          copy[ti1] = mon2;
          copy[ti2] = mon1;
          if(!_validateSubjectInSession(copy, mon1, lim1)) continue;
          if(!_validateSubjectInSession(copy, mon2, lim2)) continue;
        } else {
          const copy1 = arr1.slice();
          const copy2 = arr2.slice();
          copy1[ti1] = mon2;
          copy2[ti2] = mon1;
          if(!_validateSubjectInSession(copy1, mon1, lim1)) continue;
          if(!_validateSubjectInSession(copy1, mon2, lim2)) continue;
          if(!_validateSubjectInSession(copy2, mon1, lim1)) continue;
          if(!_validateSubjectInSession(copy2, mon2, lim2)) continue;
        }

        const delta = calcDelta(gvB, thu2, buoi2, ti2);
        const badImp = (opt && opt.hardTrong) ? calcBadDelta(gvB, thu2, buoi2, ti2) : 0;
        if((opt && opt.hardTrong) ? (badImp > bestBad || (badImp === bestBad && delta > bestDelta)) : (delta > bestDelta)){
          bestDelta = delta;
best = {type:"swap", thu2, buoi2, ti2, gvB, mon2};
        }
      }
    }

    if(!best || (bestDelta <= 0 && !(opt && opt.hardTrong && bestBad > 0))) return false;

    // Apply best move/swap
    if(best.type === "move"){
      tkb[thu1][buoi1][ti1] = "";
      tkb[best.thu2][best.buoi2][best.ti2] = mon1;
    } else {
      tkb[thu1][buoi1][ti1] = best.mon2;
      tkb[best.thu2][best.buoi2][best.ti2] = mon1;
    }
    return true;
  }catch(e){
    return false;
  }
}

function optimizeTeacherScheduleQualityAdvanced(opts={}){
  const limitTietBuoi = Number(opts.limitTietBuoi ?? 1);
  const limitTietTrong = Number(opts.limitTietTrong ?? 2);
  const scopeClassId = (opts.scopeClassId ?? "").toString();

  const maxSwaps = Number(opts.maxSwaps ?? 120);
  const maxIters = Number(opts.maxIters ?? 600);
  // (NEW) Giới hạn thời gian cho 1 "batch" tối ưu (ms). Dùng để tránh block UI.
  // Nếu =0 hoặc không truyền -> chạy theo maxIters/maxSwaps như cũ.
  const timeBudgetMs = Math.max(0, Number(opts.timeBudgetMs ?? 0));
  const t0 = timeBudgetMs > 0 ? Date.now() : 0;
  let swaps = 0;

  const opt = {limitTietBuoi, limitTietTrong};
  // Hard mode cho tiêu chí tiết trống: ưu tiên giảm lỗi (>=2 với chọn 2, >0 với chọn 1)
  if(limitTietTrong > 0) opt.hardTrong = (opts.hardTrong !== false);

  for(let iter=0; iter<maxIters; iter++){
    if(timeBudgetMs > 0 && (Date.now() - t0) >= timeBudgetMs) break;
    if(swaps >= maxSwaps) break;
    // allow panel stop
    try{ if(__OPT_PANEL_STATE?.cancel) break; }catch(_){ }

    const built = _buildTeacherOccAll();
    const occ = built.occ;
    const lessons = built.lessons;
    const roomOcc = built.roomOcc;
    // Pass lessons into lower-level improvement so we can "kéo tiết đôi" (2 tiết liền)
    // khi gặp buổi thiếu nhưng có buổi full 5.
    opt.__lessons = lessons;
    // HARD-LOCK: khoá GV đạt phân phối target trước khi tối ưu
    if(typeof _buildLockedTeachersByTarget === 'function'){
      _buildLockedTeachersByTarget(opt, lessons, occ);
    }

// (LOCK) Khóa GV đã đạt lịch hợp lý (Smin+pattern) và GV ít tiết gói 1 buổi để tránh bị xé khi tối ưu tiết trống.
if(typeof _computeLockedTeachers==='function'){
      const oldLock = _computeLockedTeachers(occ, limitTietBuoi);
      if(oldLock && oldLock.size){
        if(!opt.lockedTeachers) opt.lockedTeachers = new Set();
        for(const t of oldLock) opt.lockedTeachers.add(t);
      }
    }
let cand = _findBadSessionLessonsAdv(occ, lessons, opt);
    if(scopeClassId) cand = cand.filter(x => String(x.classId) === String(scopeClassId));
    if(opt.lockedTeachers && opt.lockedTeachers.size) cand = cand.filter(x => !opt.lockedTeachers.has(_normTeacher(x.teacher)));
    if(!cand.length) break;

    let improved = false;
    for(const one of cand){
      try{ if(__OPT_PANEL_STATE?.cancel) break; }catch(_){ }
      if(_tryImproveLessonAdv(one, occ, roomOcc, opt)){
        swaps++;
        improved = true;
        break; // rebuild occ rồi tiếp tục
      }
    }
    if(!improved) break;
  }

  return swaps;
}

/* ===== MOVED SECTION: auto_sort_all (from phanmon.js:91534-94192) ===== */

/* ======================= SẮP XẾP TỰ ĐỘNG (TẤT CẢ LỚP) =======================
   - Không xóa các tiết đã xếp
   - Bổ sung các tiết còn thiếu theo Tiết chuẩn + config OFF/cố định
*/
async function sapXepTuDongAll(){
  const lopsAuto = (DATA.lop||[]);
  if(!lopsAuto.length){
    alert("Chưa có lớp.");
    return;
  }
  if(!confirm("Sắp xếp tự động sẽ BỔ SUNG các tiết còn thiếu vào TKB của TẤT CẢ lớp (không xóa các tiết đã xếp). Tiếp tục?")) return;
  try{ setAutoSortProgress(0, "Bắt đầu"); }catch(_){}
  try{ _setStatus("Đang sắp xếp tự động...", "info"); }catch(_){}
  try{ await _autoSortProgressYield(); }catch(_){}

  const countAssigned = (tkb)=>{
    let c=0;
    for(const d of DAYS){
      for(const buoi of ["sang","chieu"]){
        (tkb?.[d]?.[buoi]||[]).forEach(v=>{ if(cellMon(v)) c++; });
      }
    }
    return c;
  };

  let changed = 0;
  for(let autoIdx=0; autoIdx<lopsAuto.length; autoIdx++){
    const l = lopsAuto[autoIdx];
    const classId = l.id;
    const lopCanon = getLopCanonById(classId);
    const khoiNum = extractKhoiNumber(l?.khoi) || extractKhoiNumber(l?.ten2) || extractKhoiNumber(l?.ten) || "";
    const className = (l?.ten2 || l?.ten || classId || "").toString();
    const basePct = Math.round((autoIdx / Math.max(1, lopsAuto.length)) * 84);
    try{ setAutoSortProgress(basePct, `Đang xếp ${autoIdx + 1}/${lopsAuto.length}: ${className}`); }catch(_){}
    try{ await _autoSortProgressYield(); }catch(_){}

    // Danh sách môn theo Tiết chuẩn + override từ Phân công (và lọc môn chưa có GV)
    const mons = computeMonsForClass(khoiNum, lopCanon);

    if(!DATA.tkb[classId]){
      // tạo khung trống + áp config OFF/cố định
      DATA.tkb[classId] = (typeof window.__tkbMakeEmptyTKBPreservingOff === "function")
        ? window.__tkbMakeEmptyTKBPreservingOff(classId, DATA.tkbConfig)
        : taoTKBTheoConfig([], DATA.tkbConfig);
    }

    const before = countAssigned(DATA.tkb[classId]);
    // Bổ sung, nhưng không đặt vào ô gây trùng lịch GV/Phòng
    const extraCanPlaceCell = (thu, buoi, tietIdx, monName)=>{
      const gv = getTeacherForClassMon(lopCanon, monName);
      if(gv){
        const c = findTeacherConflictAtSlot(gv, thu, buoi, tietIdx, classId);
        if(c) return false;
      }
      const room = getRoomForClassMon(lopCanon, monName);
      if(room){
        const r = findRoomConflictAtSlot(room, thu, buoi, tietIdx, classId);
        if(r) return false;
      }
      return true;
    };

    // Ưu tiên xếp để TKB giáo viên đẹp hơn (hạn chế 1 tiết/buổi, hạn chế khoảng trống lớn)
    const extraScoreBlock = makeExtraScoreBlockForTeacherQualityAndSpread(classId, lopCanon);

    DATA.tkb[classId] = taoTKBBoSungTheoConfig(
      DATA.tkb[classId],
      mons,
      DATA.tkbConfig,
      extraCanPlaceCell,
      extraScoreBlock
    );
    const after = countAssigned(DATA.tkb[classId]);
    if(after > before) changed++;
    const pct = Math.round(((autoIdx + 1) / Math.max(1, lopsAuto.length)) * 84);
    try{ setAutoSortProgress(pct, `Đã xếp ${autoIdx + 1}/${lopsAuto.length}`); }catch(_){}
    try{ await _autoSortProgressYield(); }catch(_){}
  }

  // Hậu xử lý: cố gắng làm TKB giáo viên "đẹp" hơn (giảm 1 tiết/buổi, giảm khoảng trống)
  try{ setAutoSortProgress(88, "Đang tối ưu giáo viên"); }catch(_){}
  try{ await _autoSortProgressYield(); }catch(_){}
  const optimizedSwaps = optimizeTeacherScheduleQualityAdvanced({
    limitTietBuoi: 2,
    limitTietTrong: 2,
    maxSwaps: 80,
    maxIters: 250
  });

  try{ setAutoSortProgress(96, "Đang lưu"); }catch(_){}
  try{ await _autoSortProgressYield(); }catch(_){}
  try{
    saveStore();
    renderCurrentView();
    loadMonList();
  }catch(e){
    console.error('Render/save after optimize failed:', e);
  }
  try{ finishAutoSortProgress("Hoàn tất"); }catch(_){}
  try{ _setStatus(`Đã xếp bổ sung cho ${changed} lớp. Tối ưu giáo viên: ${optimizedSwaps} lượt.`, "ok"); }catch(_){}
  try{ await _autoSortProgressYield(); }catch(_){}
  alert(`✔ Đã xếp bổ sung cho ${changed} lớp. (Tối ưu giáo viên: ${optimizedSwaps} lượt)`);
}

/* ===== MOVED SECTION: xep_lai (from phanmon.js:143276-144706) ===== */

/* ======================= XẾP LẠI ======================= */
function _makeSeededRandom(seed){
  let s = (Number(seed) || Date.now()) >>> 0;
  return function(){
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function _shuffleArrayCopy(arr, rng){
  const out = Array.isArray(arr) ? arr.slice() : [];
  const rand = (typeof rng === "function") ? rng : Math.random;
  for(let i=out.length-1; i>0; i--){
    const j = Math.floor(rand() * (i + 1));
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}

function _stableRandomPlacementScore(seed, thu, buoi, startIdx, monName, len){
  const raw = `${seed}|${thu}|${buoi}|${startIdx}|${monName}|${len}`;
  let h = 2166136261 >>> 0;
  for(let i=0;i<raw.length;i++){
    h ^= raw.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return (h / 4294967296) - 0.5; // [-0.5, 0.5)
}

function xepLaiLop(){
  if(!currentLop){
    alert("Chưa chọn lớp");
    return;
  }
  if(!confirm("Xếp lại sẽ xóa các tiết đã xếp của lớp này nhưng giữ nguyên tiết NGHỈ. Tiếp tục?")) return;

  const lop = (DATA.lop||[]).find(x=>x.id==currentLop);
  const lopKhoiNum = extractKhoiNumber(lop?.khoi);
  const lopCanon = getLopCanonById(currentLop);
  const seed = Date.now() ^ Math.floor(Math.random() * 0x7fffffff);
  const rng = _makeSeededRandom(seed);
  const mons = _shuffleArrayCopy(buildMonsForKhoi(lopKhoiNum, lopCanon), rng);

  // Xếp lại nhưng giữ nguyên các tiết nghỉ người dùng đã khóa.
  const empty = (typeof window.__tkbMakeEmptyTKBPreservingOff === "function")
    ? window.__tkbMakeEmptyTKBPreservingOff(currentLop, DATA.tkbConfig)
    : taoTKBTheoConfig([], DATA.tkbConfig);
  const extraCanPlaceCell = (thu, buoi, tietIdx, monName)=>{
    const gv = getTeacherForClassMon(lopCanon, monName);
    if(gv){
      const c = findTeacherConflictAtSlot(gv, thu, buoi, tietIdx, currentLop);
      if(c) return false;
    }
    const room = getRoomForClassMon(lopCanon, monName);
    if(room){
      const r = findRoomConflictAtSlot(room, thu, buoi, tietIdx, currentLop);
      if(r) return false;
    }
    return true;
  };
  const baseExtraScoreBlock = makeExtraScoreBlockForTeacherQualityAndSpread(currentLop, lopCanon);
  const extraScoreBlock = function(localTkb, thu, buoi, startIdx, monName, len){
    let score = 0;
    try{
      score = Number(baseExtraScoreBlock(localTkb, thu, buoi, startIdx, monName, len) || 0);
    }catch(e){ score = 0; }
    // Thêm nhiễu ngẫu nhiên theo seed của lần xếp lại để tránh hội tụ về cùng một lịch.
    // Biên độ đủ lớn để phá tie/tie-near-tie nhưng không đổi mọi ràng buộc cứng.
    score += _stableRandomPlacementScore(seed, thu, buoi, startIdx, monName, len) * 120;
    return score;
  };
  DATA.tkb[currentLop] = taoTKBBoSungTheoConfig(empty, mons, DATA.tkbConfig, extraCanPlaceCell, extraScoreBlock);
  try{ window.__LAST_XEPLAI_RANDOM_SEED = seed; }catch(e){}
  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }
}

/* ===== MOVED SECTION: panel_and_constraints (from phanmon.js:144706-182829) ===== */

/* ======================= PANEL TỐI ƯU ======================= */
// Trạng thái tối ưu để:
// - chạy theo thời gian giới hạn
// - cập nhật progress bar
// - cho phép dừng
let __OPT_PANEL_STATE = { running: false, cancel: false };

function _fmtMsAsMMSS(ms){
  ms = Math.max(0, Number(ms || 0));
  const sec = Math.floor(ms / 1000);
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
}

function _setOptProgressUI(p){
  const wrap = document.getElementById("optProgressWrap");
  if(!wrap) return;
  wrap.style.display = "block";

  const pct = Math.max(0, Math.min(100, Number(p?.percent ?? 0)));
  const elPct = document.getElementById("optProgressPct");
  const elFill = document.getElementById("optProgressFill");
  const elTime = document.getElementById("optProgressTime");
  const elDetail = document.getElementById("optProgressDetail");
  const elNote = document.getElementById("optProgressNote");

    const reached = !!p?.reached;
  const pctShow = reached ? 100 : Math.min(99, Math.floor(pct));
  if(elPct) elPct.textContent = `${pctShow}%`;
  if(elFill) elFill.style.width = `${pct}%`;

  const elapsed = Math.max(0, Number(p?.elapsedMs ?? 0));
  const total = Math.max(1, Number(p?.totalMs ?? 1));
  const remain = Math.max(0, total - elapsed);
  try{ __OPT_PANEL_STATE.remainingMs = remain; __OPT_PANEL_STATE.totalMs = total; }catch(e){}
  // Theo yêu cầu: đồng hồ ĐẾM NGƯỢC khi đang tối ưu
  if(elTime) elTime.textContent = `Còn lại ${_fmtMsAsMMSS(remain)} (tổng ${_fmtMsAsMMSS(total)})`;

  const moved = Number(p?.swaps ?? 0);
  const showBuoi = (p?.showBuoi === undefined) ? true : !!p.showBuoi;
  const showTrong = (p?.showTrong === undefined) ? true : !!p.showTrong;

  const nSessions = Number(p?.nSessions ?? 0);
  const totalTiet = Number(p?.totalTiet ?? 0);
  const badTietBuoi = Number(p?.badTietBuoi ?? 0);
  const badTietTrong = Number(p?.badTietTrong ?? 0);
  const totalSpan = Number(p?.totalSpan ?? 0);
  const limBuoi = Number(p?.limitTietBuoi ?? 0);
  const limTrong = Number(p?.limitTietTrong ?? 0);

  if(elDetail){
    const parts = [];
    if(Number.isFinite(nSessions) && nSessions>0) parts.push(`xét ${nSessions} buổi`);
    if(Number.isFinite(totalTiet) && totalTiet>0) parts.push(`tổng tiết xét: ${totalTiet}`);
    if(showBuoi && limBuoi>0){
      parts.push(`tiết/buổi vi phạm (<min): ${badTietBuoi}/${Math.max(1,totalTiet)}`);
    }
    if(showTrong && limTrong>0){
      const den = (totalSpan>0) ? totalSpan : "?";
      // Điều kiện dạng "gaps < limit" => vi phạm khi gaps >= limit
      parts.push(`trống vi phạm(>=${limTrong}): ${badTietTrong}/${den}`);
    }
    parts.push(`hoán đổi: ${moved}`);
    elDetail.textContent = `• ${parts.join(" • ")}`;
  }

  if(elNote){
    elNote.textContent = "Lưu ý: GV ≤5 tiết/tuần hoặc đã đạt phân phối tối ưu theo tổng tiết (dư 1/2/3 -> 3-3, 4-3, 4-4...) KHÔNG ảnh hưởng % tiến trình.";
  }

  if(elNote && p?.note != null) elNote.textContent = String(p.note);
}

// Tiến trình tối ưu theo "mức đạt yêu cầu" (không phải % chạy).
// - Nếu bật hạn chế tiết/buổi: % = 100 * (1 - (tổng "tiết lẻ" / tổng tiết xét))
//   Ví dụ: có 5 tiết lẻ trên tổng 100 tiết => đạt 95%.
// - Nếu KHÔNG bật tiết/buổi mà chỉ bật tiết trống: % dựa theo "tiết trống dư" trên tổng span (từ tiết đầu đến tiết cuối trong buổi).
// - Đạt 100% (theo tiêu chí chính) thì dừng tối ưu.
function _calcOptimizeCompliance(opt){
  // % tiến trình theo yêu cầu (CHỈ theo 2 checkbox):
  // 1) Tiết/buổi: phạt khi trong 1 buổi GV có dạy nhưng < effMinBuoi.
  //    UI mức "1" nghĩa là "không có 1 tiết/buổi" => effMin thường là 2 (theo mapping hiện tại).
  // 2) Tiết trống/buổi: phạt khi maxGap LIÊN TIẾP vượt ngưỡng (mức 2 => maxGap <= 1).
  // KHÔNG tính "lệch target 5-5-4-4..." vào % này.

  const uiMinBuoi = _uiMinTietBuoi(opt);
  let limitTietTrong = Number(opt?.limitTietTrong || 0);
  if(limitTietTrong > 2) limitTietTrong = 2;

  const built = _buildTeacherOccAll();
  const occ = built.occ || {};
  const lessons = built.lessons || {};

  let allowedMaxGap = Infinity;
  if(limitTietTrong === 1) allowedMaxGap = 0;
  else if(limitTietTrong === 2) allowedMaxGap = 1;

  let totalTietAll = 0;

  // Tiết/buổi
  let totalTietForBuoi = 0;
  let badTietBuoi = 0;
  let badBuoiSessions = 0;

  // Tiết trống (maxGap)
  let totalSpan = 0;      // tổng độ dài span (từ tiết đầu -> tiết cuối) của các buổi có dạy
  let badTietTrong = 0;   // tổng "excess maxGap"
  let badTrongSessions = 0;

  let nSessions = 0;
  let skippedTeachers = 0;
  let skippedTiet = 0;

  function _iterTeacherSessions(gv, cb){
    const byDay = occ?.[gv] || {};
    for(const dayKey of Object.keys(byDay)){
      const byBuoi = byDay[dayKey] || {};
      for(const buoiKey of Object.keys(byBuoi)){
        cb(dayKey, buoiKey, byBuoi[buoiKey] || []);
      }
    }
  }

  function _totalOccForTeacher(gv){
    let t = 0;
    _iterTeacherSessions(gv, (_d,_b,slots)=>{ t += _countTrue(slots||[]); });
    return t;
  }

  for(const gv of Object.keys(occ)){
    const totalGV = _totalOccForTeacher(gv);
    totalTietAll += totalGV;

    const effMinBuoi = _effectiveMinTietBuoiForTeacher(opt, gv, lessons);
    const skipBuoiForGV = (effMinBuoi <= 0);
    if(skipBuoiForGV){
      skippedTeachers++;
      skippedTiet += totalGV;
    }

    _iterTeacherSessions(gv, (_day,_buoi,slots)=>{
      const mm = _teacherSessionMetrics(slots||[]);
      if(mm.count === 0) return;
      nSessions++;

      // Tiết/buổi
      if(uiMinBuoi > 0 && !skipBuoiForGV){
        totalTietForBuoi += mm.count;
        if(mm.count < effMinBuoi){
          badTietBuoi += mm.count;
          badBuoiSessions += 1;
        }
      }

      // Tiết trống (maxGap)
      if(limitTietTrong > 0 && Number.isFinite(allowedMaxGap)){
        const spanLen = (mm.pos && mm.pos.length) ? (mm.pos[mm.pos.length-1] - mm.pos[0] + 1) : 0;
        if(spanLen > 0) totalSpan += spanLen;
        const excess = Math.max(0, (mm.maxGap || 0) - allowedMaxGap);
        if(excess > 0){
          badTrongSessions += 1;
          badTietTrong += excess;
        }
      }
    });
  }

  let percentBuoi = 100;
  if(uiMinBuoi > 0 && totalTietForBuoi > 0){
    percentBuoi = Math.max(0, Math.min(100, 100 * (1 - (badTietBuoi / totalTietForBuoi))));
  }

  let percentTrong = 100;
  if(limitTietTrong > 0 && totalSpan > 0){
    percentTrong = Math.max(0, Math.min(100, 100 * (1 - (badTietTrong / totalSpan))));
  }

  const enableBuoi = (uiMinBuoi > 0);
  const enableTrong = (limitTietTrong > 0);

  let percent = 100;
  if(enableBuoi && enableTrong) percent = Math.min(percentBuoi, percentTrong);
  else if(enableBuoi) percent = percentBuoi;
  else if(enableTrong) percent = percentTrong;

  const reachedBuoi = (percentBuoi >= 99.999);
  const reachedTrong = (percentTrong >= 99.999);
  const reached = (percent >= 99.999);


// Normalize: nếu không có vi phạm nào thì coi như đạt 100% (tránh sai số/rounding UI)
if(badTietBuoi === 0 && badTietTrong === 0){
  percentBuoi = 100;
  percentTrong = 100;
  percent = 100;
}

  let totalTiet = totalTietForBuoi;
  if(enableBuoi && enableTrong){
    totalTiet = (percentBuoi <= percentTrong) ? totalTietForBuoi : totalSpan;
  }else if(enableTrong && !enableBuoi){
    totalTiet = totalSpan;
  }

  // debug hook: xem ngay tiêu chí nào đang kéo % xuống
  try{
    window.__lastOptCompliance = {
      percent, percentBuoi, percentTrong,
      badTietBuoi, totalTietForBuoi, badBuoiSessions,
      badTietTrong, totalSpan, badTrongSessions,
      uiMinBuoi, limitTietTrong, allowedMaxGap
    };
  }catch(e){}

  return {
    percent,
    reached,
    percentBuoi,
    reachedBuoi,
    percentTrong,
    reachedTrong,
    nSessions,
    totalTiet,
    totalTietAll,
    totalSpan,
    badTietBuoi,
    badBuoiSessions,
    badTietTrong,
    badTrongSessions,
    skippedTeachers,
    skippedTiet,
    allowedMaxGap,
    uiMinBuoi,
    limitTietTrong
  };
}


const __OPT_MODE_META = {
  buoi1: {
    mode: "buoi1",
    limitTietBuoi: 2,
    limitTietTrong: 0,
    showBuoi: true,
    showTrong: false,
    shortLabel: "1 tiết/1 buổi"
  },
  trong2: {
    mode: "trong2",
    limitTietBuoi: 0,
    limitTietTrong: 2,
    showBuoi: false,
    showTrong: true,
    shortLabel: "2 tiết trống"
  },
  trong1: {
    mode: "trong1",
    limitTietBuoi: 0,
    limitTietTrong: 1,
    showBuoi: false,
    showTrong: true,
    shortLabel: "1 tiết trống"
  }
};

function _getOptModeMeta(mode){
  return __OPT_MODE_META[String(mode || "").trim()] || __OPT_MODE_META.buoi1;
}

function _getSelectedOptimizeMode(){
  const sel = document.querySelector('input[name="optMode"]:checked');
  return sel ? String(sel.value || "").trim() : "buoi1";
}

function _optModeLabelFromLimits(limitTietBuoi, limitTietTrong){
  if(Number(limitTietBuoi || 0) >= 2) return __OPT_MODE_META.buoi1.shortLabel;
  if(Number(limitTietTrong || 0) === 1) return __OPT_MODE_META.trong1.shortLabel;
  if(Number(limitTietTrong || 0) === 2) return __OPT_MODE_META.trong2.shortLabel;
  return "tùy chọn hiện tại";
}

function toggleOptPart(){
  const radios = Array.from(document.querySelectorAll('input[name="optMode"]'));
  if(radios.length && !radios.some(r => r.checked)) radios[0].checked = true;

  for(const box of document.querySelectorAll('[data-opt-choice]')){
    const id = box.getAttribute('data-opt-choice');
    const checked = !!document.getElementById(id)?.checked;
    box.style.borderColor = checked ? '#295bff' : '#dfe6f7';
    box.style.background = checked ? '#f4f7ff' : '#fff';
  }
}

function openTuyChinh(){
  if(document.getElementById("tkbConfigOverlay")) return;

  const overlay = document.createElement("div");
  overlay.id = "tkbConfigOverlay";


// Inline styles to avoid CSS load/order issues (prevents popup from sticking to bottom-left)
overlay.style.position = "fixed";
overlay.style.left = "0";
overlay.style.top = "0";
overlay.style.right = "0";
overlay.style.bottom = "0";
overlay.style.inset = "0";
overlay.style.background = "rgba(0,0,0,.4)";
overlay.style.display = "flex";
overlay.style.alignItems = "center";
overlay.style.justifyContent = "center";
overlay.style.zIndex = "999999";

  overlay.innerHTML = `
    <div class="tkb-config-popup">
      <div style="font-weight:700;margin-bottom:10px">Tùy chọn tối ưu</div>

      <div style="display:grid;gap:10px;margin:8px 0 12px 0">
        <label data-opt-choice="optModeBuoi1" style="display:flex;align-items:flex-start;gap:10px;padding:10px;border:1px solid #dfe6f7;border-radius:10px;cursor:pointer">
          <input type="radio" name="optMode" id="optModeBuoi1" value="buoi1" checked onchange="toggleOptPart()" style="margin-top:3px">
          <div>
            <div style="font-weight:700">1. Tối ưu hạn chế 1 tiết/1 buổi</div>
            <div style="font-size:12px;color:#555;line-height:1.45;margin-top:4px">
              Chỉ xử lý trên các buổi đã có tiết. Ưu tiên lấy tiết từ buổi có 2 tiết trước, rồi 3 tiết... để ghép cho buổi đang có 1 tiết; không tạo thêm buổi mới chưa có tiết dạy.
            </div>
          </div>
        </label>

        <label data-opt-choice="optModeTrong2" style="display:flex;align-items:flex-start;gap:10px;padding:10px;border:1px solid #dfe6f7;border-radius:10px;cursor:pointer">
          <input type="radio" name="optMode" id="optModeTrong2" value="trong2" onchange="toggleOptPart()" style="margin-top:3px">
          <div>
            <div style="font-weight:700">2. Tối ưu hạn chế 2 tiết trống</div>
            <div style="font-size:12px;color:#555;line-height:1.45;margin-top:4px">
              Xóa các buổi có khoảng trống 2 tiết trong cùng buổi. Có thể đảo vị trí giữa những buổi đã có tiết để xử lý nhanh, nhưng không được làm phát sinh buổi mới hoặc buổi chỉ còn 1 tiết.
            </div>
          </div>
        </label>

        <label data-opt-choice="optModeTrong1" style="display:flex;align-items:flex-start;gap:10px;padding:10px;border:1px solid #dfe6f7;border-radius:10px;cursor:pointer">
          <input type="radio" name="optMode" id="optModeTrong1" value="trong1" onchange="toggleOptPart()" style="margin-top:3px">
          <div>
            <div style="font-weight:700">3. Tối ưu hạn chế 1 tiết trống</div>
            <div style="font-size:12px;color:#555;line-height:1.45;margin-top:4px">
              Xóa các buổi có khoảng trống 1 tiết trong cùng buổi. Chỉ đảo vị trí trong các buổi đang có tiết để gom lại cho đẹp hơn và vẫn tránh tình trạng còn 1 tiết trong buổi.
            </div>
          </div>
        </label>
      </div>

      <div style="display:flex;align-items:center;gap:10px;margin:10px 0;flex-wrap:wrap">
        <label style="white-space:nowrap">Thời gian</label>
        <input id="optTimeLimitMin" type="number" min="0.1" step="0.1" value="2" style="width:90px">
        <span>phút</span>
      </div>

      <div id="optProgressWrap" style="display:none;margin-top:12px">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:12px">
          <div style="font-size:12px;color:#555">Tiến trình theo yêu cầu</div>
          <div id="optProgressPct" style="font-weight:800">0%</div>
        </div>
        <div style="height:10px;background:#e9eef8;border-radius:999px;overflow:hidden;margin-top:6px">
          <div id="optProgressFill" style="height:100%;width:0%;background:#295bff"></div>
        </div>
        <div id="optProgressDetail" style="font-size:12px;color:#555;margin-top:6px"></div>
        <div id="optProgressTime" style="font-size:12px;color:#777;margin-top:4px"></div>
        <div id="optProgressNote" style="font-size:12px;color:#a8071a;margin-top:6px"></div>
      </div>

      <div class="footer">
      <div id="optProblemsWrap" style="display:none;margin-top:10px;padding:10px;border:1px solid #eee;border-radius:10px;background:#fafafa;max-height:240px;overflow:auto">
        <div id="optProblemsTitle" style="font-weight:700;margin-bottom:6px"></div>
        <div id="optProblemsBody" style="font-size:12px;white-space:pre-wrap;line-height:1.35"></div>
      </div>

      <div class="footer">
        <button id="btnRunOptimize" class="primary" onclick="runOptimizeFromPanel()">Chạy tối ưu</button>
        <button id="btnContinueOptimize" class="primary" style="display:none" onclick="continueOptimizeFromPanel()">Tối ưu tiếp</button>
        <button id="btnStopOptimize" class="danger" style="display:none" onclick="stopOptimize()">Dừng</button>
        <button id="btnCloseOptimize" onclick="closePanel()">Đóng</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);


// Ensure popup has sane styling even if CSS missing
const pop = overlay.querySelector(".tkb-config-popup");
if(pop){
  pop.style.background = "#fff";
  pop.style.padding = "16px";
  pop.style.width = "560px";
  pop.style.maxWidth = "96vw";
  pop.style.borderRadius = "8px";
  pop.style.boxShadow = "0 10px 30px rgba(0,0,0,.2)";
  pop.style.maxHeight = "85vh";
  pop.style.overflow = "auto";
}

  toggleOptPart();
}

function stopOptimize(){
  __OPT_PANEL_STATE.cancel = true;
  try{
    const btnStop = document.getElementById("btnStopOptimize");
    if(btnStop) btnStop.disabled = true;
    const elNote = document.getElementById("optProgressNote");
    if(elNote) elNote.textContent = "Đang dừng...";
  }catch(_){ }
}


function _listOptimizeProblems(limitTietBuoi){
  const k = Number(limitTietBuoi || 0);
  const built = _buildTeacherOccAll();
  const occ = built.occ || {};
  const lessons = built.lessons || {};
  const out = [];

  // helper: tổng tiết/tuần theo occ (tính cả fixed)
  function _totalOccForTeacher(gv){
    let t = 0;
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        t += _countTrue(occ?.[gv]?.[thu]?.[buoi] || []);
      }
    }
    return t;
  }

  // Liệt kê THÔNG TIN: GV ít tiết hoặc không đủ min UI (không tính %)
  const lowHour = [];
  if(k > 0){
    for(const gv of Object.keys(occ)){
      const total = _totalOccForTeacher(gv);
      if(total > 0 && total < k){
        lowHour.push({gv, total});
      }
    }
    lowHour.sort((a,b)=>a.total-b.total || String(a.gv).localeCompare(String(b.gv)));
    if(lowHour.length){
      out.push("THÔNG TIN: GV ít tiết/không đủ min UI (không ảnh hưởng % tiến trình):");
      for(const it of lowHour.slice(0, 60)){
        out.push(`- ${it.gv}: tổng ${it.total} tiết (<${k})`);
      }
      if(lowHour.length > 60) out.push(`... và ${lowHour.length-60} GV khác.`);
      out.push("");
    }
  }

  // Các ca chưa đạt theo tiêu chí tiết/buổi
  const days = (typeof DAYS !== "undefined" && Array.isArray(DAYS)) ? DAYS : Object.keys(occ||{});
  for(const gv of Object.keys(occ)){
    if(k > 0){
      const total = _totalOccForTeacher(gv);
      if(total > 0 && total < k) continue; // GV ít tiết: đã liệt kê ở trên
    }
    for(const thu of days){
      for(const buoi of ["sang","chieu"]){
        const c = _countTrue(occ?.[gv]?.[thu]?.[buoi] || []);
        if(c > 0 && c < k){
          out.push(`${gv}: ${thu} ${buoi} có ${c} tiết (<${k})`);
          if(out.length >= 160) return out;
        }
      }
    }
  }

  return out;
}


function _showProblemsInline(problems, title){
  const wrap = document.getElementById("optProblemsWrap");
  const tEl = document.getElementById("optProblemsTitle");
  const bEl = document.getElementById("optProblemsBody");
  if(!wrap || !tEl || !bEl) return;

  const lines = problems.slice(0, 120);
  const tail = problems.length > 120 ? `\n... và ${problems.length-120} trường hợp khác.` : "";
  tEl.textContent = title || "Các ca chưa đạt";
  bEl.innerHTML = lines.map(x=>{
  const m = x.match(/(.+?)\|(.+?)\|(sang|chieu)\|(\d+)/);
  if(m){ const key = `${m[1]}|${m[2]}|${m[3]}|${m[4]}`;
    return `<div class='opt-problem' data-opt-key='${key}' data-gv='${m[1]}' data-thu='${m[2]}' data-buoi='${m[3]}' data-tiet='${m[4]}'>- ${x}</div>`; }
  return `<div class='opt-problem'>- ${x}</div>`;
}).join('') + (tail?`<div>${tail}</div>`:'');
_bindProblemClicks();
  wrap.style.display = "block";
}

function _hideProblemsInline(){
  const wrap = document.getElementById("optProblemsWrap");
  if(wrap) wrap.style.display = "none";
}

function _setContinueButton(text){
  const btn = document.getElementById("btnContinueOptimize");
  if(!btn) return;
  btn.textContent = text || "Tối ưu tiếp";
  btn.style.display = "inline-block";
  btn.disabled = false;
}

function _hideContinueButton(){
  const btn = document.getElementById("btnContinueOptimize");
  if(btn) btn.style.display = "none";
}

// ===== REPAIR: gom các tiết "không hợp lệ" theo tiêu chí đang chọn và sắp xếp lại =====
// Mục tiêu: khi chưa đạt 100% thì thử "đóng gói" (pack) lại các buổi GV vi phạm (tiết/buổi hoặc tiết trống)
// bằng cách chỉ gỡ/cắm lại đúng các tiết thuộc buổi vi phạm. Hạn chế thay đổi: không động OFF/fixed,
// không đụng các tiết của buổi "đạt".
// Lưu ý: tiêu chí "tiết trống" mức 1 => allowedGaps=0 (không được có gap); mức 2 => allowedGaps=1.

function _allowedGapsFromLimit(limitTietTrong){
  const n = Number(limitTietTrong || 0);
  if(n === 1) return 0;
  if(n === 2) return 1;
  return Infinity;
}

function _teacherTotalTietByOcc(occ, gv){
  let t = 0;
  for(const thu of DAYS){
    for(const buoi of ["sang","chieu"]){
      t += _countTrue(occ?.[gv]?.[thu]?.[buoi] || []);
    }
  }
  return t;
}

// Thu thập các "session" (gv+thu+buoi) đang vi phạm theo option hiện tại.
// Trả về list session có movableLessons (không fixed) để có thể gỡ/cắm lại.
function _collectInvalidTeacherSessions(opt){
  const limitTietBuoi = Number(opt?.limitTietBuoi || 0);
  let limitTietTrong = Number(opt?.limitTietTrong || 0);
  if(limitTietTrong > 2) limitTietTrong = 2;

  const allowedGaps = _allowedGapsFromLimit(limitTietTrong);

  const built = _buildTeacherOccAll();
  const occ = built.occ || {};
  const lessons = built.lessons || {};

  const sessions = [];

  for(const gv of Object.keys(occ)){
    const totalGV = _teacherTotalTietByOcc(occ, gv);
    if(_teacherMeetsTargetDistribution(gv, occ, totalGV)) continue;
    const skipBuoiForGV = (limitTietBuoi > 0 && totalGV < limitTietBuoi);

    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const slots = occ?.[gv]?.[thu]?.[buoi] || [];
        const m = _teacherSessionMetrics(slots);
        if(m.count === 0) continue;

        let bad = false;
        let severity = 0;

        if(limitTietBuoi > 0 && !skipBuoiForGV && m.count < limitTietBuoi){
          bad = true;
          severity += (limitTietBuoi - m.count) * 10;
        }

        if(limitTietTrong > 0 && Number.isFinite(allowedGaps)){
          const excess = Math.max(0, m.totalGaps - allowedGaps);
          if(excess > 0){
            bad = true;
            severity += excess * 5;
          }
        }
if(!bad) continue;

        const mv = (lessons?.[gv] || []).filter(x => x.thu === thu && x.buoi === buoi);
        if(!mv || mv.length === 0) continue; // không có gì để gỡ/cắm lại -> bỏ qua

        // fixed positions: occ true nhưng không thuộc movable lessons
        const mvPos = new Set(mv.map(x => Number(x.ti)));
        const fixedPos = [];
        for(let i=0;i<slots.length;i++){
          if(!!slots[i] && !mvPos.has(i)) fixedPos.push(i);
        }

        // lấy cell value hiện tại cho movable (để restore/đặt lại)
        const items = [];
        for(const l of mv){
          const tkb = DATA?.tkb?.[l.classId];
          const v = tkb?.[l.thu]?.[l.buoi]?.[l.ti];
          if(!v || v === "OFF" || isFixed(v)) continue; // extra-safe
          items.push({ ...l, v });
        }
        if(items.length === 0) continue;

        sessions.push({
          gv, thu, buoi,
          count: m.count,
          totalGaps: m.totalGaps,
          fixedPos,
          items,
          severity
        });
      }
    }
  }

  // ưu tiên xử lý buổi "xấu" hơn trước (gap nhiều / thiếu tiết nhiều)
  sessions.sort((a,b)=> (b.severity - a.severity) || (b.totalGaps - a.totalGaps) || (a.items.length - b.items.length));
  return sessions;
}

function _isSlotEmptyForClass(classId, thu, buoi, ti){
  const tkb = DATA?.tkb?.[classId];
  if(!tkb) return false;
  const arr = tkb?.[thu]?.[buoi];
  const v = arr?.[ti];
  return (v === "" || v == null);
}

function _canPlaceValueAt(classId, canon, monName, thu, buoi, ti){
  // class slot must be empty and not OFF
  const tkb = DATA?.tkb?.[classId];
  if(!tkb) return false;
  const cur = tkb?.[thu]?.[buoi]?.[ti];
  if(cur === "OFF") return false;
  if(cur && cur !== "") return false;

  // teacher conflict
  const gv = getTeacherForClassMon(canon, monName);
  if(gv){
    const c = findTeacherConflictAtSlot(gv, thu, buoi, ti, classId);
    if(c) return false;
  }

  // room conflict
  const room = getRoomForClassMon(canon, monName);
  if(room){
    const r = findRoomConflictAtSlot(room, thu, buoi, ti, classId);
    if(r) return false;
  }

  return true;
}

// backtracking: assign items -> times (bijection)
function _assignItemsToTimes(items, times, thu, buoi){
  // build candidate times for each item
  const cand = items.map(it=>{
    const c = [];
    for(const ti of times){
      if(_canPlaceValueAt(it.classId, it.canon, it.mon, thu, buoi, ti)) c.push(ti);
    }
    return c;
  });

  // quick fail
  for(const c of cand) if(c.length === 0) return null;

  // order by least candidates first
  const order = [...items.keys()].sort((i,j)=> cand[i].length - cand[j].length);

  const used = new Set();
  const assign = new Map(); // idx -> ti

  function dfs(k){
    if(k >= order.length) return true;
    const idx = order[k];

    // heuristic: try times with minimal "pressure" first
    const options = cand[idx].filter(t=>!used.has(t));
    // randomize a bit to escape local minima
    for(let t of options){
      used.add(t);
      assign.set(idx, t);
      if(dfs(k+1)) return true;
      assign.delete(idx);
      used.delete(t);
    }
    return false;
  }

  if(!dfs(0)) return null;

  const out = [];
  for(let i=0;i<items.length;i++){
    out.push({ item: items[i], ti: assign.get(i) });
  }
  return out;
}

// Thử "đóng gói" lại 1 session GV sao cho tổng gaps <= allowedGaps, chỉ bằng cách dời các items movable.
function _attemptPackTeacherSession(session, opt){
  const { gv, thu, buoi } = session || {};
  const items = session?.items || [];
  if(!gv || !thu || !buoi || items.length === 0) return false;

  let limitTietTrong = Number(opt?.limitTietTrong || 0);
  if(limitTietTrong > 2) limitTietTrong = 2;
  const allowedGaps = _allowedGapsFromLimit(limitTietTrong);
  if(!Number.isFinite(allowedGaps)) return false;

  // Rebuild teacher occupancy from current DATA (sau mỗi bước tối ưu, DATA đã thay đổi)
  const built = _buildTeacherOccAll();
  const slots = built?.occ?.[gv]?.[thu]?.[buoi];
  if(!slots || !slots.length) return false;

  const before = _teacherSessionMetrics(slots);
  const beforeExcess = Math.max(0, before.totalGaps - allowedGaps);
  if(before.count === 0 || beforeExcess === 0) return false;

  // Xác định các vị trí gap nằm giữa tiết đầu & cuối của buổi đó
  let first = -1, last = -1;
  for(let i=0;i<slots.length;i++){
    if(slots[i]){
      if(first < 0) first = i;
      last = i;
    }
  }
  if(first < 0 || last < 0 || last <= first) return false;

  const gapPositions = [];
  for(let i=first; i<=last; i++){
    if(!slots[i]) gapPositions.push(i);
  }
  if(gapPositions.length === 0) return false;

  // Greedy: thử chuyển 1 tiết của GV vào 1 gap để giảm số gap (ưu tiên giảm mạnh nhất)
  let bestMove = null;
  let bestGaps = before.totalGaps;

  for(const toTi of gapPositions){
    for(const it of items){
      const fromTi = Number(it.ti);
      if(!Number.isFinite(fromTi) || fromTi === toTi) continue;

      // Slot mục tiêu phải đặt được (lớp rảnh + không xung đột GV/phòng)
      if(!_canPlaceValueAt(it.classId, it.canon, it.mon, thu, buoi, toTi)) continue;

      // Mô phỏng nhanh tác động lên gap của GV trong buổi
      const tmp = slots.slice();
      tmp[fromTi] = false;
      tmp[toTi] = true;
      const after = _teacherSessionMetrics(tmp);

      if(after.totalGaps < bestGaps){
        bestGaps = after.totalGaps;
        bestMove = { it, fromTi, toTi, v: it.v };
        // Nếu đã đạt chuẩn thì dừng sớm
        if(bestGaps <= allowedGaps) break;
      }
    }
    if(bestMove && bestGaps <= allowedGaps) break;
  }

  if(!bestMove) return false;

  const tkb = DATA?.tkb?.[bestMove.it.classId];
  if(!tkb) return false;

  // Apply move (an toàn: chỉ thao tác nếu đúng value)
  const curFrom = tkb?.[thu]?.[buoi]?.[bestMove.fromTi];
  const curTo = tkb?.[thu]?.[buoi]?.[bestMove.toTi];

  // Nếu slot đích đã bị lấp trong lúc tính (race) -> bỏ
  if(curTo && curTo !== "") return false;

  // Xóa nguồn (nếu đang đúng value; nếu khác thì vẫn xóa vì mục tiêu là dời tiết của lớp đó ra khỏi vị trí này)
  if(curFrom === bestMove.v){
    tkb[thu][buoi][bestMove.fromTi] = "";
  } else if(curFrom === "" || curFrom == null){
    // đã trống -> ok
  } else {
    // Không đụng nếu là OFF/fixed hoặc ô khác (tránh phá tkb)
    if(curFrom === "OFF" || isFixed(curFrom)) return false;
    // Nếu khác mà vẫn trong cùng class+buoi, khả năng dữ liệu đã đổi -> bỏ
    return false;
  }

  tkb[thu][buoi][bestMove.toTi] = bestMove.v;
  return true;
}


// Vòng "sửa lỗi": mỗi round sẽ gom sessions vi phạm và thử pack lại.
// Nếu vẫn còn lỗi, round tiếp sẽ gom lại theo trạng thái mới.

// ===== NEW: Full reshuffle for invalid sessions (gap constraint) =====
function _attemptReshuffleSessionFull(sess, opt){
  // Mục tiêu: lấy toàn bộ tiết movable của buổi lỗi, gỡ ra, rồi cắm lại theo heuristic
  // để đạt điều kiện: "tiết trống" < limit (limit=1 => 0 gap, limit=2 => <=1 gap)
  // Bản vá: nếu ô đích không trống, cho phép "đổi chỗ trong lớp" bằng cách đẩy môn đang chiếm
  // về đúng ô nguồn của item hiện tại, miễn vẫn hợp lệ GV/phòng/gioihan. Điều này giúp xử lý
  // các ca kiểu 1-2-3-5 hoặc 1-3-4 khi move thẳng không làm được nhưng đường vòng thì làm được.
  try{
    const limitTietTrong = Number(opt?.limitTietTrong || 0);
    const allowedGaps = _allowedGapsFromLimit(limitTietTrong);
    if(!(limitTietTrong > 0) || !Number.isFinite(allowedGaps)) return false;

    const { gv, thu, buoi } = sess || {};
    if(!gv || !thu || !buoi) return false;

    const items0 = (sess?.items || []).slice();
    if(items0.length === 0) return false;

    const originals = [];
    for(const it of items0){
      const tkb = DATA?.tkb?.[it.classId];
      if(!tkb) continue;
      const cur = tkb?.[thu]?.[buoi]?.[it.ti];
      if(!cur || cur === "OFF" || isFixed(cur)) continue;
      originals.push({ classId: it.classId, canon: it.canon, mon: it.mon, fromTi: Number(it.ti), v: cur });
    }
    if(originals.length === 0) return false;

    const anyTkb = DATA?.tkb?.[originals[0].classId];
    const nSlots = (anyTkb?.[thu]?.[buoi] || []).length;
    if(!nSlots || nSlots <= 0) return false;

    for(const o of originals){
      const tkb = DATA?.tkb?.[o.classId];
      if(!tkb) continue;
      const cur = tkb?.[thu]?.[buoi]?.[o.fromTi];
      if(cur === o.v) tkb[thu][buoi][o.fromTi] = "";
    }

    const slots = new Array(nSlots).fill(false);
    const fixedPos = sess?.fixedPos || [];
    for(const p of fixedPos){
      const pi = Number(p);
      if(Number.isFinite(pi) && pi >= 0 && pi < nSlots) slots[pi] = true;
    }

    try{
      const tkbs = DATA?.tkb || {};
      for(const lopId of Object.keys(tkbs)){
        const tkb = tkbs[lopId];
        if(!tkb) continue;
        const canon = getLopCanonById(lopId);
        const arr = tkb?.[thu]?.[buoi] || [];
        for(let ti=0; ti<arr.length; ti++){
          const v = arr[ti];
          if(!v || v === "OFF") continue;
          const mon = cellMon(v);
          if(!mon) continue;
          const gv2 = getTeacherForClassMon(canon, mon);
          if(gv2 && gv2 === gv) slots[ti] = true;
        }
      }
    }catch(e){}

    const mid = (nSlots - 1) / 2;
    const items = originals.map(o=>({
      classId: o.classId,
      canon: o.canon,
      mon: o.mon,
      v: o.v,
      fromTi: o.fromTi,
      candCount: 0
    }));

    function _rollbackPlaced(placed){
      for(let i=placed.length-1; i>=0; i--){
        const p = placed[i];
        const tkb = DATA?.tkb?.[p.classId];
        if(!tkb || !tkb?.[thu]?.[buoi]) continue;
        if(p.kind === 'swap') tkb[thu][buoi][p.fromTi] = '';
        tkb[thu][buoi][p.ti] = '';
      }
      for(const o of originals){
        const tkb = DATA?.tkb?.[o.classId];
        if(!tkb) continue;
        tkb[thu][buoi][o.fromTi] = o.v;
      }
    }

    function _scorePlace(ti, kind){
      const tmp = slots.slice();
      tmp[ti] = true;
      const m = _teacherSessionMetrics(tmp);
      const gapOver = Math.max(0, m.totalGaps - allowedGaps);
      const spanLen = (m.pos && m.pos.length) ? (m.pos[m.pos.length-1] - m.pos[0] + 1) : 0;
      const edgeBias = Math.abs(ti - mid);
      const swapPenalty = (kind === 'swap') ? 15 : 0;
      return gapOver * 1000000 + spanLen * 100 + edgeBias + swapPenalty;
    }

    function _buildCandidate(it, ti){
      if(slots[ti]) return null;
      const tkb = DATA?.tkb?.[it.classId];
      const arr = tkb?.[thu]?.[buoi];
      if(!Array.isArray(arr) || ti < 0 || ti >= arr.length) return null;

      if(_canPlaceValueAt(it.classId, it.canon, it.mon, thu, buoi, ti)){
        return { kind:'place', ti, score:_scorePlace(ti, 'place') };
      }

      const vOcc = arr[ti];
      if(!vOcc || vOcc === 'OFF' || isFixed(vOcc)) return null;
      const monOcc = cellMon(vOcc);
      if(!monOcc || monOcc === it.mon) return null;

      const gvOcc = getTeacherForClassMon(it.canon, monOcc);
      if(!gvOcc) return null;
      if(findTeacherConflictAtSlot(gvOcc, thu, buoi, it.fromTi, it.classId)) return null;
      const roomOccMon = getRoomForClassMon(it.canon, monOcc);
      if(roomOccMon && findRoomConflictAtSlot(roomOccMon, thu, buoi, it.fromTi, it.classId)) return null;

      if(!_canSwapWithinClass(it.classId, it.canon, thu, buoi, it.fromTi, thu, buoi, ti, it.mon, monOcc)) return null;

      return {
        kind:'swap',
        ti,
        score:_scorePlace(ti, 'swap'),
        occValue:vOcc,
        occMon:monOcc
      };
    }

    function _candidateCount(it){
      let cnt = 0;
      for(let ti=0; ti<nSlots; ti++) if(_buildCandidate(it, ti)) cnt++;
      return cnt;
    }

    for(const it of items) it.candCount = _candidateCount(it);
    items.sort((a,b)=> (a.candCount - b.candCount) || (Math.abs(a.fromTi-mid) - Math.abs(b.fromTi-mid)));

    const placed = [];
    for(const it of items){
      let best = null;
      for(let ti=0; ti<nSlots; ti++){
        const cand = _buildCandidate(it, ti);
        if(!cand) continue;
        if(!best || cand.score < best.score) best = cand;
      }

      if(!best){
        _rollbackPlaced(placed);
        return false;
      }

      const tkb = DATA?.tkb?.[it.classId];
      if(!tkb){
        _rollbackPlaced(placed);
        return false;
      }

      if(best.kind === 'swap') tkb[thu][buoi][it.fromTi] = best.occValue;
      tkb[thu][buoi][best.ti] = it.v;
      slots[best.ti] = true;
      placed.push({ classId: it.classId, ti: best.ti, fromTi: it.fromTi, kind: best.kind, v: it.v });
    }

    const mFinal = _teacherSessionMetrics(slots);
    if(mFinal.totalGaps > allowedGaps){
      _rollbackPlaced(placed);
      return false;
    }

    return true;
  }catch(e){
    console.error("reshuffle full failed", e);
    return false;
  }
}


function _repairInvalidLessonsByReshuffle(opt, maxRounds=10){
  let rounds = 0;
  let totalTouchedSessions = 0;

  while(rounds < maxRounds){
    const stats = _calcOptimizeCompliance(opt);
    if(stats?.reached) return { rounds, totalTouchedSessions, stats };

    const sessions = _collectInvalidTeacherSessions(opt);
    if(!sessions || sessions.length === 0) break;

    let touchedThisRound = 0;

    for(const s of sessions){
      // Nếu tiêu chí tiết/buổi đang bật, nhưng GV có tổng tiết < limit => bỏ qua (không thể sửa)
      const limBuoi = Number(opt?.limitTietBuoi || 0);
  const uiMinBuoi = _uiMinTietBuoi(opt);
      if(limBuoi > 0){
        // rebuild occ quickly for total? dùng calc ở stats đã có skipped, nhưng theo từng GV thì cần nhẹ
        // -> chấp nhận vẫn thử, vì tiêu chí tiết trống vẫn có thể sửa
      }

      let ok = _attemptReshuffleSessionFull(s, opt);
      if(!ok) ok = _attemptPackTeacherSession(s, opt);
      if(!ok) ok = _attemptMoveOneLessonIntoGap(s, opt);
      if(ok) touchedThisRound++;
    }

    if(touchedThisRound === 0) break;

    totalTouchedSessions += touchedThisRound;
    rounds++;
    try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
  }

  return { rounds, totalTouchedSessions, stats: _calcOptimizeCompliance(opt) };
}

async function runOptimizeFromPanel(){
  if(__OPT_PANEL_STATE.running) return;
  __OPT_PANEL_STATE.running = true;
  __OPT_PANEL_STATE.cancel = false;

  _hideProblemsInline();
  _hideContinueButton();

  const selectedMode = _getSelectedOptimizeMode();
  const modeMeta = _getOptModeMeta(selectedMode);

  const limitTietBuoi = Number(modeMeta.limitTietBuoi || 0);
  const limitTietTrong = Number(modeMeta.limitTietTrong || 0);
  const showBuoi = !!modeMeta.showBuoi;
  const showTrong = !!modeMeta.showTrong;
  const modeLabel = modeMeta.shortLabel || _optModeLabelFromLimits(limitTietBuoi, limitTietTrong);

  let timeLimitMin = parseFloat(document.getElementById("optTimeLimitMin")?.value);
  if(!Number.isFinite(timeLimitMin) || timeLimitMin <= 0) timeLimitMin = 2;

  const userTotalMs = Math.max(5_000, Math.round(Math.max(0.1, timeLimitMin) * 60_000));
  // Chạy theo đúng thời gian người dùng chọn (chia nhỏ theo bước để UI không đơ)
  const passMs = userTotalMs;
  const totalMs = userTotalMs;


  // UI: lock
  const btnRun = document.getElementById("btnRunOptimize");
  const btnStop = document.getElementById("btnStopOptimize");
  const btnClose = document.getElementById("btnCloseOptimize");
  const lockIds = ["optModeBuoi1","optModeTrong2","optModeTrong1","optTimeLimitMin"];
  lockIds.forEach(id=>{ const el = document.getElementById(id); if(el) el.disabled = true; });
    if(btnRun) btnRun.disabled = true;
  if(btnClose) btnClose.disabled = true;
  if(btnStop){ btnStop.style.display = "inline-block"; btnStop.disabled = false; }

  const opt = { limitTietBuoi, limitTietTrong };
  let lastStats = _calcOptimizeCompliance(opt);

  const startTs = Date.now();
  const deadlineTs = startTs + passMs;
  let totalSwaps = 0;

  // Nếu đã đạt ngay từ đầu (100% theo tiêu chí chính)
  if(lastStats.reached){
    const skipNote = (showBuoi && limitTietBuoi > 0 && lastStats.skippedTeachers > 0)
      ? ` (bỏ qua ${lastStats.skippedTeachers} GV có tổng tiết < ${limitTietBuoi})`
      : "";
    _setOptProgressUI({
      percent: 100,
      reached: true,
            elapsedMs: 0,
      totalMs,
      nSessions: lastStats.nSessions,
      totalTiet: lastStats.totalTiet,
      totalSpan: lastStats.totalSpan,
      badTietBuoi: lastStats.badTietBuoi,
      badTietTrong: lastStats.badTietTrong,
      limitTietBuoi,
      limitTietTrong,
      swaps: 0,
      showBuoi,
      showTrong,
      note: "✔ Đã đạt 100% theo tiêu chí đang chọn." + skipNote
    });
    // unlock
    lockIds.forEach(id=>{ const el = document.getElementById(id); if(el) el.disabled = false; });
      if(btnRun) btnRun.disabled = false;
    if(btnClose) btnClose.disabled = false;
    if(btnStop) btnStop.style.display = "none";
    __OPT_PANEL_STATE.running = false;
    __OPT_PANEL_STATE.cancel = false;
    toggleOptPart();
    return;
  }

  // Hiển thị ngay "mức đạt" hiện tại (không phải 0%)
  _setOptProgressUI({
    percent: lastStats.percent,
    reached: lastStats.reached,
    elapsedMs: 0,
    totalMs,
    nSessions: lastStats.nSessions,
    totalTiet: lastStats.totalTiet,
    totalSpan: lastStats.totalSpan,
    badTietBuoi: lastStats.badTietBuoi,
    badTietTrong: lastStats.badTietTrong,
    limitTietBuoi,
    limitTietTrong,
    swaps: 0,
    showBuoi,
    showTrong,
    note: "Đang tối ưu..."
  });

  let lastScoreTs = 0;
  while(true){
    const now = Date.now();
    const elapsed = now - startTs;

    if(__OPT_PANEL_STATE.cancel) break;
    if(now >= deadlineTs) break;

    // "Batch" nhỏ để UI không bị đơ
    let moved = 0;

    try{
      // Tách riêng tối ưu "1 tiết/1 buổi" theo yêu cầu
      if(limitTietBuoi === 2){
        moved += optimizeTeacherScheduleQualityBuoi1({
          maxSwaps: 60,
          maxIters: 260,
          timeBudgetMs: 22,
          preferAfternoon: true
        });

        if(limitTietTrong > 0){
          // Phần "tiết trống" chạy riêng (không trộn với tiết/buổi=1 để đúng ý đồ)
          moved += optimizeTeacherScheduleQualityAdvanced({
            limitTietBuoi: 0,
            limitTietTrong,
            maxSwaps: Math.min(90, 30 + (limitTietTrong===1 ? 45 : (limitTietTrong===2 ? 22 : 0))),
            maxIters: Math.min(420, 170 + (limitTietTrong===1 ? 190 : (limitTietTrong===2 ? 130 : 0))),
            timeBudgetMs: 22
          });

          // Sau khi tối ưu tiết trống, chạy lại 1 vòng nhỏ để đảm bảo không "đẻ" lại buổi dạy 1 tiết
          // (ưu tiên đúng yêu cầu: không còn GV đi dạy lẻ 1 tiết/buổi)
          moved += optimizeTeacherScheduleQualityBuoi1({
            maxSwaps: 25,
            maxIters: 120,
            timeBudgetMs: 10,
            preferAfternoon: true
          });
        }
      } else {
        moved = optimizeTeacherScheduleQualityAdvanced({
          limitTietBuoi,
          limitTietTrong,
          maxSwaps: Math.min(90, 20 + (limitTietBuoi>0 ? limitTietBuoi * 25 : 0) + (limitTietTrong===1 ? 30 : (limitTietTrong===2 ? 18 : 0))),
          maxIters: Math.min(420, 140 + (limitTietBuoi>0 ? limitTietBuoi * 90 : 0) + (limitTietTrong===1 ? 150 : (limitTietTrong===2 ? 110 : 0))),
          timeBudgetMs: 35
        });
      }
    }catch(e){
      const msg = (e && e.message) ? e.message : String(e);
      _setOptProgressUI({
        percent: lastStats?.percent ?? 0,
        reached: !!lastStats?.reached,
        elapsedMs: elapsed,
        totalMs,
        nSessions: lastStats?.nSessions ?? 0,
        totalTiet: lastStats?.totalTiet ?? 0,
        totalSpan: lastStats?.totalSpan ?? 0,
        badTietBuoi: lastStats?.badTietBuoi ?? 0,
        badTietTrong: lastStats?.badTietTrong ?? 0,
        limitTietBuoi,
        limitTietTrong,
        swaps: totalSwaps,
        showBuoi,
        showTrong,
        note: `❌ Lỗi tối ưu: ${msg}`
      });
      break;
    }

    totalSwaps += (Number(moved)||0);
    // Hard gap repair pass (chạy thật sự) để xử lý các buổi GV có tiết trống
    if(limitTietTrong > 0 && !__OPT_PANEL_STATE.cancel){
      try{
        const stNow = _calcOptimizeCompliance({ limitTietBuoi: 0, limitTietTrong });
        if(stNow && !stNow.reachedTrong && stNow.badTietTrong > 0){
          // 1 round/loop để không tốn CPU nhưng vẫn thấy "động"
          _repairInvalidLessonsByReshuffle({ limitTietBuoi: 0, limitTietTrong }, 1);
        }
      }catch(e){ /* ignore */ }
    }


    // Chấm điểm định kỳ (tránh tốn CPU) hoặc khi vừa có hoán đổi
    if((now - lastScoreTs) >= 200 || moved > 0){
      lastStats = _calcOptimizeCompliance(opt);

      const reached = !!lastStats.reached;
      const skipNote = (showBuoi && limitTietBuoi > 0 && lastStats.skippedTeachers > 0)
        ? ` (bỏ qua ${lastStats.skippedTeachers} GV có tổng tiết < ${limitTietBuoi})`
        : "";

      _setOptProgressUI({
        percent: lastStats.percent,
        reached: reached,
        elapsedMs: elapsed,
        totalMs,
        nSessions: lastStats.nSessions,
        totalTiet: lastStats.totalTiet,
        totalSpan: lastStats.totalSpan,
        badTietBuoi: lastStats.badTietBuoi,
        badTietTrong: lastStats.badTietTrong,
        limitTietBuoi,
        limitTietTrong,
        swaps: totalSwaps,
        showBuoi,
        showTrong,
        note: reached ? ("✔ Đã đạt 100% theo tiêu chí đang chọn." + skipNote) : "Đang tối ưu..."
      });

      lastScoreTs = now;
      if(reached) break;
    } else {
      // chỉ update time để thanh tiến trình "chạy" đều
      _setOptProgressUI({
        percent: lastStats.percent,
        reached: lastStats.reached,
        elapsedMs: elapsed,
        totalMs,
        nSessions: lastStats.nSessions,
        totalTiet: lastStats.totalTiet,
        totalSpan: lastStats.totalSpan,
        badTietBuoi: lastStats.badTietBuoi,
        badTietTrong: lastStats.badTietTrong,
        limitTietBuoi,
        limitTietTrong,
        swaps: totalSwaps,
        showBuoi,
        showTrong,
        note: "Đang tối ưu..."
      });
    }

    // yield để UI có thể repaint
    await new Promise(r=>setTimeout(r, 0));
  }

  // Kết thúc: chấm lại lần cuối + render
  const finalNow = Date.now();
  const finalElapsed = finalNow - startTs;
  lastStats = _calcOptimizeCompliance(opt);

  let reached100 = !!lastStats.reached;

  // Nếu chưa đạt 100%: thử 1 vòng "gom lỗi → sắp xếp lại" để kéo về hợp lệ
  if(!reached100 && !__OPT_PANEL_STATE.cancel){
    try{
      // Thông báo rõ: đang gom các ca vi phạm và sắp xếp lại (lặp đến khi hết lỗi hoặc chạm giới hạn)
      _setOptProgressUI({
        percent: lastStats.percent,
        reached: false,
        elapsedMs: Math.min(finalElapsed, totalMs),
        totalMs,
        nSessions: lastStats.nSessions,
        totalTiet: lastStats.totalTiet,
        totalSpan: lastStats.totalSpan,
        badTietBuoi: lastStats.badTietBuoi,
        badTietTrong: lastStats.badTietTrong,
        limitTietBuoi,
        limitTietTrong,
        swaps: totalSwaps,
        showBuoi,
        showTrong,
        note: "Đang gom các ca chưa đạt và sắp xếp lại..."
      });
      await new Promise(r=>setTimeout(r, 0));

      const maxRounds = (limitTietTrong === 1) ? 18 : 10;
      const rep = _repairInvalidLessonsByReshuffle(opt, maxRounds);
      if(rep && rep.rounds > 0){
        lastStats = _calcOptimizeCompliance(opt);
        reached100 = !!lastStats.reached;
      }
    }catch(e){ console.error('repair by reshuffle failed', e); }
  }


  // Nếu chưa đạt 100%: hiện ngay danh sách + bật nút "Tối ưu tiếp"
  if(!reached100 && limitTietBuoi > 0){
    try{
      let rep = 0;
      while(rep < 30 && _safeRepairOnce(limitTietBuoi)) rep++;
  const problems = _listOptimizeProblems(limitTietBuoi);
      if(problems.length){
        __OPT_PANEL_STATE.nextMode = "spread";
        __OPT_PANEL_STATE.lastMode = selectedMode;
        __OPT_PANEL_STATE.lastK = limitTietBuoi;
        __OPT_PANEL_STATE.lastTrong = limitTietTrong;
        _showProblemsInline(problems, "⚠️ Còn ràng buộc chưa đạt (bạn có muốn tối ưu tiếp?)");
        _setContinueButton("Tối ưu tiếp (ưu tiên rải đều)");
      } else {
        _hideProblemsInline();
        _hideContinueButton();
        }
    }catch(e){
      console.error("List problems failed:", e);
    }
  } else {
    _hideProblemsInline();
    _hideContinueButton();
  }


  const reason = reached100 ? "đạt 100%" : (__OPT_PANEL_STATE.cancel ? "đã dừng" : "hết thời gian");

  const skipNote = (showBuoi && limitTietBuoi > 0 && lastStats.skippedTeachers > 0)
    ? ` (bỏ qua ${lastStats.skippedTeachers} GV có tổng tiết < ${limitTietBuoi})`
    : "";

  const note = reached100
    ? ("✔ Đã đạt 100% theo tiêu chí đang chọn." + skipNote)
    : `⏱ Dừng vì ${reason}. (Có thể còn ràng buộc làm không thể đạt 100% tuyệt đối.)`;

  _setOptProgressUI({
    percent: lastStats.percent,
    reached: reached100,
    elapsedMs: Math.min(finalElapsed, totalMs),
    totalMs,
    nSessions: lastStats.nSessions,
    totalTiet: lastStats.totalTiet,
    totalSpan: lastStats.totalSpan,
    badTietBuoi: lastStats.badTietBuoi,
    badTietTrong: lastStats.badTietTrong,
    limitTietBuoi,
    limitTietTrong,
    swaps: totalSwaps,
    showBuoi,
    showTrong,
    note
  });

  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }

  const box = document.getElementById("statusMsg");
  if(box){
    const pctTxt = reached100 ? 100 : Math.round(lastStats.percent);
    box.innerText = `✔ Tối ưu (${modeLabel}) ${reason}: ${pctTxt}% (hoán đổi ${totalSwaps}).`;
  }

  // UI unlock
  lockIds.forEach(id=>{ const el = document.getElementById(id); if(el) el.disabled = false; });
    if(btnRun) btnRun.disabled = false;
  if(btnClose) btnClose.disabled = false;
  if(btnStop) btnStop.style.display = "none";

  __OPT_PANEL_STATE.running = false;
  __OPT_PANEL_STATE.cancel = false;
  toggleOptPart();
}

function closePanel(){
  // Không cho đóng khi đang chạy (tránh lỗi DOM null); nếu muốn đóng hãy bấm Dừng trước.
  if(__OPT_PANEL_STATE.running){
    __OPT_PANEL_STATE.cancel = true;
    const elNote = document.getElementById("optProgressNote");
    if(elNote) elNote.textContent = "Đang dừng...";
    return;
  }
  document.getElementById("tkbConfigOverlay")?.remove();
}

/* ======================= RÀNG BUỘC (BUILD DẦN) =======================
   Hiện tại ưu tiên: TIẾT NGHỈ → LỚP HỌC
   - Chọn lớp nhanh
   - Nhấn giữ ô trên TKB để chọn Nghỉ/Bỏ nghỉ
   - Icon sao chép tiết nghỉ toàn trường
====================================================================== */

let __RB_STATE = {
  type: "tietnghi", // gv, monhoc, tietnghi, gioihan, batbuoc
  sub: "lop",      // lop, giaovien, monhoc, phong
};

function toggleRangBuoc(){
  const exist = document.getElementById("tkbConstraintPanel");
  if(exist){
    exist.remove();
    return;
  }

  const panel = document.createElement("div");
  panel.id = "tkbConstraintPanel";
  panel.innerHTML = `
    <div class="rb-head">
      <div class="rb-title">Ràng buộc</div>
      <button class="rb-close" onclick="toggleRangBuoc()" title="Đóng">×</button>
    </div>

    <div class="rb-row">
      <div class="rb-label">Loại ràng buộc</div>
      <select id="rbMain" class="rb-select" onchange="rbOnChangeMain()">
        <option value="giaovien">Giáo viên</option>
        <option value="monhoc">Môn học</option>
        <option value="tietnghi" selected>Tiết nghỉ</option>
        <option value="gioihan">Giới hạn tiết/thời điểm</option>
        <option value="batbuoc">Tiết bắt buộc phải có</option>
      </select>
    </div>

    <div id="rbSubWrap"></div>
    <div id="rbBody"></div>
    <div class="rb-note">Gợi ý: Trong chế độ <b>Tiết nghỉ</b>, bạn nhấn giữ (long-press) ô trên TKB để chọn <b>Nghỉ / Bỏ nghỉ</b>. Có thể copy/dán và xóa giống trang sắp xếp.</div>
  `;
  document.body.appendChild(panel);

  try{ panel.style.display = "block"; }catch(e){}

  // set defaults
  try{ document.getElementById("rbMain").value = __RB_STATE.type || "tietnghi"; }catch(e){}
  rbRender();
}

function rbOnChangeMain(){
  const v = (document.getElementById("rbMain")?.value || "").trim();
  __RB_STATE.type = v || "tietnghi";
  // default sub when switching to tiết nghỉ
  if(__RB_STATE.type === "tietnghi" && !__RB_STATE.sub) __RB_STATE.sub = "lop";
  rbRender();
}

function rbOnChangeSub(){
  const v = (document.getElementById("rbSub")?.value || "").trim();
  __RB_STATE.sub = v || "lop";
  rbRender();
}

function rbSelectLop(id){
  if(!id) return;
  try{ setViewMode("lop"); }catch(e){}
  try{ selectLop(id); }catch(e){}

  // keep selection
  const sel = document.getElementById("rbLopList");
  if(sel) sel.value = String(id);
}

function rbRender(){
  const subWrap = document.getElementById("rbSubWrap");
  const body = document.getElementById("rbBody");
  if(!subWrap || !body) return;

  // clear
  subWrap.innerHTML = "";
  body.innerHTML = "";

  if(__RB_STATE.type !== "tietnghi"){
    body.innerHTML = `<div style="padding:10px;border:1px dashed #c9d4ea;border-radius:10px;color:#5b6b82;background:#f7f9ff">
      Chức năng này sẽ được xây dựng sau. Hiện tại đã làm tốt phần <b>Tiết nghỉ → Lớp học</b>.
    </div>`;
    return;
  }

  // Tiết nghỉ: sub selector
  subWrap.innerHTML = `
    <div class="rb-row" style="margin-top:10px">
      <div class="rb-label">Áp dụng cho</div>
      <select id="rbSub" class="rb-select" onchange="rbOnChangeSub()">
        <option value="lop" selected>Lớp học</option>
        <option value="giaovien">Giáo viên</option>
        <option value="monhoc">Môn học</option>
        <option value="phong">Phòng học</option>
      </select>
    </div>
  `;
  try{ document.getElementById("rbSub").value = __RB_STATE.sub || "lop"; }catch(e){}

  if(__RB_STATE.sub !== "lop"){
    body.innerHTML = `<div style="padding:10px;border:1px dashed #c9d4ea;border-radius:10px;color:#5b6b82;background:#f7f9ff">
      Mục <b>${__RB_STATE.sub}</b> đang chuẩn bị. Bạn dùng <b>Lớp học</b> để thao tác nhanh tiết nghỉ.
    </div>`;
    return;
  }

  // Lớp học UI
  const lops = (DATA.lop || []).slice().sort((a,b)=>String((a.ten2||a.ten||"")).localeCompare(String((b.ten2||b.ten||"")),"vi"));
  const current = String(window.currentLop || "");
  const lopOptions = lops.map(l=>{
    const id = String(l.id);
    const name = (l.ten2 || l.ten || id);
    return `<option value="${id}" ${id===current?"selected":""}>${name}</option>`;
  }).join("");

  body.innerHTML = `
    <div class="rb-row" style="margin-top:10px">
      <div style="display:flex;align-items:center;justify-content:space-between;gap:10px">
        <div class="rb-label" style="margin:0">Lớp học</div>
        <button class="rb-icon-btn" onclick="openCopyOffModal()" title="Sao chép tiết nghỉ toàn trường">⧉</button>
      </div>
      <select id="rbLopList" class="rb-listbox" size="12" onchange="rbSelectLop(this.value)">
        ${lopOptions}
      </select>
    </div>
    <div class="rb-note">Icon ⧉: sao chép <b>tiết nghỉ</b> của lớp đang chọn sang các lớp khác.</div>
  `;
}

function closeCopyOffModal(){
  document.getElementById("tkbCopyOffOverlay")?.remove();
}

function openCopyOffModal(){
  const srcId = String(window.currentLop || "");
  if(!srcId){
    _setStatus("Vui lòng chọn 1 lớp trước khi sao chép tiết nghỉ.", "error");
    return;
  }
  if(document.getElementById("tkbCopyOffOverlay")) return;

  const srcLop = (DATA.lop||[]).find(x=>String(x.id)===srcId);
  const srcName = srcLop?.ten2 || srcLop?.ten || srcId;

  const lops = (DATA.lop||[]).slice().sort((a,b)=>String((a.ten2||a.ten||"")).localeCompare(String((b.ten2||b.ten||"")),"vi"));
  const chkList = lops
    .filter(l=>String(l.id)!==srcId)
    .map(l=>{
      const id = String(l.id);
      const name = (l.ten2 || l.ten || id);
      return `<label class="offcopy-classitem"><input type="checkbox" class="offcopy-chk" value="${id}" checked> ${name}</label>`;
    }).join("");

  const overlay = document.createElement("div");
  overlay.id = "tkbCopyOffOverlay";
  overlay.innerHTML = `
    <div class="offcopy-modal">
      <div class="offcopy-title">
        <div style="font-weight:800">Sao chép tiết nghỉ</div>
        <button class="rb-close" onclick="closeCopyOffModal()" title="Đóng">×</button>
      </div>

      <div class="offcopy-grid">
        <div class="offcopy-left">
          ${chkList || '<div style="padding:10px;color:#777">Không có lớp để chọn</div>'}
        </div>

        <div class="offcopy-right">
          <div class="offcopy-src">
            <div style="margin-bottom:6px;color:#666">Lớp học</div>
            <div style="font-size:22px;font-weight:800;color:#111">${srcName}</div>
          </div>

          <div class="offcopy-form">
            <div class="offcopy-form-row">
              <div>Buổi học</div>
              <select id="offcopyBuoi">
                <option value="">(Chọn tất cả)</option>
                <option value="sang">Sáng</option>
                <option value="chieu">Chiều</option>
              </select>
            </div>
            <div class="offcopy-form-row">
              <div>Thứ</div>
              <select id="offcopyThu">
                <option value="">(Chọn tất cả)</option>
                ${DAYS.map(d=>`<option value="${d}">${THU_LABEL[d]||d}</option>`).join("")}
              </select>
            </div>
            <div class="offcopy-form-row">
              <div>Tiết</div>
              <select id="offcopyTiet">
                <option value="">(Chọn tất cả)</option>
                ${Array.from({length: Math.max(SANG, CHIEU)}, (_,i)=>`<option value="${i}">${i+1}</option>`).join("")}
              </select>
            </div>
          </div>
        </div>
      </div>

      <div class="offcopy-footer">
        <label class="offcopy-all"><input id="offcopyAll" type="checkbox" checked onchange="offcopyToggleAll(this.checked)"> Chọn tất cả</label>
        <div style="flex:1"></div>
        <button class="primary" onclick="applyCopyOffFromModal()">Chấp nhận</button>
        <button onclick="closeCopyOffModal()">Hủy bỏ</button>
      </div>
    </div>
  `;
  document.body.appendChild(overlay);
}

function offcopyToggleAll(checked){
  document.querySelectorAll('#tkbCopyOffOverlay .offcopy-chk').forEach(chk=>{
    chk.checked = !!checked;
  });
}

function ensureTKBExistsForLop(lopId){
  if(!DATA.tkb) DATA.tkb = {};
  if(!DATA.tkb[lopId]){
    try{
      DATA.tkb[lopId] = (typeof window.__tkbMakeEmptyTKBPreservingOff === "function")
        ? window.__tkbMakeEmptyTKBPreservingOff(lopId, DATA.tkbConfig)
        : taoTKBTheoConfig([], DATA.tkbConfig);
    }catch(e){
      // fallback
      DATA.tkb[lopId] = DATA.tkb[lopId] || {};
    }
  }
  return DATA.tkb[lopId];
}

function _collectOffPositions(srcId, filter){
  const tkb = DATA.tkb?.[srcId];
  if(!tkb) return [];
  const wantBuoi = (filter?.buoi || "");
  const wantThu = (filter?.thu || "");
  const wantTiet = (filter?.tiet ?? "");
  const keys = [];
  for(const thu of DAYS){
    if(wantThu && wantThu !== thu) continue;
    for(const buoi of ["sang","chieu"]){
      if(wantBuoi && wantBuoi !== buoi) continue;
      const arr = tkb?.[thu]?.[buoi] || [];
      const len = (buoi === "sang" ? SANG : CHIEU);
      for(let ti=0; ti<len; ti++){
        if(wantTiet !== "" && Number(wantTiet) !== ti) continue;
        if(arr[ti] === "OFF") keys.push({thu, buoi, ti});
      }
    }
  }
  return keys;
}

function applyCopyOffFromModal(){
  const overlay = document.getElementById("tkbCopyOffOverlay");
  const srcId = String(window.currentLop || "");
  if(!overlay || !srcId){
    closeCopyOffModal();
    return;
  }

  const targets = Array.from(overlay.querySelectorAll('.offcopy-chk:checked')).map(c=>String(c.value));
  if(!targets.length){
    _setStatus("Chưa chọn lớp cần sao chép.", "error");
    return;
  }

  const buoi = (document.getElementById("offcopyBuoi")?.value || "");
  const thu = (document.getElementById("offcopyThu")?.value || "");
  const tiet = (document.getElementById("offcopyTiet")?.value || "");

  const keys = _collectOffPositions(srcId, {buoi, thu, tiet});
  if(!keys.length){
    _setStatus("Lớp nguồn không có tiết nghỉ theo điều kiện đã chọn.", "info");
    return;
  }

  let applied = 0;
  let skippedFixed = 0;

  for(const tid of targets){
    const tkb = ensureTKBExistsForLop(tid);
    for(const k of keys){
      const cur = tkb?.[k.thu]?.[k.buoi]?.[k.ti];
      if(isFixed(cur)){
        skippedFixed++;
        continue;
      }
      // chỉ set OFF nếu chưa OFF
      if(cur !== "OFF"){
        if(!tkb[k.thu]) tkb[k.thu] = {sang: Array(SANG).fill(null), chieu: Array(CHIEU).fill(null)};
        if(!tkb[k.thu][k.buoi]) tkb[k.thu][k.buoi] = Array(k.buoi==="sang"?SANG:CHIEU).fill(null);
        tkb[k.thu][k.buoi][k.ti] = "OFF";
        applied++;
      }
    }
  }

  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }

  closeCopyOffModal();
  _setStatus(`Đã sao chép tiết nghỉ: ${applied} ô (bỏ qua cố định: ${skippedFixed}).`, "ok");
}

function renderConfig(){
  const f = document.getElementById("fixedBox");
  const o = document.getElementById("offBox");
  if(!f || !o) return;

  f.innerHTML = "";
  o.innerHTML = "";

  DATA.tkbConfig.fixed.forEach((x,i)=>{
    f.innerHTML += `
      ${LABEL[x.thu]} – ${x.buoi} – tiết ${x.tiet+1} – <b>${escapeHtml(x.ten)}</b>
      <button onclick="DATA.tkbConfig.fixed.splice(${i},1);renderConfig()">X</button><br>
    `;
  });

  DATA.tkbConfig.off.forEach((x,i)=>{
    o.innerHTML += `
      ${LABEL[x.thu]} – ${x.buoi} – tiết ${x.tiet+1}
      <button onclick="DATA.tkbConfig.off.splice(${i},1);renderConfig()">X</button><br>
    `;
  });
}

function addFixed(){
  const thu = prompt("Thứ (thu2..thu7):","thu2");
  const buoi = prompt("Buổi (sang/chieu):","sang");
  const tiet = Number(prompt("Tiết (1..):","1")) - 1;
  const ten = prompt("Tên tiết cố định:","Chào cờ");

  if(thu && buoi && ten){
    DATA.tkbConfig.fixed.push({thu,buoi,tiet,ten});
    renderConfig();
  }
}

function addOff(){
  const thu = prompt("Thứ (thu2..thu7):","thu4");
  const buoi = prompt("Buổi (sang/chieu):","sang");
  const tiet = Number(prompt("Tiết (1..):","4")) - 1;

  if(thu && buoi){
    DATA.tkbConfig.off.push({thu,buoi,tiet});
    renderConfig();
  }
}

function xepTheoTuyChinh(){
  if(!currentLop){
    alert("Chưa chọn lớp");
    return;
  }

  const lop = (DATA.lop||[]).find(x=>x.id==currentLop);
  const lopKhoiNum = extractKhoiNumber(lop?.khoi);
  const lopCanon = getLopCanonById(currentLop);
  const mons = buildMonsForKhoi(lopKhoiNum, lopCanon);

  // Xếp theo tuỳ chỉnh nhưng giữ nguyên các tiết nghỉ người dùng đã khóa.
  const empty = (typeof window.__tkbMakeEmptyTKBPreservingOff === "function")
    ? window.__tkbMakeEmptyTKBPreservingOff(currentLop, DATA.tkbConfig)
    : taoTKBTheoConfig([], DATA.tkbConfig);
  const extraCanPlaceCell = (thu, buoi, tietIdx, monName)=>{
    const gv = getTeacherForClassMon(lopCanon, monName);
    if(gv){
      const c = findTeacherConflictAtSlot(gv, thu, buoi, tietIdx, currentLop);
      if(c) return false;
    }
    const room = getRoomForClassMon(lopCanon, monName);
    if(room){
      const r = findRoomConflictAtSlot(room, thu, buoi, tietIdx, currentLop);
      if(r) return false;
    }
    return true;
  };
  const extraScoreBlock = makeExtraScoreBlockForTeacherQualityAndSpread(currentLop, lopCanon);
  DATA.tkb[currentLop] = taoTKBBoSungTheoConfig(empty, mons, DATA.tkbConfig, extraCanPlaceCell, extraScoreBlock);
  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }
  closePanel();
}

/* ===== MOVED SECTION: optimize_improvements (from phanmon.js:185245-225769) ===== */

/* =========================================================
   CẢI TIẾN: TỐI ƯU "1 TIẾT/BUỔI" (NHANH + DỪNG NGAY) + SYNC REV
   - Giảm rebuild occ liên tục (giữ state và cập nhật increment)
   - Ưu tiên giảm số "buổi dạy lẻ 1 tiết" của GV (không làm GV khác xấu đi)
   ========================================================= */

(function(){
  // Tăng rev khi có thuật toán khác thay đổi TKB (để state buổi=1 tự rebuild)
  try{
    const __optAdv0 = optimizeTeacherScheduleQualityAdvanced;
    optimizeTeacherScheduleQualityAdvanced = function(opts){
      const r = __optAdv0(opts);
      if(r > 0){
        window.__TKB_REV = (window.__TKB_REV || 0) + r;
      }
      return r;
    };
  }catch(_){}

  // State cho tối ưu "1 tiết/buổi"
  let __OPT_BUOI1_STATE = null;

  function _optBuoi1Ensure(state, gv){
    const code = (gv||"").toString().trim();
    if(!code) return null;
    if(!state.occ[code]){
      state.occ[code] = {};
      state.sessCount[code] = {};
      for(const thu of DAYS){
        state.occ[code][thu] = {
          sang: Array(SANG).fill(false),
          chieu: Array(CHIEU).fill(false)
        };
        state.sessCount[code][thu] = { sang: 0, chieu: 0 };
      }
    }
    if(state.singleCount[code] == null) state.singleCount[code] = 0;
    return code;
  }

  function _optSessCount(state, gv, thu, buoi){
    const g = (gv||"").toString().trim();
    if(!g) return 0;
    return Number(state?.sessCount?.[g]?.[thu]?.[buoi] || 0);
  }

  function _optSetSessCount(state, gv, thu, buoi, newCount){
    const g = _optBuoi1Ensure(state, gv);
    if(!g) return;
    const old = Number(state.sessCount[g][thu][buoi] || 0);
    const oldSingle = (old === 1);
    const newSingle = (newCount === 1);

    if(oldSingle && !newSingle){
      state.singleCount[g] = Math.max(0, Number(state.singleCount[g] || 0) - 1);
      state.totalSingles = Math.max(0, Number(state.totalSingles || 0) - 1);
    } else if(!oldSingle && newSingle){
      state.singleCount[g] = Number(state.singleCount[g] || 0) + 1;
      state.totalSingles = Number(state.totalSingles || 0) + 1;
    }

    state.sessCount[g][thu][buoi] = Math.max(0, Number(newCount || 0));
  }

  function _optOccSet(state, gv, thu, buoi, ti, val){
    const g = _optBuoi1Ensure(state, gv);
    if(!g) return;
    const arr = state.occ[g][thu][buoi];
    const old = !!arr[ti];
    const nv = !!val;
    if(old === nv) return;

    arr[ti] = nv;
    const c = _optSessCount(state, g, thu, buoi);
    _optSetSessCount(state, g, thu, buoi, c + (nv ? 1 : -1));
  }

  function _roomKey(room, thu, buoi, ti){
    return `${(room||"").toString().trim()}|${thu}|${buoi}|${ti}`;
  }

  function _optRoomConflict(state, room, thu, buoi, ti, ignoreClassId){
    const r = (room||"").toString().trim();
    if(!r) return false;
    const key = _roomKey(r, thu, buoi, ti);
    const set = state.roomOcc.get(key);
    if(!set || set.size === 0) return false;
    if(set.size === 1 && set.has(String(ignoreClassId))) return false;
    return true;
  }

  function _optRoomMove(state, room, thuFrom, buoiFrom, tiFrom, thuTo, buoiTo, tiTo, classId){
    const r = (room||"").toString().trim();
    if(!r) return;

    const fromKey = _roomKey(r, thuFrom, buoiFrom, tiFrom);
    const toKey   = _roomKey(r, thuTo, buoiTo, tiTo);

    if(fromKey === toKey) return;

    let sFrom = state.roomOcc.get(fromKey);
    if(sFrom){
      sFrom.delete(String(classId));
      if(sFrom.size === 0) state.roomOcc.delete(fromKey);
    }
    let sTo = state.roomOcc.get(toKey);
    if(!sTo){ sTo = new Set(); state.roomOcc.set(toKey, sTo); }
    sTo.add(String(classId));
  }

  function _optRoomSwap(state, roomA, roomB, thu1, buoi1, ti1, thu2, buoi2, ti2, classId){
    if(roomA && roomB && roomA === roomB) return; // cùng phòng: không đổi
    if(roomA) _optRoomMove(state, roomA, thu1, buoi1, ti1, thu2, buoi2, ti2, classId);
    if(roomB) _optRoomMove(state, roomB, thu2, buoi2, ti2, thu1, buoi1, ti1, classId);
  }

  function _optBuildState(){
    const state = {
      occ: {},
      sessCount: {},
      singleCount: {},
      totalSingles: 0,
      slotLesson: new Map(),      // key gv|thu|buoi|ti -> lesson(movable)
      lessonsByTeacher: {},       // gv -> [lesson]
      roomOcc: new Map(),         // key room|thu|buoi|ti -> Set(classId)
      stuck: new Set(),           // key gv|thu|buoi
      rev: (window.__TKB_REV || 0)
    };

    const tkbs = DATA.tkb || {};
    for(const classIdRaw of Object.keys(tkbs)){
      const classId = String(classIdRaw);
      const tkb = tkbs[classId];
      if(!tkb) continue;

      const canon = getLopCanonById(classId);
      for(const thu of DAYS){
        for(const buoi of ["sang","chieu"]){
          const arr = (tkb?.[thu]?.[buoi] || []);
          for(let ti=0; ti<arr.length; ti++){
            const v = arr[ti];
            if(!v || v === "OFF") continue;

            const mon = cellMon(v);
            if(!mon) continue;

            const fixed = isFixed(v);
            const gv = getTeacherForClassMon(canon, mon);
            if(gv){
              const g = _optBuoi1Ensure(state, gv);
              if(g && !state.occ[g][thu][buoi][ti]){
                state.occ[g][thu][buoi][ti] = true;
                state.sessCount[g][thu][buoi] = Number(state.sessCount[g][thu][buoi] || 0) + 1;
              }
              if(g && !fixed){
                const lesson = { teacher: g, classId, canon, thu, buoi, ti, mon };
                if(!state.lessonsByTeacher[g]) state.lessonsByTeacher[g] = [];
                state.lessonsByTeacher[g].push(lesson);
                state.slotLesson.set(`${g}|${thu}|${buoi}|${ti}`, lesson);
              }
            }

            const room = getRoomForClassMon(canon, mon);
            if(room){
              const rk = _roomKey(room, thu, buoi, ti);
              let set = state.roomOcc.get(rk);
              if(!set){ set = new Set(); state.roomOcc.set(rk, set); }
              set.add(classId);
            }
          }
        }
      }
    }

    // tính totalSingles
    for(const gv of Object.keys(state.occ)){
      let sc = 0;
      for(const thu of DAYS){
        for(const buoi of ["sang","chieu"]){
          const c = Number(state.sessCount?.[gv]?.[thu]?.[buoi] || 0);
          if(c === 1) sc++;
        }
      }
      state.singleCount[gv] = sc;
      state.totalSingles += sc;
    }

    return state;
  }

  function _localDeltaSingle(oldCount, newCount){
    return (oldCount === 1 ? 1 : 0) - (newCount === 1 ? 1 : 0);
  }

  function _calcDeltaForTeachers(state, gvA, thu1, buoi1, thu2, buoi2, gvB){
    // gvA: remove at (thu1,buoi1), add at (thu2,buoi2)
    const a1 = _optSessCount(state, gvA, thu1, buoi1);
    const a2 = _optSessCount(state, gvA, thu2, buoi2);
    const deltaA = _localDeltaSingle(a1, a1 - 1) + _localDeltaSingle(a2, a2 + 1);

    let deltaB = 0;
    if(gvB){
      const b1 = _optSessCount(state, gvB, thu1, buoi1);
      const b2 = _optSessCount(state, gvB, thu2, buoi2);
      deltaB = _localDeltaSingle(b1, b1 + 1) + _localDeltaSingle(b2, b2 - 1);
    }
    return { deltaA, deltaB, total: deltaA + deltaB };
  }

  function _pickTeacherWithMostSingles(state){
    let best = null;
    let bestV = 0;
    for(const gv of Object.keys(state.singleCount || {})){
      const v = Number(state.singleCount[gv] || 0);
      if(v > bestV){
        bestV = v;
        best = gv;
      }
    }
    return bestV > 0 ? best : null;
  }

  function _findSingleSession(state, gv){
    const g = (gv||"").toString().trim();
    if(!g) return null;
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        if(_optSessCount(state, g, thu, buoi) !== 1) continue;
        const key = `${g}|${thu}|${buoi}`;
        if(state.stuck.has(key)) continue;
        const arr = state.occ[g][thu][buoi];
        const ti = Array.isArray(arr) ? arr.findIndex(x=>!!x) : -1;
        if(ti < 0) continue;
        const lesson = state.slotLesson.get(`${g}|${thu}|${buoi}|${ti}`) || null; // null nếu tiết cố định
        return { gv: g, thu, buoi, ti, lesson };
      }
    }
    return null;
  }

  function _tryRelocateSingleLesson(state, one){
    // one: {teacher,classId,canon,thu,buoi,ti,mon}
    if(!one || !one.teacher) return false;

    const gvA = one.teacher;
    const classId = one.classId;
    const canon = one.canon || getLopCanonById(classId);
    const tkb = DATA.tkb?.[classId];
    if(!tkb) return false;

    const thu1 = one.thu, buoi1 = one.buoi, ti1 = Number(one.ti);
    const v1 = tkb?.[thu1]?.[buoi1]?.[ti1];
    if(cellMon(v1) !== one.mon) return false;
    if(isFixed(v1)) return false; // chỉ xử lý tiết có thể đổi

    // session targets: nơi gvA đã có >=1 tiết
    const targets = [];
    for(const thu2 of DAYS){
      for(const buoi2 of ["sang","chieu"]){
        if(thu2 === thu1 && buoi2 === buoi1) continue;
        const c = _optSessCount(state, gvA, thu2, buoi2);
        if(c < 1) continue;
        targets.push({ thu: thu2, buoi: buoi2, c });
      }
    }
    targets.sort((a,b)=>a.c - b.c); // ưu tiên c=1 để "ghép đôi" nhanh

    const room1 = getRoomForClassMon(canon, one.mon);

    let best = null;

    for(const t of targets){
      const thu2 = t.thu, buoi2 = t.buoi;
      const arr2 = tkb?.[thu2]?.[buoi2];
      if(!Array.isArray(arr2)) continue;

      const len2 = arr2.length;
      for(let ti2=0; ti2<len2; ti2++){
        const v2 = arr2[ti2];

        // OFF / FIXED không đụng
        if(v2 === "OFF" || isFixed(v2)) continue;

        // GV A phải rảnh tại slot đích
        if(state.occ?.[gvA]?.[thu2]?.[buoi2]?.[ti2]) continue;

        const mon2 = cellMon(v2);
        const gvB = mon2 ? getTeacherForClassMon(canon, mon2) : "";

        // nếu swap: GV B phải rảnh tại slot nguồn + không tạo "buổi dạy 1 tiết" mới
        if(mon2 && gvB){
          if(state.occ?.[gvB]?.[thu1]?.[buoi1]?.[ti1]) continue;
          // Không cho B từ 0 -> 1 (tạo buổi lẻ)
          if(_optSessCount(state, gvB, thu1, buoi1) < 1) continue;
        }

        // phòng học
        const room2 = mon2 ? getRoomForClassMon(canon, mon2) : "";

        // xung đột phòng tại slot đích (cho mon1) / slot nguồn (cho mon2)
        if(room1 && _optRoomConflict(state, room1, thu2, buoi2, ti2, classId)) continue;
        if(mon2 && room2 && _optRoomConflict(state, room2, thu1, buoi1, ti1, classId)) continue;

        // validate subject limit + contiguous trong buổi của lớp
        // giả lập sau khi swap/move
        if(tkb?.[thu2]?.[buoi2]){
          const sessSrc = (tkb?.[thu1]?.[buoi1] || []).slice();
          const sessDst = (tkb?.[thu2]?.[buoi2] || []).slice();

          sessSrc[ti1] = mon2 ? mon2 : "";
          sessDst[ti2] = one.mon;

          const lim1 = getGioiHanBuoiByKhoiMon(extractKhoiNumberByClassId(classId), one.mon) || 99;
          if(!_validateSubjectInSession(sessDst, one.mon, lim1)) continue;

          if(mon2){
            const lim2 = getGioiHanBuoiByKhoiMon(extractKhoiNumberByClassId(classId), mon2) || 99;
            if(!_validateSubjectInSession(sessSrc, mon2, lim2)) continue;
          }
        }

        // tính delta buổi lẻ
        const d = _calcDeltaForTeachers(state, gvA, thu1, buoi1, thu2, buoi2, (mon2 && gvB) ? gvB : null);

        // tiêu chí: A phải tốt lên, B không được xấu đi
        if(d.deltaA <= 0) continue;
        if(d.deltaB < 0) continue;

        const score = d.total * 1000 + (t.c === 1 ? 50 : 0) + (mon2 ? 5 : 10); // ưu tiên move vào ô trống
        if(!best || score > best.score){
          best = { score, thu2, buoi2, ti2, mon2, gvB, room2, delta: d };
          if(d.total >= 2) break; // rất tốt, có thể dừng sớm
        }
      }
      if(best && best.delta.total >= 2) break;
    }

    if(!best) return false;

    const { thu2, buoi2, ti2, mon2, gvB, room2 } = best;

    // APPLY
    if(mon2){
      // swap
      tkb[thu1][buoi1][ti1] = mon2;
      tkb[thu2][buoi2][ti2] = one.mon;

      // update occ + counts
      _optOccSet(state, gvA, thu1, buoi1, ti1, false);
      _optOccSet(state, gvA, thu2, buoi2, ti2, true);

      _optOccSet(state, gvB, thu2, buoi2, ti2, false);
      _optOccSet(state, gvB, thu1, buoi1, ti1, true);

      // update lesson maps
      const keyAOld = `${gvA}|${thu1}|${buoi1}|${ti1}`;
      const keyANew = `${gvA}|${thu2}|${buoi2}|${ti2}`;

      const keyBOld = `${gvB}|${thu2}|${buoi2}|${ti2}`;
      const keyBNew = `${gvB}|${thu1}|${buoi1}|${ti1}`;
      const lessonB = state.slotLesson.get(keyBOld);

      state.slotLesson.delete(keyAOld);
      state.slotLesson.set(keyANew, one);
      one.thu = thu2; one.buoi = buoi2; one.ti = ti2;

      if(lessonB){
        state.slotLesson.delete(keyBOld);
        state.slotLesson.set(keyBNew, lessonB);
        lessonB.thu = thu1; lessonB.buoi = buoi1; lessonB.ti = ti1;
      } else {
        // nếu không tìm thấy (hiếm), rebuild để tránh lệch state
        state.__invalid = true;
      }
} else {
      // move vào ô trống
      tkb[thu1][buoi1][ti1] = "";
      tkb[thu2][buoi2][ti2] = one.mon;

      _optOccSet(state, gvA, thu1, buoi1, ti1, false);
      _optOccSet(state, gvA, thu2, buoi2, ti2, true);

      const keyOld = `${gvA}|${thu1}|${buoi1}|${ti1}`;
      const keyNew = `${gvA}|${thu2}|${buoi2}|${ti2}`;
      state.slotLesson.delete(keyOld);
      state.slotLesson.set(keyNew, one);
      one.thu = thu2; one.buoi = buoi2; one.ti = ti2;
    }

    // update roomOcc
    if(room1){
      if(mon2){
        _optRoomSwap(state, room1, room2, thu1, buoi1, ti1, thu2, buoi2, ti2, classId);
      } else {
        _optRoomMove(state, room1, thu1, buoi1, ti1, thu2, buoi2, ti2, classId);
      }
    } else if(mon2 && room2){
      // chỉ mon2 có phòng
      _optRoomMove(state, room2, thu2, buoi2, ti2, thu1, buoi1, ti1, classId);
    }

    // clear stuck for involved sessions
    state.stuck.delete(`${gvA}|${thu1}|${buoi1}`);
    state.stuck.delete(`${gvA}|${thu2}|${buoi2}`);
    if(gvB){
      state.stuck.delete(`${gvB}|${thu1}|${buoi1}`);
      state.stuck.delete(`${gvB}|${thu2}|${buoi2}`);
    }

    return true;
  }

  function _tryBringLessonIntoSingleSession(state, gv, thuS, buoiS, tiS){
    // Nếu buổi (thuS,buoiS) đang có đúng 1 tiết của gv (có thể fixed), thử kéo 1 tiết khác của gv vào cùng buổi
    const g = (gv||"").toString().trim();
    if(!g) return false;
    if(_optSessCount(state, g, thuS, buoiS) !== 1) return false;

    const freeSlots = [];
    const arrOcc = state.occ?.[g]?.[thuS]?.[buoiS] || [];
    for(let ti=0; ti<arrOcc.length; ti++){
      if(ti === tiS) continue;
      if(!arrOcc[ti]) freeSlots.push(ti);
    }
    if(freeSlots.length === 0) return false;

    const lessons = state.lessonsByTeacher?.[g] || [];
    // ưu tiên nguồn có >=3 tiết để không tạo buổi lẻ mới
    for(const srcLesson of lessons){
      if(!srcLesson) continue;
      if(srcLesson.thu === thuS && srcLesson.buoi === buoiS) continue;

      const cSrc = _optSessCount(state, g, srcLesson.thu, srcLesson.buoi);
      if(cSrc < 3) continue; // strict để đảm bảo giảm thật

      const classId = srcLesson.classId;
      const canon = srcLesson.canon || getLopCanonById(classId);
      const tkb = DATA.tkb?.[classId];
      if(!tkb) continue;

      const thu1 = srcLesson.thu, buoi1 = srcLesson.buoi, ti1 = Number(srcLesson.ti);
      const v1 = tkb?.[thu1]?.[buoi1]?.[ti1];
      if(cellMon(v1) !== srcLesson.mon) continue;
      if(isFixed(v1)) continue;

      const room1 = getRoomForClassMon(canon, srcLesson.mon);

      // thử đặt vào các slot rảnh trong buổi single
      for(const ti2 of freeSlots){
        const v2 = tkb?.[thuS]?.[buoiS]?.[ti2];
        if(v2 === "OFF" || isFixed(v2)) continue;

        // gv đang free tại slot này (đúng vì freeSlots) và các ràng buộc GV khác khi swap
        const mon2 = cellMon(v2);
        const gvB = mon2 ? getTeacherForClassMon(canon, mon2) : "";
        if(mon2 && gvB){
          if(state.occ?.[gvB]?.[thu1]?.[buoi1]?.[ti1]) continue;
          if(_optSessCount(state, gvB, thu1, buoi1) < 1) continue;
          // không cho gvB bị xấu đi
          const b2 = _optSessCount(state, gvB, thuS, buoiS);
          const b1 = _optSessCount(state, gvB, thu1, buoi1);
          // swap sẽ: B +1 ở nguồn, -1 ở đích
          const deltaB = _localDeltaSingle(b1, b1 + 1) + _localDeltaSingle(b2, b2 - 1);
          if(deltaB < 0) continue;
        }

        const room2 = mon2 ? getRoomForClassMon(canon, mon2) : "";

        if(room1 && _optRoomConflict(state, room1, thuS, buoiS, ti2, classId)) continue;
        if(mon2 && room2 && _optRoomConflict(state, room2, thu1, buoi1, ti1, classId)) continue;

        // validate subject limit/contiguous
        const sessSrc = (tkb?.[thu1]?.[buoi1] || []).slice();
        const sessDst = (tkb?.[thuS]?.[buoiS] || []).slice();
        sessSrc[ti1] = mon2 ? mon2 : "";
        sessDst[ti2] = srcLesson.mon;

        const lim1 = getGioiHanBuoiByKhoiMon(extractKhoiNumberByClassId(classId), srcLesson.mon) || 99;
        if(!_validateSubjectInSession(sessDst, srcLesson.mon, lim1)) continue;
        if(mon2){
          const lim2 = getGioiHanBuoiByKhoiMon(extractKhoiNumberByClassId(classId), mon2) || 99;
          if(!_validateSubjectInSession(sessSrc, mon2, lim2)) continue;
        }

        // delta cho gv chính: buổi single (thuS,buoiS) từ 1->2; nguồn >=3 -> >=2 (không tạo single)
        // => cải thiện thật
        // APPLY
        if(mon2){
          tkb[thu1][buoi1][ti1] = mon2;
          tkb[thuS][buoiS][ti2] = srcLesson.mon;

          _optOccSet(state, g, thu1, buoi1, ti1, false);
          _optOccSet(state, g, thuS, buoiS, ti2, true);

          _optOccSet(state, gvB, thuS, buoiS, ti2, false);
          _optOccSet(state, gvB, thu1, buoi1, ti1, true);

          // update slotLesson map (g)
          state.slotLesson.delete(`${g}|${thu1}|${buoi1}|${ti1}`);
          state.slotLesson.set(`${g}|${thuS}|${buoiS}|${ti2}`, srcLesson);
          srcLesson.thu = thuS; srcLesson.buoi = buoiS; srcLesson.ti = ti2;

          // update slotLesson map (gvB) nếu có object
          const lbKeyOld = `${gvB}|${thuS}|${buoiS}|${ti2}`;
          const lb = state.slotLesson.get(lbKeyOld);
          if(lb){
            state.slotLesson.delete(lbKeyOld);
            state.slotLesson.set(`${gvB}|${thu1}|${buoi1}|${ti1}`, lb);
            lb.thu = thu1; lb.buoi = buoi1; lb.ti = ti1;
          } else {
            // nếu không tìm thấy (hiếm), rebuild để tránh lệch state
            state.__invalid = true;
          }

          _optRoomSwap(state, room1, room2, thu1, buoi1, ti1, thuS, buoiS, ti2, classId);
        } else {
          tkb[thu1][buoi1][ti1] = "";
          tkb[thuS][buoiS][ti2] = srcLesson.mon;

          _optOccSet(state, g, thu1, buoi1, ti1, false);
          _optOccSet(state, g, thuS, buoiS, ti2, true);

          state.slotLesson.delete(`${g}|${thu1}|${buoi1}|${ti1}`);
          state.slotLesson.set(`${g}|${thuS}|${buoiS}|${ti2}`, srcLesson);
          srcLesson.thu = thuS; srcLesson.buoi = buoiS; srcLesson.ti = ti2;

          if(room1) _optRoomMove(state, room1, thu1, buoi1, ti1, thuS, buoiS, ti2, classId);
        }

        state.stuck.delete(`${g}|${thuS}|${buoiS}`);
        state.stuck.delete(`${g}|${thu1}|${buoi1}`);
        if(state.__invalid) return true; // sẽ rebuild ở vòng ngoài
        return true;
      }
    }

    return false;
  }

  // Override: tối ưu buổi=1 nhanh
  window.optimizeTeacherScheduleQualityBuoi1 = function(opts){
    const maxSwaps = Math.max(0, Number(opts?.maxSwaps ?? 80));
    const timeBudgetMs = Math.max(0, Number(opts?.timeBudgetMs ?? 0));
    const t0 = Date.now();

    const curRev = (window.__TKB_REV || 0);
    const force = !!opts?.forceRebuild;

    if(force || !__OPT_BUOI1_STATE || __OPT_BUOI1_STATE.rev !== curRev || __OPT_BUOI1_STATE.__invalid){
      __OPT_BUOI1_STATE = _optBuildState();
      __OPT_BUOI1_STATE.rev = curRev;
    }

    const state = __OPT_BUOI1_STATE;
    let swaps = 0;
    let stuckGuard = 0;

    while(swaps < maxSwaps){
      if(__OPT_PANEL_STATE?.cancel) break;
      if(timeBudgetMs > 0 && (Date.now() - t0) >= timeBudgetMs) break;
      if(!state || Number(state.totalSingles || 0) <= 0) break;

      const gv = _pickTeacherWithMostSingles(state);
      if(!gv) break;

      const sess = _findSingleSession(state, gv);
      if(!sess){
        // nếu GV nhiều singles nhưng session bị stuck, thử bỏ stuck để tìm đường khác
        stuckGuard++;
        if(stuckGuard > 10) break;
        state.stuck.forEach(k=>{ if(k.startsWith(gv+"|")) state.stuck.delete(k); });
        continue;
      }

      const kSess = `${sess.gv}|${sess.thu}|${sess.buoi}`;

      let ok = false;
      if(sess.lesson){
        ok = _tryRelocateSingleLesson(state, sess.lesson);
      } else {
        // tiết cố định -> thử kéo 1 tiết khác vào cùng buổi
        ok = _tryBringLessonIntoSingleSession(state, sess.gv, sess.thu, sess.buoi, sess.ti);
      }

      if(state.__invalid){
        // rebuild để tránh lệch mapping
        __OPT_BUOI1_STATE = _optBuildState();
        __OPT_BUOI1_STATE.rev = (window.__TKB_REV || 0);
        __OPT_BUOI1_STATE.__invalid = false;
      }

      if(ok){
        swaps++;
        window.__TKB_REV = (window.__TKB_REV || 0) + 1; // bump nhẹ để state khác tự biết
        state.rev = (window.__TKB_REV || 0);
        state.stuck.delete(kSess);
        stuckGuard = 0;
      } else {
        state.stuck.add(kSess);
        stuckGuard++;
        if(stuckGuard > 40) break;
      }
    }

    return swaps;
  };

})();

async function continueOptimizeFromPanel(){
  if(__OPT_PANEL_STATE.running) return;

  const limitTietBuoi = Number(__OPT_PANEL_STATE.lastK || 0);
  const limitTietTrong = Number(__OPT_PANEL_STATE.lastTrong || 0);
  if(limitTietBuoi <= 0 && limitTietTrong <= 0) return;

  __OPT_PANEL_STATE.running = true;
  __OPT_PANEL_STATE.cancel = false;

  const btnRun = document.getElementById("btnRunOptimize");
  const btnCont = document.getElementById("btnContinueOptimize");
  const btnClose = document.getElementById("btnCloseOptimize");
  const btnStop = document.getElementById("btnStopOptimize");
  if(btnRun) btnRun.disabled = true;
  if(btnCont) btnCont.disabled = true;
  if(btnClose) btnClose.disabled = true;
  if(btnStop){ btnStop.style.display = "inline-block"; btnStop.disabled = false; }

  const startTs = Date.now();
    const remainingMs = Math.max(0, Number(__OPT_PANEL_STATE.remainingMs || 0));
  const passMs = remainingMs > 0 ? Math.min(2500, remainingMs) : 2500;
  const deadlineTs = startTs + passMs;

  let totalSwaps = 0;
  let lastStats = _calcOptimizeCompliance({ limitTietBuoi, limitTietTrong });

  _setOptProgressUI({
    percent: lastStats.percent,
        reached: lastStats.reached,
    elapsedMs: 0,
    totalMs: passMs,
    nSessions: lastStats.nSessions,
    totalTiet: lastStats.totalTiet,
    totalSpan: lastStats.totalSpan,
    badTietBuoi: lastStats.badTietBuoi,
    badTietTrong: lastStats.badTietTrong,
    limitTietBuoi,
    limitTietTrong,
    swaps: 0,
    showBuoi: limitTietBuoi > 0,
    showTrong: limitTietTrong > 0,
    note: "Đang tối ưu (ưu tiên bổ sung & rải đều)..."
  });

  try{
    while(true){
      const now = Date.now();
      const elapsed = now - startTs;
      if(__OPT_PANEL_STATE.cancel) break;
      if(now >= deadlineTs) break;

      const moved = optimizeTeacherScheduleQualityAdvanced({
        limitTietBuoi,
        limitTietTrong,
        spreadWeight: 170,
        maxSwaps: 260,
        maxIters: 650,
        timeBudgetMs: 55
      });

      totalSwaps += (Number(moved)||0);

      lastStats = _calcOptimizeCompliance({ limitTietBuoi, limitTietTrong });
      _setOptProgressUI({
        percent: lastStats.percent,
        reached: lastStats.reached,
        elapsedMs: elapsed,
        totalMs: passMs,
        nSessions: lastStats.nSessions,
        totalTiet: lastStats.totalTiet,
        totalSpan: lastStats.totalSpan,
        badTietBuoi: lastStats.badTietBuoi,
        badTietTrong: lastStats.badTietTrong,
        limitTietBuoi,
        limitTietTrong,
        swaps: totalSwaps,
        showBuoi: limitTietBuoi > 0,
        showTrong: limitTietTrong > 0,
        note: lastStats.reached ? "✔ Đã đạt 100%." : "Đang tối ưu..."
      });

      if(lastStats.reached) break;
      await new Promise(r=>setTimeout(r, 0));
    }
  }catch(e){
    console.error("continueOptimizeFromPanel failed:", e);
  }

  // Thử "bổ sung từ buổi full 5" thêm vài lượt (không hạ tiêu chuẩn)
  if(!lastStats.reached && limitTietBuoi > 0){
    try{
      let rep = 0;
      while(rep < 30 && _safeRepairOnce(limitTietBuoi)){
        rep++;
      }
      lastStats = _calcOptimizeCompliance({ limitTietBuoi, limitTietTrong });
    }catch(e){
      console.error("safeRepair loop failed:", e);
    }
  }

  // render + unlock
  try{ saveStore(); }catch(e){ console.error('saveStore failed', e); }
  try{ renderCurrentView(); }catch(e){ console.error('renderCurrentView failed', e); }
  try{ loadMonList(); }catch(e){ console.error('loadMonList failed', e); }

  if(btnRun) btnRun.disabled = false;
  if(btnClose) btnClose.disabled = false;
  if(btnStop) btnStop.style.display = "none";

  __OPT_PANEL_STATE.running = false;
  __OPT_PANEL_STATE.cancel = false;

  // Update UI cuối
  if(lastStats.reached){
    _hideProblemsInline();
    _hideContinueButton();
    const note = document.getElementById("optProgressNote");
    if(note){
      const skipNote = (limitTietBuoi > 0 && lastStats.skippedTeachers > 0)
        ? ` (bỏ qua ${lastStats.skippedTeachers} GV có tổng tiết < ${limitTietBuoi})`
        : "";
      note.textContent = "✔ Đã đạt 100% theo tiêu chí đang chọn." + skipNote;
    }
    return;
  }

  const problems = _listOptimizeProblems(limitTietBuoi);
  _showProblemsInline(problems, "⚠️ Vẫn còn ca chưa đạt");
  __OPT_PANEL_STATE.nextMode = "spread";
  _setContinueButton("Tối ưu tiếp (ưu tiên bổ sung)");
}



function _buildOptimizeManualLog(limitTietBuoi, limitTietTrong){
  const k = Number(limitTietBuoi || 0);
  const built = _buildTeacherOccAll();
  const occ = built.occ || {};
  const lessons = built.lessons || {};
  const days = DAYS || [];
  const sessions = ["sang","chieu"];

  function _totalOccForTeacher(gv){
    let t = 0;
    for(const thu of days){
      for(const buoi of sessions){
        t += _countTrue(occ?.[gv]?.[thu]?.[buoi] || []);
      }
    }
    return t;
  }

  const lines = [];
  lines.push("=== LOG CA CHƯA ĐẠT (để sửa tay) ===");
  lines.push(`Tiêu chuẩn: >=${k} tiết/buổi, tiết trống <=${limitTietTrong||0}`);
  lines.push("");

  // GV ít tiết
  if(k > 0){
    const low = [];
    for(const gv of Object.keys(occ)){
      const total = _totalOccForTeacher(gv);
      if(total > 0 && total < k) low.push({gv, total});
    }
    if(low.length){
      low.sort((a,b)=>a.total-b.total || String(a.gv).localeCompare(String(b.gv)));
      lines.push("GV ít tiết (không thể đạt tiêu chí, không tính %):");
      for(const it of low.slice(0, 120)){
        lines.push(`- ${it.gv}: tổng ${it.total} tiết (<${k})`);
      }
      if(low.length > 120) lines.push(`... và ${low.length-120} GV khác.`);
      lines.push("");
    }
  }

  // Ca chưa đạt theo tiêu chí tiết/buổi
  for(const gv of Object.keys(occ)){
    if(k > 0){
      const total = _totalOccForTeacher(gv);
      if(total > 0 && total < k) continue;
    }

    for(const thu of days){
      for(const buoi of sessions){
        const arr = (occ[gv]?.[thu]?.[buoi]) || [];
        const count = _countTrue(arr);
        if(count > 0 && count < k){
          lines.push(`- ${gv}: ${thu} ${buoi} có ${count} tiết (<${k})`);
          const list = (lessons[gv]||[]).filter(l => l.thu===thu && l.buoi===buoi);
          if(list.length){
            for(const l of list){
              const key = `${l.classId}|${l.thu}|${l.buoi}|${l.ti}`;
              const mon = l.mon || l.subject || "";
              lines.push(`    • ${key}${mon?(" | "+mon):""}`);
            }
          } else {
            lines.push("    • (không tìm thấy lesson movable – có thể là tiết cứng/fixed)");
          }
        }
      }
    }
  }

  return lines.join("\n");
}

function _toggleCopyLogButton(show){
  const btn = document.getElementById("btnCopyOptimizeLog");
  if(!btn) return;
  btn.style.display = show ? "inline-block" : "none";
  btn.disabled = false;
}
// ===== SAFE AUTO-REPAIR (chỉ sửa chắc chắn, không phá bố cục) =====
// Tiêu chí an toàn:
// - Chỉ thêm tiết vào buổi đang thiếu (fill-up)
// - Chỉ dùng slot trống cùng ngày hoặc cùng GV
// - Không swap dây chuyền
function _safeRepairOnce(limitTietBuoi){
  const k = Number(limitTietBuoi || 0);
  if(!Number.isFinite(k) || k <= 0) return false;

  const built = _buildTeacherOccAll();
  const occ = built.occ || {};
  const lessons = built.lessons || {};
  const tkbs = DATA.tkb || {};

  function _sessCount(gv, thu, buoi){
    return _countTrue(occ?.[gv]?.[thu]?.[buoi] || []);
  }

  function _totalOcc(gv){
    let t = 0;
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        t += _sessCount(gv, thu, buoi);
      }
    }
    return t;
  }

  // GV ít tiết: không cố "đẩy" vì có thể không đủ tiết để đạt tiêu chí
  const totalByGv = {};
  for(const gv of Object.keys(occ)){
    totalByGv[gv] = _totalOcc(gv);
  }

  function _targetSlotsSingle(gv, thuT, buoiT){
    const arr = occ?.[gv]?.[thuT]?.[buoiT] || [];
    const pos = [];
    const empty = [];
    for(let i=0;i<arr.length;i++){
      if(arr[i]) pos.push(i);
      else empty.push(i);
    }
    if(pos.length === 0) return empty; // hiếm
    const minP = Math.min(...pos);
    const maxP = Math.max(...pos);
    const pref = [];
    if(minP-1 >= 0 && !arr[minP-1]) pref.push(minP-1);
    if(maxP+1 < arr.length && !arr[maxP+1]) pref.push(maxP+1);
    const rest = empty.filter(x=>!pref.includes(x))
      .sort((a,b)=> (a-b)); // ưu tiên sớm để kéo về tiết 1-2
    return [...pref, ...rest];
  }

  function _targetStartsDouble(gv, thuT, buoiT){
    const arr = occ?.[gv]?.[thuT]?.[buoiT] || [];
    const starts = [];
    for(let s=0;s<arr.length-1;s++){
      if(!arr[s] && !arr[s+1]) starts.push(s);
    }
    return starts; // đã theo thứ tự sớm -> muộn
  }

  function _isBlockedCell(v){
    return (v === "OFF" || isFixed(v));
  }

  function _wouldCreateViolationForOtherTeacher(gvB, thuSrc, buoiSrc, thuT, buoiT, removeN, addN){
    if(!gvB) return false;
    const totalB = Number(totalByGv[gvB] || 0);
    if(totalB > 0 && totalB < k) return false; // GV ít tiết: không ép theo tiêu chí

    const cT = _sessCount(gvB, thuT, buoiT);
    const cS = _sessCount(gvB, thuSrc, buoiSrc);

    const newT = cT - removeN;
    const newS = cS + addN;

    if(newT > 0 && newT < k) return true;
    if(newS > 0 && newS < k) return true;
    return false;
  }

  function _getGioiHanForLopIdMon(lopId, canon, mon){
    try{
      const khoi = extractKhoiNumberByClassId(lopId);
      const lim = getGioiHanBuoiByKhoiMon(khoi, mon);
      return Number.isFinite(lim) ? lim : 99;
    }catch(e){
      return 99;
    }
  }

  function _validateSwapInClass(lopId, canon, thu1, buoi1, ti1, newMon1, thu2, buoi2, ti2, newMon2){
    const tkb = tkbs?.[lopId];
    if(!tkb) return false;
    const sess1 = (tkb?.[thu1]?.[buoi1] || []).slice();
    const sess2 = (tkb?.[thu2]?.[buoi2] || []).slice();
    sess1[ti1] = newMon1 || "";
    sess2[ti2] = newMon2 || "";
    if(newMon1){
      const lim1 = _getGioiHanForLopIdMon(lopId, canon, newMon1);
      if(!_validateSubjectInSession(sess1, newMon1, lim1)) return false;
    }
    if(newMon2){
      const lim2 = _getGioiHanForLopIdMon(lopId, canon, newMon2);
      if(!_validateSubjectInSession(sess2, newMon2, lim2)) return false;
    }
    return true;
  }

  function _roomOk(lopId, canon, mon, thu, buoi, ti){
    if(!mon) return true;
    const room = getRoomForClassMon(canon, mon);
    if(!room) return true;
    const conflict = findRoomConflictAtSlot(room, thu, buoi, ti, lopId);
    return !conflict;
  }

  // ===== 1) Thử kéo TIẾT ĐÔI từ buổi full 5 sang buổi thiếu =====
  function _tryPullDouble(gv, thuT, buoiT){
    const list = lessons?.[gv] || [];
    if(list.length === 0) return false;

    // map để tìm nhanh lesson theo slot
    const byKey = new Map();
    for(const l of list){
      if(!l) continue;
      byKey.set(`${l.classId}|${l.thu}|${l.buoi}|${l.ti}`, l);
    }

    // target starts (ưu tiên tiết 1-2)
    const targetStarts = _targetStartsDouble(gv, thuT, buoiT);
    if(targetStarts.length === 0) return false;

    for(const l1 of list){
      if(!l1) continue;
      const thuS = l1.thu, buoiS = l1.buoi;
      if(_sessCount(gv, thuS, buoiS) !== 5) continue; // chỉ kéo từ buổi full 5

      const ti1 = Number(l1.ti);
      const ti2 = ti1 + 1;
      if(ti2 >= 5) continue;

      const l2 = byKey.get(`${l1.classId}|${thuS}|${buoiS}|${ti2}`);
      if(!l2) continue;
      if(l2.mon !== l1.mon) continue; // tiết đôi đúng định nghĩa: cùng môn, cùng lớp, liền kề

      const lopId = l1.classId;
      const canon = l1.canon || getLopCanonById(lopId);
      const tkb = tkbs?.[lopId];
      if(!tkb) continue;

      // source cells phải đúng môn & không fixed
      const vS1 = tkb?.[thuS]?.[buoiS]?.[ti1];
      const vS2 = tkb?.[thuS]?.[buoiS]?.[ti2];
      if(_isBlockedCell(vS1) || _isBlockedCell(vS2)) continue;
      if(cellMon(vS1) !== l1.mon || cellMon(vS2) !== l1.mon) continue;

      for(const startT of targetStarts){
        const tiT1 = startT, tiT2 = startT + 1;

        // gv phải rảnh ở 2 slot target
        if((occ?.[gv]?.[thuT]?.[buoiT]?.[tiT1]) || (occ?.[gv]?.[thuT]?.[buoiT]?.[tiT2])) continue;

        const vT1 = tkb?.[thuT]?.[buoiT]?.[tiT1];
        const vT2 = tkb?.[thuT]?.[buoiT]?.[tiT2];
        if(_isBlockedCell(vT1) || _isBlockedCell(vT2)) continue;

        const monB1 = cellMon(vT1) || "";
        const monB2 = cellMon(vT2) || "";
        const gvB1 = monB1 ? getTeacherForClassMon(canon, monB1) : "";
        const gvB2 = monB2 ? getTeacherForClassMon(canon, monB2) : "";

        // GV bị đẩy đi phải rảnh ở slot nguồn tương ứng
        if(gvB1 && occ?.[gvB1]?.[thuS]?.[buoiS]?.[ti1]) continue;
        if(gvB2 && occ?.[gvB2]?.[thuS]?.[buoiS]?.[ti2]) continue;

        // không tạo thêm buổi thiếu mới cho GV khác
        const sameB = gvB1 && gvB2 && (gvB1 === gvB2);
        if(sameB){
          if(_wouldCreateViolationForOtherTeacher(gvB1, thuS, buoiS, thuT, buoiT, 2, 2)) continue;
        } else {
          if(_wouldCreateViolationForOtherTeacher(gvB1, thuS, buoiS, thuT, buoiT, 1, 1)) continue;
          if(_wouldCreateViolationForOtherTeacher(gvB2, thuS, buoiS, thuT, buoiT, 1, 1)) continue;
        }

        // room check
        if(!_roomOk(lopId, canon, l1.mon, thuT, buoiT, tiT1)) continue;
        if(!_roomOk(lopId, canon, l1.mon, thuT, buoiT, tiT2)) continue;
        if(!_roomOk(lopId, canon, monB1, thuS, buoiS, ti1)) continue;
        if(!_roomOk(lopId, canon, monB2, thuS, buoiS, ti2)) continue;

        // subject-limit/contiguous check trong lớp
        const okA = _validateSwapInClass(lopId, canon, thuS, buoiS, ti1, monB1, thuT, buoiT, tiT1, l1.mon);
        if(!okA) continue;
        const okB = _validateSwapInClass(lopId, canon, thuS, buoiS, ti2, monB2, thuT, buoiT, tiT2, l1.mon);
        if(!okB) continue;

        // APPLY (4 cells)
        tkb[thuS][buoiS][ti1] = monB1;
        tkb[thuS][buoiS][ti2] = monB2;
        tkb[thuT][buoiT][tiT1] = l1.mon;
        tkb[thuT][buoiT][tiT2] = l1.mon;

        return true;
      }
    }

    return false;
  }

  // ===== 2) Thử kéo 1 tiết từ buổi full 5/4/3 sang buổi thiếu =====
  function _tryPullSingle(gv, thuT, buoiT){
    const list = lessons?.[gv] || [];
    if(list.length === 0) return false;

    // ưu tiên lấy từ buổi có nhiều tiết hơn (5 -> 4 -> 3)
    const candidates = [];
    for(const l of list){
      if(!l) continue;
      const cSrc = _sessCount(gv, l.thu, l.buoi);
      if(cSrc >= k) candidates.push({l, cSrc});
    }
    candidates.sort((a,b)=> (b.cSrc - a.cSrc) || (Number(a.l.ti)-Number(b.l.ti)));
    if(candidates.length === 0) return false;

    const targetSlots = _targetSlotsSingle(gv, thuT, buoiT);
    if(targetSlots.length === 0) return false;

    for(const it of candidates){
      const l = it.l;
      const lopId = l.classId;
      const canon = l.canon || getLopCanonById(lopId);
      const tkb = tkbs?.[lopId];
      if(!tkb) continue;

      const thuS = l.thu, buoiS = l.buoi, tiS = Number(l.ti);
      if(thuS === thuT && buoiS === buoiT) continue;

      const vS = tkb?.[thuS]?.[buoiS]?.[tiS];
      if(_isBlockedCell(vS)) continue;
      if(cellMon(vS) !== l.mon) continue;

      // chỉ ưu tiên thực sự "đẩy từ full 5" trước
      if(it.cSrc < 5){
        // nếu target thiếu 1 tiết nhưng không còn full 5, vẫn cho phép
        // nhưng tránh tạo buổi thiếu mới: nguồn phải còn >=k sau khi rút (=> cSrc-1 >= k hoặc về 0)
        if((it.cSrc - 1) > 0 && (it.cSrc - 1) < k) continue;
      }

      for(const tiT of targetSlots){
        if(occ?.[gv]?.[thuT]?.[buoiT]?.[tiT]) continue;

        const vT = tkb?.[thuT]?.[buoiT]?.[tiT];
        if(_isBlockedCell(vT)) continue;

        const monB = cellMon(vT) || "";
        const gvB = monB ? getTeacherForClassMon(canon, monB) : "";
        if(gvB && occ?.[gvB]?.[thuS]?.[buoiS]?.[tiS]) continue;

        if(_wouldCreateViolationForOtherTeacher(gvB, thuS, buoiS, thuT, buoiT, 1, 1)) continue;

        if(!_roomOk(lopId, canon, l.mon, thuT, buoiT, tiT)) continue;
        if(!_roomOk(lopId, canon, monB, thuS, buoiS, tiS)) continue;

        const okSwap = _validateSwapInClass(lopId, canon, thuS, buoiS, tiS, monB, thuT, buoiT, tiT, l.mon);
        if(!okSwap) continue;

        // APPLY
        tkb[thuS][buoiS][tiS] = monB;
        tkb[thuT][buoiT][tiT] = l.mon;

        return true;
      }
    }

    return false;
  }

  // ===== Main scan: ưu tiên sửa ca thiếu nặng trước =====
  const candidatesNeed = [];
  for(const gv of Object.keys(occ)){
    const total = Number(totalByGv[gv] || 0);
    if(total <= 0) continue;
    if(total < k) continue; // GV ít tiết: không cố "đẩy"
    for(const thu of DAYS){
      for(const buoi of ["sang","chieu"]){
        const c = _sessCount(gv, thu, buoi);
        if(c > 0 && c < k){
          candidatesNeed.push({gv, thu, buoi, c});
        }
      }
    }
  }
  // thiếu nhiều trước, sau đó ưu tiên buổi có 2 tiết (để lên 3)
  candidatesNeed.sort((a,b)=> (a.c - b.c) || String(a.gv).localeCompare(String(b.gv)));

  for(const need of candidatesNeed){
    const missing = k - need.c;
    if(missing >= 2){
      if(_tryPullDouble(need.gv, need.thu, need.buoi)) return true;
    }
    if(_tryPullSingle(need.gv, need.thu, need.buoi)) return true;
  }

  return false;
}






// ===== HIGHLIGHT Ô LỖI (SAFE) =====
// Không giả định DOM có data-opt-key.
// Nếu không tìm được ô, chỉ scroll theo ngày/buổi và KHÔNG throw lỗi.
window.__OPT_HIGHLIGHT = { timer: null };

function _clearHighlight(){
  document.querySelectorAll('.opt-highlight').forEach(el=>{
    el.classList.remove('opt-highlight');
  });
}

function _highlightByInfo(info){
  _clearHighlight();
  if(!info) return;

  // Thử các selector phổ biến (nếu có)
  const candidates = [
    `[data-gv="${info.gv}"][data-thu="${info.thu}"][data-buoi="${info.buoi}"][data-tiet="${info.ti}"]`,
    `[data-opt-key="${info.key||''}"]`
  ];
  let el = null;
  for(const sel of candidates){
    try{
      el = document.querySelector(sel);
      if(el) break;
    }catch(e){}
  }

  if(el){
    el.classList.add('opt-highlight');
    el.scrollIntoView({behavior:'smooth', block:'center', inline:'center'});
    if(window.__OPT_HIGHLIGHT.timer) clearTimeout(window.__OPT_HIGHLIGHT.timer);
    window.__OPT_HIGHLIGHT.timer = setTimeout(_clearHighlight, 5000);
  } else {
    // Fallback an toàn: scroll theo cột ngày/buổi nếu có
    try{
      const col = document.querySelector(`[data-thu="${info.thu}"][data-buoi="${info.buoi}"]`);
      if(col) col.scrollIntoView({behavior:'smooth', block:'center', inline:'center'});
    }catch(e){}
  }
}

// Gắn click cho danh sách vấn đề (an toàn, không throw)
function _bindProblemClicks(){
  const wrap = document.getElementById("optProblemsWrap");
  if(!wrap) return;
  wrap.querySelectorAll('.opt-problem').forEach(el=>{
    el.onclick = ()=>{
      try{
        const info = {
          gv: el.getAttribute('data-gv'),
          thu: el.getAttribute('data-thu'),
          buoi: el.getAttribute('data-buoi'),
          ti: el.getAttribute('data-tiet'),
          key: el.getAttribute('data-opt-key')
        };
        _highlightByInfo(info);
      }catch(e){
        console.error('highlight failed', e);
      }
    };
  });
}



/* ==============================
   GAP REPAIR v5 – SWAP-BASED (fix dồn tiết/gap khó)
   - limit=1 => gaps < 1  (allowedGaps=0)
   - limit=2 => gaps < 2  (allowedGaps=1)  => vi phạm khi gaps>=2
   Chiến lược:
   1) thử move vào ô trống (nhanh)
   2) nếu không có ô trống: thử swap trong cùng lớp tại slot gap (dùng _canSwapWithinClass)
============================== */
window.__PHANMON_OPS_VERSION = "gaprepair5-swapbased-2026-02-03";

function _allowedGapsFromLimit(limitTietTrong){
  // "dưới N tiết trống" => gaps < N
  // limit=1 => allowed 0; limit=2 => allowed 1
  if(limitTietTrong === 1) return 0;
  if(limitTietTrong === 2) return 1;
  return Infinity;
}

function _attemptMoveOrSwapToFillGap(session, opt){
  const { gv, thu, buoi } = session || {};
  const items = session?.items || [];
  if(!gv || !thu || !buoi || items.length === 0) return false;

  let limitTietTrong = Number(opt?.limitTietTrong || 0);
  if(limitTietTrong > 2) limitTietTrong = 2;
  const allowedGaps = _allowedGapsFromLimit(limitTietTrong);
  if(!Number.isFinite(allowedGaps)) return false;

  // rebuild occupancy + quick lookup (mỗi lần gọi)
  const built = (typeof _buildTeacherOccAllV2 === "function") ? _buildTeacherOccAllV2() : _buildTeacherOccAll();
  const occ = built?.occ || {};
  const slots = occ?.[gv]?.[thu]?.[buoi];
  if(!slots || !slots.length) return false;

  const before = _teacherSessionMetrics(slots);
  if(before.count === 0 || before.totalGaps <= allowedGaps) return false;

  // gap positions between first-last
  let first=-1,last=-1;
  for(let i=0;i<slots.length;i++){ if(slots[i]){ if(first<0) first=i; last=i; } }
  if(first<0 || last<=first) return false;

  const gapPos=[];
  for(let i=first;i<=last;i++){ if(!slots[i]) gapPos.push(i); }
  if(!gapPos.length) return false;

  // 1) MOVE into empty slot (like before) – choose best improvement
  let best = null;
  let bestGaps = before.totalGaps;

  for(const toTi of gapPos){
    // gv must be free at toTi by definition (gap), but re-check
    if(occ?.[gv]?.[thu]?.[buoi]?.[toTi]) continue;

    for(const it of items){
      const fromTi = Number(it.ti);
      if(!Number.isFinite(fromTi) || fromTi === toTi) continue;

      if(!_canPlaceValueAt(it.classId, it.canon, it.mon, thu, buoi, toTi)) continue;

      const tmp = slots.slice();
      tmp[fromTi]=false; tmp[toTi]=true;
      const after = _teacherSessionMetrics(tmp);
      if(after.totalGaps < bestGaps){
        bestGaps = after.totalGaps;
        best = {mode:"move", it, fromTi, toTi, v: it.v};
        if(bestGaps <= allowedGaps) break;
      }
    }
    if(best && bestGaps <= allowedGaps) break;
  }

  if(best && best.mode==="move"){
    const tkb = DATA?.tkb?.[best.it.classId];
    if(!tkb) return false;

    const curFrom = tkb?.[thu]?.[buoi]?.[best.fromTi];
    const curTo   = tkb?.[thu]?.[buoi]?.[best.toTi];
    if(curTo && curTo !== "") return false;
    if(curFrom !== best.v) return false;

    tkb[thu][buoi][best.fromTi] = "";
    tkb[thu][buoi][best.toTi] = best.v;
    return true;
  }

  // 2) SWAP within class to put gv-lesson into gap slot (when slot isn't empty)
  //    Choose a swap that reduces gv gaps, and doesn't break constraints/teacher-room conflicts
  // Rebuild for swap checks (fresh)
  const built2 = (typeof _buildTeacherOccAllV2 === "function") ? _buildTeacherOccAllV2() : _buildTeacherOccAll();
  const occ2 = built2?.occ || {};
  const slots2 = occ2?.[gv]?.[thu]?.[buoi] || [];
  const before2 = _teacherSessionMetrics(slots2);
  if(before2.count===0) return false;

  let bestSwap=null;
  let bestSwapGaps=before2.totalGaps;

  for(const toTi of gapPos){
    if(occ2?.[gv]?.[thu]?.[buoi]?.[toTi]) continue; // gv must be free

    for(const it of items){
      const fromTi = Number(it.ti);
      if(!Number.isFinite(fromTi) || fromTi === toTi) continue;

      const tkb = DATA?.tkb?.[it.classId];
      if(!tkb) continue;

      const vFrom = tkb?.[thu]?.[buoi]?.[fromTi];
      const vTo   = tkb?.[thu]?.[buoi]?.[toTi];
      if(!vFrom || vFrom==="OFF" || isFixed(vFrom)) continue;
      if(!vTo || vTo==="OFF" || isFixed(vTo)) continue; // need something to swap with; empty handled above
      if(vFrom !== it.v) continue;

      const monFrom = cellMon(vFrom);
      const monTo   = cellMon(vTo);
      if(!monFrom || !monTo) continue;

      // class/session subject contiguity & gioihan
      if(typeof _canSwapWithinClass === "function"){
        if(!_canSwapWithinClass(it.classId, it.canon, thu, buoi, fromTi, thu, buoi, toTi, monFrom, monTo)) continue;
      }

      const gvTo = getTeacherForClassMon(it.canon, monTo);
      if(gvTo){
        if(gvTo === gv) continue;
        // gvTo must be free at fromTi (after swap gvTo will teach there)
        if(occ2?.[gvTo]?.[thu]?.[buoi]?.[fromTi]) continue;
      }

      // room conflicts after swap
      const roomFrom = getRoomForClassMon(it.canon, monFrom);
      const roomTo   = getRoomForClassMon(it.canon, monTo);
      if(roomFrom){
        const r = findRoomConflictAtSlot(roomFrom, thu, buoi, toTi, it.classId);
        if(r) continue;
      }
      if(roomTo){
        const r = findRoomConflictAtSlot(roomTo, thu, buoi, fromTi, it.classId);
        if(r) continue;
      }

      // simulate gv gaps
      const tmp = slots2.slice();
      tmp[fromTi]=false; tmp[toTi]=true;
      const after = _teacherSessionMetrics(tmp);

      if(after.totalGaps < bestSwapGaps){
        bestSwapGaps = after.totalGaps;
        bestSwap = { it, fromTi, toTi, vFrom, vTo };
        if(bestSwapGaps <= allowedGaps) break;
      }
    }
    if(bestSwap && bestSwapGaps <= allowedGaps) break;
  }

  if(!bestSwap) return false;

  const tkb = DATA?.tkb?.[bestSwap.it.classId];
  if(!tkb) return false;

  // apply swap
  const curFrom = tkb?.[thu]?.[buoi]?.[bestSwap.fromTi];
  const curTo   = tkb?.[thu]?.[buoi]?.[bestSwap.toTi];
  if(curFrom !== bestSwap.vFrom) return false;
  if(curTo   !== bestSwap.vTo) return false;

  tkb[thu][buoi][bestSwap.fromTi] = bestSwap.vTo;
  tkb[thu][buoi][bestSwap.toTi]   = bestSwap.vFrom;
  return true;
}

// override pack: prioritize true swap-based fill
function _attemptPackTeacherSession(session, opt){
  return _attemptMoveOrSwapToFillGap(session, opt);
}

// override repair: xử lý mạnh tay hơn, quét hết sessions lỗi mỗi vòng
function _repairInvalidLessonsByReshuffle(opt, maxRounds=30){
  let rounds = 0;
  let totalTouchedSessions = 0;

  while(rounds < maxRounds){
    const stats = _calcOptimizeCompliance(opt);
    if(stats?.reached) return { rounds, totalTouchedSessions, stats };

    const sessions = _collectInvalidTeacherSessions(opt);
    if(!sessions || sessions.length === 0) break;

    let touchedThisRound = 0;

    for(const s of sessions){
      // chỉ xử lý phần "tiết trống" trong pass này (buổi lẻ vẫn do engine chính)
      if(!(Number(opt?.limitTietTrong||0) > 0)) break;

      // attempt multiple micro-moves per session to really close gaps
      let moved = false;
      for(let k=0;k<6;k++){
        if(_attemptPackTeacherSession(s, opt)){ moved = true; }
        else break;
      }
      if(moved){
        touchedThisRound++;
        totalTouchedSessions++;
      }
    }

    rounds++;
    if(touchedThisRound === 0) break; // không tiến triển
  }

  const finalStats = _calcOptimizeCompliance(opt);
  return { rounds, totalTouchedSessions, stats: finalStats };
}


/* =========================================================
   PATCH: Ưu tiên GOM buổi dạy (giảm số buổi GV phải đi dạy)
   - Sửa bug: optimizeTeacherScheduleQualityAdvanced trước đây KHÔNG truyền spreadWeight vào opt
   - Cho phép spreadWeight âm (pack), và thêm packWeight (thưởng phi tuyến cho buổi "chưa full")
   ========================================================= */
(function(){
  try{
    // ---- 1) Override score: pack ưu tiên buổi chưa full, giảm buổi lẻ ----
    if(typeof window._teacherSessionMetrics === "function"){
      const __origScore = window._scoreTeacherSessionAdv;

      window._scoreTeacherSessionAdv = function(slots, opt){
        try{
          const m = window._teacherSessionMetrics(slots || []);
          const limBuoi = Number(opt?.limitTietBuoi || 0);
  const uiMinBuoi = _uiMinTietBuoi(opt);
          const limTrong = Number(opt?.limitTietTrong || 0);

          let score = 0;

          // Thưởng: buổi nhiều tiết -> giảm số buổi phải đi dạy
          score += m.count * 10;

          // NEW: thưởng "gom" theo phi tuyến (càng gần full càng được thưởng nhiều)
          const packW = Number(opt?.packWeight || 0); // 0.. (mặc định set ở optimizer)
          if(packW){
            score += packW * (m.count * m.count);
            // thưởng thêm khi sát/full (giáo viên "chưa full" -> ưu tiên bổ sung)
            const sessLen = Array.isArray(slots) ? slots.length : 0;
            if(sessLen > 0){
              if(m.count === sessLen) score += 80;
              else if(m.count === sessLen - 1) score += 35;
              else if(m.count === sessLen - 2) score += 15;
            }
          }

          // Phạt: buổi ít tiết (theo tuỳ chọn)
          const effMinBuoi = _uiMinTietBuoi(opt);
  if(effMinBuoi > 0 && m.count < effMinBuoi){
            score -= 1000;
          }

          // Phạt: tiết trống trong buổi
          if(m.totalGaps > 0){
            if(limTrong === 1){
              score -= 520 * m.totalGaps + 220 * m.maxGap;
            } else if(limTrong === 2){
              score -= 90 * m.totalGaps;
              if(m.totalGaps >= 2) score -= 260 * (m.totalGaps - 1);
              if(m.maxGap >= 2) score -= 280 * (m.maxGap - 1);
            } else if(limTrong === 3){
              score -= 70 * m.totalGaps;
              if(m.totalGaps >= 3) score -= 180 * (m.totalGaps - 2);
              if(m.maxGap >= 3) score -= 200 * (m.maxGap - 2);
            } else {
              score -= 60 * m.totalGaps;
            }
          } else {
            // contiguous bonus
            if(m.count >= 2) score += 35;
          }

          // Spread/Pack theo ngày trong tuần:
          // - spreadWeight > 0: rải đều (phạt lệch)
          // - spreadWeight < 0: gom buổi (thưởng lệch) => giảm số buổi đi dạy
          const spreadW = Number(opt?.spreadWeight || 0);
          if(spreadW !== 0 && opt?.__occGv && opt?.__thu){
            try{
              const occGv = opt.__occGv;
              const days = (typeof DAYS !== "undefined" && Array.isArray(DAYS)) ? DAYS : Object.keys(occGv||{});
              if(days && days.length){
                const counts = days.map(d=>{
                  const o = occGv?.[d] || {};
                  return window._countTrue(o.sang||[]) + window._countTrue(o.chieu||[]);
                });
                const avg = counts.reduce((a,b)=>a+b,0) / (counts.length||1);
                const dayCount = window._countTrue((occGv?.[opt.__thu]?.sang)||[]) + window._countTrue((occGv?.[opt.__thu]?.chieu)||[]);
                // Note: giữ nguyên công thức score -= spreadW * |dayCount-avg|
                // => spreadW âm sẽ thành cộng điểm (ưu tiên gom)
                score -= spreadW * Math.abs(dayCount - avg);
              }
            }catch(_){}
          }

          // fallback: cộng thêm score gốc nếu có (để không mất các tinh chỉnh khác nếu file gốc đã cập nhật)
          if(typeof __origScore === "function"){
            try{
              // tránh double-count: chỉ lấy các phần ngoài spread/pack từ bản gốc (spread=0, pack=0)
              const o2 = Object.assign({}, opt || {});
              o2.spreadWeight = 0; o2.packWeight = 0;
              score += 0.0 * __origScore(slots, o2); // intentionally 0 (giữ để dễ bật khi cần)
            }catch(_){}
          }

          return score;
        }catch(e){
          // fallback
          if(typeof __origScore === "function") return __origScore(slots, opt);
          return 0;
        }
      };
    }

    // ---- 2) Override optimizer advanced: truyền spreadWeight/packWeight vào opt ----
    if(typeof window.optimizeTeacherScheduleQualityAdvanced === "function"){
      const __origOptAdv = window.optimizeTeacherScheduleQualityAdvanced;

      window.optimizeTeacherScheduleQualityAdvanced = function(opts={}){
        // Nếu file gốc đã fix rồi thì wrapper này vẫn OK (chỉ thêm opt fields)
        try{
          const limitTietBuoi = Number(opts.limitTietBuoi ?? 1);
          const limitTietTrong = Number(opts.limitTietTrong ?? 2);
          const scopeClassId = (opts.scopeClassId ?? "").toString();

          const maxSwaps = Number(opts.maxSwaps ?? 120);
          const maxIters = Number(opts.maxIters ?? 600);
          const timeBudgetMs = Math.max(0, Number(opts.timeBudgetMs ?? 0));
          const t0 = timeBudgetMs > 0 ? Date.now() : 0;

          // Pack mặc định: nếu caller truyền spreadWeight dương (đang dùng 170) thì đảo dấu để "gom"
          let spreadWeight = Number(opts.spreadWeight ?? 0);
          if(spreadWeight > 0) spreadWeight = -spreadWeight;

          // PackWeight: tăng nếu user đang bật tiết trống (để đẩy mạnh gom vào buổi "chưa full")
          const packWeight = Number.isFinite(Number(opts.packWeight))
            ? Number(opts.packWeight)
            : (limitTietTrong > 0 ? 2.4 : 1.8);

          let swaps = 0;
          const opt = { limitTietBuoi, limitTietTrong, spreadWeight, packWeight };

          for(let iter=0; iter<maxIters; iter++){
            if(timeBudgetMs > 0 && (Date.now() - t0) >= timeBudgetMs) break;
            if(swaps >= maxSwaps) break;
            try{ if(window.__OPT_PANEL_STATE?.cancel) break; }catch(_){}

            const built = window._buildTeacherOccAll();
            const occ = built.occ;
            const lessons = built.lessons;
            const roomOcc = built.roomOcc;

            opt.__lessons = lessons;
    // HARD-LOCK: khoá GV đạt phân phối target trước khi tối ưu
    if(typeof _buildLockedTeachersByTarget === 'function'){
      _buildLockedTeachersByTarget(opt, lessons, occ);
    }


            let cand = window._findBadSessionLessonsAdv(occ, lessons, opt);
            if(scopeClassId) cand = cand.filter(x => String(x.classId) === String(scopeClassId));
            if(!cand.length) break;

            let improved = false;
            for(const one of cand){
              try{ if(window.__OPT_PANEL_STATE?.cancel) break; }catch(_){}
              if(window._tryImproveLessonAdv(one, occ, roomOcc, opt)){
                swaps++;
                improved = true;
                break;
              }
            }
            if(!improved) break;
          }
          return swaps;
        }catch(e){
          // fallback về bản gốc
          try{ return __origOptAdv(opts); }catch(_){ return 0; }
        }
      };
    }
  }catch(e){
    console.error("[phanmon-ops] packteacher patch failed:", e);
  }
})();



/* =======================
   FULL-N (N=5/4) + NEAR-FULL (+1 ảo) TEACHER LOCK (TEMP PHASE)
   - Mục tiêu: chỉ KHÓA chiến lược cho GV có tổng tiết "đầy buổi"
     + Chuẩn: T % N == 0  (vd 5,10,15,...)
     + Gần đầy: cho phép +1 "tiết ảo" => T % N == N-1 (vd 14,29,34,... khi N=5; hoặc 11,15,... khi N=4)
   - Chỉ khóa khi ĐÃ đạt trạng thái ĐẸP:
     + số buổi = ceil(T / N)
     + các buổi đều PACKED (liền nhau, không gap)
     + và phân phối số tiết đúng mẫu:
         * nếu rem==0: tất cả buổi = N
         * nếu rem==N-1: đúng 1 buổi = N-1, còn lại = N
   - KHÔNG áp dụng cho GV có tiết FIXED (để tránh GV lịch đặc biệt)
   - KHÔNG áp dụng cho GV nằm trong danh sách loại trừ
   Cấu hình:
     DATA.tkbConfig.fullSessionLen = 5 (THCS/THPT) hoặc 4 (tiểu học)
     DATA.tkbConfig.skipAutoFull5Teachers = ["GV01",...]
     DATA.tkbConfig.skipAutoFullTeachers  = ["GV01",...] (alias)
======================= */

function _getFullSessionLen(){
  try{
    const cfg = DATA.tkbConfig || {};
    const v = Number(cfg.fullSessionLen || 0);
    if(Number.isFinite(v) && v >= 2) return Math.floor(v);
  }catch(_){}
  const a = Number(typeof SANG !== "undefined" ? SANG : 0);
  const b = Number(typeof CHIEU !== "undefined" ? CHIEU : 0);
  const m = Math.max(a||0, b||0);
  return (m >= 2 ? m : 5);
}

function _parseSkipTeacherList(){
  const cfg = DATA.tkbConfig || {};
  // tương thích: key cũ và key mới
  let list = cfg.skipAutoFull5Teachers ?? cfg.skipAutoFullTeachers ?? [];
  if(typeof list === "string"){
    list = list.split(",").map(s=>s.trim()).filter(Boolean);
  }
  if(!Array.isArray(list)) list = [];
  return new Set(list.map(x=>String(x).trim().toLowerCase()).filter(Boolean));
}

function _buildFixedTeacherSet(){
  const fixedSet = new Set();
  try{
    const tkbs = DATA.tkb || {};
    for(const lopId of Object.keys(tkbs)){
      const tkb = tkbs[lopId];
      if(!tkb) continue;
      const canon = getLopCanonById(lopId);
      for(const thu of DAYS){
        for(const buoi of ["sang","chieu"]){
          const arr = tkb?.[thu]?.[buoi] || [];
          for(let ti=0; ti<arr.length; ti++){
            const v = arr[ti];
            if(!v || v === "OFF" || !isFixed(v)) continue;
            const mon = cellMon(v);
            if(!mon) continue;
            const gv2 = getTeacherForClassMon(canon, mon);
            if(gv2){
              fixedSet.add(String(gv2).trim().toLowerCase());
            }
          }
        }
      }
    }
  }catch(_){}
  return fixedSet;
}

// Override: mở rộng _computeLockedTeachers với rule FULL-N + NEAR-FULL(+1)
(function(){
  const __orig_computeLockedTeachers = _computeLockedTeachers;
  _computeLockedTeachers = function(occ, k){
    const locked = __orig_computeLockedTeachers(occ, k) || new Set();

    const N = _getFullSessionLen();
    const skip = _parseSkipTeacherList();
    const fixedSet = _buildFixedTeacherSet();

    try{
      for(const gvRaw of Object.keys(occ || {})){
        const gvNorm = _normTeacher(gvRaw);
        if(!gvNorm) continue;

        // loại trừ GV đặc biệt
        if(skip.has(gvNorm)) continue;
        if(fixedSet.has(gvNorm)) continue;

        const T = _teacherTotalOccForTeacher(occ, gvRaw); // tính cả fixed
        if(!T || T <= 0) continue;

        const rem = T % N;
        const isFull = (rem === 0);
        const isNearFull = (rem === (N-1)); // +1 "tiết ảo"

        if(!isFull && !isNearFull) continue;

        const sessions = _collectTeacherSessions(occ, gvRaw);
        if(!sessions.length) continue;

        const expectSessions = Math.ceil(T / N);
        if(sessions.length !== expectSessions) continue;

        // tất cả buổi phải packed (liền nhau)
        const packed = sessions.every(ss =>
          _isPackedSessionSlots(occ?.[gvRaw]?.[ss.thu]?.[ss.buoi] || [])
        );
        if(!packed) continue;

        const counts = sessions.map(s=>Number(s.count||0)).sort((a,b)=>b-a);

        if(isFull){
          // tất cả = N
          if(counts.every(c=>c===N)){
            locked.add(gvNorm);
          }
          continue;
        }

        if(isNearFull){
          // đúng 1 buổi = N-1, còn lại = N
          const cN = counts.filter(c=>c===N).length;
          const cNm1 = counts.filter(c=>c===(N-1)).length;
          if(cNm1 === 1 && cN === (expectSessions - 1)){
            locked.add(gvNorm);
          }
          continue;
        }
      }
    }catch(e){}

    return locked;
  };
})();

console.log("[phanmon-ops] FULL-N + NEAR-FULL(+1) lock enabled (temp phase)");



/* =======================
   FORCE PACK: GV CHIA HẾT FULL-N (TRIỆT ĐỂ)
   - Mục tiêu: nếu GV có tổng tiết T chia hết cho N (mặc định N=5, tiểu học N=4)
     thì cố gắng GOM về đúng T/N buổi, mỗi buổi đúng N tiết liền nhau.
   - Chỉ chạy cho GV "eligible":
     + T % N === 0
     + không có tiết fixed
     + không nằm trong skipAutoFullTeachers
   - Heuristic best-effort: chỉ di chuyển trong phạm vi hoán đổi / dời tiết trong chính lớp đó,
     tôn trọng GV/Phòng/giới hạn môn trong buổi.
======================= */

function _getFullSessionLen(){
  const cfg = DATA.tkbConfig || {};
  const v = Number(cfg.fullSessionLen || cfg.fullN || 5);
  return (Number.isFinite(v) && v >= 2) ? v : 5;
}

function _teacherInSkipAutoFullTeachers(gvRaw){
  const gv = (gvRaw||"").toString().trim().toLowerCase();
  if(!gv) return false;
  const cfg = DATA.tkbConfig || {};
  let list = cfg.skipAutoFullTeachers || cfg.skipAutoFull5Teachers || [];
  if(typeof list === "string"){
    list = list.split(",").map(s=>s.trim()).filter(Boolean);
  }
  if(!Array.isArray(list)) return false;
  return list.map(x=>String(x).trim().toLowerCase()).includes(gv);
}

function _teacherEligibleFullN(occ, gvRaw, N){
  const T = _teacherTotalOccForTeacher(occ, gvRaw);
  if(!T || T % N !== 0) return false;
  if(_teacherHasAnyFixedLesson(gvRaw)) return false;
  if(_teacherInSkipAutoFullTeachers(gvRaw)) return false;
  return true;
}

function _teacherIsPerfectFullN(occ, gvRaw, N){
  const T = _teacherTotalOccForTeacher(occ, gvRaw);
  if(!T || T % N !== 0) return false;
  const expect = T / N;
  const sessions = _collectTeacherSessions(occ, gvRaw);
  if(sessions.length !== expect) return false;
  if(!sessions.every(s=>s.count===N)) return false;
  if(!sessions.every(ss => _isPackedSessionSlots(occ?.[gvRaw]?.[ss.thu]?.[ss.buoi] || []))) return false;
  return true;
}

function _freeIndicesInTeacherSession(occ, gvRaw, thu, buoi){
  const slots = occ?.[gvRaw]?.[thu]?.[buoi] || [];
  const out = [];
  for(let i=0;i<slots.length;i++) if(!slots[i]) out.push(i);
  return out;
}

// Thử di chuyển 1 tiết (lesson) của GV về 1 buổi mục tiêu (thuTo/buoiTo)
// - Ưu tiên move vào ô trống trong lớp, nếu không được thì swap với 1 ô khác trong cùng lớp.
function _tryMoveLessonToTargetSession(lesson, thuTo, buoiTo, built){
  const gvA = (lesson?.teacher||"").toString().trim();
  const classId = lesson?.classId;
  const canon = lesson?.canon || getLopCanonById(classId);
  const thu1 = lesson?.thu, buoi1 = lesson?.buoi, ti1 = Number(lesson?.ti);
  const mon1 = (lesson?.mon||"").toString().trim();
  if(!gvA || !classId || !thu1 || !buoi1 || !Number.isFinite(ti1) || !mon1) return false;

  const tkb = DATA.tkb?.[classId];
  if(!tkb) return false;

  const v1 = tkb?.[thu1]?.[buoi1]?.[ti1];
  if(!v1 || v1==="OFF" || isFixed(v1)) return false;
  if(cellMon(v1) !== mon1) return false;

  // target session array
  const arrT = tkb?.[thuTo]?.[buoiTo];
  if(!Array.isArray(arrT) || !arrT.length) return false;

  const roomOcc = built.roomOcc;
  const occ = built.occ;
  const lessonByKey = built.lessonByKey;

  const room1 = getRoomForClassMon(canon, mon1);
  const lim1 = _getGioihanForLopIdMon(classId, canon, mon1);

  for(let ti2=0; ti2<arrT.length; ti2++){
    // GV phải rảnh ở slot đích
    if(occ?.[gvA]?.[thuTo]?.[buoiTo]?.[ti2]) continue;

    const v2 = arrT[ti2];
    if(v2 === "OFF" || isFixed(v2)) continue;

    // Phòng
    if(room1 && _roomConflictQuick(roomOcc, room1, thuTo, buoiTo, ti2, classId)) continue;

    const mon2 = cellMon(v2);

    if(!mon2){
      // MOVE vào ô trống
      const srcArr = (tkb?.[thu1]?.[buoi1] || []).slice();
      const tarArr = (tkb?.[thuTo]?.[buoiTo] || []).slice();
      srcArr[ti1] = "";
      tarArr[ti2] = mon1;

      if(!_validateSubjectInSession(srcArr, mon1, lim1)) continue;
      if(!_validateSubjectInSession(tarArr, mon1, lim1)) continue;

      // Apply
      tkb[thu1][buoi1][ti1] = "";
      tkb[thuTo][buoiTo][ti2] = mon1;

      // Update lessonByKey (best-effort)
      if(lessonByKey){
        const k1 = `${classId}|${thu1}|${buoi1}|${ti1}`;
        delete lessonByKey[k1];
        lesson.thu = thuTo; lesson.buoi = buoiTo; lesson.ti = ti2;
        lessonByKey[`${classId}|${thuTo}|${buoiTo}|${ti2}`] = lesson;
      }
      return true;
    }

    // SWAP trong cùng lớp (đổi 2 ô)
    const gvB = getTeacherForClassMon(canon, mon2);
    if(!gvB || gvB === gvA) continue;

    // GV B phải rảnh ở slot nguồn
    if(occ?.[gvB]?.[thu1]?.[buoi1]?.[ti1]) continue;

    // phòng môn2 ở slot nguồn
    const room2 = getRoomForClassMon(canon, mon2);
    if(room2 && _roomConflictQuick(roomOcc, room2, thu1, buoi1, ti1, classId)) continue;

    const lim2 = _getGioihanForLopIdMon(classId, canon, mon2);

    if(!_canSwapWithinClass(classId, canon, thu1, buoi1, ti1, thuTo, buoiTo, ti2, mon1, mon2)) continue;

    // Apply swap
    tkb[thu1][buoi1][ti1] = mon2;
    tkb[thuTo][buoiTo][ti2] = mon1;

    // Update lessonByKey if possible
    if(lessonByKey){
      const k1 = `${classId}|${thu1}|${buoi1}|${ti1}`;
      const k2 = `${classId}|${thuTo}|${buoiTo}|${ti2}`;
      const l1 = lessonByKey[k1]; // should be lesson
      const l2 = lessonByKey[k2]; // may exist if movable
      // Only update if both are movable-tracked
      if(l1 && l2){
        delete lessonByKey[k1]; delete lessonByKey[k2];
        const oldThu=l1.thu, oldBuoi=l1.buoi, oldTi=l1.ti;
        l1.thu = thuTo; l1.buoi = buoiTo; l1.ti = ti2;
        l2.thu = oldThu; l2.buoi = oldBuoi; l2.ti = oldTi;
        lessonByKey[`${classId}|${l1.thu}|${l1.buoi}|${l1.ti}`] = l1;
        lessonByKey[`${classId}|${l2.thu}|${l2.buoi}|${l2.ti}`] = l2;
      }
    }
    return true;
  }

  return false;
}

// Pass chính: gom các GV chia hết cho N về full-N
function forcePackTeachersDivisibleByN(opts={}){
  const N = Number(opts.N || _getFullSessionLen());
  const maxMoves = Number(opts.maxMoves ?? 600);
  const maxRounds = Number(opts.maxRounds ?? 12);

  let moves = 0;

  for(let round=0; round<maxRounds; round++){
    if(moves >= maxMoves) break;
    try{ if(__OPT_PANEL_STATE?.cancel) break; }catch(_){ }

    const built = _buildTeacherOccAllV2();
    const occ = built.occ;
    const lessons = built.lessons;

    // danh sách GV eligible
    const gvList = Object.keys(occ || {}).filter(gvRaw => _teacherEligibleFullN(occ, gvRaw, N));

    let changed = false;

    for(const gvRaw of gvList){
      if(moves >= maxMoves) break;

      // nếu đã perfect thì skip
      if(_teacherIsPerfectFullN(occ, gvRaw, N)) continue;

      const T = _teacherTotalOccForTeacher(occ, gvRaw);
      const expectSessions = T / N;

      // chọn session mục tiêu: buổi có nhiều tiết nhất (để gom vào)
      const sessions = _collectTeacherSessions(occ, gvRaw);
      sessions.sort((a,b)=>b.count-a.count);
      const target = sessions[0];
      if(!target) continue;

      // nếu target đã full N nhưng vẫn có buổi khác -> cứ gom vào target (giảm số buổi)
      const thuTo = target.thu, buoiTo = target.buoi;

      // danh sách lesson của GV không nằm ở buổi mục tiêu
      const list = (lessons?.[gvRaw] || []).filter(l => !(l.thu===thuTo && l.buoi===buoiTo));
      // ưu tiên kéo từ buổi ít tiết nhất trước (để xóa buổi)
      list.sort((a,b)=>{
        const ca = _countTrue(occ?.[gvRaw]?.[a.thu]?.[a.buoi] || []);
        const cb = _countTrue(occ?.[gvRaw]?.[b.thu]?.[b.buoi] || []);
        return ca - cb;
      });

      let didOne = false;

      for(const l of list){
        try{ if(__OPT_PANEL_STATE?.cancel) break; }catch(_){ }

        // Nếu buổi mục tiêu không còn slot trống thì không kéo được (đợi vòng sau chọn target khác)
        const freeIdx = _freeIndicesInTeacherSession(occ, gvRaw, thuTo, buoiTo);
        if(!freeIdx.length) break;

        // thử move/swap lesson về buổi mục tiêu
        const ok = _tryMoveLessonToTargetSession(l, thuTo, buoiTo, built);
        if(ok){
          moves += 1;
          didOne = true;
          changed = true;
          break; // rebuild ở round sau để đồng bộ occ/lessons/room
        }
      }

      if(didOne) break; // rebuild toàn bộ ở round sau
    }

    if(!changed) break;
  }

  return moves;
}

(function(){
  // Wrap advanced optimizer: chạy pha gom FULL-N (chỉ GV chia hết cho N) trước khi tối ưu khác
  const __orig_adv = optimizeTeacherScheduleQualityAdvanced;
  optimizeTeacherScheduleQualityAdvanced = function(opts={}){
    try{
      // Chỉ gom cho GV chia hết N, không đụng nhóm khác
      forcePackTeachersDivisibleByN({ N: _getFullSessionLen(), maxMoves: 600, maxRounds: 12 });
    }catch(e){}
    return __orig_adv(opts);
  };

  // Wrap buoi-1 optimizer cũng chạy pha gom trước (an toàn)
  const __orig_buoi1 = optimizeTeacherScheduleQualityBuoi1;
  optimizeTeacherScheduleQualityBuoi1 = function(opts={}){
    try{
      forcePackTeachersDivisibleByN({ N: _getFullSessionLen(), maxMoves: 600, maxRounds: 12 });
    }catch(e){}
    return __orig_buoi1(opts);
  };
})();

console.log("[phanmon-ops] FORCE PACK divisible-by-N enabled (triệt để)");


// ===============================
// PACK & LOCK BY TOTAL LESSONS (theo bàn bạc)
// - Tách tổng tiết T thành các buổi mục tiêu theo phần dư mod 5:
//   r=0: 5-5-...
//   r=4: 5-...-4
//   r=1: ... +3+3 (mượn 2 từ 1 buổi 5 nếu có)  | 6 => 3-3
//   r=2: ... +4+3 (mượn 1 từ 1 buổi 5 nếu có)  | 7 => 4-3
//   r=3: ... +4+4 (mượn 1 từ 1 buổi 5 nếu có)  | 8 => 4-4
// - Sau khi đạt phân phối mục tiêu => hard-lock GV, không cho optimizer "xé" để vá người khác.
// ===============================

function _targetSessionSizesByRemainder(T){
  if(!Number.isFinite(T) || T<=0) return [];
  if(T<=5) return [T];

  const k5 = Math.floor(T/5);
  const r = T % 5;

  // base full 5 blocks
  let sizes = Array(k5).fill(5);

  if(r===0){
    // ok
  }else if(r===4){
    sizes.push(4);
  }else if(r===1){
    if(k5>=1){
      // 5...5 +1 -> 3+3 (mượn 2 từ 1 buổi 5)
      sizes.pop(); // remove one 5
      sizes.push(3,3);
    }else{
      sizes = [3,3]; // T=6
    }
  }else if(r===2){
    if(k5>=1){
      // 5...5 +2 -> 4+3 (mượn 1 từ 1 buổi 5)
      sizes.pop();
      sizes.push(4,3);
    }else{
      sizes = [4,3]; // T=7
    }
  }else if(r===3){
    if(k5>=1){
      // 5...5 +3 -> 4+4 (mượn 1 từ 1 buổi 5)
      sizes.pop();
      sizes.push(4,4);
    }else{
      sizes = [4,4]; // T=8
    }
  }

  // yêu cầu: 16 ưu tiên 5-5-3-3 (đã ra đúng theo r=1,k5=3)
  // sort desc để ưu tiên xếp buổi lớn trước
  sizes.sort((a,b)=>b-a);
  return sizes;
}

function _multisetEqNums(a,b){
  if(!Array.isArray(a)||!Array.isArray(b)) return false;
  if(a.length!==b.length) return false;
  const aa=[...a].sort((x,y)=>x-y);
  const bb=[...b].sort((x,y)=>x-y);
  for(let i=0;i<aa.length;i++) if(aa[i]!==bb[i]) return false;
  return true;
}

function _teacherSessionsFromOcc(occT){
  const out=[];
  if(!occT) return out;
  for(const thu of Object.keys(occT)){
    for(const buoi of Object.keys(occT[thu]||{})){
      const arr = occT[thu][buoi] || [];
      const c = _countTrue(arr);
      if(c>0) out.push({thu,buoi,count:c});
    }
  }
  return out;
}

function _tryMoveOneLesson(teacher, lesson, toThu, toBuoi, built){
  const tkbs = DATA.tkb || {};
  const classId = lesson.classId;
  const mon = lesson.mon;
  const thuS = lesson.thu, buoiS = lesson.buoi, tiS = lesson.ti;

  const tkb = tkbs[classId];
  if(!tkb || !tkb[toThu] || !tkb[toThu][toBuoi]) return false;

  const arrD = tkb[toThu][toBuoi];
  const occ = built.occ || {};
  const roomOcc = built.roomOcc;

  // choose empty slot in dest (MOVE)
  for(let tiD=0; tiD<arrD.length; tiD++){
    const v = arrD[tiD];
    if(v==="OFF" || isFixed(v)) continue;
    if(cellMon(v)) continue;

    if(occ?.[teacher]?.[toThu]?.[toBuoi]?.[tiD]) continue;

    const canon = getLopCanonById(classId);
    const roomName = getRoomForClassMon(canon, mon);
    if(roomName){
      const keyRoom = `${roomName}|${toThu}|${toBuoi}|${tiD}`;
      const cur = roomOcc?.get(keyRoom);
      if(cur && cur.count>0){
        if(String(cur.owner||"") !== String(classId)) continue;
      }
    }

    const arrS = tkb?.[thuS]?.[buoiS];
    if(!arrS) return false;
    const vS = arrS[tiS];
    if(vS==="OFF" || isFixed(vS)) return false;
    if(cellMon(vS) !== mon) return false;

    // apply
    arrS[tiS] = "";
    arrD[tiD] = mon;
    return true;
  }
  // ===== SWAP fallback (khi lớp không còn ô trống ở buổi đích) =====
  // Hoán đổi môn hiện tại của lớp tại ô đích sang ô nguồn, và đưa môn của GV sang ô đích.
  // Điều kiện: cả 2 ô đều movable, GV của môn bị hoán đổi rảnh ở ô nguồn, và phòng hợp lệ.
  const tkbs2 = DATA.tkb || {};
  const arrS2 = tkb?.[thuS]?.[buoiS];
  if(Array.isArray(arrS2)){
    for(let tiD=0; tiD<arrD.length; tiD++){
      const vD = arrD[tiD];
      if(vD==="OFF" || isFixed(vD)) continue;
      const monOther = cellMon(vD);
      if(!monOther) continue; // already handled by MOVE
      if(monOther === mon) continue;

      // our teacher must be free at target slot
      if(occ?.[teacher]?.[toThu]?.[toBuoi]?.[tiD]) continue;

      // teacher of other subject must be free at source slot
      const gvOther = getTeacherForClassMon(getLopCanonById(classId), monOther);
      if(gvOther){
        const gvO = String(gvOther).trim();
        if(gvO && occ?.[gvO]?.[thuS]?.[buoiS]?.[tiS]) continue;
      }

      // room constraints for mon at dest
      const canon = getLopCanonById(classId);
      const roomMon = getRoomForClassMon(canon, mon);
      if(roomMon){
        const keyRoom = `${roomMon}|${toThu}|${toBuoi}|${tiD}`;
        const cur = roomOcc?.get(keyRoom);
        // at dest currently occupied by monOther, roomMon must be free (or owned by this class and will swap out)
        if(cur && cur.count>0 && String(cur.owner||"") !== String(classId)) continue;
      }

      // room constraints for monOther at source
      const roomOther = getRoomForClassMon(getLopCanonById(classId), monOther);
      if(roomOther){
        const keyRoom2 = `${roomOther}|${thuS}|${buoiS}|${tiS}`;
        const cur2 = roomOcc?.get(keyRoom2);
        if(cur2 && cur2.count>0 && String(cur2.owner||"") !== String(classId)) continue;
      }

      // source still has our mon and is movable
      const vS = arrS2[tiS];
      if(vS==="OFF" || isFixed(vS)) continue;
      if(cellMon(vS) !== mon) continue;

      // apply swap
      arrS2[tiS] = monOther;
      arrD[tiD] = mon;
      return true;
    }
  }

  return false;
}

function _repackTeacherToTarget(teacher, opt){
  // PACK theo targetSizesByRemainder(T) bằng MOVE-ONLY (an toàn).
  // Chiến lược:
  //  - Nếu đang nhiều buổi hơn target -> ưu tiên MERGE: chuyển tiết từ buổi nhỏ (1/2/3) vào buổi lớn còn chỗ trống để XÓA buổi nhỏ.
  //  - Nếu số buổi đã đúng nhưng phân phối lệch (vd 5-5-5-3 vs 5-5-4-4) -> BALANCE nhẹ: chuyển 1 tiết từ buổi lớn sang buổi nhỏ (nếu có chỗ trống hợp lệ) để tiệm cận target.
  //  - Đạt target thì hard-lock ngay.
  const built0 = _buildTeacherOccAll();
  const occ0 = built0.occ || {};
  const lessons0 = built0.lessons || {};
  const ls0 = lessons0[teacher] || [];
  const T = ls0.length;
  if(T<=0) return false;

  const target = (typeof _targetSessionSizesByRemainder==="function") ? _targetSessionSizesByRemainder(T) : [];
  if(!target.length) return false;

  function sessionList(occT){
    return _teacherSessionCountsFromOcc(occT).sort((a,b)=>a.count-b.count);
  }
  function lockNow(){
    if(!opt.lockedTeachers) opt.lockedTeachers = new Set();
    opt.lockedTeachers.add(String(teacher));
    try{ window.__HARD_LOCKED_TEACHERS.add(String(teacher)); }catch(e){}
  }
  function countsNow(){
    const built = _buildTeacherOccAll();
    const sess = sessionList(built.occ?.[teacher]);
    
if(percent > 99.999) percent = 100;
if(percentBuoi > 99.999) percentBuoi = 100;
if(percentTrong > 99.999) percentTrong = 100;

return {built, sess, counts: sess.map(x=>x.count)};
  }

  // Nếu đã đạt target -> lock
  const init = countsNow();
  if(typeof _multisetEqNums==="function" && _multisetEqNums(init.counts, target)){
    lockNow();
    return false;
  }

  const maxIter = 200;
  for(let it=0; it<maxIter; it++){
    const cur = countsNow();
    const built = cur.built;
    const occ = built.occ || {};
    const lessons = built.lessons || {};
    const ls = lessons[teacher] || [];
    const sess = cur.sess;
    const counts = cur.counts;

    if(typeof _multisetEqNums==="function" && _multisetEqNums(counts, target)){
      lockNow();
      return true;
    }

    const needMerge = sess.length > target.length;

    // pick destination sessions: largest first, but still <5
    const destSess = [...sess].filter(s=>s.count<5).sort((a,b)=>b.count-a.count);
    // source sessions for merging: smallest first, ưu tiên 1/2/3
    const srcSess = [...sess].filter(s=>s.count>0).sort((a,b)=>a.count-b.count);

    let moved = false;

    if(needMerge){
      // MERGE: move from the smallest session into best destination sessions
      const src = srcSess[0];
      if(!src) return false;
      const srcLessons = ls.filter(l=>String(l.thu)===String(src.thu) && String(l.buoi)===String(src.buoi));
      // try move each lesson of this small session into destinations
      for(const lesson of srcLessons){
        let placed = false;
        for(const d of destSess){
          if(String(d.thu)===String(src.thu) && String(d.buoi)===String(src.buoi)) continue;
          if(_tryMoveOneLesson(teacher, lesson, d.thu, d.buoi, built)){
            moved = true; placed = true; break;
          }
        }
        if(!placed){
          // cannot place this lesson anywhere -> stop merge attempt
          break;
        }
      }
    }else{
      // BALANCE: số buổi đúng nhưng lệch phân phối.
      // Chuyển 1 tiết từ buổi lớn nhất (count>minTarget) sang buổi nhỏ nhất (count<maxTarget) nếu có slot rỗng.
      const tgtSorted = [...target].sort((a,b)=>a-b);
      const minT = tgtSorted[0];
      const maxT = tgtSorted[tgtSorted.length-1];

      const src = [...sess].sort((a,b)=>b.count-a.count).find(s=>s.count>minT);
      const dst = [...sess].sort((a,b)=>a.count-b.count).find(s=>s.count<maxT && s.count<5);

      if(src && dst && !(String(src.thu)===String(dst.thu) && String(src.buoi)===String(dst.buoi))){
        const srcLessons = ls.filter(l=>String(l.thu)===String(src.thu) && String(l.buoi)===String(src.buoi));
        for(const lesson of srcLessons){
          if(_tryMoveOneLesson(teacher, lesson, dst.thu, dst.buoi, built)){
            moved = true;
            break;
          }
        }
      }
    }

    if(!moved) return false;
  }
  return false;
}


// ===== PANEL INLINE FIX STAMP =====
window.__PHANMON_OPS_VERSION = 'panel-inline-fix-2026-03-03';


// ===== COMPLIANCE FIX STAMP =====
window.__PHANMON_OPS_VERSION = 'panel-inline+legacy-compliance-2026-03-03';


// ===== FINAL PATCH STAMP =====
window.__PHANMON_OPS_VERSION = 'final-opt-pack-2026-03-03';


// ===== FINAL COMPLIANCE STAMP =====
window.__PHANMON_OPS_VERSION = 'final-opt-pack+legacy-percent-2026-03-03';


// ===== ROUNDING FIX STAMP =====
window.__PHANMON_OPS_VERSION = 'final-opt-pack+legacy-percent+rounding-2026-03-03';


// ===== TIME LIMIT FIX STAMP =====
window.__PHANMON_OPS_VERSION = 'final-opt-pack+legacy-percent+timelimit-2026-03-03';

/* ===== MERGED HOTFIX (appended) ===== */
/* =========================================================
   phanmon-ops.hotfix.js  (test nhanh - không cần tải file)
   Mục tiêu:
   1) Chuẩn hóa limitTietBuoi: opt.limitTietBuoi = MIN tiết/buổi thực tế (0/2/3/4)
   2) Chuẩn hóa HARD-LOCK theo _normTeacher (không còn lock mà vẫn bị xé)
   3) Đồng bộ lockedTeachers: set chứa cả raw + normalized để mọi chỗ .has() đều đúng
   ========================================================= */
(function(){
  // Ensure _normTeacher exists
  if(typeof window._normTeacher !== "function"){
    window._normTeacher = (x)=> (x==null?"":String(x)).trim().toLowerCase();
  }

  // 1) Fix limitTietBuoi mapping: NO +1 here
  // Quy ước: limitTietBuoi là min tiết/buổi thực tế (0/2/3/4).
  // Guard: nếu ai đó còn truyền 1 (UI cũ) => hiểu là 2.
  window._uiMinTietBuoi = function(opt){
    const v0 = Number(opt?.limitTietBuoi || 0);
    if(!Number.isFinite(v0) || v0 <= 0) return 0;
    const v = Math.round(v0);
    return (v <= 1) ? 2 : v;
  };

  // 2) Ensure global hard lock set exists
  window.__HARD_LOCKED_TEACHERS = window.__HARD_LOCKED_TEACHERS || new Set();

  function addRawAndNorm(set, name){
    const raw = String(name ?? "").trim();
    if(!raw) return;
    set.add(raw);
    set.add(window._normTeacher(raw));
  }

  function normalizeSet(set){
    const out = new Set();
    try{
      if(set && typeof set.forEach === "function"){
        set.forEach((t)=> addRawAndNorm(out, t));
      }
    }catch(e){}
    return out;
  }

  // Normalize existing hard lock set
  window.__HARD_LOCKED_TEACHERS = normalizeSet(window.__HARD_LOCKED_TEACHERS);

  // 3) Fix hard-lock checks: always compare normalized + raw
  window._isHardLockedTeacherName = function(gv){
    try{
      if(!gv) return false;
      const raw = String(gv).trim();
      const key = window._normTeacher(raw);
      const set = window.__HARD_LOCKED_TEACHERS;
      return !!(set && (set.has(raw) || set.has(key)));
    }catch(e){}
    return false;
  };

  window._isTeacherHardLocked = function(opt, teacher){
    try{
      if(!teacher) return false;
      const raw = String(teacher).trim();
      const key = window._normTeacher(raw);
      const set = opt?.lockedTeachers;
      if(set && typeof set.has === "function"){
        return set.has(raw) || set.has(key);
      }
    }catch(e){}
    return false;
  };

  // 4) Wrap buildLockedTeachersByTarget (nếu có) để output luôn raw+norm
  if(typeof window._buildLockedTeachersByTarget === "function"){
    const old = window._buildLockedTeachersByTarget;
    window._buildLockedTeachersByTarget = function(opt, lessonsMap, occ){
      const locked = old(opt, lessonsMap, occ) || new Set();
      const fixed = normalizeSet(locked);
      try{
        if(opt) opt.lockedTeachers = fixed;
        window.__HARD_LOCKED_TEACHERS = fixed;
      }catch(e){}
      return fixed;
    };
  }

  // 5) Nếu code nào đó dựa vào __HARD_LOCKED_TEACHERS.has(raw) thì giờ vẫn đúng
  // vì set chứa cả raw & norm.

  console.log("[phanmon-ops.hotfix] applied", {
    min1: window._uiMinTietBuoi({limitTietBuoi:1}), // expect 2
    min2: window._uiMinTietBuoi({limitTietBuoi:2}), // expect 3
    min3: window._uiMinTietBuoi({limitTietBuoi:3})  // expect 4
  });
})();

(function(){ try{ console.log("[phanmon-ops] merged build merged+hotfix-2026-03-05-43b48000f29f"); }catch(e){} })();



/* =========================================================
   EXTRA PATCH: teacher-pack stability (2026-03-05)
   - Fix _repackTeacherToTarget: remove stray "percent" references (ReferenceError)
   - Improve _teacherMeetsTargetDistribution:
       * T<=5 MUST be 1 session (no longer auto-true)
       * Accept distributions within [minTarget..maxTarget] with correct #sessions (prevents unnecessary "xé")
   - Expand hard-lock: lock teachers that meet target (or near-target) so optimizer won't break them
   - Run a light "remainder pack" pass before advanced optimizer to merge tiny sessions when possible
   ========================================================= */
(function(){
  try{ if(window.__PHANMON_EXTRA_PATCH_20260305) return; }catch(e){}
  try{ window.__PHANMON_EXTRA_PATCH_20260305 = true; }catch(e){}

  // --- helpers ---
  if(typeof window._normTeacher !== "function"){
    window._normTeacher = (x)=> (x==null?"":String(x)).trim().toLowerCase();
  }
  function _addRawNorm(set, name){
    const raw = String(name ?? "").trim();
    if(!raw) return;
    set.add(raw);
    try{ set.add(window._normTeacher(raw)); }catch(e){}
  }
  function _normalizeSet(set){
    const out = new Set();
    try{
      if(set && typeof set.forEach === "function"){
        set.forEach((t)=> _addRawNorm(out, t));
      }
    }catch(e){}
    return out;
  }
  function _eqMultiset(a,b){
    if(typeof window._multisetEqNums === "function") return window._multisetEqNums(a,b);
    if(!Array.isArray(a)||!Array.isArray(b)||a.length!==b.length) return false;
    const aa=[...a].sort((x,y)=>x-y), bb=[...b].sort((x,y)=>x-y);
    for(let i=0;i<aa.length;i++) if(aa[i]!==bb[i]) return false;
    return true;
  }
  function _countsFromOcc(occ, gv){
    const counts=[];
    try{
      for(const thu of (typeof DAYS!=="undefined" && Array.isArray(DAYS) ? DAYS : Object.keys(occ?.[gv]||{}))){
        for(const buoi of ["sang","chieu"]){
          const slots = occ?.[gv]?.[thu]?.[buoi] || [];
          const c = (typeof window._countTrue==="function") ? window._countTrue(slots) : (Array.isArray(slots)?slots.filter(Boolean).length:0);
          if(c>0) counts.push(c);
        }
      }
    }catch(e){}
    return counts;
  }
  function _totalOcc(occ, gv){
    try{
      const counts = _countsFromOcc(occ, gv);
      return counts.reduce((a,b)=>a+b,0);
    }catch(e){
      return 0;
    }
  }
  function _isPackedAndNoTiny(occT){
    try{
      let ok = true;
      for(const dayKey of Object.keys(occT||{})){
        const byBuoi = occT[dayKey] || {};
        for(const buoiKey of Object.keys(byBuoi||{})){
          const slots = byBuoi[buoiKey] || [];
          const mm = (typeof window._teacherSessionMetrics==="function") ? window._teacherSessionMetrics(slots) : {count:0,maxGap:0};
          if(mm.count<=0) continue;
          if(mm.maxGap > 0) ok = false;
          if(mm.count < 2) ok = false; // avoid locking singles (kẹt)
        }
      }
      return ok;
    }catch(e){
      return false;
    }
  }

  // --- 1) Fix teacher-meets-target logic ---
  // Old behavior: T<=5 => true (skip), causes GV ít tiết bị xé mà không được sửa.
  // New behavior: require đúng số buổi tối thiểu + không có buổi quá nhỏ (dựa theo target mod-5).
  window._teacherMeetsTargetDistribution = function(gv, occ, totalGV){
    try{
      const T = Number(totalGV||0);
      if(!Number.isFinite(T) || T<=0) return true;

      const counts = _countsFromOcc(occ, gv);
      if(counts.length === 0) return true; // không dạy

      // target theo remainder (bàn bạc)
      const targetR = (typeof window._targetSessionSizesByRemainder==="function") ? window._targetSessionSizesByRemainder(T) : [];
      if(!targetR.length) return false;

      // Với GV <=5: bắt buộc gom về 1 buổi (targetR=[T])
      if(T <= 5){
        return (counts.length === 1 && counts[0] === T);
      }

      // Nếu match đúng target remainder -> OK
      if(_eqMultiset(counts, targetR)) return true;

      // Cho phép "tương đương tốt": đúng số buổi, không có buổi < minTarget và không có buổi > maxTarget (và <=5)
      // Ví dụ 12 tiết: 4-4-4 vẫn OK dù targetR là 5-4-3 (cùng 3 buổi, min=3, max=5).
      const minT = Math.min(...targetR);
      const maxT = Math.max(...targetR);
      if(counts.length === targetR.length){
        for(const c of counts){
          if(c < minT) return false;
          if(c > 5) return false;
          if(c > maxT) return false;
        }
        const sum = counts.reduce((a,b)=>a+b,0);
        if(sum === T) return true;
      }

      return false;
    }catch(e){
      return false;
    }
  };

  // --- 2) Expand hard-lock builder to include teachers that meet target distribution (or near-target) ---
  // Rationale: _buildLockedTeachersByTarget hiện chỉ khóa theo _targetSessionSizesOptimal,
  // nên 12 tiết dạng 5-4-3 không được lock -> dễ bị optimizer "xé" để vá người khác.
  if(typeof window._buildLockedTeachersByTarget === "function"){
    const _oldBL = window._buildLockedTeachersByTarget;
    window._buildLockedTeachersByTarget = function(opt, lessonsMap, occ){
      const base = _oldBL(opt, lessonsMap, occ) || new Set();
      const fixed = _normalizeSet(base);

      try{
        const map = lessonsMap || {};
        const occAll = occ || {};
        for(const teacher of Object.keys(map)){
          const total = _totalOcc(occAll, teacher);
          if(total <= 0) continue;

          // Only lock if teacher schedule is packed and has no tiny single-session (avoid kẹt optimizer)
          if(!_isPackedAndNoTiny(occAll?.[teacher] || {})) continue;

          if(window._teacherMeetsTargetDistribution && window._teacherMeetsTargetDistribution(teacher, occAll, total)){
            _addRawNorm(fixed, teacher);
          }
        }
      }catch(e){}

      try{
        if(opt) opt.lockedTeachers = fixed;
        window.__HARD_LOCKED_TEACHERS = fixed;
      }catch(e){}
      return fixed;
    };
  }

  // --- 3) Fix _repackTeacherToTarget (remove stray percent vars) ---
  window._repackTeacherToTarget = function(teacher, opt={}, cfg={}){
    try{
      const maxIter = Number(cfg.maxIter || 120);
      const t0 = Date.now();
      const maxMs = Number(cfg.maxMs || 0);

      const built0 = window._buildTeacherOccAll();
      const lessons0 = built0.lessons || {};
      const ls0 = lessons0[teacher] || [];
      const T = ls0.length;
      if(T<=0) return false;

      const target = (typeof window._targetSessionSizesByRemainder==="function") ? window._targetSessionSizesByRemainder(T) : [];
      if(!target.length) return false;

      function sessionList(occT){
        return window._teacherSessionCountsFromOcc(occT).sort((a,b)=>a.count-b.count);
      }
      function lockNow(){
        if(!opt.lockedTeachers) opt.lockedTeachers = new Set();
        _addRawNorm(opt.lockedTeachers, teacher);
        try{
          window.__HARD_LOCKED_TEACHERS = window.__HARD_LOCKED_TEACHERS || new Set();
          _addRawNorm(window.__HARD_LOCKED_TEACHERS, teacher);
        }catch(e){}
      }
      function countsNow(){
        const built = window._buildTeacherOccAll();
        const sess = sessionList(built.occ?.[teacher]);
        return {built, sess, counts: sess.map(x=>x.count)};
      }

      // If already "good enough" -> lock
      const init = countsNow();
      if(_eqMultiset(init.counts, target)){
        lockNow();
        return false;
      }
      if(window._teacherMeetsTargetDistribution && window._teacherMeetsTargetDistribution(teacher, init.built.occ, T)){
        lockNow();
        return false;
      }

      for(let it=0; it<maxIter; it++){
        if(maxMs>0 && (Date.now()-t0)>=maxMs) break;

        const cur = countsNow();
        const built = cur.built;
        const lessons = built.lessons || {};
        const ls = lessons[teacher] || [];
        const sess = cur.sess;
        const counts = cur.counts;

        if(_eqMultiset(counts, target) || (window._teacherMeetsTargetDistribution && window._teacherMeetsTargetDistribution(teacher, built.occ, T))){
          lockNow();
          return true;
        }

        if(sess.length <= 1) break;

        const needMerge = sess.length > target.length || (T<=5 && sess.length>1);

        const destSess = [...sess].filter(s=>s.count<5).sort((a,b)=>b.count-a.count);
        const srcSess  = [...sess].filter(s=>s.count>0).sort((a,b)=>a.count-b.count);

        let moved = false;

        if(needMerge){
          const src = srcSess[0];
          if(!src) break;
          const srcLessons = ls.filter(l=>String(l.thu)===String(src.thu) && String(l.buoi)===String(src.buoi));
          for(const lesson of srcLessons){
            let placed=false;
            for(const d of destSess){
              if(String(d.thu)===String(src.thu) && String(d.buoi)===String(src.buoi)) continue;
              if(window._tryMoveOneLesson && window._tryMoveOneLesson(teacher, lesson, d.thu, d.buoi, built)){
                moved=true; placed=true; break;
              }
            }
            if(!placed) break;
          }
        }else{
          const tgtSorted = [...target].sort((a,b)=>a-b);
          const minT = tgtSorted[0];
          const maxT = tgtSorted[tgtSorted.length-1];

          const src = [...sess].sort((a,b)=>b.count-a.count).find(s=>s.count>minT);
          const dst = [...sess].sort((a,b)=>a.count-b.count).find(s=>s.count<maxT && s.count<5);

          if(src && dst && !(String(src.thu)===String(dst.thu) && String(src.buoi)===String(dst.buoi))){
            const srcLessons = ls.filter(l=>String(l.thu)===String(src.thu) && String(l.buoi)===String(src.buoi));
            for(const lesson of srcLessons){
              if(window._tryMoveOneLesson && window._tryMoveOneLesson(teacher, lesson, dst.thu, dst.buoi, built)){
                moved=true;
                break;
              }
            }
          }
        }

        if(!moved) break;
      }

      return false;
    }catch(e){
      return false;
    }
  };

  // --- 4) Light remainder-pack pass (run before advanced optimizer) ---
  window.forcePackTeachersByRemainder = function(opts={}){
    try{
      const maxMs = Number(opts.maxMs || 1200);
      const maxTeachers = Number(opts.maxTeachers || 120);
      const maxIterPerTeacher = Number(opts.maxIterPerTeacher || 80);

      const t0 = Date.now();
      const built = window._buildTeacherOccAll();
      const occ = built.occ || {};
      const lessons = built.lessons || {};

      let tried=0, changed=0;

      const teachers = Object.keys(lessons||{});
      for(const teacher of teachers){
        if(maxMs>0 && (Date.now()-t0)>=maxMs) break;
        if(tried>=maxTeachers) break;

        const ls = lessons[teacher] || [];
        const T = ls.length;
        if(T<=0) continue;

        const target = (typeof window._targetSessionSizesByRemainder==="function") ? window._targetSessionSizesByRemainder(T) : [];
        if(!target.length) continue;

        const sess = window._teacherSessionCountsFromOcc(occ?.[teacher]);
        const counts = sess.map(s=>s.count);

        // already good enough -> add to locks
        if(window._teacherMeetsTargetDistribution && window._teacherMeetsTargetDistribution(teacher, occ, T)){
          if(!opts.lockedTeachers) opts.lockedTeachers = new Set();
          _addRawNorm(opts.lockedTeachers, teacher);
          try{
            window.__HARD_LOCKED_TEACHERS = window.__HARD_LOCKED_TEACHERS || new Set();
            _addRawNorm(window.__HARD_LOCKED_TEACHERS, teacher);
          }catch(e){}
          continue;
        }

        const minT = Math.min(...target);
        let shouldTry = false;
        if(T<=5){
          shouldTry = (counts.length > 1);
        }else{
          if(counts.length > target.length) shouldTry = true;
          if(counts.some(c=>c>0 && c < minT)) shouldTry = true;
          if(counts.length === target.length){
            if(counts.some(c=>c>0 && c<=2)) shouldTry = true;
          }
        }
        if(!shouldTry) continue;

        tried++;
        const ok = window._repackTeacherToTarget(teacher, opts, {maxIter:maxIterPerTeacher, maxMs: Math.max(0, maxMs - (Date.now()-t0))});
        if(ok) changed++;
      }

      return {tried, changed};
    }catch(e){
      return {tried:0, changed:0, error:String(e?.message||e)};
    }
  };

  // --- 5) Wrap optimizers (idempotent) ---
  function _wrapOnce(fnName){
    try{
      const cur = window[fnName];
      if(typeof cur !== "function") return;
      if(cur.__remainderPackWrapped) return;

      const wrapped = function(opts={}){
        try{
          window.forcePackTeachersByRemainder({maxMs: 1400, maxTeachers: 120, maxIterPerTeacher: 70});
        }catch(e){}
        return cur.call(this, opts);
      };
      wrapped.__remainderPackWrapped = true;
      window[fnName] = wrapped;
    }catch(e){}
  }

  _wrapOnce("optimizeTeacherScheduleQualityAdvanced");
  _wrapOnce("optimizeTeacherScheduleQualityBuoi1");

  console.log("[phanmon-ops] EXTRA PATCH 2026-03-05 applied");
})();



/* =========================================================
   PATCH: Repair teacher overlaps (trùng GV cùng buổi/tiết)
   - Generated: 2026-03-05
   - Strategy:
     1) Quét toàn bộ DATA.tkb, gom các nhóm {GV_norm + slot} có >=2 lớp cùng dạy.
     2) Giữ 1 tiết (ưu tiên fixed, hoặc lớp ít slot trống hơn), các tiết còn lại sẽ MOVE sang ô TRỐNG của chính lớp đó.
     3) Không đụng OFF/fixed. Khi MOVE có kiểm tra:
        - GV rảnh ở slot đích (toàn trường)
        - Phòng rảnh (nếu môn có phòng)
        - Giới hạn & tính liên tục môn trong buổi (validateSubjectInSession)
     4) Ưu tiên slot đích:
        - Cùng buổi (thu+buoi) để hạn chế phá cấu trúc
        - Buổi mà GV đã có tiết (tránh tạo buổi lẻ mới)
        - Slot giúp giảm gap trong buổi của GV (fill gap/adjacent)
   - Auto-run sau: runOptimizeFromPanel / continueOptimizeFromPanel / optimizeTeacherScheduleQualityAdvanced / optimizeTeacherScheduleQualityBuoi1
   ========================================================= */
(function(){
  try{
    if(window.__PHANMON_OVERLAP_REPAIR_APPLIED) return;
    window.__PHANMON_OVERLAP_REPAIR_APPLIED = true;
  }catch(e){}
  try{ window.__PHANMON_OVERLAP_REPAIR_VERSION = "overlap-repair-2026-03-05"; }catch(e){}

  function _safeNormTeacher(gv){
    try{
      if(gv == null) return "";
      const s = String(gv).trim();
      if(!s) return "";
      if(typeof window._normTeacher === "function") return window._normTeacher(s);
      return s.toLowerCase();
    }catch(e){ return ""; }
  }

  function _slotKey(thu, buoi, ti){ return `${thu}|${buoi}|${ti}`; }
  function _roomKey(room, thu, buoi, ti){ return `${room}|${thu}|${buoi}|${ti}`; }

  function _countTeacherInSession(teacherSet, thu, buoi){
    if(!teacherSet) return 0;
    const prefix = `${thu}|${buoi}|`;
    let c = 0;
    for(const k of teacherSet){
      if(typeof k === "string" && k.startsWith(prefix)) c++;
    }
    return c;
  }

  function _parseTiFromSlotKey(k){
    try{
      const parts = String(k||"").split("|");
      const ti = Number(parts[2]);
      return Number.isFinite(ti) ? ti : -1;
    }catch(e){ return -1; }
  }

  function _teacherSessionMetricsSimple(teacherSet, thu, buoi, len){
    // metric đơn giản để ưu tiên fill gap
    const prefix = `${thu}|${buoi}|`;
    const on = new Array(Math.max(0, len|0)).fill(false);
    if(teacherSet){
      for(const k of teacherSet){
        if(typeof k !== "string" || !k.startsWith(prefix)) continue;
        const ti = _parseTiFromSlotKey(k);
        if(ti >= 0 && ti < on.length) on[ti] = true;
      }
    }
    let first = -1, last = -1, count = 0;
    for(let i=0;i<on.length;i++){
      if(on[i]){
        count++;
        if(first<0) first=i;
        last=i;
      }
    }
    let gaps = 0;
    if(count >= 2){
      for(let i=first;i<=last;i++){
        if(!on[i]) gaps++;
      }
    }
    const span = (first>=0 && last>=0) ? (last-first+1) : 0;
    return {count, first, last, gaps, span, on};
  }

  function _classEmptyCount(tkb){
    try{
      let c=0;
      for(const thu of (typeof DAYS!=="undefined" && Array.isArray(DAYS) ? DAYS : Object.keys(tkb||{}))){
        for(const buoi of ["sang","chieu"]){
          const arr = tkb?.[thu]?.[buoi];
          if(!Array.isArray(arr)) continue;
          for(let i=0;i<arr.length;i++){
            const v = arr[i];
            if(v === "OFF") continue;
            if(typeof window.isFixed==="function" && window.isFixed(v)) continue;
            const mon = (typeof window.cellMon==="function") ? window.cellMon(v) : (v?String(v).trim():"");
            if(!mon) c++;
          }
        }
      }
      return c;
    }catch(e){ return 999999; }
  }

  function _getGioihan(lopId, canon, mon){
    try{
      if(typeof window._getGioihanForLopIdMon === "function") return window._getGioihanForLopIdMon(lopId, canon, mon);
      if(typeof window._getGioiHanForLopIdMon === "function") return window._getGioiHanForLopIdMon(lopId, canon, mon);
      return 99;
    }catch(e){ return 99; }
  }

  function _validateSession(arr, mon, lim){
    try{
      if(typeof window._validateSubjectInSession === "function"){
        return !!window._validateSubjectInSession(arr, mon, lim);
      }
      // fallback: không có validator thì coi như hợp lệ
      return true;
    }catch(e){ return false; }
  }

  function _pickKeepIndex(list){
    // ưu tiên FIXED; nếu không có fixed thì giữ lớp ít ô trống hơn (khó move hơn)
    let keep = 0;
    for(let i=0;i<list.length;i++){
      if(list[i]?.fixed){ return i; }
    }
    let best = 0;
    let bestEmpty = Infinity;
    for(let i=0;i<list.length;i++){
      const e = _classEmptyCount(list[i]?.tkb);
      if(e < bestEmpty){
        bestEmpty = e; best = i;
      }
    }
    return best;
  }

  function _moveOne(a, teacherSet, roomCount, opts, logs){
    try{
      const tkb = a.tkb;
      if(!tkb) return false;

      // cell nguồn có thể đã bị thay đổi bởi một move trước đó
      const srcArr0 = tkb?.[a.thu]?.[a.buoi];
      if(!Array.isArray(srcArr0) || srcArr0[a.ti] == null) return false;

      // nếu ô nguồn không còn là môn này nữa -> bỏ qua (coi như đã được xử lý)
      const curMon = (typeof window.cellMon==="function") ? window.cellMon(srcArr0[a.ti]) : String(srcArr0[a.ti]||"").trim();
      if(!curMon || curMon !== a.mon) return true;

      if(srcArr0[a.ti] === "OFF") return false;
      if(typeof window.isFixed==="function" && window.isFixed(srcArr0[a.ti])) return false;

      const days = (typeof DAYS!=="undefined" && Array.isArray(DAYS)) ? DAYS : Object.keys(tkb||{});
      const dayOrder = [a.thu, ...days.filter(d=>d!==a.thu)];
      const buoiOrder = [a.buoi, ...(a.buoi==="sang"?["chieu"]:["sang"])];

      const lim = _getGioihan(a.lopId, a.canon, a.mon);
      const room = a.room;

      let best = null;
      let bestScore = -1e18;

      for(const thu2 of dayOrder){
        for(const buoi2 of buoiOrder){
          const arr2 = tkb?.[thu2]?.[buoi2];
          if(!Array.isArray(arr2) || arr2.length===0) continue;

          const lenSess = arr2.length;
          const preM = _teacherSessionMetricsSimple(teacherSet, thu2, buoi2, lenSess);

          for(let ti2=0; ti2<lenSess; ti2++){
            if(thu2===a.thu && buoi2===a.buoi && ti2===a.ti) continue;

            const v2 = arr2[ti2];
            if(v2 === "OFF") continue;
            if(typeof window.isFixed==="function" && window.isFixed(v2)) continue;

            const mon2 = (typeof window.cellMon==="function") ? window.cellMon(v2) : (v2?String(v2).trim():"");
            if(mon2) continue; // chỉ move vào ô trống

            const slot2 = _slotKey(thu2, buoi2, ti2);
            if(teacherSet && teacherSet.has(slot2)) continue; // GV bận slot đích

            if(room){
              const rk = _roomKey(room, thu2, buoi2, ti2);
              if((roomCount.get(rk)||0) > 0) continue;
            }

            // Validate theo môn trong buổi
            if(thu2===a.thu && buoi2===a.buoi){
              const sess = srcArr0.slice();
              sess[a.ti] = "";
              sess[ti2] = a.mon;
              if(!_validateSession(sess, a.mon, lim)) continue;
            }else{
              const sessSrc = srcArr0.slice();
              sessSrc[a.ti] = "";
              if(!_validateSession(sessSrc, a.mon, lim)) continue;

              const sessDst = arr2.slice();
              sessDst[ti2] = a.mon;
              if(!_validateSession(sessDst, a.mon, lim)) continue;
            }

            // scoring
            let score = 0;

            // ưu tiên cùng buổi
            if(thu2===a.thu && buoi2===a.buoi) score += 1200;
            else if(thu2===a.thu) score += 300;

            // tránh tạo buổi mới cho GV
            const cSess = preM.count;
            if(cSess > 0) score += 240;
            else score -= 220;

            // ưu tiên slot giúp giảm gap của GV trong buổi
            const postOn = preM.on.slice();
            if(ti2>=0 && ti2<postOn.length) postOn[ti2] = true;
            // compute post gaps quickly
            let first=-1,last=-1,count=0;
            for(let i=0;i<postOn.length;i++){ if(postOn[i]){ count++; if(first<0) first=i; last=i; } }
            let gaps=0;
            if(count>=2){
              for(let i=first;i<=last;i++){ if(!postOn[i]) gaps++; }
            }
            const postSpan = (first>=0 && last>=0) ? (last-first+1) : 0;

            // delta gaps: giảm gap thưởng, tăng gap phạt
            score += (preM.gaps - gaps) * 120;
            // delta span: hạn chế kéo dài khoảng
            score -= (postSpan - preM.span) * 12;

            // gần vị trí cũ để ít "xáo" lớp
            score -= Math.abs(ti2 - a.ti) * 3;

            // ưu tiên đứng cạnh block môn cùng tên (trong buổi đích)
            try{
              const left = (ti2-1>=0) ? ((typeof window.cellMon==="function") ? window.cellMon(arr2[ti2-1]) : String(arr2[ti2-1]||"").trim()) : "";
              const right = (ti2+1<lenSess) ? ((typeof window.cellMon==="function") ? window.cellMon(arr2[ti2+1]) : String(arr2[ti2+1]||"").trim()) : "";
              if(left === a.mon) score += 25;
              if(right === a.mon) score += 25;
            }catch(e){}

            if(score > bestScore){
              bestScore = score;
              best = {thu: thu2, buoi: buoi2, ti: ti2};
            }
          }
        }
      }

      if(!best) return false;

      // apply move
      const dstArr = tkb?.[best.thu]?.[best.buoi];
      if(!Array.isArray(dstArr)) return false;

      // re-check destination still empty + not fixed
      const v2n = dstArr[best.ti];
      if(v2n === "OFF") return false;
      if(typeof window.isFixed==="function" && window.isFixed(v2n)) return false;
      const mon2n = (typeof window.cellMon==="function") ? window.cellMon(v2n) : (v2n?String(v2n).trim():"");
      if(mon2n) return false;

      // do it
      srcArr0[a.ti] = "";
      dstArr[best.ti] = a.mon;

      // update teacher set
      if(teacherSet) teacherSet.add(_slotKey(best.thu, best.buoi, best.ti));

      // update room counts
      if(room){
        const oldKey = _roomKey(room, a.thu, a.buoi, a.ti);
        const oldC = (roomCount.get(oldKey)||0) - 1;
        if(oldC > 0) roomCount.set(oldKey, oldC);
        else roomCount.delete(oldKey);

        const newKey = _roomKey(room, best.thu, best.buoi, best.ti);
        roomCount.set(newKey, (roomCount.get(newKey)||0) + 1);
      }

      try{
        logs && logs.push({
          gv: a.gvRaw || a.gvNorm,
          from: {lopId:a.lopId, thu:a.thu, buoi:a.buoi, ti:a.ti},
          to: {lopId:a.lopId, thu:best.thu, buoi:best.buoi, ti:best.ti},
          mon: a.mon
        });
      }catch(e){}

      return true;
    }catch(e){
      return false;
    }
  }

  window.repairTeacherOverlaps = function(opts={}){
    const maxMoves = Number.isFinite(Number(opts.maxMoves)) ? Number(opts.maxMoves) : 800;
    const timeBudgetMs = Number.isFinite(Number(opts.timeBudgetMs)) ? Number(opts.timeBudgetMs) : 1800;
    const t0 = Date.now();

    const tkbs = (typeof DATA!=="undefined" && DATA && DATA.tkb) ? DATA.tkb : {};
    const days = (typeof DAYS!=="undefined" && Array.isArray(DAYS)) ? DAYS : [];
    const sessions = ["sang","chieu"];

    const teacherBusy = new Map(); // gvNorm -> Set(slotKey)
    const roomCount = new Map();   // room|slot -> count
    const conflictMap = new Map(); // gvNorm|slot -> [assignments]
    let scanned = 0;

    // scan all
    for(const lopId of Object.keys(tkbs||{})){
      const tkb = tkbs[lopId];
      if(!tkb) continue;

      const canon = (typeof window.getLopCanonById==="function") ? window.getLopCanonById(lopId) : null;

      const dayList = days.length ? days : Object.keys(tkb||{});
      for(const thu of dayList){
        for(const buoi of sessions){
          const arr = tkb?.[thu]?.[buoi];
          if(!Array.isArray(arr)) continue;

          for(let ti=0; ti<arr.length; ti++){
            const v = arr[ti];
            if(!v || v==="OFF") continue;

            const mon = (typeof window.cellMon==="function") ? window.cellMon(v) : String(v||"").trim();
            if(!mon) continue;

            const gvRaw = (typeof window.getTeacherForClassMon==="function") ? window.getTeacherForClassMon(canon, mon) : "";
            const gvNorm = _safeNormTeacher(gvRaw);
            if(!gvNorm) continue;

            const slot = _slotKey(thu, buoi, ti);
            let set = teacherBusy.get(gvNorm);
            if(!set){ set = new Set(); teacherBusy.set(gvNorm, set); }
            set.add(slot);

            const key = `${gvNorm}|${slot}`;
            let list = conflictMap.get(key);
            if(!list){ list = []; conflictMap.set(key, list); }

            const room = (typeof window.getRoomForClassMon==="function") ? window.getRoomForClassMon(canon, mon) : "";
            if(room){
              const rk = _roomKey(String(room).trim(), thu, buoi, ti);
              roomCount.set(rk, (roomCount.get(rk)||0)+1);
            }

            list.push({
              lopId: String(lopId),
              canon,
              tkb,
              thu, buoi, ti,
              v,
              mon,
              gvRaw: String(gvRaw||"").trim(),
              gvNorm,
              room: room ? String(room).trim() : "",
              fixed: (typeof window.isFixed==="function") ? window.isFixed(v) : false
            });

            scanned++;
          }
        }
      }
    }

    const groups = [];
    for(const list of conflictMap.values()){
      if(list && list.length > 1) groups.push(list);
    }

    const conflicts = groups.length;
    if(conflicts === 0){
      try{
        window.__lastTeacherOverlapRepair = {ts: Date.now(), scanned, conflicts:0, moved:0, unresolved:0};
      }catch(e){}
      return {scanned, conflicts:0, moved:0, unresolved:0};
    }

    // sort: nhóm lớn trước
    groups.sort((a,b)=> (b.length - a.length));

    const logs = [];
    let moved = 0;
    let unresolved = 0;

    for(const list of groups){
      if(timeBudgetMs>0 && (Date.now()-t0)>=timeBudgetMs) break;
      if(maxMoves>0 && moved>=maxMoves) break;

      const keepIdx = _pickKeepIndex(list);

      // teacher set
      const gvNorm = list[0]?.gvNorm;
      const teacherSet = teacherBusy.get(gvNorm);

      for(let i=0;i<list.length;i++){
        if(i===keepIdx) continue;
        if(timeBudgetMs>0 && (Date.now()-t0)>=timeBudgetMs) break;
        if(maxMoves>0 && moved>=maxMoves) break;

        const a = list[i];
        if(!a || a.fixed){ unresolved++; continue; }

        const ok = _moveOne(a, teacherSet, roomCount, opts, logs);
        if(ok) moved++;
        else unresolved++;
      }
    }

    if(moved > 0){
      try{ window.__TKB_REV = (window.__TKB_REV||0) + 1; }catch(e){}
      try{ if(typeof window.saveStore==="function") window.saveStore(); }catch(e){}
      // Không auto-render để tránh giật UI; panel/flow bên ngoài sẽ render sau.
    }

    try{
      window.__lastTeacherOverlapRepair = {ts: Date.now(), scanned, conflicts, moved, unresolved, logs: logs.slice(0,120)};
    }catch(e){}

    try{
      console.log("[phanmon] repairTeacherOverlaps", {scanned, conflicts, moved, unresolved});
    }catch(e){}

    return {scanned, conflicts, moved, unresolved};
  };

  // ===== Wrap to auto-run after optimizers (idempotent) =====
  function _wrapAfter(fnName, isAsync){
    try{
      const cur = window[fnName];
      if(typeof cur !== "function") return;
      if(cur.__afterOverlapWrapped) return;

      const wrapped = isAsync
        ? async function(...args){
            const res = await cur.apply(this, args);
            try{ window.repairTeacherOverlaps({timeBudgetMs: 1800, maxMoves: 800}); }catch(e){}
            return res;
          }
        : function(...args){
            const res = cur.apply(this, args);
            try{ window.repairTeacherOverlaps({timeBudgetMs: 1800, maxMoves: 800}); }catch(e){}
            return res;
          };

      wrapped.__afterOverlapWrapped = true;
      window[fnName] = wrapped;
    }catch(e){}
  }

  _wrapAfter("runOptimizeFromPanel", true);
  _wrapAfter("continueOptimizeFromPanel", true);
  _wrapAfter("optimizeTeacherScheduleQualityAdvanced", false);
  _wrapAfter("optimizeTeacherScheduleQualityBuoi1", false);

  try{
    console.log("[phanmon-ops] OVERLAP REPAIR PATCH 2026-03-05 applied");
  }catch(e){}
})();




/* =========================================================
   FIXPACK4: Collision Guard v4 (2026-03-08)
   - Mục tiêu: loại bỏ triệt để trùng giáo viên (GV dạy 2 lớp cùng 1 tiết)
   - Nguyên tắc: ưu tiên MOVE vào ô trống trong CÙNG LỚP, chỉ SWAP trong lớp khi không có ô trống.
   - Không phá toàn bộ lịch: chỉ đụng đúng các ô gây collision (và ô đích swap/move).
   - Fix bug Set không đủ biểu diễn nhiều lesson cùng 1 slot: dùng teacherSlotCount (đếm số lượng).
   ========================================================= */
(function(){
  try{
    window.__PHANMON_FIXPACK4 = "fixpack4-collisionguard-2026-03-08";
  }catch(e){}

  // (A) Chuẩn hóa output getTeacherForClassMon để giảm nguy cơ tạo collision do mismatch khoảng trắng
  try{
    if(typeof window.getTeacherForClassMon === "function" && !window.getTeacherForClassMon.__fixpack4TrimWrapped){
      const __orig = window.getTeacherForClassMon;
      const __wrapped = function(){
        const r = __orig.apply(this, arguments);
        if(r == null) return r;
        try{
          return String(r).replace(/\s+/g,' ').trim();
        }catch(e){
          return r;
        }
      };
      __wrapped.__fixpack4TrimWrapped = true;
      __wrapped.__orig = __orig;
      window.getTeacherForClassMon = __wrapped;
    }
  }catch(e){}

  function _normKey(x){
    return String(x||"").replace(/\s+/g,' ').trim().toLowerCase();
  }
  function _slotKey(thu, buoi, ti){ return String(thu)+"|"+String(buoi)+"|"+String(ti); }
  function _roomKey(room, thu, buoi, ti){ return String(room)+"|"+_slotKey(thu,buoi,ti); }

  function _cellMonSafe(v){
    try{
      if(typeof window.cellMon === "function") return window.cellMon(v);
    }catch(e){}
    return String(v||"").trim();
  }
  function _isEmptyCell(v){
    if(v == null) return true;
    if(v === "") return true;
    if(v === "OFF") return false;
    try{
      if(typeof window.cellMon === "function") return !_cellMonSafe(v);
    }catch(e){}
    return !String(v).trim();
  }
  function _isFixedCell(v){
    try{ if(typeof window.isFixed === "function") return !!window.isFixed(v); }catch(e){}
    return false;
  }

  function _getLimit(classId, canon, mon){
    try{
      if(typeof window._getGioihanForLopIdMon === "function"){
        return window._getGioihanForLopIdMon(classId, canon, mon);
      }
    }catch(e){}
    return 99;
  }
  function _validateSession(arr, mon, lim){
    try{
      if(typeof window._validateSubjectInSession === "function"){
        return window._validateSubjectInSession(arr, mon, lim);
      }
    }catch(e){}
    return true;
  }

  function _incCountMap(m, key, delta){
    if(!m) return;
    const v = (m.get(key)||0) + delta;
    if(v <= 0) m.delete(key);
    else m.set(key, v);
  }

  function _teacherSlotCountGet(teacherSlotCount, gvNorm, slot){
    const m = teacherSlotCount.get(gvNorm);
    if(!m) return 0;
    return m.get(slot) || 0;
  }
  function _teacherSlotCountInc(teacherSlotCount, gvNorm, slot, delta){
    let m = teacherSlotCount.get(gvNorm);
    if(!m){ m = new Map(); teacherSlotCount.set(gvNorm, m); }
    _incCountMap(m, slot, delta);
  }

  function _scanAll(){
    const tkbs = (typeof window.DATA !== "undefined" && window.DATA && window.DATA.tkb) ? window.DATA.tkb : {};
    const days = (typeof window.DAYS !== "undefined" && Array.isArray(window.DAYS)) ? window.DAYS : [];
    const sessions = ["sang","chieu"];

    const teacherSlotCount = new Map(); // gvNorm -> Map(slot->count)
    const roomSlotCount = new Map();    // room|slot -> count
    const conflictMap = new Map();      // gvNorm|slot -> list(assign)
    let scanned = 0;

    for(const lopId of Object.keys(tkbs||{})){
      const tkb = tkbs[lopId];
      if(!tkb) continue;

      const canon = (typeof window.getLopCanonById === "function") ? window.getLopCanonById(lopId) : null;
      const dayList = days.length ? days : Object.keys(tkb||{});

      for(const thu of dayList){
        for(const buoi of sessions){
          const arr = tkb?.[thu]?.[buoi];
          if(!Array.isArray(arr)) continue;

          for(let ti=0; ti<arr.length; ti++){
            const v = arr[ti];
            if(!v || v === "OFF") continue;

            const mon = _cellMonSafe(v);
            if(!mon) continue;

            const gvRaw = (typeof window.getTeacherForClassMon === "function") ? window.getTeacherForClassMon(canon, mon) : "";
            const gvNorm = _normKey(gvRaw);
            if(!gvNorm) continue;

            const slot = _slotKey(thu, buoi, ti);
            _teacherSlotCountInc(teacherSlotCount, gvNorm, slot, +1);

            const key = gvNorm + "|" + slot;
            let list = conflictMap.get(key);
            if(!list){ list = []; conflictMap.set(key, list); }

            const room = (typeof window.getRoomForClassMon === "function") ? window.getRoomForClassMon(canon, mon) : "";
            const roomStr = room ? String(room).trim() : "";
            if(roomStr){
              _incCountMap(roomSlotCount, _roomKey(roomStr, thu, buoi, ti), +1);
            }

            list.push({
              lopId: String(lopId),
              canon,
              tkb,
              thu, buoi, ti,
              v,
              mon: String(mon).trim(),
              gvRaw: String(gvRaw||"").replace(/\s+/g,' ').trim(),
              gvNorm,
              room: roomStr,
              fixed: _isFixedCell(v)
            });

            scanned++;
          }
        }
      }
    }

    const groups = [];
    for(const list of conflictMap.values()){
      if(list && list.length > 1) groups.push(list);
    }

    // sort groups lớn trước (nếu 3-4 collision cùng slot)
    groups.sort((a,b)=> (b.length - a.length));

    return { scanned, groups, teacherSlotCount, roomSlotCount };
  }

  function _countEmptySlotsInClass(tkb){
    try{
      let c = 0;
      for(const thu of Object.keys(tkb||{})){
        for(const buoi of ["sang","chieu"]){
          const arr = tkb?.[thu]?.[buoi];
          if(!Array.isArray(arr)) continue;
          for(let i=0;i<arr.length;i++){
            const v = arr[i];
            if(v==="OFF" || _isFixedCell(v)) continue;
            if(_isEmptyCell(v)) c++;
          }
        }
      }
      return c;
    }catch(e){
      return 0;
    }
  }

  function _pickKeepIndex(list){
    // ưu tiên fixed; nếu không có fixed thì giữ item thuộc lớp "khó move" (ít ô trống)
    let keep = -1;
    for(let i=0;i<list.length;i++){
      if(list[i]?.fixed){ keep = i; break; }
    }
    if(keep >= 0) return keep;

    let bestI = 0;
    let bestEmpty = 1e18;
    for(let i=0;i<list.length;i++){
      const a = list[i];
      const e = _countEmptySlotsInClass(a?.tkb);
      if(e < bestEmpty){
        bestEmpty = e;
        bestI = i;
      }
    }
    return bestI;
  }

  function _roomFree(roomSlotCount, room, thu, buoi, ti){
    if(!room) return true;
    const k = _roomKey(room, thu, buoi, ti);
    return (roomSlotCount.get(k) || 0) === 0;
  }

  function _moveWithinClass(a, teacherSlotCount, roomSlotCount, opts, logs){
    // Move cell a.v (mon a.mon) within SAME class to an empty slot that teacher is free.
    try{
      const tkb = a.tkb;
      const classId = a.lopId;
      const canon = a.canon;
      const gvNorm = a.gvNorm;

      // nguồn phải còn đúng môn và không fixed
      const vSrc = tkb?.[a.thu]?.[a.buoi]?.[a.ti];
      if(!vSrc || vSrc === "OFF" || _isFixedCell(vSrc)) return false;
      const monSrc = _cellMonSafe(vSrc);
      if(String(monSrc||"").trim() !== String(a.mon||"").trim()) return false;

      const days = (typeof window.DAYS !== "undefined" && Array.isArray(window.DAYS) && window.DAYS.length) ? window.DAYS : Object.keys(tkb||{});
      const sessions = ["sang","chieu"];

      // scan order: ưu tiên cùng thứ/cùng buổi, sau đó cùng thứ/khác buổi, rồi qua ngày khác
      const dayOrder = [];
      if(days && days.length){
        dayOrder.push(a.thu);
        for(const d of days) if(String(d)!==String(a.thu)) dayOrder.push(d);
      }

      function trySlot(thu2, buoi2, ti2){
        const arr2 = tkb?.[thu2]?.[buoi2];
        if(!Array.isArray(arr2)) return false;

        const v2 = arr2[ti2];
        if(v2 === "OFF" || _isFixedCell(v2)) return false;
        if(!_isEmptyCell(v2)) return false;

        const slot2 = _slotKey(thu2, buoi2, ti2);
        if(_teacherSlotCountGet(teacherSlotCount, gvNorm, slot2) > 0) return false;

        // room check
        if(a.room){
          if(!_roomFree(roomSlotCount, a.room, thu2, buoi2, ti2)) return false;
        }

        // validate subject constraints
        const arrS = (tkb?.[a.thu]?.[a.buoi] || []).slice();
        const arrT = (tkb?.[thu2]?.[buoi2] || []).slice();
        arrS[a.ti] = "";
        arrT[ti2] = vSrc;

        const lim = _getLimit(classId, canon, a.mon);
        if(!_validateSession(arrS, a.mon, lim)) return false;
        if(!_validateSession(arrT, a.mon, lim)) return false;

        // APPLY
        tkb[a.thu][a.buoi][a.ti] = "";
        tkb[thu2][buoi2][ti2] = vSrc;

        const oldSlot = _slotKey(a.thu, a.buoi, a.ti);
        _teacherSlotCountInc(teacherSlotCount, gvNorm, oldSlot, -1);
        _teacherSlotCountInc(teacherSlotCount, gvNorm, slot2, +1);

        if(a.room){
          _incCountMap(roomSlotCount, _roomKey(a.room, a.thu, a.buoi, a.ti), -1);
          _incCountMap(roomSlotCount, _roomKey(a.room, thu2, buoi2, ti2), +1);
        }

        try{
          logs && logs.push({kind:"move", gv:a.gvRaw||a.gvNorm, mon:a.mon, from:{lopId:classId, thu:a.thu, buoi:a.buoi, ti:a.ti}, to:{lopId:classId, thu:thu2, buoi:buoi2, ti:ti2}});
        }catch(e){}

        return true;
      }

      // 1) cùng ngày & cùng buổi trước
      for(const thu2 of dayOrder){
        // prefer same buoi first
        const buoiOrder = (String(thu2)===String(a.thu)) ? [a.buoi, (a.buoi==="sang"?"chieu":"sang")] : [a.buoi, (a.buoi==="sang"?"chieu":"sang")];
        for(const buoi2 of buoiOrder){
          const arr2 = tkb?.[thu2]?.[buoi2];
          if(!Array.isArray(arr2)) continue;
          for(let ti2=0; ti2<arr2.length; ti2++){
            if(trySlot(thu2, buoi2, ti2)) return true;
          }
        }
      }

      return false;
    }catch(e){
      return false;
    }
  }

  function _swapWithinClass(a, teacherSlotCount, roomSlotCount, opts, logs){
    // Swap a.v (mon a.mon) with another lesson in SAME class (non-fixed) to resolve collision
    try{
      const tkb = a.tkb;
      const classId = a.lopId;
      const canon = a.canon;

      const vSrc = tkb?.[a.thu]?.[a.buoi]?.[a.ti];
      if(!vSrc || vSrc==="OFF" || _isFixedCell(vSrc)) return false;
      const mon1 = _cellMonSafe(vSrc);
      if(String(mon1||"").trim() !== String(a.mon||"").trim()) return false;

      const gvA = a.gvNorm;
      const slotFrom = _slotKey(a.thu, a.buoi, a.ti);

      const days = (typeof window.DAYS !== "undefined" && Array.isArray(window.DAYS) && window.DAYS.length) ? window.DAYS : Object.keys(tkb||{});
      const sessions = ["sang","chieu"];

      for(const thu2 of days){
        for(const buoi2 of sessions){
          const arr2 = tkb?.[thu2]?.[buoi2];
          if(!Array.isArray(arr2)) continue;

          for(let ti2=0; ti2<arr2.length; ti2++){
            if(String(thu2)===String(a.thu) && String(buoi2)===String(a.buoi) && Number(ti2)===Number(a.ti)) continue;

            const v2 = arr2[ti2];
            if(!v2 || v2==="OFF" || _isFixedCell(v2)) continue;
            if(_isEmptyCell(v2)) continue; // nếu trống thì move đã xử lý rồi

            const mon2 = _cellMonSafe(v2);
            if(!mon2 || String(mon2).trim() === String(mon1).trim()) continue;

            // teacher B
            const gvRawB = (typeof window.getTeacherForClassMon==="function") ? window.getTeacherForClassMon(canon, mon2) : "";
            const gvB = _normKey(gvRawB);
            if(!gvB || gvB === gvA) continue;

            const slotTo = _slotKey(thu2, buoi2, ti2);

            // teacher availability
            if(_teacherSlotCountGet(teacherSlotCount, gvA, slotTo) > 0) continue;
            if(_teacherSlotCountGet(teacherSlotCount, gvB, slotFrom) > 0) continue;

            // room availability
            const room1 = a.room || ((typeof window.getRoomForClassMon==="function") ? window.getRoomForClassMon(canon, mon1) : "");
            const room2 = (typeof window.getRoomForClassMon==="function") ? window.getRoomForClassMon(canon, mon2) : "";
            const r1 = room1 ? String(room1).trim() : "";
            const r2 = room2 ? String(room2).trim() : "";
            if(r1 && r2 && r1 === r2){
              // ok
            }else{
              if(r1 && !_roomFree(roomSlotCount, r1, thu2, buoi2, ti2)) continue;
              if(r2 && !_roomFree(roomSlotCount, r2, a.thu, a.buoi, a.ti)) continue;
            }

            // validate subject constraints using existing helper if possible
            if(typeof window._canSwapWithinClass === "function"){
              if(!window._canSwapWithinClass(classId, canon, a.thu, a.buoi, a.ti, thu2, buoi2, ti2, String(mon1).trim(), String(mon2).trim())) continue;
            }else{
              // fallback validate minimal
              const lim1 = _getLimit(classId, canon, String(mon1).trim());
              const lim2 = _getLimit(classId, canon, String(mon2).trim());
              const arrS = (tkb?.[a.thu]?.[a.buoi] || []).slice();
              const arrT = (tkb?.[thu2]?.[buoi2] || []).slice();
              arrS[a.ti] = v2;
              arrT[ti2] = vSrc;
              if(!_validateSession(arrS, String(mon1).trim(), lim1)) continue;
              if(!_validateSession(arrS, String(mon2).trim(), lim2)) continue;
              if(!_validateSession(arrT, String(mon1).trim(), lim1)) continue;
              if(!_validateSession(arrT, String(mon2).trim(), lim2)) continue;
            }

            // APPLY swap (swap raw cell values to preserve metadata)
            tkb[a.thu][a.buoi][a.ti] = v2;
            tkb[thu2][buoi2][ti2] = vSrc;

            // update teacherSlotCount
            _teacherSlotCountInc(teacherSlotCount, gvA, slotFrom, -1);
            _teacherSlotCountInc(teacherSlotCount, gvA, slotTo, +1);

            _teacherSlotCountInc(teacherSlotCount, gvB, slotTo, -1);
            _teacherSlotCountInc(teacherSlotCount, gvB, slotFrom, +1);

            // update room counts
            if(r1 && r2 && r1 === r2){
              // no change
            }else{
              if(r1){
                _incCountMap(roomSlotCount, _roomKey(r1, a.thu, a.buoi, a.ti), -1);
                _incCountMap(roomSlotCount, _roomKey(r1, thu2, buoi2, ti2), +1);
              }
              if(r2){
                _incCountMap(roomSlotCount, _roomKey(r2, thu2, buoi2, ti2), -1);
                _incCountMap(roomSlotCount, _roomKey(r2, a.thu, a.buoi, a.ti), +1);
              }
            }

            try{
              logs && logs.push({kind:"swap", gvA:a.gvRaw||a.gvNorm, gvB:String(gvRawB||"").trim(), monA:String(mon1).trim(), monB:String(mon2).trim(), at:{lopId:classId}, from:{thu:a.thu,buoi:a.buoi,ti:a.ti}, to:{thu:thu2,buoi:buoi2,ti:ti2}});
            }catch(e){}

            return true;
          }
        }
      }

      return false;
    }catch(e){
      return false;
    }
  }

  // MAIN (multi-pass)
  window.repairTeacherOverlaps = function(opts={}){
    const t0 = Date.now();

    const maxRounds = Number.isFinite(Number(opts.maxRounds)) ? Math.max(1, Number(opts.maxRounds)) : 5;

    // auto-run wrappers trong fixpack3 truyền opts nhỏ -> nâng tối thiểu lên mức mạnh
    const maxMovesMin = 3000;
    const timeBudgetMin = 6000;

    const maxMoves = Number.isFinite(Number(opts.maxMoves)) ? Math.max(maxMovesMin, Number(opts.maxMoves)) : maxMovesMin;
    const timeBudgetMs = Number.isFinite(Number(opts.timeBudgetMs)) ? Math.max(timeBudgetMin, Number(opts.timeBudgetMs)) : timeBudgetMin;

    const allowSwap = (opts.allowSwap !== false);

    let moved = 0;
    let swapped = 0;
    let unresolved = 0;
    let unresolvedFixed = 0;
    let scannedTotal = 0;
    let conflictsTotal = 0;
    const logs = [];

    let roundsUsed = 0;

    for(let round=0; round<maxRounds; round++){
      roundsUsed = round + 1;
      if(timeBudgetMs>0 && (Date.now()-t0) >= timeBudgetMs) break;

      const scan = _scanAll();
      scannedTotal = scan.scanned;
      const groups = scan.groups || [];
      const teacherSlotCount = scan.teacherSlotCount;
      const roomSlotCount = scan.roomSlotCount;

      conflictsTotal = groups.length;
      if(!groups.length) break;

      let changedThisRound = 0;

      for(const list of groups){
        if(timeBudgetMs>0 && (Date.now()-t0) >= timeBudgetMs) break;
        if(maxMoves>0 && (moved+swapped) >= maxMoves) break;

        const keepIdx = _pickKeepIndex(list);

        for(let i=0;i<list.length;i++){
          if(i === keepIdx) continue;
          if(timeBudgetMs>0 && (Date.now()-t0) >= timeBudgetMs) break;
          if(maxMoves>0 && (moved+swapped) >= maxMoves) break;

          const a = list[i];
          if(!a) continue;

          // fixed -> không đụng
          if(a.fixed){
            unresolvedFixed++;
            continue;
          }

          // Try MOVE into empty slot in same class
          if(_moveWithinClass(a, teacherSlotCount, roomSlotCount, opts, logs)){
            moved++;
            changedThisRound++;
            continue;
          }

          // Try SWAP fallback
          if(allowSwap && _swapWithinClass(a, teacherSlotCount, roomSlotCount, opts, logs)){
            swapped++;
            changedThisRound++;
            continue;
          }

          unresolved++;
        }
      }

      if(changedThisRound === 0){
        // không còn khả năng sửa thêm ở mức "không phá lịch"
        break;
      }
    }

    const elapsed = Date.now() - t0;

    if((moved+swapped) > 0){
      try{ window.__TKB_REV = (window.__TKB_REV||0) + 1; }catch(e){}
      try{ if(typeof window.saveStore === "function") window.saveStore(); }catch(e){}
    }

    const result = {
      ts: Date.now(),
      version: window.__PHANMON_FIXPACK4 || "fixpack4",
      roundsUsed,
      elapsedMs: elapsed,
      scanned: scannedTotal,
      conflicts: conflictsTotal,
      moved,
      swapped,
      unresolved,
      unresolvedFixed,
      logs: logs.slice(0, 160)
    };

    try{ window.__lastTeacherOverlapRepair = result; }catch(e){}
    try{ console.log("[phanmon] repairTeacherOverlaps v4", result); }catch(e){}

    return result;
  };

  // Helper quick check (optional)
  window.findTeacherOverlaps = function(){
    try{
      const scan = _scanAll();
      const out = [];
      for(const list of (scan.groups||[])){
        const gv = list[0]?.gvRaw || list[0]?.gvNorm;
        const thu = list[0]?.thu, buoi = list[0]?.buoi, ti = list[0]?.ti;
        out.push({gv, thu, buoi, ti, n: list.length, items: list.map(x=>({lopId:x.lopId, mon:x.mon, fixed:x.fixed}))});
      }
      return out;
    }catch(e){
      return [];
    }
  };

  try{
    console.log("[phanmon-ops] FIXPACK4 COLLISION GUARD applied", window.__PHANMON_FIXPACK4);
  }catch(e){}
})();


/* =========================================================
   POST-OPT OVERLAP REPAIR WRAP (2026-03-09)
   - Bổ sung chạy repairTeacherOverlaps ngay sau các flow chính
   - Giữ thuật toán optimize hiện tại, chỉ thêm pass dọn trùng cuối
   - Ưu tiên move vào ô trống; swap là fallback trong repairTeacherOverlaps v4
   ========================================================= */
(function(){
  try{ window.__PHANMON_POST_OVERLAP_WRAP = 'post-overlap-wrap-2026-03-09'; }catch(e){}

  function _runTeacherOverlapRepairSafe(){
    try{
      if(typeof window.repairTeacherOverlaps !== 'function') return;
      window.repairTeacherOverlaps({
        maxRounds: 8,
        maxMoves: 5000,
        timeBudgetMs: 8000,
        allowSwap: true
      });
    }catch(e){
      try{ console.warn('[phanmon] post overlap repair failed', e); }catch(_){}
    }
  }

  function _wrapAfterFinal(fnName, isAsync){
    try{
      const cur = window[fnName];
      if(typeof cur !== 'function') return;
      if(cur.__postOverlapFinalWrapped) return;

      const wrapped = isAsync
        ? async function(){
            const res = await cur.apply(this, arguments);
            _runTeacherOverlapRepairSafe();
            return res;
          }
        : function(){
            const res = cur.apply(this, arguments);
            _runTeacherOverlapRepairSafe();
            return res;
          };

      try{ Object.defineProperty(wrapped, '__postOverlapFinalWrapped', {value:true}); }
      catch(e){ wrapped.__postOverlapFinalWrapped = true; }
      try{ wrapped.__orig = cur; }catch(e){}
      window[fnName] = wrapped;
    }catch(e){}
  }

  _wrapAfterFinal('sapXepTuDongAll', false);
  _wrapAfterFinal('xepLaiLop', false);
  _wrapAfterFinal('runOptimizeFromPanel', true);
  _wrapAfterFinal('continueOptimizeFromPanel', true);

  try{ console.log('[phanmon-ops] POST OVERLAP WRAP 2026-03-09 applied', window.__PHANMON_POST_OVERLAP_WRAP); }catch(e){}
})();

/* =========================================================
   ARCHITECTURAL OVERLAP FIX (2026-03-09)
   - Ưu tiên tuyệt đối: không trùng giáo viên
   - Repair mode bỏ qua hard-lock/full-lock trong lúc sửa trùng
   - Ưu tiên move/swap theo BLOCK để tránh split-block
   - Hỗ trợ tốt hơn cho ca full / near-full (15,20 tiết)
   ========================================================= */
(function(){
  try{ window.__PHANMON_ARCH_OVERLAP_FIX_20260309 = 'arch-overlap-fix-2026-03-09'; }catch(e){}

  const _DAYS = (typeof DAYS !== 'undefined' && Array.isArray(DAYS)) ? DAYS.slice() : ["T2","T3","T4","T5","T6","T7"];
  const _BUOI = ["sang","chieu"];

  function _arrLen(buoi){
    try{
      return buoi === 'chieu' ? Number(CHIEU||5) : Number(SANG||5);
    }catch(e){ return 5; }
  }
  function _norm(x){ return String(x == null ? '' : x).trim().toLowerCase(); }
  function _sameTeacher(a,b){ return _norm(a) && _norm(a) === _norm(b); }
  function _cloneArr(a, len){ return Array.isArray(a) ? a.slice() : Array(Number(len)||5).fill(''); }
  function _cellMon(v){ try{ return (typeof cellMon === 'function') ? cellMon(v) : ((typeof v === 'string') ? v : ''); }catch(e){ return ''; } }
  function _isFixed(v){ try{ return (typeof isFixed === 'function') ? isFixed(v) : !!(v && typeof v === 'object' && v.fixed); }catch(e){ return false; } }
  function _getCanon(lopId){ try{ return (typeof getLopCanonById === 'function') ? getLopCanonById(lopId) : lopId; }catch(e){ return lopId; } }
  function _teacherFor(lopId, mon){
    try{ return (typeof getTeacherForClassMon === 'function') ? getTeacherForClassMon(_getCanon(lopId), mon) : ''; }
    catch(e){ return ''; }
  }
  function _roomFor(lopId, mon){
    try{ return (typeof getRoomForClassMon === 'function') ? getRoomForClassMon(_getCanon(lopId), mon) : ''; }
    catch(e){ return ''; }
  }
  function _limitFor(lopId, mon){
    try{ return (typeof _getGioihanForLopIdMon === 'function') ? _getGioihanForLopIdMon(lopId, _getCanon(lopId), mon) : 99; }
    catch(e){ return 99; }
  }
  function _validateSession(arr, mon, lim){
    try{ return (typeof _validateSubjectInSession === 'function') ? _validateSubjectInSession(arr, mon, lim) : true; }
    catch(e){ return false; }
  }
  function _teacherFree(gv, thu, buoi, ti, ignoreLopId){
    if(!gv) return true;
    try{
      if(typeof findTeacherConflictAtSlot === 'function') return !findTeacherConflictAtSlot(gv, thu, buoi, ti, ignoreLopId);
    }catch(e){}
    return true;
  }
  function _roomFree(room, thu, buoi, ti, ignoreLopId){
    if(!room) return true;
    try{
      if(typeof findRoomConflictAtSlot === 'function') return !findRoomConflictAtSlot(room, thu, buoi, ti, ignoreLopId);
    }catch(e){}
    return true;
  }
  function _sessionArr(lopId, thu, buoi){
    const tkb = DATA?.tkb?.[lopId];
    return _cloneArr(tkb?.[thu]?.[buoi], _arrLen(buoi));
  }
  function _setSessionArr(lopId, thu, buoi, arr){
    if(!DATA?.tkb?.[lopId]) return;
    if(!DATA.tkb[lopId][thu]) DATA.tkb[lopId][thu] = {};
    DATA.tkb[lopId][thu][buoi] = arr.slice();
    try{ if(typeof window.__tkbReapplyAllUserOffLocks === 'function') window.__tkbReapplyAllUserOffLocks(); }catch(e){}
  }
  function _findBlock(arr, ti, mon){
    if(!Array.isArray(arr) || !mon || !Number.isFinite(Number(ti))) return null;
    const idx = Number(ti);
    if(_cellMon(arr[idx]) !== mon) return null;
    let s = idx, e = idx;
    while(s-1 >= 0 && _cellMon(arr[s-1]) === mon) s--;
    while(e+1 < arr.length && _cellMon(arr[e+1]) === mon) e++;
    return {start:s, end:e, len:e-s+1};
  }
  function _blockCells(arr, block){
    const out = [];
    for(let i=block.start;i<=block.end;i++) out.push(arr[i]);
    return out;
  }
  function _allLessons(){
    const out = [];
    const all = DATA?.tkb || {};
    for(const lopId of Object.keys(all)){
      const tkb = all[lopId] || {};
      for(const thu of _DAYS){
        for(const buoi of _BUOI){
          const arr = tkb?.[thu]?.[buoi] || [];
          for(let ti=0; ti<arr.length; ti++){
            const v = arr[ti];
            const mon = _cellMon(v);
            if(!mon) continue;
            const gv = _teacherFor(lopId, mon);
            if(!gv) continue;
            out.push({lopId, thu, buoi, ti, v, mon, gv, fixed:_isFixed(v)});
          }
        }
      }
    }
    return out;
  }
  function _scanGroups(){
    const map = new Map();
    for(const it of _allLessons()){
      const key = [_norm(it.gv), it.thu, it.buoi, it.ti].join('|');
      if(!map.has(key)) map.set(key, []);
      map.get(key).push(it);
    }
    return Array.from(map.values()).filter(g => g.length > 1);
  }
  function _scoreItemDifficulty(item){
    try{
      const arr = _sessionArr(item.lopId, item.thu, item.buoi);
      const block = _findBlock(arr, item.ti, item.mon);
      const total = Object.values(DATA?.phancong || {}).reduce ? 0 : 0;
      return (block ? block.len : 1) * 100 + (item.fixed ? 1000 : 0);
    }catch(e){ return 999; }
  }
  function _candidateKeepIndex(group){
    // Giữ tiết khó dời nhất: fixed > block dài > gần full/full
    let bestIdx = 0, bestScore = -1;
    for(let i=0;i<group.length;i++){
      const x = group[i];
      const arr = _sessionArr(x.lopId, x.thu, x.buoi);
      const block = _findBlock(arr, x.ti, x.mon);
      const score = (x.fixed ? 100000 : 0) + ((block?.len || 1) * 100) + (_teacherTotal(x.gv) >= 14 ? 25 : 0);
      if(score > bestScore){ bestScore = score; bestIdx = i; }
    }
    return bestIdx;
  }
  function _teacherTotal(gv){
    let n = 0;
    try{
      for(const it of _allLessons()) if(_sameTeacher(it.gv, gv)) n++;
    }catch(e){}
    return n;
  }
  function _candidateRanges(arr, len){
    const out = [];
    if(!Array.isArray(arr) || len <= 0 || len > arr.length) return out;
    for(let s=0; s+len-1 < arr.length; s++) out.push({start:s, end:s+len-1});
    return out;
  }
  function _rangeEmpty(arr, s, e){
    for(let i=s;i<=e;i++) if(_cellMon(arr[i])) return false;
    return true;
  }
  function _allTeacherFree(gv, thu, buoi, s, e, ignoreLopId){
    for(let i=s;i<=e;i++) if(!_teacherFree(gv, thu, buoi, i, ignoreLopId)) return false;
    return true;
  }
  function _allRoomFree(room, thu, buoi, s, e, ignoreLopId){
    for(let i=s;i<=e;i++) if(!_roomFree(room, thu, buoi, i, ignoreLopId)) return false;
    return true;
  }
  function _copyInto(arr, s, cells){
    const out = arr.slice();
    for(let i=0;i<cells.length;i++) out[s+i] = cells[i];
    return out;
  }
  function _clearRange(arr, s, e){
    const out = arr.slice();
    for(let i=s;i<=e;i++) out[i] = '';
    return out;
  }
  function _validateMoveBlock(item, block, targetThu, targetBuoi, targetStart){
    const sourceArr = _sessionArr(item.lopId, item.thu, item.buoi);
    const targetArr = _sessionArr(item.lopId, targetThu, targetBuoi);
    const cells = _blockCells(sourceArr, block);
    const room = _roomFor(item.lopId, item.mon);
    const lim = _limitFor(item.lopId, item.mon);
    if(!_rangeEmpty(targetArr, targetStart, targetStart + block.len - 1)) return null;
    if(!_allTeacherFree(item.gv, targetThu, targetBuoi, targetStart, targetStart + block.len - 1, item.lopId)) return null;
    if(!_allRoomFree(room, targetThu, targetBuoi, targetStart, targetStart + block.len - 1, item.lopId)) return null;
    const nextSource = _clearRange(sourceArr, block.start, block.end);
    const nextTarget = _copyInto(targetArr, targetStart, cells);
    if(!_validateSession(nextSource, item.mon, lim)) return null;
    if(!_validateSession(nextTarget, item.mon, lim)) return null;
    return {nextSource, nextTarget};
  }
  function _applyMoveBlock(item, block, targetThu, targetBuoi, targetStart){
    const built = _validateMoveBlock(item, block, targetThu, targetBuoi, targetStart);
    if(!built) return false;
    _setSessionArr(item.lopId, item.thu, item.buoi, built.nextSource);
    _setSessionArr(item.lopId, targetThu, targetBuoi, built.nextTarget);
    return true;
  }
  function _tryMoveWholeBlock(item){
    const sourceArr = _sessionArr(item.lopId, item.thu, item.buoi);
    const block = _findBlock(sourceArr, item.ti, item.mon);
    if(!block) return false;
    const total = _teacherTotal(item.gv);
    // full / near full: ưu tiên dời cả block trước
    for(const thu2 of _DAYS){
      for(const buoi2 of _BUOI){
        if(thu2 === item.thu && buoi2 === item.buoi) continue;
        const targetArr = _sessionArr(item.lopId, thu2, buoi2);
        for(const rg of _candidateRanges(targetArr, block.len)){
          if(total >= 14){
            // ưu tiên đưa vào buổi đã có ít nhất một tiết của GV đó, tránh mở buổi mới nếu có thể
            let hasTeacher = false;
            for(let i=0;i<targetArr.length;i++){
              const m = _cellMon(targetArr[i]);
              if(m && _sameTeacher(_teacherFor(item.lopId, m), item.gv)){ hasTeacher = true; break; }
            }
            if(!hasTeacher) continue;
          }
          if(_applyMoveBlock(item, block, thu2, buoi2, rg.start)) return true;
        }
      }
    }
    // fallback mở buổi mới nếu không còn cách nào khác
    for(const thu2 of _DAYS){
      for(const buoi2 of _BUOI){
        if(thu2 === item.thu && buoi2 === item.buoi) continue;
        const targetArr = _sessionArr(item.lopId, thu2, buoi2);
        for(const rg of _candidateRanges(targetArr, block.len)){
          if(_applyMoveBlock(item, block, thu2, buoi2, rg.start)) return true;
        }
      }
    }
    return false;
  }
  function _swapBlocksValid(item, blockA, thu2, buoi2, blockB){
    const arrA = _sessionArr(item.lopId, item.thu, item.buoi);
    const arrB = _sessionArr(item.lopId, thu2, buoi2);
    if(blockA.len !== blockB.len) return null;
    const cellsA = _blockCells(arrA, blockA);
    const cellsB = _blockCells(arrB, blockB);
    const monB = _cellMon(cellsB[0]);
    if(!monB || monB === item.mon) return null;
    for(let i=0;i<cellsB.length;i++) if(_cellMon(cellsB[i]) !== monB) return null;
    const gvB = _teacherFor(item.lopId, monB);
    if(!gvB || _sameTeacher(gvB, item.gv)) return null;
    const roomA = _roomFor(item.lopId, item.mon);
    const roomB = _roomFor(item.lopId, monB);
    for(let i=0;i<blockA.len;i++){
      if(!_teacherFree(item.gv, thu2, buoi2, blockB.start + i, item.lopId)) return null;
      if(!_teacherFree(gvB, item.thu, item.buoi, blockA.start + i, item.lopId)) return null;
      if(!_roomFree(roomA, thu2, buoi2, blockB.start + i, item.lopId)) return null;
      if(!_roomFree(roomB, item.thu, item.buoi, blockA.start + i, item.lopId)) return null;
    }
    const nextA = arrA.slice(), nextB = arrB.slice();
    for(let i=0;i<blockA.len;i++){
      nextA[blockA.start + i] = cellsB[i];
      nextB[blockB.start + i] = cellsA[i];
    }
    const limA = _limitFor(item.lopId, item.mon);
    const limB = _limitFor(item.lopId, monB);
    if(!_validateSession(nextA, item.mon, limA)) return null;
    if(!_validateSession(nextB, item.mon, limA)) return null;
    if(!_validateSession(nextA, monB, limB)) return null;
    if(!_validateSession(nextB, monB, limB)) return null;
    return {nextA, nextB};
  }
  function _trySwapWholeBlock(item){
    const arrA = _sessionArr(item.lopId, item.thu, item.buoi);
    const blockA = _findBlock(arrA, item.ti, item.mon);
    if(!blockA) return false;
    for(const thu2 of _DAYS){
      for(const buoi2 of _BUOI){
        if(thu2 === item.thu && buoi2 === item.buoi) continue;
        const arrB = _sessionArr(item.lopId, thu2, buoi2);
        const seen = new Set();
        for(let ti2=0; ti2<arrB.length; ti2++){
          const mon2 = _cellMon(arrB[ti2]);
          if(!mon2) continue;
          const blockB = _findBlock(arrB, ti2, mon2);
          if(!blockB) continue;
          const key = blockB.start + '-' + blockB.end;
          if(seen.has(key)) continue;
          seen.add(key);
          const built = _swapBlocksValid(item, blockA, thu2, buoi2, blockB);
          if(!built) continue;
          _setSessionArr(item.lopId, item.thu, item.buoi, built.nextA);
          _setSessionArr(item.lopId, thu2, buoi2, built.nextB);
          return true;
        }
      }
    }
    return false;
  }
  function _tryMoveEdgeOrSingle(item){
    const arr = _sessionArr(item.lopId, item.thu, item.buoi);
    const block = _findBlock(arr, item.ti, item.mon);
    if(!block) return false;
    if(!(block.len === 1 || item.ti === block.start || item.ti === block.end)) return false;

    const cell = arr[item.ti];
    const lim = _limitFor(item.lopId, item.mon);
    const room = _roomFor(item.lopId, item.mon);
    for(const thu2 of _DAYS){
      for(const buoi2 of _BUOI){
        const arr2 = _sessionArr(item.lopId, thu2, buoi2);
        for(let ti2=0; ti2<arr2.length; ti2++){
          if(_cellMon(arr2[ti2])) continue;
          if(!_teacherFree(item.gv, thu2, buoi2, ti2, item.lopId)) continue;
          if(!_roomFree(room, thu2, buoi2, ti2, item.lopId)) continue;
          const next1 = arr.slice(); next1[item.ti] = '';
          const next2 = arr2.slice(); next2[ti2] = cell;
          if(!_validateSession(next1, item.mon, lim)) continue;
          if(!_validateSession(next2, item.mon, lim)) continue;
          _setSessionArr(item.lopId, item.thu, item.buoi, next1);
          _setSessionArr(item.lopId, thu2, buoi2, next2);
          return true;
        }
      }
    }
    return false;
  }

  function _resolveOne(item){
    if(!item || item.fixed) return false;
    // Thứ tự ưu tiên: block move -> block swap -> edge/single
    if(_tryMoveWholeBlock(item)) return true;
    if(_trySwapWholeBlock(item)) return true;
    if(_tryMoveEdgeOrSingle(item)) return true;
    return false;
  }

  window.findTeacherOverlaps = function(){
    try{
      return _scanGroups().map(list => ({
        gv: list[0]?.gv,
        thu: list[0]?.thu,
        buoi: list[0]?.buoi,
        ti: list[0]?.ti,
        n: list.length,
        items: list.map(x => ({lopId:x.lopId, mon:x.mon, fixed:x.fixed}))
      }));
    }catch(e){ return []; }
  };

  window.repairTeacherOverlaps = function(opts={}){
    const t0 = Date.now();
    const maxRounds = Math.max(1, Number(opts.maxRounds || 10));
    const timeBudgetMs = Math.max(6000, Number(opts.timeBudgetMs || 12000));
    const maxMoves = Math.max(2000, Number(opts.maxMoves || 8000));
    let moved = 0, unresolved = 0, unresolvedFixed = 0, roundsUsed = 0;
    let lastConflicts = 0;
    const logs = [];

    for(let round=0; round<maxRounds; round++){
      roundsUsed = round + 1;
      if(Date.now() - t0 >= timeBudgetMs) break;
      const groups = _scanGroups();
      lastConflicts = groups.length;
      if(!groups.length) break;
      let changed = 0;

      // ưu tiên nhóm nặng trước: nhiều tiết trùng, GV full/gần full, block dài
      groups.sort((a,b)=>{
        const ta = _teacherTotal(a[0]?.gv || '');
        const tb = _teacherTotal(b[0]?.gv || '');
        if(b.length !== a.length) return b.length - a.length;
        return tb - ta;
      });

      for(const group of groups){
        if(Date.now() - t0 >= timeBudgetMs) break;
        if(moved >= maxMoves) break;
        const keep = _candidateKeepIndex(group);
        for(let i=0;i<group.length;i++){
          if(i === keep) continue;
          const item = group[i];
          if(item.fixed){ unresolvedFixed++; continue; }
          if(_resolveOne(item)){
            moved++;
            changed++;
            logs.push({kind:'resolve', gv:item.gv, lopId:item.lopId, mon:item.mon, at:{thu:item.thu, buoi:item.buoi, ti:item.ti}});
          }else{
            unresolved++;
          }
          if(Date.now() - t0 >= timeBudgetMs) break;
          if(moved >= maxMoves) break;
        }
      }
      if(changed === 0) break;
    }

    const left = _scanGroups();
    const result = {
      ts: Date.now(),
      version: window.__PHANMON_ARCH_OVERLAP_FIX_20260309,
      roundsUsed,
      elapsedMs: Date.now() - t0,
      conflicts: left.length,
      moved,
      swapped: 0,
      unresolved,
      unresolvedFixed,
      logs: logs.slice(0, 200)
    };
    try{ window.__lastTeacherOverlapRepair = result; }catch(e){}
    try{ if(typeof saveStore === 'function') saveStore(); }catch(e){}
    try{ if(typeof renderCurrentView === 'function') renderCurrentView(); }catch(e){}
    try{ if(typeof loadMonList === 'function') loadMonList(); }catch(e){}
    try{ console.log('[phanmon] repairTeacherOverlaps ARCH FIX', result); }catch(e){}
    return result;
  };

  function _runArchRepair(){
    try{
      if(typeof window.repairTeacherOverlaps !== 'function') return;
      window.repairTeacherOverlaps({maxRounds: 12, maxMoves: 9000, timeBudgetMs: 15000});
    }catch(e){ try{ console.warn('[phanmon] arch repair failed', e); }catch(_e){} }
  }
  function _wrapAfter(fnName, isAsync){
    try{
      const cur = window[fnName];
      if(typeof cur !== 'function') return;
      if(cur.__archOverlapWrapped) return;
      const wrapped = isAsync ? async function(){ const res = await cur.apply(this, arguments); _runArchRepair(); return res; }
                              : function(){ const res = cur.apply(this, arguments); _runArchRepair(); return res; };
      try{ Object.defineProperty(wrapped, '__archOverlapWrapped', {value:true}); }catch(e){ wrapped.__archOverlapWrapped = true; }
      window[fnName] = wrapped;
    }catch(e){}
  }
  _wrapAfter('sapXepTuDongAll', false);
  _wrapAfter('xepLaiLop', false);
  _wrapAfter('runOptimizeFromPanel', true);
  _wrapAfter('continueOptimizeFromPanel', true);
  try{ console.log('[phanmon-ops] ARCHITECTURAL OVERLAP FIX applied', window.__PHANMON_ARCH_OVERLAP_FIX_20260309); }catch(e){}
})();


/* =========================================================
   FINAL POLICY PATCH V2 (2026-03-17)
   - GV <=5 tiết: bắt buộc 1 buổi, packed rồi khóa
   - GV >5 tiết: số buổi tối thiểu ceil(T/5), mọi buổi trong [3..5]
   - Gom buổi 1/2 tiết trước optimize, dọn nhẹ 1/2 tiết và 1/2 tiết trống sau optimize
   - Placement chỉ tăng/giảm điểm vừa phải, không hard-filter nặng
   ========================================================= */
(function(){
  try{
    window.__PHANMON_FINAL_POLICY_PATCH = 'final-policy-v2-2026-03-17';

    function __pmLexDesc(a,b){
      const n=Math.max(a.length,b.length);
      for(let i=0;i<n;i++){
        const av=Number(a[i]||0), bv=Number(b[i]||0);
        if(av!==bv) return bv-av;
      }
      return 0;
    }

    function __pmGeneratePatterns(T){
      T = Number(T||0);
      if(!Number.isFinite(T) || T<=0) return [];
      if(T<=5) return [[T]];
      const S = Math.max(1, Math.ceil(T/5));
      const out = [];
      function dfs(idx, remain, acc){
        if(idx===S){
          if(remain===0){
            const a = acc.slice().sort((x,y)=>y-x);
            out.push(a);
          }
          return;
        }
        const left = S - idx - 1;
        for(let x=5; x>=3; x--){
          const rem2 = remain - x;
          if(rem2 < left*3) continue;
          if(rem2 > left*5) continue;
          acc.push(x); dfs(idx+1, rem2, acc); acc.pop();
        }
      }
      dfs(0, T, []);
      const uniq = [];
      const seen = new Set();
      for(const a of out){
        const k=a.join('-');
        if(!seen.has(k)){ seen.add(k); uniq.push(a); }
      }
      uniq.sort(__pmLexDesc);
      return uniq;
    }

    function __pmAnyPattern(T){ return __pmGeneratePatterns(T); }

    function __pmSessionCountsFromOcc(occT){
      const out=[];
      if(!occT) return out;
      for(const thu of Object.keys(occT)){
        for(const buoi of Object.keys(occT[thu]||{})){
          const arr = occT[thu][buoi] || [];
          const c = (typeof _countTrue==='function') ? _countTrue(arr) : 0;
          if(c>0) out.push({thu, buoi, count:c, slots:arr});
        }
      }
      return out;
    }

    function __pmPackedNoGaps(slots){
      try{
        const mm = _teacherSessionMetrics(slots||[]);
        return mm.count<=1 || mm.maxGap===0;
      }catch(e){ return true; }
    }

    function __pmTeacherTotal(lessonsMap, gv){
      return Number((lessonsMap?.[gv] || []).length || 0);
    }

    window._targetSessionSizesOptimal = function(T){
      const ps = __pmAnyPattern(T);
      return ps.length ? ps[0].slice() : [];
    };
    window._targetSessionSizesByRemainder = window._targetSessionSizesOptimal;

    window._effectiveMinTietBuoiForTeacher = function(opt, teacher, lessonsMap){
      try{
        const T = __pmTeacherTotal(lessonsMap, teacher);
        if(T<=0) return 0;
        if(T<=5) return 0;
        const ps = __pmAnyPattern(T);
        if(!ps.length) return 0;
        const mins = ps.map(p => Math.min.apply(null, p));
        const bestMin = Math.max.apply(null, mins);
        return bestMin >= 3 ? 3 : 0;
      }catch(e){ return 0; }
    };

    window._teacherMeetsTargetDistribution = function(gv, occ, totalGV){
      try{
        const T = Number(totalGV||0);
        if(T<=0) return true;
        const sess = __pmSessionCountsFromOcc(occ?.[gv]);
        const counts = sess.map(s=>s.count).sort((a,b)=>b-a);
        if(T<=5){
          return counts.length===1 && counts[0]===T && sess.every(s=>__pmPackedNoGaps(s.slots));
        }
        if(counts.length !== Math.ceil(T/5)) return false;
        if(sess.some(s=>s.count<3 || s.count>5)) return false;
        if(sess.some(s=>!__pmPackedNoGaps(s.slots))) return false;
        const patterns = __pmAnyPattern(T);
        return patterns.some(p=>typeof _multisetEqNums==='function' ? _multisetEqNums(counts,p) : _multisetEq(counts,p));
      }catch(e){ return false; }
    };

    window._buildLockedTeachersByTarget = function(opt, lessonsMap, occ){
      const locked = new Set();
      try{
        for(const teacher of Object.keys(lessonsMap||{})){
          const T = __pmTeacherTotal(lessonsMap, teacher);
          if(T<=0) continue;
          if(window._teacherMeetsTargetDistribution && window._teacherMeetsTargetDistribution(teacher, occ, T)){
            locked.add(String(teacher));
          }
        }
      }catch(e){}
      try{ if(opt) opt.lockedTeachers = locked; window.__HARD_LOCKED_TEACHERS = locked; }catch(e){}
      return locked;
    };

    window._computeLockedTeachers = function(occ, k){
      const locked = new Set();
      try{
        const built = _buildTeacherOccAll();
        const lessons = built.lessons || {};
        for(const gvRaw of Object.keys(occ||{})){
          const gv = _normTeacher(gvRaw);
          const T = __pmTeacherTotal(lessons, gvRaw) || __pmSessionCountsFromOcc(occ?.[gvRaw]).reduce((a,s)=>a+s.count,0);
          if(T>0 && window._teacherMeetsTargetDistribution && window._teacherMeetsTargetDistribution(gvRaw, occ, T)) locked.add(gv);
        }
      }catch(e){}
      return locked;
    };

    if(typeof window.makeExtraScoreBlockForTeacherQualityAndSpread === 'function'){
      const __origExtra = window.makeExtraScoreBlockForTeacherQualityAndSpread;
      window.makeExtraScoreBlockForTeacherQualityAndSpread = function(classId, lopCanon, opt){
        const base = __origExtra(classId, lopCanon, opt);
        return function(localTkb, thu, buoi, startIdx, monName, len){
          let score = 0;
          try{ score += Number(base(localTkb, thu, buoi, startIdx, monName, len) || 0); }catch(e){}
          try{
            const arr = (localTkb?.[thu]?.[buoi] || []).slice();
            const L = arr.length;
            for(let k=0;k<Number(len||1);k++){
              const idx = Number(startIdx)+k;
              if(idx>=0 && idx<L) arr[idx] = monName || '__X__';
            }
            const pos=[];
            for(let i=0;i<arr.length;i++) if(cellMon(arr[i]) || (monName && arr[i]===monName)) pos.push(i+1);
            const c = pos.length;
            if(c===0) return score;
            const contiguous = pos.every((v,i)=> i===0 || v===pos[i-1]+1);
            const gaps=[]; for(let i=1;i<pos.length;i++) gaps.push(pos[i]-pos[i-1]-1);
            const totalGap = gaps.reduce((a,b)=>a+b,0);
            const maxGap = gaps.reduce((a,b)=>Math.max(a,b),0);
            if(c===1) score -= 18;
            else if(c===2) score += contiguous ? 14 : -42;
            else if(c===3) score += contiguous ? 24 : -65;
            else if(c===4) score += contiguous ? 36 : -90;
            else if(c>=5) score += contiguous ? 46 : -80;
            score -= totalGap * 16 + maxGap * 24;
          }catch(e){}
          return score;
        };
      };
    }

    function __pmMergeSmallSessionsPass(){
      let changed = false;
      try{
        let guard = 0;
        while(guard < 20){
          guard++;
          const built = _buildTeacherOccAll();
          const occ = built.occ || {};
          const lessons = built.lessons || {};
          let moved = false;
          for(const gv of Object.keys(lessons)){
            const T = __pmTeacherTotal(lessons, gv);
            if(T<=5) continue;
            const sess = __pmSessionCountsFromOcc(occ?.[gv]);
            const hasSmall = sess.some(s=>s.count>0 && s.count<3);
            if(!hasSmall) continue;
            if(typeof _tryMergeSmallSessionsForTeacher === 'function' && _tryMergeSmallSessionsForTeacher(gv, {__lessons:lessons, limitTietBuoi:3})){
              moved = true; changed = true; break;
            }
          }
          if(!moved) break;
        }
      }catch(e){}
      return changed;
    }

    function __pmFinalCleanup(opts){
      try{
        const o = Object.assign({}, opts || {});
        o.limitTietBuoi = Math.max(3, Number(o.limitTietBuoi || 0));
        if(!Number.isFinite(o.limitTietTrong)) o.limitTietTrong = 1;
        o.limitTietTrong = Math.min(2, Math.max(1, Number(o.limitTietTrong || 1)));
        if(typeof _repairInvalidLessonsByReshuffle === 'function'){
          _repairInvalidLessonsByReshuffle(o, 2);
        }
      }catch(e){}
    }

    if(typeof window.optimizeTeacherScheduleQualityAdvanced === 'function'){
      const __origOpt = window.optimizeTeacherScheduleQualityAdvanced;
      window.optimizeTeacherScheduleQualityAdvanced = function(opts={}){
        try{ __pmMergeSmallSessionsPass(); }catch(e){}
        const res = __origOpt(opts);
        try{ __pmFinalCleanup(opts); }catch(e){}
        return res;
      };
    }

    console.log('[phanmon-ops] final policy patch v2 loaded');
  }catch(e){
    console.error('[phanmon-ops] final policy patch v2 failed', e);
  }
})();


/* ==== legacy references captured before integrated core ==== */
window.__PM_LEGACY_OPTIMIZE = window.optimizeTeacherScheduleQuality;
window.__PM_LEGACY_BUOI1 = window.optimizeTeacherScheduleQualityBuoi1;
window.__PM_LEGACY_ADV = window.optimizeTeacherScheduleQualityAdvanced;
window.__PM_LEGACY_RUNOPT = window.runOptimizeFromPanel;
window.__PM_LEGACY_REPAIR = window._repairInvalidLessonsByReshuffle;
window.__PM_LEGACY_COMPLIANCE = window._calcOptimizeCompliance;


/* ==== integrated optimizer core ==== */

(function(){
  try{
    if(window.PhanMonOptimizerCore) return;

    const DAYS_SAFE = (typeof DAYS !== 'undefined' && Array.isArray(DAYS) && DAYS.length)
      ? DAYS.slice()
      : ['T2','T3','T4','T5','T6','T7'];
    const BUOI_SAFE = ['sang','chieu'];

    function getFullLen(){
      try{
        const cfg = window.DATA?.tkbConfig || {};
        const v = Number(cfg.fullSessionLen || cfg.fullN || 5);
        if(Number.isFinite(v) && v >= 2) return Math.floor(v);
      }catch(e){}
      return 5;
    }

    function normTeacher(x){
      try{ if(typeof window._normTeacher === 'function') return window._normTeacher(x); }catch(e){}
      return String(x == null ? '' : x).trim().toLowerCase();
    }

    function countTrue(arr){
      try{ if(typeof window._countTrue === 'function') return window._countTrue(arr || []); }catch(e){}
      let c = 0;
      for(const v of (arr || [])) if(!!v) c++;
      return c;
    }

    function metrics(slots){
      if(typeof window._teacherSessionMetrics === 'function') return window._teacherSessionMetrics(slots || []);
      const pos = [];
      for(let i=0;i<(slots||[]).length;i++) if(!!slots[i]) pos.push(i);
      let totalGaps = 0, maxGap = 0;
      for(let i=1;i<pos.length;i++){
        const g = pos[i] - pos[i-1] - 1;
        if(g > 0){ totalGaps += g; if(g > maxGap) maxGap = g; }
      }
      return {count:pos.length, totalGaps, maxGap, pos};
    }

    function multisetEq(a,b){
      if(!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
      const aa = a.slice().sort((x,y)=>x-y);
      const bb = b.slice().sort((x,y)=>x-y);
      for(let i=0;i<aa.length;i++) if(aa[i] !== bb[i]) return false;
      return true;
    }

    function uniqueSortedPatterns(list){
      const seen = new Set();
      const out = [];
      for(const arr of list){
        const key = arr.slice().sort((a,b)=>b-a).join('-');
        if(seen.has(key)) continue;
        seen.add(key);
        out.push(arr.slice().sort((a,b)=>b-a));
      }
      out.sort((a,b)=>{
        const n = Math.max(a.length,b.length);
        for(let i=0;i<n;i++){
          const av = Number(a[i]||0), bv = Number(b[i]||0);
          if(av !== bv) return bv-av;
        }
        return 0;
      });
      return out;
    }

    function genPatterns(total, maxLen, minLen, acc, out){
      if(total === 0){ out.push(acc.slice()); return; }
      const start = Math.min(maxLen, total);
      for(let x = start; x >= minLen; x--){
        acc.push(x);
        genPatterns(total - x, Math.min(x, maxLen), minLen, acc, out);
        acc.pop();
      }
    }

    function generatePatterns(T, fullLen){
      T = Number(T || 0);
      fullLen = Number(fullLen || getFullLen());
      if(!Number.isFinite(T) || T <= 0) return [];
      if(T <= fullLen) return [[T]];
      const raw = [];
      genPatterns(T, fullLen, 3, [], raw);
      return uniqueSortedPatterns(raw);
    }

    function patternPenalty(pattern, fullLen){
      const sizes = pattern.slice().sort((a,b)=>b-a);
      const total = sizes.reduce((a,b)=>a+b, 0);
      const remainder = total % fullLen;
      let p = 0;
      for(const x of sizes){
        if(x <= 2) p += 1000;
        if(x === fullLen) p -= 60;
        else if(x === fullLen - 1) p -= 36;
        else if(x === fullLen - 2) p -= 16;
        else p += 8;
      }
      p += sizes.length * 7;
      p += sizes.filter(x => x <= 3).length * 9;
      if(remainder === 1){
        if(sizes.filter(x => x === 3).length >= 2) p -= 28;
        if(sizes.every(x => x >= 3)) p -= 12;
      }
      if(remainder === 2){
        if(sizes.includes(4) && sizes.includes(3)) p -= 26;
        if(sizes.some(x => x <= 2)) p += 140;
      }
      if(remainder === 3){
        if(sizes.filter(x => x === 4).length >= 2) p -= 24;
      }
      return p;
    }

    function targetSessionSizes(T, fullLen){
      const patterns = generatePatterns(T, fullLen || getFullLen());
      if(!patterns.length) return [];
      let best = patterns[0], bestScore = Infinity;
      for(const p of patterns){
        const score = patternPenalty(p, fullLen || getFullLen());
        if(score < bestScore){ best = p; bestScore = score; }
      }
      return best.slice().sort((a,b)=>b-a);
    }

    function allowedPositionsBySize(size, arrLen){
      arrLen = Number(arrLen || getFullLen());
      if(size <= 0 || size > arrLen) return [];
      if(size === 4 && arrLen === 5) return [[0,1,2,3],[1,2,3,4]];
      if(size === 3 && arrLen === 5) return [[0,1,2],[1,2,3],[2,3,4]];
      const out = [];
      for(let start=0; start + size <= arrLen; start++) out.push(Array.from({length:size}, (_,i)=>start+i));
      return out;
    }

    function isAllowedPacked(pos, count, arrLen){
      if(!count) return true;
      const sig = (pos || []).slice().sort((a,b)=>a-b).join(',');
      return allowedPositionsBySize(count, arrLen).some(x => x.join(',') === sig);
    }

    function strictSessionOk(slots){
      const m = metrics(slots || []);
      if(m.count <= 1) return true;
      return isAllowedPacked(m.pos, m.count, Array.isArray(slots) ? slots.length : getFullLen());
    }

    function sessionCountsFromOcc(occT){
      if(typeof window._teacherSessionCountsFromOcc === 'function') return (window._teacherSessionCountsFromOcc(occT) || []).map(x=>Object.assign({},x));
      const out = [];
      if(!occT) return out;
      for(const thu of Object.keys(occT)){
        for(const buoi of Object.keys(occT[thu] || {})){
          const arr = occT[thu][buoi] || [];
          const c = countTrue(arr);
          if(c>0) out.push({thu, buoi, count:c});
        }
      }
      return out;
    }

    function lessonsInSession(lessonsMap, teacher, thu, buoi){
      return (lessonsMap?.[teacher] || []).filter(l => String(l.thu) === String(thu) && String(l.buoi) === String(buoi));
    }

    function teacherMatchesPolicy(teacher, occ, totalGV, fullLen){
      const T = Number(totalGV || 0);
      if(!Number.isFinite(T) || T <= 0) return true;
      const target = targetSessionSizes(T, fullLen || getFullLen());
      if(!target.length) return false;
      const counts = [];
      for(const thu of DAYS_SAFE){
        for(const buoi of BUOI_SAFE){
          const slots = occ?.[teacher]?.[thu]?.[buoi] || [];
          const m = metrics(slots);
          if(m.count <= 0) continue;
          if(!strictSessionOk(slots)) return false;
          counts.push(m.count);
        }
      }
      return multisetEq(counts, target);
    }

    function rankTeacherPhase(T, fullLen){
      if(T <= 0) return 99;
      if(T < fullLen) return 0;
      const r = T % fullLen;
      if(r === 0 || r === fullLen - 1) return 1;
      if(r === 2 || r === 3) return 2;
      if(r === 1) return 3;
      return 4;
    }

    function teacherHasFixedLesson(teacher){
      try{ if(typeof window._teacherHasAnyFixedLesson === 'function') return !!window._teacherHasAnyFixedLesson(teacher); }catch(e){}
      return false;
    }

    function scoreSessionForTarget(slots, targetCount){
      const m = metrics(slots || []);
      const arrLen = Array.isArray(slots) ? slots.length : getFullLen();
      let score = 0;
      score -= Math.abs(m.count - targetCount) * 40;
      score -= m.totalGaps * 30;
      score -= m.maxGap * 45;
      if(isAllowedPacked(m.pos, m.count, arrLen)) score += 20;
      return score;
    }

    function bestDestinationsForTeacher(teacher, targetCount, built, exceptThu, exceptBuoi){
      const occT = built?.occ?.[teacher] || {};
      const out = [];
      for(const thu of Object.keys(occT)){
        for(const buoi of Object.keys(occT[thu] || {})){
          if(String(thu) === String(exceptThu) && String(buoi) === String(exceptBuoi)) continue;
          const slots = occT[thu][buoi] || [];
          const m = metrics(slots);
          if(m.count >= getFullLen()) continue;
          out.push({thu, buoi, count:m.count, score:scoreSessionForTarget(slots, targetCount)});
        }
      }
      out.sort((a,b)=>b.score-a.score || b.count-a.count);
      return out;
    }

    function moveTeacherTowardTarget(teacher, built, target){
      const lessons = built.lessons || {};
      const ls = lessons[teacher] || [];
      if(!ls.length) return false;
      const fullLen = getFullLen();
      const occT = built.occ?.[teacher] || {};
      const sessions = sessionCountsFromOcc(occT).sort((a,b)=>a.count-b.count);
      if(!sessions.length) return false;
      const counts = sessions.map(s=>s.count).sort((a,b)=>b-a);
      if(multisetEq(counts, target) && sessions.every(s => strictSessionOk(occT?.[s.thu]?.[s.buoi] || []))) return false;

      const needMerge = sessions.length > target.length;
      const targetAsc = target.slice().sort((a,b)=>a-b);
      const minTarget = targetAsc[0] || 0;
      const maxTarget = targetAsc[targetAsc.length-1] || fullLen;

      if(needMerge){
        const src = sessions[0];
        const srcLessons = lessonsInSession(lessons, teacher, src.thu, src.buoi);
        const dests = bestDestinationsForTeacher(teacher, maxTarget, built, src.thu, src.buoi).filter(d => d.count < fullLen);
        for(const lesson of srcLessons){
          for(const d of dests){
            if(typeof window._tryMoveLessonToTargetSession === 'function' && window._tryMoveLessonToTargetSession(lesson, d.thu, d.buoi, built)) return true;
          }
        }
      }

      const under = sessions.slice().sort((a,b)=>a.count-b.count).find(s => s.count < minTarget || !strictSessionOk(occT?.[s.thu]?.[s.buoi] || []));
      const over = sessions.slice().sort((a,b)=>b.count-a.count).find(s => s.count > minTarget || s.count > maxTarget);
      if(over && under){
        const srcLessons = lessonsInSession(lessons, teacher, over.thu, over.buoi);
        for(const lesson of srcLessons){
          if(typeof window._tryMoveLessonToTargetSession === 'function' && window._tryMoveLessonToTargetSession(lesson, under.thu, under.buoi, built)) return true;
        }
      }

      if(typeof window._tryMergeSmallSessionsForTeacher === 'function'){
        try{ return !!window._tryMergeSmallSessionsForTeacher(teacher, {__lessons:lessons, limitTietBuoi:3}); }catch(e){}
      }
      return false;
    }

    function buildHardLocks(lessons, occ){
      const set = new Set();
      for(const teacher of Object.keys(lessons || {})){
        const total = (lessons[teacher] || []).length;
        if(total > 0 && teacherMatchesPolicy(teacher, occ, total, getFullLen())){
          set.add(String(teacher).trim());
          set.add(normTeacher(teacher));
        }
      }
      return set;
    }

    function forcePackTeachers(opts={}){
      const maxRounds = Math.max(1, Number(opts.maxRounds || 12));
      const fullLen = getFullLen();
      let moved = 0;
      for(let round=0; round<maxRounds; round++){
        const built = typeof window._buildTeacherOccAll === 'function' ? window._buildTeacherOccAll() : null;
        if(!built) break;
        const occ = built.occ || {};
        const lessons = built.lessons || {};
        const teachers = Object.keys(lessons)
          .map(t => ({teacher:t, total:(lessons[t] || []).length}))
          .filter(x => x.total > 0)
          .sort((a,b) => rankTeacherPhase(a.total, fullLen) - rankTeacherPhase(b.total, fullLen) || b.total - a.total);

        let changed = false;
        for(const item of teachers){
          if(teacherHasFixedLesson(item.teacher)) continue;
          if(teacherMatchesPolicy(item.teacher, occ, item.total, fullLen)) continue;
          const target = targetSessionSizes(item.total, fullLen);
          if(moveTeacherTowardTarget(item.teacher, built, target)){
            moved++;
            changed = true;
            break;
          }
        }
        if(!changed) break;
      }
      return moved;
    }

    function calcCompliance(baseOpt={}){
      const built = typeof window._buildTeacherOccAll === 'function' ? window._buildTeacherOccAll() : null;
      if(!built) return {percent:100, ok:0, bad:0, total:0};
      const occ = built.occ || {};
      const lessons = built.lessons || {};
      let ok = 0, bad = 0;
      for(const teacher of Object.keys(lessons)){
        const total = (lessons[teacher] || []).length;
        if(total <= 0) continue;
        if(teacherMatchesPolicy(teacher, occ, total, getFullLen())) ok++;
        else bad++;
      }
      const total = ok + bad;
      return { ok, bad, total, percent: total ? Math.round(ok * 10000 / total) / 100 : 100 };
    }

    const legacy = {
      optimizeTeacherScheduleQuality: (typeof window.optimizeTeacherScheduleQuality === 'function') ? window.optimizeTeacherScheduleQuality : null,
      optimizeTeacherScheduleQualityBuoi1: (typeof window.optimizeTeacherScheduleQualityBuoi1 === 'function') ? window.optimizeTeacherScheduleQualityBuoi1 : null,
      optimizeTeacherScheduleQualityAdvanced: (typeof window.optimizeTeacherScheduleQualityAdvanced === 'function') ? window.optimizeTeacherScheduleQualityAdvanced : null,
      runOptimizeFromPanel: (typeof window.runOptimizeFromPanel === 'function') ? window.runOptimizeFromPanel : null,
      calcOptimizeCompliance: (typeof window._calcOptimizeCompliance === 'function') ? window._calcOptimizeCompliance : null,
      repairInvalidLessonsByReshuffle: (typeof window._repairInvalidLessonsByReshuffle === 'function') ? window._repairInvalidLessonsByReshuffle : null
    };

    function optimizeTeacherScheduleQuality(opts={}){
      let moved = 0;
      moved += forcePackTeachers({maxRounds:8});
      if(typeof legacy.optimizeTeacherScheduleQuality === 'function') moved += Number(legacy.optimizeTeacherScheduleQuality(opts) || 0);
      moved += forcePackTeachers({maxRounds:5});
      return moved;
    }

    function optimizeTeacherScheduleQualityBuoi1(opts={}){
      let moved = 0;
      moved += forcePackTeachers({maxRounds:8});
      if(typeof legacy.optimizeTeacherScheduleQualityBuoi1 === 'function') moved += Number(legacy.optimizeTeacherScheduleQualityBuoi1(opts) || 0);
      moved += forcePackTeachers({maxRounds:4});
      return moved;
    }

    function optimizeTeacherScheduleQualityAdvanced(opts={}){
      let moved = 0;
      moved += forcePackTeachers({maxRounds:10});
      if(typeof legacy.optimizeTeacherScheduleQualityAdvanced === 'function') moved += Number(legacy.optimizeTeacherScheduleQualityAdvanced(opts) || 0);
      moved += forcePackTeachers({maxRounds:6});
      if(typeof legacy.repairInvalidLessonsByReshuffle === 'function'){
        try{ legacy.repairInvalidLessonsByReshuffle({ limitTietBuoi: 0, limitTietTrong: Number(opts?.limitTietTrong || 1) }, 1); }catch(e){}
      }
      return moved;
    }

    async function runOptimizeFromPanel(){
      forcePackTeachers({maxRounds:10});
      if(typeof legacy.runOptimizeFromPanel === 'function') return await legacy.runOptimizeFromPanel();
      return 0;
    }

    function installGlobals(){
      window._targetSessionSizesByRemainder = targetSessionSizes;
      window._teacherMeetsTargetDistribution = teacherMatchesPolicy;
      window._buildLockedTeachersByTarget = function(opt, lessonsMap, occ){
        const locked = buildHardLocks(lessonsMap || {}, occ || {});
        opt = opt || {};
        opt.lockedTeachers = opt.lockedTeachers || new Set();
        for(const gv of locked) opt.lockedTeachers.add(gv);
        window.__HARD_LOCKED_TEACHERS = window.__HARD_LOCKED_TEACHERS || new Set();
        for(const gv of locked) window.__HARD_LOCKED_TEACHERS.add(gv);
        return locked;
      };
      window._computeLockedTeachers = function(occ, k){
        try{
          const built = typeof window._buildTeacherOccAll === 'function' ? window._buildTeacherOccAll() : null;
          if(!built) return new Set();
          return buildHardLocks(built.lessons || {}, built.occ || {});
        }catch(e){
          return new Set();
        }
      };
      window._calcOptimizeCompliance = function(opt={}){
        const base = (typeof legacy.calcOptimizeCompliance === 'function') ? (legacy.calcOptimizeCompliance(opt) || {}) : {};
        const policy = calcCompliance(opt);
        base.policyPercent = policy.percent;
        base.policyOk = policy.ok;
        base.policyBad = policy.bad;
        return base;
      };
      window.optimizeTeacherScheduleQuality = optimizeTeacherScheduleQuality;
      window.optimizeTeacherScheduleQualityBuoi1 = optimizeTeacherScheduleQualityBuoi1;
      window.optimizeTeacherScheduleQualityAdvanced = optimizeTeacherScheduleQualityAdvanced;
      window.runOptimizeFromPanel = runOptimizeFromPanel;
      window._repairInvalidLessonsByReshuffle = function(opt={}, maxRounds=10){
        let touched = 0;
        for(let i=0;i<Math.max(1, Number(maxRounds || 1));i++){
          const moved = forcePackTeachers({maxRounds:4});
          if(!moved) break;
          touched += moved;
        }
        if(typeof legacy.repairInvalidLessonsByReshuffle === 'function'){
          try{ return legacy.repairInvalidLessonsByReshuffle(opt, maxRounds); }catch(e){}
        }
        return { rounds: maxRounds, totalTouchedSessions: touched, stats: calcCompliance(opt) };
      };
    }

    window.PhanMonOptimizerCore = {
      version: 'core-mod5-v1',
      getFullLen,
      targetSessionSizes,
      teacherMatchesPolicy,
      forcePackTeachers,
      calcCompliance,
      installGlobals,
      strictSessionOk,
      optimizeTeacherScheduleQuality,
      optimizeTeacherScheduleQualityBuoi1,
      optimizeTeacherScheduleQualityAdvanced,
      runOptimizeFromPanel
    };

    installGlobals();
    console.log('[PhanMonOptimizerCore] loaded', {
      version: 'core-mod5-v1',
      fullLen: getFullLen(),
      samples: {
        6: targetSessionSizes(6, getFullLen()),
        7: targetSessionSizes(7, getFullLen()),
        11: targetSessionSizes(11, getFullLen()),
        12: targetSessionSizes(12, getFullLen()),
        13: targetSessionSizes(13, getFullLen()),
        16: targetSessionSizes(16, getFullLen())
      }
    });
  }catch(e){
    console.error('[PhanMonOptimizerCore] failed', e);
  }
})();


/* =========================================================
   STRICT GAP-1 CLEANUP PATCH (2026-03-19)
   - Reduce remaining 1-gap errors after mod-5 packing
   - Keep direct-run style: only phanmon-ops.js is needed
   ========================================================= */
(function(){
  try{
    if(!window.PhanMonOptimizerCore) return;
    const core = window.PhanMonOptimizerCore;
    window.__PHANMON_STRICT_GAP1_PATCH = 'strict-gap1-2026-03-19';

    function compliance(){
      try{ return core.calcCompliance({limitTietTrong:1}) || {bad:0, percent:100}; }catch(e){ return {bad:0, percent:100}; }
    }

    function forcePackHard(rounds){
      try{ return Number(core.forcePackTeachers({maxRounds: Math.max(1, Number(rounds||8))}) || 0); }catch(e){ return 0; }
    }

    function cleanupGap1Strict(maxRounds){
      let totalMoved = 0;
      let prevBad = Infinity;
      for(let round=0; round<Math.max(1, Number(maxRounds||8)); round++){
        const before = compliance();
        const badBefore = Number(before.bad || 0);
        if(badBefore <= 0) break;
        let moved = 0;
        moved += forcePackHard(10);
        if(typeof window.__PM_LEGACY_ADV === 'function'){
          try{ moved += Number(window.__PM_LEGACY_ADV({limitTietBuoi:0, limitTietTrong:1, maxSwaps:80, maxIters:260, timeBudgetMs:160}) || 0); }catch(e){}
        }
        moved += forcePackHard(8);
        const after = compliance();
        const badAfter = Number(after.bad || 0);
        totalMoved += moved;
        if(badAfter <= 0) break;
        if(badAfter >= badBefore && moved <= 0) break;
        if(badAfter >= prevBad) break;
        prevBad = badAfter;
      }
      return totalMoved;
    }

    function patchedOptimizeBasic(opts){
      let moved = 0;
      moved += forcePackHard(10);
      if(typeof window.__PM_LEGACY_OPTIMIZE === 'function'){
        try{ moved += Number(window.__PM_LEGACY_OPTIMIZE(opts || {}) || 0); }catch(e){}
      }
      moved += forcePackHard(6);
      moved += cleanupGap1Strict(4);
      return moved;
    }

    function patchedOptimizeBuoi1(opts){
      let moved = 0;
      moved += forcePackHard(12);
      if(typeof window.__PM_LEGACY_BUOI1 === 'function'){
        try{ moved += Number(window.__PM_LEGACY_BUOI1(Object.assign({}, opts||{}, {maxSwaps:80, timeBudgetMs:60})) || 0); }catch(e){}
      }
      moved += forcePackHard(8);
      moved += cleanupGap1Strict(6);
      return moved;
    }

    function patchedOptimizeAdvanced(opts){
      const o = Object.assign({}, opts || {});
      const limTrong = Number(o.limitTietTrong || 0);
      let moved = 0;
      moved += forcePackHard(14);
      if(typeof window.__PM_LEGACY_ADV === 'function'){
        try{ moved += Number(window.__PM_LEGACY_ADV(Object.assign({}, o, {maxSwaps:80, maxIters:280, timeBudgetMs:160})) || 0); }catch(e){}
      }
      moved += forcePackHard(10);
      if(limTrong >= 1) moved += cleanupGap1Strict(limTrong===1 ? 10 : 6);
      return moved;
    }

    core.optimizeTeacherScheduleQuality = patchedOptimizeBasic;
    core.optimizeTeacherScheduleQualityBuoi1 = patchedOptimizeBuoi1;
    core.optimizeTeacherScheduleQualityAdvanced = patchedOptimizeAdvanced;

    window.optimizeTeacherScheduleQuality = patchedOptimizeBasic;
    window.optimizeTeacherScheduleQualityBuoi1 = patchedOptimizeBuoi1;
    window.optimizeTeacherScheduleQualityAdvanced = patchedOptimizeAdvanced;

    try{ console.log('[phanmon-ops] STRICT GAP1 PATCH applied', window.__PHANMON_STRICT_GAP1_PATCH); }catch(e){}
  }catch(e){
    try{ console.error('[phanmon-ops] STRICT GAP1 PATCH failed', e); }catch(_e){}
  }
})();

/* ===== PATCH 2026-03-28: SMALL TEACHERS FIRST + HARD LOCK (<5) ===== */
(function(){
  try{
    const DAYS_SAFE = (Array.isArray(window.DAYS) && window.DAYS.length) ? window.DAYS : ["2","3","4","5","6","7"];
    const BUOI_SAFE = ["sang","chieu"];
    function normTeacher(x){ return (x==null?"":String(x)).trim().toLowerCase(); }
    function countTrue(arr){ let c=0; for(const v of (arr||[])) if(v) c++; return c; }
    function metrics(slots){
      const pos=[];
      for(let i=0;i<(slots||[]).length;i++) if(slots[i]) pos.push(i);
      let totalGaps=0, maxGap=0;
      for(let i=1;i<pos.length;i++){
        const g = pos[i]-pos[i-1]-1;
        if(g>0){ totalGaps+=g; if(g>maxGap) maxGap=g; }
      }
      return { count: pos.length, pos, totalGaps, maxGap };
    }
    function allowedPositionsBySize(size, arrLen){
      arrLen = Number(arrLen || 5);
      if(size <= 0 || size > arrLen) return [];
      if(size === 4 && arrLen === 5) return [[0,1,2,3],[1,2,3,4]];
      if(size === 3 && arrLen === 5) return [[0,1,2],[1,2,3],[2,3,4]];
      const out=[];
      for(let s=0; s+size<=arrLen; s++) out.push(Array.from({length:size}, (_,i)=>s+i));
      return out;
    }
    function strictSessionOk(slots){
      const m = metrics(slots || []);
      if(m.count <= 1) return true;
      const sig = m.pos.slice().sort((a,b)=>a-b).join(',');
      const arrLen = Array.isArray(slots) ? slots.length : 5;
      return allowedPositionsBySize(m.count, arrLen).some(x => x.join(',') === sig);
    }
    function sessionCountsFromOcc(occT){
      const out=[];
      if(!occT) return out;
      for(const thu of Object.keys(occT)){
        for(const buoi of Object.keys(occT[thu]||{})){
          const arr = occT[thu][buoi] || [];
          const c = countTrue(arr);
          if(c>0) out.push({thu, buoi, count:c, slots:arr});
        }
      }
      return out;
    }
    function smallTeacherPacked(teacher, occ, total){
      const T = Number(total||0);
      if(!(T > 0 && T < 5)) return false;
      const sess = sessionCountsFromOcc(occ?.[teacher]);
      if(sess.length !== 1) return false;
      if(sess[0].count !== T) return false;
      return strictSessionOk(sess[0].slots || []);
    }
    function teacherMatchesPolicy2(teacher, occ, totalGV){
      const T = Number(totalGV || 0);
      if(!Number.isFinite(T) || T <= 0) return true;
      if(T < 5) return smallTeacherPacked(teacher, occ, T);
      if(typeof window._teacherMeetsTargetDistribution === 'function'){
        try{ return !!window._teacherMeetsTargetDistribution(teacher, occ, T); }catch(e){}
      }
      return false;
    }
    function buildHardLocks2(lessons, occ){
      const set = new Set();
      for(const teacher of Object.keys(lessons || {})){
        const total = Number((lessons[teacher] || []).length || 0);
        if(total <= 0) continue;
        if(teacherMatchesPolicy2(teacher, occ, total)){
          const raw = String(teacher).trim();
          if(raw){ set.add(raw); set.add(normTeacher(raw)); }
        }
      }
      return set;
    }

    const legacyBuildOcc = (typeof window._buildTeacherOccAll === 'function') ? window._buildTeacherOccAll : null;
    if(legacyBuildOcc){
      // keep existing; lock builders below will call it fresh when needed
    }

    window._buildLockedTeachersByTarget = function(opt, lessonsMap, occ){
      const locked = buildHardLocks2(lessonsMap || {}, occ || {});
      opt = opt || {};
      opt.lockedTeachers = new Set([...(opt.lockedTeachers||[]), ...locked]);
      window.__HARD_LOCKED_TEACHERS = new Set([...(window.__HARD_LOCKED_TEACHERS||[]), ...locked]);
      return locked;
    };

    window._computeLockedTeachers = function(occ, k){
      try{
        const built = (typeof window._buildTeacherOccAll === 'function') ? window._buildTeacherOccAll() : null;
        if(!built) return new Set();
        return buildHardLocks2(built.lessons || {}, built.occ || {});
      }catch(e){ return new Set(); }
    };

    if(typeof window.optimizeTeacherScheduleQualityAdvanced === 'function'){
      const oldAdv = window.optimizeTeacherScheduleQualityAdvanced;
      window.optimizeTeacherScheduleQualityAdvanced = function(opts={}){
        let pre = 0;
        try{
          if(typeof window.forcePackTeachers === 'function') pre += Number(window.forcePackTeachers({maxRounds:12}) || 0);
        }catch(e){}
        const moved = Number(oldAdv(opts) || 0);
        try{
          const built = (typeof window._buildTeacherOccAll === 'function') ? window._buildTeacherOccAll() : null;
          if(built){
            const locked = buildHardLocks2(built.lessons || {}, built.occ || {});
            opts.lockedTeachers = opts.lockedTeachers || new Set();
            for(const gv of locked) opts.lockedTeachers.add(gv);
            window.__HARD_LOCKED_TEACHERS = new Set([...(window.__HARD_LOCKED_TEACHERS||[]), ...locked]);
          }
        }catch(e){}
        return pre + moved;
      };
    }

    if(typeof window.forcePackTeachers === 'function'){
      const oldForce = window.forcePackTeachers;
      window.forcePackTeachers = function(opts={}){
        return oldForce(opts);
      };
    }

    // Reinstall a sorter that puts teachers with total<5 first, and smaller totals earlier.
    if(typeof window.runOptimizeFromPanel === 'function'){
      // no-op: scheduler uses forcePackTeachers order from installed implementation; next patch below adjusts that order directly if helper exposed.
    }

    console.log('[phanmon-ops.patch] small teachers first+lock active');
  }catch(e){ console.error('[phanmon-ops.patch] failed', e); }
})();


/* ===== PATCH 2026-03-28: LATE SWAP / RESHUFFLE ONLY WHEN FEW GAP ERRORS REMAIN ===== */
(function(){
  try{
    function num(v, d){ v = Number(v); return Number.isFinite(v) ? v : d; }
    function getGapState(limitTietTrong){
      try{
        if(typeof window._calcOptimizeCompliance === 'function'){
          const st = window._calcOptimizeCompliance({ limitTietBuoi: 0, limitTietTrong: Number(limitTietTrong || 1) }) || {};
          return {
            badTietTrong: num(st.badTietTrong, 0),
            badTrongSessions: num(st.badTrongSessions, 0),
            percentTrong: num(st.percentTrong, 100),
            reachedTrong: !!st.reachedTrong
          };
        }
      }catch(e){}
      return { badTietTrong: 0, badTrongSessions: 0, percentTrong: 100, reachedTrong: true };
    }
    function shouldAllowLateSwap(limitTietTrong){
      const st = getGapState(limitTietTrong);
      if(st.reachedTrong || st.badTietTrong <= 0) return false;
      return (st.badTietTrong <= 2) || (st.badTrongSessions <= 2);
    }
    function markLateSwapDecision(tag, allow, st){
      try{
        window.__PM_LAST_LATE_SWAP = {
          tag: String(tag || ''),
          allow: !!allow,
          badTietTrong: num(st?.badTietTrong, 0),
          badTrongSessions: num(st?.badTrongSessions, 0),
          percentTrong: num(st?.percentTrong, 100),
          reachedTrong: !!st?.reachedTrong,
          ts: Date.now()
        };
      }catch(e){}
    }

    if(typeof window._repairInvalidLessonsByReshuffle === 'function'){
      const oldRepair = window._repairInvalidLessonsByReshuffle;
      window._repairInvalidLessonsByReshuffle = function(opt={}, maxRounds=10){
        const limTrong = Number(opt?.limitTietTrong || 0);
        if(limTrong <= 0){
          return oldRepair.apply(this, arguments);
        }
        const st = getGapState(limTrong);
        const allow = shouldAllowLateSwap(limTrong);
        markLateSwapDecision('repair', allow, st);
        if(!allow){
          return {
            rounds: 0,
            totalTouchedSessions: 0,
            skippedLateSwap: true,
            reason: 'gap-errors-not-small-enough',
            stats: st
          };
        }
        return oldRepair.apply(this, arguments);
      };
    }

    if(typeof window.optimizeTeacherScheduleQualityAdvanced === 'function'){
      const oldAdv = window.optimizeTeacherScheduleQualityAdvanced;
      window.optimizeTeacherScheduleQualityAdvanced = function(opts={}){
        const res = oldAdv.apply(this, arguments);
        const limTrong = Number(opts?.limitTietTrong || 0);
        if(limTrong > 0){
          const st = getGapState(limTrong);
          markLateSwapDecision('advanced-post', shouldAllowLateSwap(limTrong), st);
        }
        return res;
      };
    }

    try{ console.log('[phanmon-ops.patch] late swap gate active'); }catch(e){}
  }catch(e){
    try{ console.error('[phanmon-ops.patch] late swap gate failed', e); }catch(_e){}
  }
})();


/* ===== PATCH 2026-03-28: STRICT ONE-GAP IS STILL AN ERROR ===== */
(function(){
  try{
    window.__PM_STRICT_ONE_GAP = 'strict-one-gap-2026-03-28';

    function _strictAllowedGaps(limitTietTrong){
      const n = Number(limitTietTrong || 0);
      if(n >= 1) return 0;
      return Infinity;
    }

    function _strictIsBadTeacherSessionAdv(slots, opt){
      const m = _teacherSessionMetrics(Array.isArray(slots) ? slots : []);
      if(m.count === 0) return false;
      const uiMinBuoi = (typeof _uiMinTietBuoi === 'function') ? _uiMinTietBuoi(opt) : Number(opt?.limitTietBuoi || 0);
      const limTrong = Number(opt?.limitTietTrong || 0);
      if(uiMinBuoi > 0 && m.count < uiMinBuoi) return true;
      if(limTrong >= 1){
        if(m.totalGaps > 0 || m.maxGap > 0) return true;
      }
      return false;
    }

    function _strictSessionBadnessAdv(slots, opt){
      const m = _teacherSessionMetrics(Array.isArray(slots) ? slots : []);
      if(m.count === 0) return 0;
      const uiMinBuoi = (typeof _uiMinTietBuoi === 'function') ? _uiMinTietBuoi(opt) : Number(opt?.limitTietBuoi || 0);
      const limTrong = Number(opt?.limitTietTrong || 0);
      let bad = 0;
      if(uiMinBuoi > 0 && m.count < uiMinBuoi){
        bad += 1000 + (uiMinBuoi - m.count) * 250;
      }
      if(limTrong >= 1 && (m.totalGaps > 0 || m.maxGap > 0)){
        bad += 800 + m.totalGaps * 250 + m.maxGap * 300;
      }
      return bad;
    }

    _allowedGapsFromLimit = _strictAllowedGaps;
    _isBadTeacherSessionAdv = _strictIsBadTeacherSessionAdv;
    _sessionBadnessAdv = _strictSessionBadnessAdv;
    if(typeof window !== 'undefined'){
      window._allowedGapsFromLimit = _strictAllowedGaps;
      window._isBadTeacherSessionAdv = _strictIsBadTeacherSessionAdv;
      window._sessionBadnessAdv = _strictSessionBadnessAdv;
    }

    try{ console.log('[phanmon-ops.patch] strict one-gap active', window.__PM_STRICT_ONE_GAP); }catch(e){}
  }catch(e){
    try{ console.error('[phanmon-ops.patch] strict one-gap failed', e); }catch(_e){}
  }
})();

/* ===== POST-LOAD PATCH 2026-05-05: STRICT ZERO "1 TIET/BUOI" ===== */
(function(){
  try{
    if(window.__PM_MODE1_ZERO_SINGLE_POSTLOAD_PATCH) return;
    window.__PM_MODE1_ZERO_SINGLE_POSTLOAD_PATCH = "zero-single-postload-2026-05-05";

    const priorBuoi1 = (typeof window.optimizeTeacherScheduleQualityBuoi1 === "function") ? window.optimizeTeacherScheduleQualityBuoi1 : null;
    const priorCalc = (typeof window._calcOptimizeCompliance === "function") ? window._calcOptimizeCompliance : null;

    function bld(){
      if(typeof window._buildTeacherOccAllV2 === "function") return window._buildTeacherOccAllV2();
      if(typeof window._buildTeacherOccAll === "function") return window._buildTeacherOccAll();
      return {occ:{}, lessons:{}};
    }
    function ct(arr){
      if(typeof window._countTrue === "function") return window._countTrue(arr || []);
      let n = 0; for(const v of (arr || [])) if(v) n++; return n;
    }
    function flen(){
      try{
        if(typeof window._getFullSessionLen === "function"){
          const n = Number(window._getFullSessionLen());
          if(Number.isFinite(n) && n >= 2) return Math.floor(n);
        }
      }catch(e){}
      return Math.max(2, Number(window.SANG || 0), Number(window.CHIEU || 0), 5);
    }
    function sess(occ, gv){
      const out = [];
      const root = occ?.[gv] || {};
      for(const thu of Object.keys(root)){
        for(const buoi of Object.keys(root[thu] || {})){
          const slots = root[thu][buoi] || [];
          const count = ct(slots);
          if(count > 0) out.push({gv, thu, buoi, count, slots});
        }
      }
      return out;
    }
    function st(){
      const built = bld();
      const occ = built.occ || {};
      const byTeacher = {};
      let one = 0, totalSessions = 0, totalPeriods = 0;
      for(const gv of Object.keys(occ)){
        const ss = sess(occ, gv);
        byTeacher[gv] = ss;
        for(const s of ss){
          totalSessions++;
          totalPeriods += Number(s.count || 0);
          if(Number(s.count || 0) === 1) one++;
        }
      }
      return {built, byTeacher, one, totalSessions, totalPeriods};
    }
    function snap(){
      try{ return JSON.parse(JSON.stringify(window.DATA?.tkb || {})); }catch(e){ return null; }
    }
    function restore(x){
      if(!x) return;
      if(!window.DATA) window.DATA = {};
      window.DATA.tkb = JSON.parse(JSON.stringify(x));
      try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
    }
    function same(a,b){ return String(a?.thu) === String(b?.thu) && String(a?.buoi) === String(b?.buoi); }
    function days(){
      if(typeof DAYS !== "undefined" && Array.isArray(DAYS) && DAYS.length) return DAYS;
      return (Array.isArray(window.DAYS) && window.DAYS.length) ? window.DAYS : [];
    }
    function gap(slots){
      const pos = [];
      for(let i=0;i<(slots || []).length;i++) if(slots[i]) pos.push(i);
      let total = 0, max = 0;
      for(let i=1;i<pos.length;i++){
        const g = pos[i] - pos[i-1] - 1;
        if(g > 0){ total += g; max = Math.max(max, g); }
      }
      return total * 10 + max * 20;
    }
    function rank(c){
      const n = Number(c || 0);
      if(n === 1) return 0;
      if(n === 2) return 1;
      if(n === 3) return 2;
      if(n === 4) return 3;
      return 10 + n;
    }
    function targets(list, occ, gv){
      const ds = days();
      return (list || []).slice().sort((a,b) =>
        (rank(a.count) - rank(b.count))
        || (gap(occ?.[gv]?.[b.thu]?.[b.buoi] || []) - gap(occ?.[gv]?.[a.thu]?.[a.buoi] || []))
        || (ds.indexOf(a.thu) - ds.indexOf(b.thu))
        || String(a.buoi).localeCompare(String(b.buoi))
      );
    }
    function ok(before, after, mustDropOne, mustDropSession){
      if(after.totalSessions > before.totalSessions) return false;
      if(after.one > before.one) return false;
      if(mustDropOne && after.one >= before.one) return false;
      if(mustDropSession && after.totalSessions >= before.totalSessions) return false;
      return after.one < before.one || after.totalSessions < before.totalSessions;
    }
    function lessonsIn(built, gv, s){
      return (built?.lessons?.[gv] || [])
        .filter(l => String(l.thu) === String(s.thu) && String(l.buoi) === String(s.buoi))
        .sort((a,b) => Number(a.ti || 0) - Number(b.ti || 0));
    }
    function findNow(built, gv, old){
      return (built?.lessons?.[gv] || []).find(l =>
        String(l.classId) === String(old.classId) &&
        String(l.mon) === String(old.mon) &&
        String(l.thu) === String(old.thu) &&
        String(l.buoi) === String(old.buoi) &&
        Number(l.ti) === Number(old.ti)
      ) || null;
    }
    function move(lesson, thu, buoi, built){
      if(!lesson) return false;
      if(typeof window._tryMoveLessonToTargetSession === "function"){
        return !!window._tryMoveLessonToTargetSession(lesson, thu, buoi, built || bld(), {requireSwapTeacherHasSessionAtSource:true});
      }
      if(typeof window._tryMoveOneLesson === "function"){
        return !!window._tryMoveOneLesson(lesson.teacher, lesson, thu, buoi, built || bld());
      }
      return false;
    }
    function eliminateSingle(gv, single, exactTarget){
      const s0 = snap();
      const before = st();
      const occ0 = before.built.occ || {};
      if(ct(occ0?.[gv]?.[single.thu]?.[single.buoi] || []) !== 1){ restore(s0); return false; }
      const srcLessons = lessonsIn(before.built, gv, single);
      if(!srcLessons.length){ restore(s0); return false; }
      const oldLesson = srcLessons[0];
      let dst = sess(occ0, gv)
        .filter(x => !same(x, single))
        .filter(x => Number(x.count || 0) > 0 && Number(x.count || 0) < flen());
      if(exactTarget) dst = dst.filter(x => String(x.thu) === String(exactTarget.thu) && String(x.buoi) === String(exactTarget.buoi));
      dst = targets(dst, occ0, gv);
      for(const d of dst){
        restore(s0);
        const built = bld();
        const now = findNow(built, gv, oldLesson);
        if(!now) continue;
        if(!move(now, d.thu, d.buoi, built)) continue;
        const after = st();
        const sourceAfter = ct(after.built.occ?.[gv]?.[single.thu]?.[single.buoi] || []);
        const targetAfter = ct(after.built.occ?.[gv]?.[d.thu]?.[d.buoi] || []);
        if(sourceAfter === 0 && targetAfter >= 2 && ok(before, after, true, false)) return true;
      }
      restore(s0);
      return false;
    }
    function pullHeavyIntoSingle(gv, single){
      const s0 = snap();
      const before = st();
      const occ0 = before.built.occ || {};
      if(ct(occ0?.[gv]?.[single.thu]?.[single.buoi] || []) !== 1){ restore(s0); return false; }
      const srcs = sess(occ0, gv).filter(x => !same(x, single) && Number(x.count || 0) >= 3)
        .sort((a,b) => Number(a.count || 0) - Number(b.count || 0));
      for(const src of srcs){
        for(const oldLesson of lessonsIn(before.built, gv, src)){
          restore(s0);
          const built = bld();
          const occ = built.occ || {};
          if(ct(occ?.[gv]?.[single.thu]?.[single.buoi] || []) !== 1) continue;
          if(ct(occ?.[gv]?.[src.thu]?.[src.buoi] || []) < 3) continue;
          const now = findNow(built, gv, oldLesson);
          if(!now) continue;
          if(!move(now, single.thu, single.buoi, built)) continue;
          const after = st();
          const singleAfter = ct(after.built.occ?.[gv]?.[single.thu]?.[single.buoi] || []);
          const srcAfter = ct(after.built.occ?.[gv]?.[src.thu]?.[src.buoi] || []);
          if(singleAfter >= 2 && srcAfter >= 2 && ok(before, after, true, false)) return true;
        }
      }
      restore(s0);
      return false;
    }
    function clearSession(gv, source){
      const s0 = snap();
      const before = st();
      const src0 = ct(before.built.occ?.[gv]?.[source.thu]?.[source.buoi] || []);
      if(src0 <= 0){ restore(s0); return false; }
      for(let step=0; step<Math.max(8, src0 * 8 + 8); step++){
        const built = bld();
        const occ = built.occ || {};
        const srcCount = ct(occ?.[gv]?.[source.thu]?.[source.buoi] || []);
        if(srcCount === 0) break;
        const dst = sess(occ, gv)
          .filter(x => !same(x, source))
          .filter(x => Number(x.count || 0) > 0 && Number(x.count || 0) < flen())
          .sort((a,b) => {
            const capA = flen() - Number(a.count || 0);
            const capB = flen() - Number(b.count || 0);
            return ((capB >= srcCount ? 1 : 0) - (capA >= srcCount ? 1 : 0))
              || (rank(a.count) - rank(b.count))
              || (capA - capB);
          });
        if(!dst.length) break;
        let movedOne = false;
        for(const oldLesson of lessonsIn(built, gv, source)){
          for(const d of dst){
            const bNow = bld();
            const now = findNow(bNow, gv, oldLesson);
            if(now && move(now, d.thu, d.buoi, bNow)){ movedOne = true; break; }
          }
          if(movedOne) break;
        }
        if(!movedOne) break;
      }
      const after = st();
      const srcAfter = ct(after.built.occ?.[gv]?.[source.thu]?.[source.buoi] || []);
      if(srcAfter === 0 && ok(before, after, false, true)) return true;
      restore(s0);
      return false;
    }
    function teacherInfos(){
      const state0 = st();
      const out = [];
      for(const gv of Object.keys(state0.byTeacher || {})){
        const ss = state0.byTeacher[gv] || [];
        const singles = ss.filter(x => Number(x.count || 0) === 1);
        if(!singles.length) continue;
        out.push({
          gv,
          singles,
          doubles:ss.filter(x => Number(x.count || 0) === 2),
          heavy:ss.filter(x => Number(x.count || 0) >= 3).sort((a,b) => Number(a.count || 0) - Number(b.count || 0)),
          sessions:ss,
          total:ss.reduce((sum,x) => sum + Number(x.count || 0), 0)
        });
      }
      out.sort((a,b) => b.singles.length - a.singles.length || b.total - a.total || String(a.gv).localeCompare(String(b.gv), "vi"));
      return out;
    }
    function core(opts){
      const deadline = Date.now() + Math.max(30, Number(opts?.timeBudgetMs || 80));
      const maxSwaps = Math.max(1, Number(opts?.maxSwaps || 80));
      const blocked = new Set();
      let moved = 0;
      while(moved < maxSwaps && Date.now() < deadline){
        if(window.__OPT_PANEL_STATE?.cancel) break;
        const list = teacherInfos();
        if(!list.length) break;
        let progressed = false;
        for(const info of list){
          if(moved >= maxSwaps || Date.now() >= deadline) break;
          const key = [info.gv, info.singles.length, info.doubles.length, info.heavy.length, info.sessions.length].join("|");
          if(blocked.has(key)) continue;
          let did = false;
          if(info.singles.length >= 2){
            outer:
            for(let i=0;i<info.singles.length;i++){
              for(let j=i+1;j<info.singles.length;j++){
                if(eliminateSingle(info.gv, info.singles[i], info.singles[j]) || eliminateSingle(info.gv, info.singles[j], info.singles[i])){
                  did = true; break outer;
                }
              }
            }
          }
          if(!did && info.doubles.length && info.singles.length >= 2){
            for(const d of info.doubles){ if(clearSession(info.gv, d)){ did = true; break; } }
          }
          if(!did){ for(const s of info.singles){ if(eliminateSingle(info.gv, s, null)){ did = true; break; } } }
          if(!did){ for(const s of info.singles){ if(pullHeavyIntoSingle(info.gv, s)){ did = true; break; } } }
          if(!did){ for(const h of info.heavy){ if(clearSession(info.gv, h)){ did = true; break; } } }
          if(did){ moved++; progressed = true; blocked.clear(); }
          else blocked.add(key);
        }
        if(!progressed) break;
      }
      return moved;
    }
    function priorSafe(opts, ms){
      if(!priorBuoi1 || priorBuoi1 === window.optimizeTeacherScheduleQualityBuoi1) return 0;
      const s0 = snap();
      const before = st();
      let moved = 0;
      try{ moved = Number(priorBuoi1(Object.assign({}, opts || {}, {timeBudgetMs:Math.max(20, ms || 40)})) || 0); }
      catch(e){ restore(s0); return 0; }
      const after = st();
      if(after.one > before.one || after.totalSessions > before.totalSessions){ restore(s0); return 0; }
      return moved;
    }

    window.optimizeTeacherScheduleQualityBuoi1 = function(opts={}){
      const s0 = snap();
      const before = st();
      const budget = Math.max(45, Number(opts?.timeBudgetMs || 90));
      const t0 = Date.now();
      let moved = core(Object.assign({}, opts, {timeBudgetMs: Math.floor(budget * 0.7)}));
      if(st().one > 0 && Date.now() - t0 < budget){
        moved += priorSafe(opts, budget - (Date.now() - t0));
        moved += core(Object.assign({}, opts, {timeBudgetMs: budget - (Date.now() - t0)}));
      }
      const after = st();
      if(after.one > before.one || after.totalSessions > before.totalSessions){ restore(s0); return 0; }
      if(after.one < before.one || after.totalSessions < before.totalSessions){
        try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
      }
      return moved;
    };

    if(priorCalc){
      window._calcOptimizeCompliance = function(opt={}){
        const base = priorCalc(opt) || {};
        const raw = Number(opt?.limitTietBuoi || 0);
        const minBuoi = (typeof window._uiMinTietBuoi === "function") ? Number(window._uiMinTietBuoi(opt)) : raw;
        if(raw > 0 && minBuoi > 0 && minBuoi <= 2){
          const now = st();
          const denom = Math.max(1, Number(now.totalPeriods || 0));
          const percentBuoi = now.one <= 0 ? 100 : Math.max(0, Math.min(100, 100 * (1 - now.one / denom)));
          const hasGap = Number(opt?.limitTietTrong || 0) > 0;
          const percentTrong = Number.isFinite(Number(base.percentTrong)) ? Number(base.percentTrong) : 100;
          const reachedTrong = hasGap ? !!base.reachedTrong : true;
          base.percentBuoi = percentBuoi;
          base.reachedBuoi = now.one <= 0;
          base.badTietBuoi = now.one;
          base.badBuoiSessions = now.one;
          base.singleSessionCount = now.one;
          base.totalSessionsStrict = now.totalSessions;
          base.totalTiet = now.totalPeriods;
          base.skippedTeachers = 0;
          base.skippedTiet = 0;
          base.percent = hasGap ? Math.min(percentBuoi, percentTrong) : percentBuoi;
          base.reached = now.one <= 0 && reachedTrong;
        }
        return base;
      };
    }

    try{ console.log("[phanmon-ops.patch] post-load zero-single mode1 active"); }catch(e){}
  }catch(e){
    try{ console.error("[phanmon-ops.patch] post-load zero-single mode1 failed", e); }catch(_e){}
  }
})();

/* ===== POST-LOAD PATCH 2026-05-05B: MODE-1 INTRA-CLASS SWAP SEARCH ===== */
(function(){
  try{
    if(window.__PM_MODE1_CLASS_SWAP_POSTLOAD_PATCH) return;
    window.__PM_MODE1_CLASS_SWAP_POSTLOAD_PATCH = "mode1-class-swap-2026-05-05b";

    const strictMode1 = (typeof window.optimizeTeacherScheduleQualityBuoi1 === "function")
      ? window.optimizeTeacherScheduleQualityBuoi1
      : null;

    function build(){
      if(typeof window._buildTeacherOccAllV2 === "function") return window._buildTeacherOccAllV2();
      if(typeof window._buildTeacherOccAll === "function") return window._buildTeacherOccAll();
      return { occ:{}, lessons:{} };
    }
    function countTrue(arr){
      if(typeof window._countTrue === "function") return window._countTrue(arr || []);
      let n = 0; for(const v of (arr || [])) if(v) n++; return n;
    }
    function snapshot(){
      try{ return JSON.parse(JSON.stringify(window.DATA?.tkb || {})); }catch(e){ return null; }
    }
    function restore(snap){
      if(!snap) return;
      if(!window.DATA) window.DATA = {};
      window.DATA.tkb = JSON.parse(JSON.stringify(snap));
      try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
    }
    function sessionMetrics(slots){
      const arr = Array.isArray(slots) ? slots : [];
      const pos = [];
      for(let i=0;i<arr.length;i++) if(arr[i]) pos.push(i);
      let totalGaps = 0, maxGap = 0;
      for(let i=1;i<pos.length;i++){
        const g = pos[i] - pos[i-1] - 1;
        if(g > 0){ totalGaps += g; maxGap = Math.max(maxGap, g); }
      }
      return {
        count: pos.length,
        has: pos.length > 0 ? 1 : 0,
        single: pos.length === 1 ? 1 : 0,
        bad: totalGaps * 10 + maxGap * 20
      };
    }
    function stateScore(built){
      built = built || build();
      const occ = built.occ || {};
      let one = 0, totalSessions = 0, totalPeriods = 0, gapBad = 0;
      for(const gv of Object.keys(occ)){
        for(const thu of Object.keys(occ[gv] || {})){
          for(const buoi of Object.keys(occ[gv][thu] || {})){
            const m = sessionMetrics(occ[gv][thu][buoi] || []);
            totalSessions += m.has;
            one += m.single;
            totalPeriods += m.count;
            gapBad += m.bad;
          }
        }
      }
      return { one, totalSessions, totalPeriods, gapBad };
    }
    function scoreBetter(after, before){
      if(after.totalSessions > before.totalSessions) return false;
      if(after.one > before.one) return false;
      return after.one < before.one || after.totalSessions < before.totalSessions || after.gapBad < before.gapBad;
    }
    function sessionKey(gv, thu, buoi){ return String(gv) + "|" + String(thu) + "|" + String(buoi); }
    function cloneSlots(occ, gv, thu, buoi, fallbackLen){
      const slots = occ?.[gv]?.[thu]?.[buoi];
      if(Array.isArray(slots)) return slots.slice();
      return Array(Math.max(1, Number(fallbackLen || 5))).fill(false);
    }
    function getSessionCount(occ, gv, thu, buoi){
      return countTrue(occ?.[gv]?.[thu]?.[buoi] || []);
    }
    function teacherBusyAt(occ, gv, thu, buoi, ti){
      if(!gv) return false;
      return !!occ?.[gv]?.[thu]?.[buoi]?.[ti];
    }
    function rawCellMon(v){
      try{ if(typeof window.cellMon === "function") return window.cellMon(v); }catch(e){}
      return String(v || "").trim();
    }
    function isBlockedCell(v){
      if(!v || v === "OFF") return true;
      try{ if(typeof window.isFixed === "function" && window.isFixed(v)) return true; }catch(e){}
      return !rawCellMon(v);
    }
    function roomFor(canon, mon){
      try{ if(typeof window.getRoomForClassMon === "function") return window.getRoomForClassMon(canon, mon); }catch(e){}
      return "";
    }
    function teacherFor(canon, mon){
      try{ if(typeof window.getTeacherForClassMon === "function") return window.getTeacherForClassMon(canon, mon); }catch(e){}
      return "";
    }
    function roomFree(room, thu, buoi, ti, classId){
      if(!room) return true;
      try{
        if(typeof window.findRoomConflictAtSlot === "function"){
          return !window.findRoomConflictAtSlot(room, thu, buoi, ti, classId);
        }
      }catch(e){}
      return true;
    }
    function canSwapWithinClass(a, b, built){
      if(!a || !b || String(a.classId) !== String(b.classId)) return false;
      if(a.thu === b.thu && a.buoi === b.buoi && Number(a.ti) === Number(b.ti)) return false;
      if(!a.gv || !b.gv || a.gv === b.gv) return false;

      const occ = built.occ || {};
      if(teacherBusyAt(occ, a.gv, b.thu, b.buoi, b.ti)) return false;
      if(teacherBusyAt(occ, b.gv, a.thu, a.buoi, a.ti)) return false;
      if(!roomFree(a.room, b.thu, b.buoi, b.ti, a.classId)) return false;
      if(!roomFree(b.room, a.thu, a.buoi, a.ti, a.classId)) return false;

      try{
        if(typeof window._canSwapWithinClass === "function"){
          if(!window._canSwapWithinClass(a.classId, a.canon, a.thu, a.buoi, a.ti, b.thu, b.buoi, b.ti, a.mon, b.mon)) return false;
        }
      }catch(e){ return false; }
      return true;
    }
    function deltaForSwap(a, b, built){
      const occ = built.occ || {};
      const lenA = Math.max(1, (window.DATA?.tkb?.[a.classId]?.[a.thu]?.[a.buoi] || []).length || 5);
      const lenB = Math.max(1, (window.DATA?.tkb?.[b.classId]?.[b.thu]?.[b.buoi] || []).length || 5);
      const keys = new Map();
      function ensure(gv, thu, buoi, len){
        const key = sessionKey(gv, thu, buoi);
        if(!keys.has(key)){
          const before = cloneSlots(occ, gv, thu, buoi, len);
          keys.set(key, { before, after: before.slice() });
        }
        return keys.get(key);
      }

      ensure(a.gv, a.thu, a.buoi, lenA).after[a.ti] = false;
      ensure(a.gv, b.thu, b.buoi, lenB).after[b.ti] = true;
      ensure(b.gv, b.thu, b.buoi, lenB).after[b.ti] = false;
      ensure(b.gv, a.thu, a.buoi, lenA).after[a.ti] = true;

      const before = { one:0, totalSessions:0, gapBad:0 };
      const after = { one:0, totalSessions:0, gapBad:0 };
      for(const x of keys.values()){
        const mb = sessionMetrics(x.before);
        const ma = sessionMetrics(x.after);
        before.one += mb.single; before.totalSessions += mb.has; before.gapBad += mb.bad;
        after.one += ma.single; after.totalSessions += ma.has; after.gapBad += ma.bad;
      }
      return {
        one: after.one - before.one,
        totalSessions: after.totalSessions - before.totalSessions,
        gapBad: after.gapBad - before.gapBad
      };
    }
    function deltaScore(d){
      return d.one * 100000 + d.totalSessions * 5000 + d.gapBad;
    }
    function collectCellsByClass(){
      const out = {};
      const tkbs = window.DATA?.tkb || {};
      const days = (typeof DAYS !== "undefined" && Array.isArray(DAYS) && DAYS.length)
        ? DAYS
        : ((Array.isArray(window.DAYS) && window.DAYS.length) ? window.DAYS : ["thu2","thu3","thu4","thu5","thu6","thu7"]);
      for(const classId of Object.keys(tkbs)){
        const tkb = tkbs[classId];
        if(!tkb) continue;
        const canon = (typeof window.getLopCanonById === "function") ? window.getLopCanonById(classId) : classId;
        const cells = [];
        for(const thu of days){
          for(const buoi of ["sang","chieu"]){
            const arr = tkb?.[thu]?.[buoi];
            if(!Array.isArray(arr)) continue;
            for(let ti=0; ti<arr.length; ti++){
              const v = arr[ti];
              if(isBlockedCell(v)) continue;
              const mon = rawCellMon(v);
              const gv = teacherFor(canon, mon);
              if(!gv) continue;
              cells.push({
                classId:String(classId),
                canon,
                thu,
                buoi,
                ti,
                v,
                mon,
                gv:String(gv).trim(),
                room:String(roomFor(canon, mon) || "").trim()
              });
            }
          }
        }
        if(cells.length > 1) out[classId] = cells;
      }
      return out;
    }
    function applySwap(a, b){
      const tkb = window.DATA?.tkb?.[a.classId];
      if(!tkb) return false;
      if(tkb?.[a.thu]?.[a.buoi]?.[a.ti] !== a.v) return false;
      if(tkb?.[b.thu]?.[b.buoi]?.[b.ti] !== b.v) return false;
      tkb[a.thu][a.buoi][a.ti] = b.v;
      tkb[b.thu][b.buoi][b.ti] = a.v;
      try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
      return true;
    }
    function classSwapSearch(opts){
      const t0 = Date.now();
      const budget = Math.max(20, Number(opts?.timeBudgetMs || 80));
      const deadline = t0 + budget;
      const maxSwaps = Math.max(1, Number(opts?.maxSwaps || 80));
      let moved = 0;

      while(moved < maxSwaps && Date.now() < deadline){
        if(window.__OPT_PANEL_STATE?.cancel) break;
        const built = build();
        const occ = built.occ || {};
        let best = null;
        const byClass = collectCellsByClass();

        for(const classId of Object.keys(byClass)){
          const cells = byClass[classId];
          for(let i=0; i<cells.length; i++){
            const a = cells[i];
            const aSrc = getSessionCount(occ, a.gv, a.thu, a.buoi);
            for(let j=i+1; j<cells.length; j++){
              if(Date.now() >= deadline) break;
              const b = cells[j];
              const bSrc = getSessionCount(occ, b.gv, b.thu, b.buoi);
              const aDst = getSessionCount(occ, a.gv, b.thu, b.buoi);
              const bDst = getSessionCount(occ, b.gv, a.thu, a.buoi);

              // Focus mode 1: at least one involved session should be able to close/avoid a single.
              if(aSrc !== 1 && bSrc !== 1 && aDst !== 1 && bDst !== 1) continue;
              if(!canSwapWithinClass(a, b, built)) continue;

              const d = deltaForSwap(a, b, built);
              if(d.one > 0 || d.totalSessions > 0) continue;
              if(!(d.one < 0 || d.totalSessions < 0 || d.gapBad < 0)) continue;
              const s = deltaScore(d);
              if(!best || s < best.score){
                best = { a, b, d, score:s };
                if(d.one <= -2) break;
              }
            }
            if(best && best.d.one <= -2) break;
          }
          if(best && best.d.one <= -2) break;
          if(Date.now() >= deadline) break;
        }

        if(!best) break;
        if(applySwap(best.a, best.b)) moved++;
        else break;
      }
      return moved;
    }

    window.optimizeTeacherScheduleQualityBuoi1 = function(opts={}){
      const snap0 = snapshot();
      const before = stateScore();
      const budget = Math.max(45, Number(opts?.timeBudgetMs || 90));
      const t0 = Date.now();
      let moved = 0;
      moved += classSwapSearch(Object.assign({}, opts, { timeBudgetMs: Math.max(20, Math.floor(budget * 0.55)) }));
      if(strictMode1 && Date.now() - t0 < budget){
        try{
          moved += Number(strictMode1(Object.assign({}, opts, { timeBudgetMs: Math.max(20, budget - (Date.now() - t0)) })) || 0);
        }catch(e){}
      }
      if(Date.now() - t0 < budget){
        moved += classSwapSearch(Object.assign({}, opts, { timeBudgetMs: Math.max(20, budget - (Date.now() - t0)) }));
      }
      const after = stateScore();
      if(after.one > before.one || after.totalSessions > before.totalSessions){
        restore(snap0);
        return 0;
      }
      return moved;
    };

    try{ console.log("[phanmon-ops.patch] mode1 intra-class swap search active"); }catch(e){}
  }catch(e){
    try{ console.error("[phanmon-ops.patch] mode1 intra-class swap search failed", e); }catch(_e){}
  }
})();

/* ===== POST-LOAD PATCH 2026-05-05C: MODE-1 SHAKE SEARCH TO ZERO ===== */
(function(){
  try{
    if(window.__PM_MODE1_SHAKE_ZERO_POSTLOAD_PATCH) return;
    window.__PM_MODE1_SHAKE_ZERO_POSTLOAD_PATCH = "mode1-shake-zero-2026-05-05c";

    const priorMode1 = (typeof window.optimizeTeacherScheduleQualityBuoi1 === "function")
      ? window.optimizeTeacherScheduleQualityBuoi1
      : null;

    function build(){
      if(typeof window._buildTeacherOccAllV2 === "function") return window._buildTeacherOccAllV2();
      if(typeof window._buildTeacherOccAll === "function") return window._buildTeacherOccAll();
      return {occ:{}};
    }
    function countTrue(arr){
      if(typeof window._countTrue === "function") return window._countTrue(arr || []);
      let n = 0; for(const v of (arr || [])) if(v) n++; return n;
    }
    function snapshot(){
      try{ return JSON.parse(JSON.stringify(window.DATA?.tkb || {})); }catch(e){ return null; }
    }
    function restore(s){
      if(!s) return;
      if(!window.DATA) window.DATA = {};
      window.DATA.tkb = JSON.parse(JSON.stringify(s));
      try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
    }
    function metrics(slots){
      const pos = [];
      for(let i=0;i<(slots || []).length;i++) if(slots[i]) pos.push(i);
      let totalGaps = 0, maxGap = 0;
      for(let i=1;i<pos.length;i++){
        const g = pos[i] - pos[i-1] - 1;
        if(g > 0){ totalGaps += g; maxGap = Math.max(maxGap, g); }
      }
      return {
        count: pos.length,
        has: pos.length ? 1 : 0,
        one: pos.length === 1 ? 1 : 0,
        gap: totalGaps * 10 + maxGap * 20
      };
    }
    function stateScore(){
      const occ = build().occ || {};
      let one = 0, totalSessions = 0, gap = 0, periods = 0;
      for(const gv of Object.keys(occ)){
        for(const thu of Object.keys(occ[gv] || {})){
          for(const buoi of Object.keys(occ[gv][thu] || {})){
            const m = metrics(occ[gv][thu][buoi] || []);
            one += m.one;
            totalSessions += m.has;
            gap += m.gap;
            periods += m.count;
          }
        }
      }
      return {one, totalSessions, gap, periods};
    }
    function scalar(s){
      return Number(s.one || 0) * 1000000 + Number(s.totalSessions || 0) * 1000 + Number(s.gap || 0);
    }
    function blocked(v){
      if(!v || v === "OFF") return true;
      try{ if(typeof window.isFixed === "function" && window.isFixed(v)) return true; }catch(e){}
      try{ if(typeof window.cellMon === "function") return !window.cellMon(v); }catch(e){}
      return !String(v || "").trim();
    }
    function monOf(v){
      try{ if(typeof window.cellMon === "function") return window.cellMon(v); }catch(e){}
      return String(v || "").trim();
    }
    function teacherFor(canon, mon){
      try{ if(typeof window.getTeacherForClassMon === "function") return String(window.getTeacherForClassMon(canon, mon) || "").trim(); }catch(e){}
      return "";
    }
    function roomFor(canon, mon){
      try{ if(typeof window.getRoomForClassMon === "function") return String(window.getRoomForClassMon(canon, mon) || "").trim(); }catch(e){}
      return "";
    }
    function roomFree(room, thu, buoi, ti, classId){
      if(!room) return true;
      try{
        if(typeof window.findRoomConflictAtSlot === "function"){
          return !window.findRoomConflictAtSlot(room, thu, buoi, ti, classId);
        }
      }catch(e){}
      return true;
    }
    function collectPairs(){
      const out = [];
      const tkbs = window.DATA?.tkb || {};
      const days = (typeof DAYS !== "undefined" && Array.isArray(DAYS) && DAYS.length)
        ? DAYS
        : ((Array.isArray(window.DAYS) && window.DAYS.length) ? window.DAYS : ["thu2","thu3","thu4","thu5","thu6","thu7"]);
      for(const classId of Object.keys(tkbs)){
        const tkb = tkbs[classId];
        const cells = [];
        for(const thu of days){
          for(const buoi of ["sang","chieu"]){
            const arr = tkb?.[thu]?.[buoi];
            if(!Array.isArray(arr)) continue;
            for(let ti=0; ti<arr.length; ti++){
              if(!blocked(arr[ti])) cells.push({classId:String(classId), thu, buoi, ti});
            }
          }
        }
        for(let i=0;i<cells.length;i++){
          for(let j=i+1;j<cells.length;j++) out.push([cells[i], cells[j]]);
        }
      }
      return out;
    }
    function cellAt(pos){
      const tkb = window.DATA?.tkb?.[pos.classId];
      const v = tkb?.[pos.thu]?.[pos.buoi]?.[pos.ti];
      if(blocked(v)) return null;
      const canon = (typeof window.getLopCanonById === "function") ? window.getLopCanonById(pos.classId) : pos.classId;
      const mon = monOf(v);
      const gv = teacherFor(canon, mon);
      if(!gv) return null;
      return Object.assign({}, pos, {v, canon, mon, gv, room:roomFor(canon, mon)});
    }
    function canSwap(a, b, built){
      if(!a || !b || a.classId !== b.classId || a.gv === b.gv) return false;
      const occ = built.occ || {};
      if(occ?.[a.gv]?.[b.thu]?.[b.buoi]?.[b.ti]) return false;
      if(occ?.[b.gv]?.[a.thu]?.[a.buoi]?.[a.ti]) return false;
      if(!roomFree(a.room, b.thu, b.buoi, b.ti, a.classId)) return false;
      if(!roomFree(b.room, a.thu, a.buoi, a.ti, a.classId)) return false;
      try{
        if(typeof window._canSwapWithinClass === "function"){
          return !!window._canSwapWithinClass(a.classId, a.canon, a.thu, a.buoi, a.ti, b.thu, b.buoi, b.ti, a.mon, b.mon);
        }
      }catch(e){ return false; }
      return true;
    }
    function swapCells(a, b){
      const tkb = window.DATA?.tkb?.[a.classId];
      if(!tkb) return false;
      if(tkb?.[a.thu]?.[a.buoi]?.[a.ti] !== a.v) return false;
      if(tkb?.[b.thu]?.[b.buoi]?.[b.ti] !== b.v) return false;
      tkb[a.thu][a.buoi][a.ti] = b.v;
      tkb[b.thu][b.buoi][b.ti] = a.v;
      return true;
    }
    function randomInt(n){ return Math.floor(Math.random() * Math.max(1, n)); }
    function shakeToZero(opts, maxFinalSessions){
      const base = stateScore();
      if(base.one <= 0) return 0;
      const deadline = Date.now() + Math.max(90, Number(opts?.timeBudgetMs || 160));
      const pairs = collectPairs();
      if(!pairs.length) return 0;

      let current = base;
      let best = base;
      let bestSnap = snapshot();
      let accepted = 0;
      let steps = 0;
      const maxTempOne = Math.max(base.one + 4, 6);
      const maxTempSessions = Math.max(Number(maxFinalSessions || base.totalSessions) + 5, base.totalSessions + 3);

      while(Date.now() < deadline && best.one > 0){
        if(window.__OPT_PANEL_STATE?.cancel) break;
        const pair = pairs[randomInt(pairs.length)];
        const built = build();
        const a = cellAt(pair[0]);
        const b = cellAt(pair[1]);
        if(!canSwap(a, b, built)) continue;
        if(!swapCells(a, b)) continue;

        const next = stateScore();
        const elapsedRatio = Math.min(1, Math.max(0, 1 - ((deadline - Date.now()) / Math.max(1, Number(opts?.timeBudgetMs || 160)))));
        const temp = Math.max(0.03, 1 - elapsedRatio);
        const diff = scalar(next) - scalar(current);
        const insideBand = next.one <= maxTempOne && next.totalSessions <= maxTempSessions;
        const accept = insideBand && (diff <= 0 || Math.random() < Math.exp(-diff / (260000 * temp)));

        if(accept){
          current = next;
          accepted++;
          if(scalar(next) < scalar(best) && next.totalSessions <= Number(maxFinalSessions || base.totalSessions)){
            best = next;
            bestSnap = snapshot();
            if(best.one <= 0) break;
          }
        }else{
          swapCells(cellAt(pair[0]) || a, cellAt(pair[1]) || b);
        }
        steps++;
      }

      restore(bestSnap);
      try{ window.__PM_LAST_MODE1_SHAKE = {base, best, accepted, steps, ts:Date.now()}; }catch(e){}
      return scalar(best) < scalar(base) ? Math.max(1, accepted) : 0;
    }

    window.optimizeTeacherScheduleQualityBuoi1 = function(opts={}){
      const whole = snapshot();
      const before = stateScore();
      const budget = Math.max(120, Number(opts?.timeBudgetMs || 160));
      const t0 = Date.now();
      let moved = 0;

      if(priorMode1){
        try{
          moved += Number(priorMode1(Object.assign({}, opts, {timeBudgetMs: Math.max(60, Math.floor(budget * 0.45))})) || 0);
        }catch(e){}
      }

      let now = stateScore();
      if(now.one > 0 && Date.now() - t0 < budget){
        moved += shakeToZero(Object.assign({}, opts, {timeBudgetMs: Math.max(80, budget - (Date.now() - t0))}), before.totalSessions);
      }

      const after = stateScore();
      if(after.one > before.one || after.totalSessions > before.totalSessions){
        restore(whole);
        return 0;
      }
      if(after.one < before.one || after.totalSessions < before.totalSessions){
        try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
      }
      return moved;
    };

    try{ console.log("[phanmon-ops.patch] mode1 shake-to-zero active"); }catch(e){}
  }catch(e){
    try{ console.error("[phanmon-ops.patch] mode1 shake-to-zero failed", e); }catch(_e){}
  }
})();

/* ===== POST-LOAD PATCH 2026-05-05D: FET-LIKE 3-CYCLE EJECTION ===== */
(function(){
  try{
    if(window.__PM_MODE1_FET_CYCLE_POSTLOAD_PATCH) return;
    window.__PM_MODE1_FET_CYCLE_POSTLOAD_PATCH = "mode1-fet-cycle-2026-05-05d";

    const priorMode1 = (typeof window.optimizeTeacherScheduleQualityBuoi1 === "function")
      ? window.optimizeTeacherScheduleQualityBuoi1
      : null;

    function dayList(){
      if(typeof DAYS !== "undefined" && Array.isArray(DAYS) && DAYS.length) return DAYS;
      if(Array.isArray(window.DAYS) && window.DAYS.length) return window.DAYS;
      return ["thu2","thu3","thu4","thu5","thu6","thu7"];
    }
    function countTrue(arr){
      if(typeof window._countTrue === "function") return window._countTrue(arr || []);
      let n = 0; for(const v of (arr || [])) if(v) n++; return n;
    }
    function build(){
      if(typeof window._buildTeacherOccAllV2 === "function") return window._buildTeacherOccAllV2();
      if(typeof window._buildTeacherOccAll === "function") return window._buildTeacherOccAll();
      return {occ:{}};
    }
    function snapshot(){
      try{ return JSON.parse(JSON.stringify(window.DATA?.tkb || {})); }catch(e){ return null; }
    }
    function restore(s){
      if(!s) return;
      if(!window.DATA) window.DATA = {};
      window.DATA.tkb = JSON.parse(JSON.stringify(s));
      try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
    }
    function cellMonSafe(v){
      try{ if(typeof window.cellMon === "function") return window.cellMon(v); }catch(e){}
      return String(v || "").trim();
    }
    function isFixedSafe(v){
      try{ return !!(typeof window.isFixed === "function" && window.isFixed(v)); }catch(e){ return false; }
    }
    function blocked(v){ return !v || v === "OFF" || isFixedSafe(v) || !cellMonSafe(v); }
    function teacherFor(canon, mon){
      try{ if(typeof window.getTeacherForClassMon === "function") return String(window.getTeacherForClassMon(canon, mon) || "").trim(); }catch(e){}
      return "";
    }
    function roomFor(canon, mon){
      try{ if(typeof window.getRoomForClassMon === "function") return String(window.getRoomForClassMon(canon, mon) || "").trim(); }catch(e){}
      return "";
    }
    function metrics(slots){
      const pos = [];
      for(let i=0;i<(slots || []).length;i++) if(slots[i]) pos.push(i);
      let gap = 0, max = 0;
      for(let i=1;i<pos.length;i++){
        const g = pos[i] - pos[i-1] - 1;
        if(g > 0){ gap += g; max = Math.max(max, g); }
      }
      return {count:pos.length, has:pos.length ? 1 : 0, one:pos.length === 1 ? 1 : 0, gap:gap * 10 + max * 20};
    }
    function stateScore(){
      const occ = build().occ || {};
      let one = 0, totalSessions = 0, gap = 0, periods = 0;
      for(const gv of Object.keys(occ)){
        for(const thu of Object.keys(occ[gv] || {})){
          for(const buoi of Object.keys(occ[gv][thu] || {})){
            const m = metrics(occ[gv][thu][buoi] || []);
            one += m.one;
            totalSessions += m.has;
            gap += m.gap;
            periods += m.count;
          }
        }
      }
      return {one, totalSessions, gap, periods};
    }
    function scalar(s){ return Number(s.one || 0) * 1000000 + Number(s.totalSessions || 0) * 1000 + Number(s.gap || 0); }
    function sessionCount(occ, gv, thu, buoi){ return countTrue(occ?.[gv]?.[thu]?.[buoi] || []); }
    function collectByClass(){
      const out = {};
      const tkbs = window.DATA?.tkb || {};
      for(const classId of Object.keys(tkbs)){
        const canon = (typeof window.getLopCanonById === "function") ? window.getLopCanonById(classId) : classId;
        const cells = [];
        const tkb = tkbs[classId];
        for(const thu of dayList()){
          for(const buoi of ["sang","chieu"]){
            const arr = tkb?.[thu]?.[buoi];
            if(!Array.isArray(arr)) continue;
            for(let ti=0; ti<arr.length; ti++){
              const v = arr[ti];
              if(blocked(v)) continue;
              const mon = cellMonSafe(v);
              const gv = teacherFor(canon, mon);
              if(!gv) continue;
              cells.push({classId:String(classId), canon, thu, buoi, ti, v, mon, gv, room:roomFor(canon, mon)});
            }
          }
        }
        if(cells.length >= 3) out[classId] = cells;
      }
      return out;
    }
    function applyCycle(cycle){
      if(!cycle || cycle.length < 3) return false;
      const tkb = window.DATA?.tkb?.[cycle[0].classId];
      if(!tkb) return false;
      for(const p of cycle){
        if(tkb?.[p.thu]?.[p.buoi]?.[p.ti] !== p.v) return false;
      }
      const vals = cycle.map(p => p.v);
      tkb[cycle[0].thu][cycle[0].buoi][cycle[0].ti] = vals[vals.length - 1];
      for(let i=1; i<cycle.length; i++){
        tkb[cycle[i].thu][cycle[i].buoi][cycle[i].ti] = vals[i - 1];
      }
      return true;
    }
    function validateAffected(cycle){
      try{
        const tkbs = window.DATA?.tkb || {};
        const teacherSlots = new Map();
        const roomSlots = new Map();

        for(const classId of Object.keys(tkbs)){
          const canon = (typeof window.getLopCanonById === "function") ? window.getLopCanonById(classId) : classId;
          const tkb = tkbs[classId];
          for(const thu of dayList()){
            for(const buoi of ["sang","chieu"]){
              const arr = tkb?.[thu]?.[buoi];
              if(!Array.isArray(arr)) continue;
              for(let ti=0; ti<arr.length; ti++){
                const v = arr[ti];
                if(blocked(v)) continue;
                const mon = cellMonSafe(v);
                const gv = teacherFor(canon, mon);
                if(gv){
                  const k = gv + "|" + thu + "|" + buoi + "|" + ti;
                  teacherSlots.set(k, (teacherSlots.get(k) || 0) + 1);
                  if(teacherSlots.get(k) > 1) return false;
                }
                const room = roomFor(canon, mon);
                if(room){
                  const rk = room + "|" + thu + "|" + buoi + "|" + ti;
                  roomSlots.set(rk, (roomSlots.get(rk) || 0) + 1);
                  if(roomSlots.get(rk) > 1) return false;
                }
              }
            }
          }
        }

        if(typeof window._validateSubjectInSession === "function"){
          const seen = new Set();
          for(const p of cycle){
            const key = p.classId + "|" + p.thu + "|" + p.buoi;
            if(seen.has(key)) continue;
            seen.add(key);
            const arr = tkbs?.[p.classId]?.[p.thu]?.[p.buoi] || [];
            const subs = new Set();
            for(const v of arr){
              const mon = cellMonSafe(v);
              if(mon) subs.add(mon);
            }
            for(const mon of subs){
              let lim = 99;
              try{
                if(typeof window._getGioihanForLopIdMon === "function") lim = window._getGioihanForLopIdMon(p.classId, p.canon, mon);
                else if(typeof _getGioihanForLopIdMon === "function") lim = _getGioihanForLopIdMon(p.classId, p.canon, mon);
              }catch(e){}
              if(!window._validateSubjectInSession(arr, mon, lim)) return false;
            }
          }
        }
        return true;
      }catch(e){
        return false;
      }
    }
    function cycleSearch(opts, maxFinalSessions){
      const start = stateScore();
      if(start.one <= 0) return 0;
      const baseSnap = snapshot();
      const deadline = Date.now() + Math.max(45, Number(opts?.timeBudgetMs || 90));
      let moved = 0;

      while(Date.now() < deadline){
        if(window.__OPT_PANEL_STATE?.cancel) break;
        const before = stateScore();
        let best = null;
        const built = build();
        const occ = built.occ || {};
        const byClass = collectByClass();

        for(const classId of Object.keys(byClass)){
          const cells = byClass[classId];
          const singles = cells.filter(p => sessionCount(occ, p.gv, p.thu, p.buoi) === 1);
          for(const p0 of singles){
            const p1s = cells.filter(p => p !== p0 && sessionCount(occ, p0.gv, p.thu, p.buoi) > 0);
            for(const p1 of p1s.slice(0, 24)){
              const p2s = cells.filter(p => p !== p0 && p !== p1 && (sessionCount(occ, p1.gv, p.thu, p.buoi) > 0 || sessionCount(occ, p.gv, p0.thu, p0.buoi) > 0));
              for(const p2 of p2s.slice(0, 36)){
                if(Date.now() >= deadline) break;
                const snapTry = snapshot();
                const cycle = [p0, p1, p2];
                if(!applyCycle(cycle)){ restore(snapTry); continue; }
                if(!validateAffected(cycle)){ restore(snapTry); continue; }
                const after = stateScore();
                restore(snapTry);
                if(after.one > before.one || after.totalSessions > before.totalSessions) continue;
                if(after.totalSessions > Number(maxFinalSessions || before.totalSessions)) continue;
                if(!(after.one < before.one || after.totalSessions < before.totalSessions || after.gap < before.gap)) continue;
                const score = scalar(after);
                if(!best || score < best.score){
                  best = {cycle, score, after};
                  if(after.one <= Math.max(0, before.one - 2)) break;
                }
              }
              if(best && best.after.one <= Math.max(0, before.one - 2)) break;
            }
            if(best && best.after.one <= Math.max(0, before.one - 2)) break;
          }
          if(best && best.after.one <= Math.max(0, before.one - 2)) break;
        }

        if(!best) break;
        if(!applyCycle(best.cycle) || !validateAffected(best.cycle)){
          restore(baseSnap);
          return 0;
        }
        moved++;
        if(stateScore().one <= 0) break;
      }
      const final = stateScore();
      if(final.one > start.one || final.totalSessions > start.totalSessions || final.totalSessions > Number(maxFinalSessions || start.totalSessions)){
        restore(baseSnap);
        return 0;
      }
      try{ window.__PM_LAST_MODE1_FET_CYCLE = {start, final, moved, ts:Date.now()}; }catch(e){}
      return moved;
    }

    window.optimizeTeacherScheduleQualityBuoi1 = function(opts={}){
      const whole = snapshot();
      const before = stateScore();
      const budget = Math.max(160, Number(opts?.timeBudgetMs || 180));
      const t0 = Date.now();
      let moved = 0;

      if(priorMode1){
        try{ moved += Number(priorMode1(Object.assign({}, opts, {timeBudgetMs: Math.max(90, Math.floor(budget * 0.65))})) || 0); }catch(e){}
      }
      if(stateScore().one > 0 && Date.now() - t0 < budget){
        moved += cycleSearch(Object.assign({}, opts, {timeBudgetMs: Math.max(45, budget - (Date.now() - t0))}), before.totalSessions);
      }

      const after = stateScore();
      if(after.one > before.one || after.totalSessions > before.totalSessions){
        restore(whole);
        return 0;
      }
      if(after.one < before.one || after.totalSessions < before.totalSessions){
        try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
      }
      return moved;
    };

    try{ console.log("[phanmon-ops.patch] mode1 FET-like 3-cycle active"); }catch(e){}
  }catch(e){
    try{ console.error("[phanmon-ops.patch] mode1 FET-like 3-cycle failed", e); }catch(_e){}
  }
})();

/* ===== POST-LOAD PATCH 2026-05-05E: MODE-1 DIRECT RELOCATION SWEEP ===== */
(function(){
  try{
    if(window.__PM_MODE1_DIRECT_RELOCATION_PATCH) return;
    window.__PM_MODE1_DIRECT_RELOCATION_PATCH = "mode1-direct-relocation-2026-05-05e";

    const priorMode1 = (typeof window.optimizeTeacherScheduleQualityBuoi1 === "function")
      ? window.optimizeTeacherScheduleQualityBuoi1
      : null;

    function days(){
      if(typeof DAYS !== "undefined" && Array.isArray(DAYS) && DAYS.length) return DAYS;
      if(Array.isArray(window.DAYS) && window.DAYS.length) return window.DAYS;
      return ["thu2","thu3","thu4","thu5","thu6","thu7"];
    }
    function countTrue(arr){
      if(typeof window._countTrue === "function") return window._countTrue(arr || []);
      let n = 0; for(const v of (arr || [])) if(v) n++; return n;
    }
    function snapshot(){
      try{ return JSON.parse(JSON.stringify(window.DATA?.tkb || {})); }catch(e){ return null; }
    }
    function restore(s){
      if(!s) return;
      if(!window.DATA) window.DATA = {};
      window.DATA.tkb = JSON.parse(JSON.stringify(s));
      try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
    }
    function cellMonSafe(v){
      try{ if(typeof window.cellMon === "function") return window.cellMon(v); }catch(e){}
      return String(v || "").trim();
    }
    function isFixedSafe(v){
      try{ return !!(typeof window.isFixed === "function" && window.isFixed(v)); }catch(e){ return false; }
    }
    function isMovableLesson(v){ return !!v && v !== "OFF" && !isFixedSafe(v) && !!cellMonSafe(v); }
    function isFreeCell(v){ return v == null || v === "" || (!isFixedSafe(v) && !cellMonSafe(v) && v !== "OFF"); }
    function teacherFor(canon, mon){
      try{ if(typeof window.getTeacherForClassMon === "function") return String(window.getTeacherForClassMon(canon, mon) || "").trim(); }catch(e){}
      return "";
    }
    function roomFor(canon, mon){
      try{ if(typeof window.getRoomForClassMon === "function") return String(window.getRoomForClassMon(canon, mon) || "").trim(); }catch(e){}
      return "";
    }
    function limitFor(classId, canon, mon){
      try{
        if(typeof window._getGioihanForLopIdMon === "function") return window._getGioihanForLopIdMon(classId, canon, mon);
        if(typeof _getGioihanForLopIdMon === "function") return _getGioihanForLopIdMon(classId, canon, mon);
      }catch(e){}
      return 99;
    }
    function validSession(arr, mon, lim){
      try{
        if(typeof window._validateSubjectInSession === "function") return !!window._validateSubjectInSession(arr, mon, lim);
        if(typeof _validateSubjectInSession === "function") return !!_validateSubjectInSession(arr, mon, lim);
      }catch(e){ return false; }
      return true;
    }
    function fullLenFor(buoi){
      const sangLen = (typeof SANG !== "undefined") ? Number(SANG || 0) : Number(window.SANG || 0);
      const chieuLen = (typeof CHIEU !== "undefined") ? Number(CHIEU || 0) : Number(window.CHIEU || 0);
      if(buoi === "sang" && sangLen > 0) return sangLen;
      if(buoi === "chieu" && chieuLen > 0) return chieuLen;
      return Math.max(2, sangLen, chieuLen, 5);
    }
    function buildState(){
      const occ = {};
      const classOcc = {};
      const roomOcc = new Map();
      const lessonsByTeacher = {};
      const tkbs = window.DATA?.tkb || {};

      function ensureTeacher(gv){
        if(!occ[gv]) occ[gv] = {};
        for(const d of days()){
          if(!occ[gv][d]) occ[gv][d] = {
            sang:Array(fullLenFor("sang")).fill(false),
            chieu:Array(fullLenFor("chieu")).fill(false)
          };
        }
      }
      function ensureClass(classId){
        if(!classOcc[classId]) classOcc[classId] = {};
        for(const d of days()){
          if(!classOcc[classId][d]) classOcc[classId][d] = {
            sang:Array(fullLenFor("sang")).fill(false),
            chieu:Array(fullLenFor("chieu")).fill(false)
          };
        }
      }

      for(const classIdRaw of Object.keys(tkbs)){
        const classId = String(classIdRaw);
        const tkb = tkbs[classId];
        const canon = (typeof window.getLopCanonById === "function") ? window.getLopCanonById(classId) : classId;
        ensureClass(classId);
        for(const thu of days()){
          for(const buoi of ["sang","chieu"]){
            const arr = tkb?.[thu]?.[buoi];
            if(!Array.isArray(arr)) continue;
            for(let ti=0; ti<arr.length; ti++){
              const v = arr[ti];
              if(!v || v === "OFF") continue;
              const mon = cellMonSafe(v);
              if(!mon) continue;
              classOcc[classId][thu][buoi][ti] = true;
              const gv = teacherFor(canon, mon);
              if(gv){
                ensureTeacher(gv);
                occ[gv][thu][buoi][ti] = true;
                if(!isFixedSafe(v)){
                  const lesson = {classId, canon, thu, buoi, ti, v, mon, gv, room:roomFor(canon, mon)};
                  if(!lessonsByTeacher[gv]) lessonsByTeacher[gv] = [];
                  lessonsByTeacher[gv].push(lesson);
                }
              }
              const room = roomFor(canon, mon);
              if(room){
                const key = room + "|" + thu + "|" + buoi + "|" + ti;
                roomOcc.set(key, (roomOcc.get(key) || 0) + 1);
              }
            }
          }
        }
      }
      return {occ, classOcc, roomOcc, lessonsByTeacher};
    }
    function score(){
      const st = buildState();
      let one = 0, totalSessions = 0, periods = 0;
      for(const gv of Object.keys(st.occ)){
        for(const thu of Object.keys(st.occ[gv] || {})){
          for(const buoi of Object.keys(st.occ[gv][thu] || {})){
            const c = countTrue(st.occ[gv][thu][buoi] || []);
            if(c > 0){
              totalSessions++;
              periods += c;
              if(c === 1) one++;
            }
          }
        }
      }
      return {one, totalSessions, periods};
    }
    function roomAvailable(st, room, thu, buoi, ti){
      if(!room) return true;
      return !st.roomOcc.has(room + "|" + thu + "|" + buoi + "|" + ti);
    }
    function targetScore(st, lesson, thu, buoi, ti){
      const c = countTrue(st.occ?.[lesson.gv]?.[thu]?.[buoi] || []);
      const sameDay = String(thu) === String(lesson.thu) ? 0 : 1;
      return (c === 1 ? -10000 : 0) + c * -100 + sameDay * 5 + Math.abs(Number(ti) - Number(lesson.ti));
    }
    function canMove(st, lesson, thuTo, buoiTo, tiTo){
      const tkb = window.DATA?.tkb?.[lesson.classId];
      if(!tkb) return false;
      if(String(thuTo) === String(lesson.thu) && String(buoiTo) === String(lesson.buoi)) return false;
      const srcArr = tkb?.[lesson.thu]?.[lesson.buoi];
      const dstArr = tkb?.[thuTo]?.[buoiTo];
      if(!Array.isArray(srcArr) || !Array.isArray(dstArr)) return false;
      if(srcArr[lesson.ti] !== lesson.v) return false;
      if(!isMovableLesson(srcArr[lesson.ti])) return false;
      if(!isFreeCell(dstArr[tiTo])) return false;
      if(st.occ?.[lesson.gv]?.[thuTo]?.[buoiTo]?.[tiTo]) return false;
      if(st.classOcc?.[lesson.classId]?.[thuTo]?.[buoiTo]?.[tiTo]) return false;
      if(!roomAvailable(st, lesson.room, thuTo, buoiTo, tiTo)) return false;

      const srcNext = srcArr.slice();
      const dstNext = dstArr.slice();
      srcNext[lesson.ti] = "";
      dstNext[tiTo] = lesson.v;
      const lim = limitFor(lesson.classId, lesson.canon, lesson.mon);
      if(!validSession(srcNext, lesson.mon, lim)) return false;
      if(!validSession(dstNext, lesson.mon, lim)) return false;
      return true;
    }
    function applyMove(lesson, thuTo, buoiTo, tiTo){
      const tkb = window.DATA?.tkb?.[lesson.classId];
      if(!tkb || tkb?.[lesson.thu]?.[lesson.buoi]?.[lesson.ti] !== lesson.v) return false;
      tkb[lesson.thu][lesson.buoi][lesson.ti] = "";
      tkb[thuTo][buoiTo][tiTo] = lesson.v;
      return true;
    }
    function findBestDirectMove(st){
      let best = null;
      for(const gv of Object.keys(st.occ)){
        const sessions = [];
        for(const thu of Object.keys(st.occ[gv] || {})){
          for(const buoi of Object.keys(st.occ[gv][thu] || {})){
            const c = countTrue(st.occ[gv][thu][buoi] || []);
            if(c > 0) sessions.push({thu, buoi, count:c});
          }
        }
        const singles = sessions.filter(s => s.count === 1);
        if(!singles.length) continue;
        const targets = sessions.filter(s => s.count > 0 && s.count < fullLenFor(s.buoi));
        const teacherLessons = st.lessonsByTeacher[gv] || [];
        for(const single of singles){
          const lesson = teacherLessons.find(l => String(l.thu) === String(single.thu) && String(l.buoi) === String(single.buoi));
          if(!lesson) continue;
          for(const target of targets){
            if(String(target.thu) === String(single.thu) && String(target.buoi) === String(single.buoi)) continue;
            const len = fullLenFor(target.buoi);
            for(let ti=0; ti<len; ti++){
              if(!canMove(st, lesson, target.thu, target.buoi, ti)) continue;
              const score = targetScore(st, lesson, target.thu, target.buoi, ti);
              if(!best || score < best.score) best = {lesson, thu:target.thu, buoi:target.buoi, ti, score};
            }
          }
        }
      }
      return best;
    }
    function directSweep(opts){
      const deadline = Date.now() + Math.max(30, Number(opts?.timeBudgetMs || 80));
      const maxMoves = Math.max(1, Number(opts?.maxSwaps || 120));
      let moved = 0;
      while(moved < maxMoves && Date.now() < deadline){
        if(window.__OPT_PANEL_STATE?.cancel) break;
        const st = buildState();
        const mv = findBestDirectMove(st);
        if(!mv) break;
        if(!applyMove(mv.lesson, mv.thu, mv.buoi, mv.ti)) break;
        moved++;
        try{ window.__TKB_REV = (window.__TKB_REV || 0) + 1; }catch(e){}
      }
      return moved;
    }

    window.optimizeTeacherScheduleQualityBuoi1 = function(opts={}){
      const snap0 = snapshot();
      const before = score();
      const budget = Math.max(180, Number(opts?.timeBudgetMs || 220));
      const t0 = Date.now();
      let moved = 0;

      moved += directSweep(Object.assign({}, opts, {timeBudgetMs: Math.max(60, Math.floor(budget * 0.45))}));
      if(priorMode1 && Date.now() - t0 < budget){
        try{ moved += Number(priorMode1(Object.assign({}, opts, {timeBudgetMs: Math.max(60, Math.floor(budget * 0.35))})) || 0); }catch(e){}
      }
      if(Date.now() - t0 < budget){
        moved += directSweep(Object.assign({}, opts, {timeBudgetMs: Math.max(40, budget - (Date.now() - t0))}));
      }

      const after = score();
      if(after.one > before.one || after.totalSessions > before.totalSessions){
        restore(snap0);
        return 0;
      }
      try{ window.__PM_LAST_MODE1_DIRECT_RELOCATION = {before, after, moved, ts:Date.now()}; }catch(e){}
      return moved;
    };

    try{ console.log("[phanmon-ops.patch] mode1 direct relocation sweep active"); }catch(e){}
  }catch(e){
    try{ console.error("[phanmon-ops.patch] mode1 direct relocation sweep failed", e); }catch(_e){}
  }
})();
